# Reproduction

Released binding checks (Python 3.12 was used):

```bash
python3 -m venv .venv
.venv/bin/pip install QuantLib==1.43
.venv/bin/python minimal_repro.py
.venv/bin/python reproduce.py --mode wheel --output wheel-rerun.json
.venv/bin/python reproduce_bachelier.py --mode wheel --output bachelier-wheel-rerun.json
.venv/bin/python downstream_capfloor.py
```

For the tested macOS/Clang C++ build, `bootstrap_native.py` verifies/extracts the included source, downloads checksum-pinned Boost if absent, and applies the patch into separate candidate files. No sudo or system installation is required. The build helper uses Darwin `-dead_strip`; Linux users must adapt this linker flag to `--gc-sections` and use section compiler flags if necessary. This portability adaptation was not tested.

```bash
.venv/bin/python bootstrap_native.py
.venv/bin/python build_native.py baseline
.venv/bin/python build_native.py corrected
.venv/bin/python build_native.py mutation
.venv/bin/python reproduce.py --mode corrected --exe native-corrected --output black-corrected-rerun.json
.venv/bin/python reproduce_bachelier.py --mode corrected --exe native-corrected --output bachelier-corrected-rerun.json
.venv/bin/python build_native.py corrected --upstream-tests
./test-blackformula-corrected --report_level=detailed
.venv/bin/python build_native.py corrected --engine
.venv/bin/python validate_native_engines.py corrected
```

Repeat the helper and engine commands with `baseline` and `mutation` to reproduce the failures. The focused upstream group fails on the two added regressions with either original source variant. Full-library tests were not run. Expected output is preserved under `evidence/` and `logs/`.
