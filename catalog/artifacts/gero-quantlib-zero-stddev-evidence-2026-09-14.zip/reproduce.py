"""Independent probability oracle; invoke released native bindings or compiled upstream C++."""
import argparse, hashlib, json, math, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

BASE = [
 ('stock_otm',80.,100.,0.), ('stock_itm',120.,100.,0.),
 ('stock_atm',100.,100.,0.), ('zero_strike',100.,0.,0.),
 ('rate_otm',.04,.05,0.), ('rate_itm',.06,.05,0.), ('rate_atm',.05,.05,0.),
 ('small_units',1e-8,2e-8,0.), ('large_units',2e8,1e8,0.),
 ('shifted_otm',-.02,-.01,.05), ('shifted_itm',-.01,-.02,.05),
 ('shifted_atm',-.01,-.01,.05), ('shifted_zero_fwd',0.,.01,.03),
 ('shifted_zero_strike',-.04,-.05,.05),
]
def cases():
 return [dict(label=name,kind=kind,forward=f*scale,strike=k*scale,
              shift=d*scale,stddev=sd,scale=scale)
         for name,f,k,d in BASE for scale in (1e-12,1.,1e12)
         for kind in (1,-1) for sd in (0.,1e-6,.01,.2,1.)]

def oracle(c):
 f,k,d,s,kind=(c[x] for x in ('forward','strike','shift','stddev','kind'))
 if s == 0.:
  return float(kind*(f-k)>0.)
 if k+d == 0.:
  return float(kind==1)
 z=(math.log((f+d)/(k+d))/s + .5*s)*kind
 return .5*math.erfc(-z/math.sqrt(2.))

def run(mode,output,exe=None):
 cs=cases()
 if mode=='wheel':
  import QuantLib as q
  version=q.__version__
  observations=[[q.blackFormulaAssetItmProbability(c['kind'],c['strike'],c['forward'],c['stddev'],c['shift']),
                 None,
                 q.blackFormulaCashItmProbability(c['kind'],c['strike'],c['forward'],c['stddev'],c['shift']),
                 q.blackFormula(c['kind'],c['strike'],c['forward'],c['stddev'],1.,c['shift'])] for c in cs]
  native=Path(q.__file__).parent/'_QuantLib.abi3.so'
  if not native.exists(): native=next(Path(q.__file__).parent.glob('_QuantLib*.so'))
 else:
  version='current-source ca953b7ebdb400f2839d86f18eeb0d4a2a4a30a4'
  data=''.join(f"1 {c['kind']} {c['strike']:.17g} {c['forward']:.17g} {c['stddev']:.17g} {c['shift']:.17g}\n" for c in cs)
  completed=subprocess.run([str(Path(exe).resolve())],input=data,text=True,capture_output=True,check=True)
  observations=[list(map(float,line.split())) for line in completed.stdout.splitlines()]
  assert len(observations)==len(cs)
  native=Path(exe)
 rows=[]
 for c,(actual,overload,cash,price) in zip(cs,observations):
  ref=oracle(c)
  decomposition=c['kind']*((c['forward']+c['shift'])*actual-(c['strike']+c['shift'])*cash)
  scale=max(abs(c['forward']+c['shift']),abs(c['strike']+c['shift']),1e-300)
  rows.append(dict(**c,actual=actual,payoff_overload=overload,expected=ref,
    passed=math.isclose(actual,ref,rel_tol=2e-13,abs_tol=2e-13),
    overload_agrees=overload is None or actual==overload,
    in_probability_range=0.<=actual<=1., cash_probability=cash, black_price=price,
    reconstructed_price=decomposition,
    decomposition_passed=abs(decomposition-price)<=2e-13*scale))
 groups={}
 for r in rows:
  key='zero/off_strike' if r['stddev']==0 and r['forward']!=r['strike'] else ('zero/at_strike_control' if r['stddev']==0 else 'positive_control')
  g=groups.setdefault(key,dict(total=0,probability_failures=0,decomposition_failures=0))
  g['total']+=1;g['probability_failures']+=not r['passed'];g['decomposition_failures']+=not r['decomposition_passed']
 result=dict(utc=datetime.now(timezone.utc).isoformat(),mode=mode,version=version,python=sys.version,
  platform=platform.platform(),native_file=str(native.resolve()),native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),
  total=len(rows),failures=sum(not r['passed'] for r in rows),groups=groups,
  overload_failures=sum(not r['overload_agrees'] for r in rows),
  range_failures=sum(not r['in_probability_range'] for r in rows),rows=rows)
 Path(output).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['wheel','baseline','corrected','mutation'],required=True)
 p.add_argument('--exe');p.add_argument('--output',required=True);args=p.parse_args()
 r=run(args.mode,args.output,args.exe)
 if args.mode=='corrected': assert r['failures']==0 and r['overload_failures']==0 and r['range_failures']==0
 else: assert r['failures']>0
