# Duplicate review, 14 September 2026

No exact earlier report was found in the bounded searches recorded in `evidence/duplicate-review/`. This is not a claim of exhaustive global novelty.

The canonical GERO GitHub catalog at 00159b6bd55d07fca47af82c707490818213a03c contains 91 publication units and no QuantLib ITM-probability report. FinancePy BondFRN face scaling was rejected this run because it is already covered by our PR256.

GitHub issue/PR searches (both open and closed) included exact Black and Bachelier function names, asset/probability, delta/zero, stdDev/probability, cap/delta/zero, and blackformula/zero. All stored GitHub search pages reported `incomplete_results=false` and fewer than 100 results.

- PR674 introduced the helpers and optionlet delta results in 2019. Its description, discussion and review were checked: vector length/testing and API work, not a report or fix of these deterministic branches. The introduction commit 1512e270658a303cddc495a06c5418b43a4b1e79 already contains the reversed Black comparison.
- Issue2176 requests a Bachelier calculator; it does not identify this probability/payoff substitution.
- Issue525 concerns generic Black-Scholes expiry-zero Greeks; our cases have future fixing dates and zero volatility. It does not name or reproduce either helper defect.
- Issues/PR2749,2755,2757 concern low-volatility American option boundary solvers, a different code path.
- Other returned cases concern binomial trees, credit curves, Bessel functions, cashflow sensitivities and callable bonds, not these helpers.

Web searches for the exact function plus zero, asset probability reversed, and optionletsDelta zero volatility returned source mirrors or unrelated pages. Source mirrors expose the code but are not separate bug reports. Exact searches of prior GERO report contents did not match.

Current source was pinned through the official GitHub API. Released QuantLib 1.43 was obtained from PyPI; its wheel digest matches PyPI metadata. No maintainer acceptance is implied by this research.
