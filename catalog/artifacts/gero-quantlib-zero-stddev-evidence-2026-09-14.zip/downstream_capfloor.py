"""Measure released BlackCapFloorEngine normalized optionlet deltas versus price bumps."""
import json, math
from datetime import datetime,timezone
from pathlib import Path
import QuantLib as q
q.Settings.instance().evaluationDate=q.Date(14,9,2026)
quote=q.SimpleQuote(.05)
forward_curve=q.YieldTermStructureHandle(q.FlatForward(0,q.TARGET(),q.QuoteHandle(quote),q.Actual365Fixed()))
disc=q.YieldTermStructureHandle(q.FlatForward(0,q.TARGET(),.03,q.Actual365Fixed()))
index=q.Euribor6M(forward_curve)
schedule=q.Schedule(q.Date(15,1,2027),q.Date(15,1,2028),q.Period('6M'),q.TARGET(),q.ModifiedFollowing,q.ModifiedFollowing,q.DateGeneration.Forward,False)
leg=q.IborLeg([1e6],schedule,index)
weights=[q.as_floating_rate_coupon(c).nominal()*q.as_floating_rate_coupon(c).accrualPeriod()*disc.discount(c.date()) for c in leg]
rows=[]
for engine_name,engine_type,vol in [("Black",q.BlackCapFloorEngine,0.),("Black",q.BlackCapFloorEngine,.2),("Bachelier",q.BachelierCapFloorEngine,0.),("Bachelier",q.BachelierCapFloorEngine,.01)]:
 for name,constructor,kind in [('Cap',q.Cap,1),('Floor',q.Floor,-1)]:
  for strike in [.04,.06]:
   ins=constructor(leg,[strike]);ins.setPricingEngine(engine_type(disc,q.QuoteHandle(q.SimpleQuote(vol))))
   quote.setValue(.05)
   npv=ins.NPV();reported=list(ins.optionletsDelta());fwd=list(ins.optionletsAtmForward());prices=list(ins.optionletsPrice());stddev=list(ins.optionletsStdDev())
   quote.setValue(.05+1e-6);up=ins.NPV();up_prices=list(ins.optionletsPrice());up_fwd=list(ins.optionletsAtmForward())
   quote.setValue(.05-1e-6);dn=ins.NPV();dn_prices=list(ins.optionletsPrice());dn_fwd=list(ins.optionletsAtmForward())
   quote.setValue(.05)
   for i,(a,p) in enumerate(zip(reported,prices)):
    fd=(up_prices[i]-dn_prices[i])/(up_fwd[i]-dn_fwd[i])/weights[i]
    f=fwd[i];sd=stddev[i]
    z=(math.log(f/strike)/sd+.5*sd) if engine_name=="Black" and vol>0 else ((f-strike)/sd if vol>0 else 0.)
    expected=float(kind*(f-strike)>0)*kind if vol==0 else kind*.5*math.erfc(-kind*z/math.sqrt(2))
    analytic_price=weights[i]*max(kind*(f-strike),0.) if vol==0 else None
    rows.append(dict(engine=engine_name,instrument=name,strike=strike,volatility=vol,optionlet=i,forward=f,stddev=sd,
      reported_normalized_delta=a,expected_normalized_delta=expected,price_bump_normalized_delta=fd,
      passed=math.isclose(a,expected,rel_tol=2e-8,abs_tol=2e-8),fd_agrees=math.isclose(expected,fd,rel_tol=2e-8,abs_tol=2e-8),
      optionlet_price=p,deterministic_price_oracle=analytic_price,price_passed=analytic_price is None or math.isclose(p,analytic_price,rel_tol=1e-12,abs_tol=1e-8),instrument_npv=npv,discounted_accrual=weights[i]))
out=dict(utc=datetime.now(timezone.utc).isoformat(),quantlib=q.__version__,scope='Released wheel only; corrected full cap/floor engine has not been executed.',
 total=len(rows),delta_failures=sum(not r['passed'] for r in rows),oracle_vs_bump_failures=sum(not r['fd_agrees'] for r in rows),price_failures=sum(not r['price_passed'] for r in rows),rows=rows)
Path('evidence/downstream-capfloor-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
assert out['delta_failures']==12 and out['oracle_vs_bump_failures']==0 and out['price_failures']==0
