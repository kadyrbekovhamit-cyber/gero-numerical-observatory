# Licenses and authorship

Report and original GERO graphics: Copyright (c) 2026 Xamit Kadirbekov, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

Original GERO reproducer and audit scripts: MIT License. Copyright (c) 2026 Xamit Kadirbekov.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Upstream QuantLib sources, including modified source/test files, retain the QuantLib license and original copyright notices. The source archive contains the complete upstream license. The tested Boost 1.88.0 dependency retains the Boost Software License 1.0; download URL and hash are recorded, not a relicensing of Boost.

The report does not assert affiliation with QuantLib or any bank. Numerical experiments and original source records are distinguished from AI-assisted writing, packaging and synthetic narration.
