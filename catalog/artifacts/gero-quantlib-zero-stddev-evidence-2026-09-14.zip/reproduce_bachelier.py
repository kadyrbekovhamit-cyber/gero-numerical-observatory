"""Dimensionless probability and derivative checks against an independent normal CDF."""
import argparse,hashlib,json,math,platform,subprocess
from datetime import datetime,timezone
from pathlib import Path
BASE=[('otm',80.,100.),('itm',120.,100.),('atm',100.,100.),('rate_otm',.04,.05),('rate_itm',.06,.05),('rate_atm',.05,.05),('negative_otm',-.02,-.01),('negative_itm',-.01,-.02),('zero_forward',0.,.01),('zero_strike',100.,0.)]
def run(mode,output,exe):
 cs=[dict(label=label,forward=f*scale,strike=k*scale,stddev=s*scale,scale=scale,kind=kind) for label,f,k in BASE for scale in (1e-12,1.,1e12) for kind in (1,-1) for s in (0.,1e-6,.02,20.)]
 if mode=='wheel':
  import QuantLib as q
  obs=[[q.bachelierBlackFormulaAssetItmProbability(c['kind'],c['strike'],c['forward'],c['stddev']),None,None,q.bachelierBlackFormula(c['kind'],c['strike'],c['forward'],c['stddev'])] for c in cs]
 else:
  data=''.join(f"2 {c['kind']} {c['strike']:.17g} {c['forward']:.17g} {c['stddev']:.17g} 0\n" for c in cs)
  out=subprocess.run([str(Path(exe).resolve())],input=data,text=True,capture_output=True,check=True)
  obs=[list(map(float,row.split())) for row in out.stdout.splitlines()];assert len(obs)==len(cs)
 rows=[]
 for c,(actual,overload,slope,price) in zip(cs,obs):
  d=(c['forward']-c['strike'])*c['kind'];s=c['stddev']
  expected=float(d>0.) if s==0 else .5*math.erfc(-d/s/math.sqrt(2.))
  rows.append(dict(**c,actual=actual,payoff_overload=overload,forward_derivative=slope,price=price,expected=expected,passed=math.isclose(actual,expected,abs_tol=2e-13,rel_tol=2e-13),range_passed=0<=actual<=1,overload_passed=overload is None or actual==overload,derivative_passed=slope is None or math.isclose(c['kind']*actual,slope,abs_tol=2e-13,rel_tol=2e-13)))
 groups={}
 for row in rows:
  key='zero/in_money' if row['stddev']==0 and row['kind']*(row['forward']-row['strike'])>0 else ('zero/control' if row['stddev']==0 else 'positive/control')
  g=groups.setdefault(key,dict(total=0,failures=0,range_failures=0));g['total']+=1;g['failures']+=not row['passed'];g['range_failures']+=not row['range_passed']
 out=dict(utc=datetime.now(timezone.utc).isoformat(),mode=mode,total=len(rows),failures=sum(not x['passed'] for x in rows),groups=groups,overload_failures=sum(not x['overload_passed'] for x in rows),derivative_failures=sum(not x['derivative_passed'] for x in rows),rows=rows)
 Path(output).write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
 assert out['failures']==(0 if mode=='corrected' else 24)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--mode',required=True);p.add_argument('--exe');p.add_argument('--output',required=True);a=p.parse_args();run(a.mode,a.output,a.exe)
