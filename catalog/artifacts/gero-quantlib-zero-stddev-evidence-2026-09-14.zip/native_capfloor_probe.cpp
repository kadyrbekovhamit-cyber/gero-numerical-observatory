#include <ql/pricingengines/capfloor/blackcapfloorengine.hpp>
#include <ql/pricingengines/capfloor/bacheliercapfloorengine.hpp>
#include <ql/termstructures/yield/flatforward.hpp>
#include <ql/time/daycounters/actual365fixed.hpp>
#include <ql/settings.hpp>
#include <iostream>
#include <iomanip>
#include <any>
int main() {
 using namespace QuantLib;
 Date today(14,September,2026),start(15,January,2027),fix(13,January,2027),end(15,July,2027);
 Settings::instance().evaluationDate()=today;
 Handle<YieldTermStructure> curve(ext::make_shared<FlatForward>(today,.03,Actual365Fixed()));
 const Real weight=1e6*.5*curve->discount(end);
 std::cout<<std::setprecision(17);
 int family,kind;Real f,k,v;
 while(std::cin>>family>>kind>>f>>k>>v) {
  ext::shared_ptr<PricingEngine> engine;
  if(family==1)engine=ext::make_shared<BlackCapFloorEngine>(curve,v);
  else engine=ext::make_shared<BachelierCapFloorEngine>(curve,v);
  auto* a=dynamic_cast<CapFloor::arguments*>(engine->getArguments());
  a->type=kind==1?CapFloor::Cap:CapFloor::Floor;
  a->startDates={start};a->fixingDates={fix};a->endDates={end};a->accrualTimes={.5};
  a->capRates={k};a->floorRates={k};a->forwards={f};a->gearings={1.};a->spreads={0.};a->nominals={1e6};
  a->validate();engine->calculate();
  const auto* r=dynamic_cast<const Instrument::results*>(engine->getResults());
  Real price=r->value;
  Real delta=std::any_cast<std::vector<Real>>(r->additionalResults.at("optionletsDelta"))[0];
  Real sd=std::any_cast<std::vector<Real>>(r->additionalResults.at("optionletsStdDev"))[0];
  a->forwards={f+1e-6};engine->calculate();Real up=r->value;
  a->forwards={f-1e-6};engine->calculate();Real dn=r->value;
  std::cout<<delta<<" "<<price/weight<<" "<<sd<<" "<<(up-dn)/(2e-6*weight)<<" "<<price<<"\n";
 }
}
