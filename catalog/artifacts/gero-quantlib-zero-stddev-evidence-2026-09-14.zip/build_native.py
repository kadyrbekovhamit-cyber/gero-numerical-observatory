"""Build full original translation units, plus the focused upstream Boost.Test group."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('mode',choices=['baseline','corrected','mutation']);p.add_argument('--upstream-tests',action='store_true');p.add_argument('--engine',action='store_true');a=p.parse_args()
r=Path.cwd();q=r/'quantlib-current';boost=r/'boost_1_88_0'
flags=['clang++','-std=c++17','-O2','-DNDEBUG','-DQL_USE_STD_SHARED_PTR','-I'+str(q),'-I'+str(q/'test-suite'),'-I'+str(boost)]
common=['ql/math/distributions/normaldistribution.cpp','ql/math/errorfunction.cpp','ql/errors.cpp','ql/instruments/payoffs.cpp']
test_extra=['test-suite/quantlibtestsuite.cpp','test-suite/utilities.cpp','ql/settings.cpp','ql/indexes/indexmanager.cpp','ql/currencies/exchangeratemanager.cpp','ql/time/date.cpp','ql/time/period.cpp','ql/patterns/observable.cpp','ql/currencies/europe.cpp','ql/currencies/america.cpp','ql/exchangerate.cpp','ql/currency.cpp','ql/math/rounding.cpp','ql/utilities/dataformatters.cpp','ql/termstructure.cpp','ql/termstructures/yieldtermstructure.cpp','ql/time/daycounters/actual365fixed.cpp','ql/interestrate.cpp','ql/time/calendar.cpp','ql/termstructures/yield/flatforward.cpp']
source=q/'ql/pricingengines/blackformula.cpp' if a.mode=='baseline' else r/a.mode/'blackformula.cpp'
files=[source]+[q/x for x in common]
if a.upstream_tests: files +=[r/'corrected/blackformula-test.cpp']+[q/x for x in test_extra]
elif a.engine:
 files += [q/x for x in test_extra if not x.startswith('test-suite/')]
 files += [r/'native_capfloor_probe.cpp']+[q/x for x in ['ql/pricingengines/capfloor/blackcapfloorengine.cpp','ql/pricingengines/capfloor/bacheliercapfloorengine.cpp','ql/termstructures/volatility/optionlet/constantoptionletvol.cpp','ql/termstructures/volatility/optionlet/optionletvolatilitystructure.cpp','ql/termstructures/voltermstructure.cpp','ql/instruments/capfloor.cpp','ql/termstructures/volatility/flatsmilesection.cpp','ql/termstructures/volatility/smilesection.cpp']]
else: files+=[r/'native_probe.cpp']
objdir=r/'objects';objdir.mkdir(exist_ok=True);objs=[];commands=[]
for f in files:
 assert f.is_file(),f
 digest=hashlib.sha256(f.read_bytes()+json.dumps(flags).encode()).hexdigest()[:16]
 obj=objdir/(f.stem+'-'+digest+'.o');objs.append(str(obj));cmd=flags+['-c',str(f),'-o',str(obj)];commands.append(cmd)
 if not obj.exists():
  print('Compile',f.relative_to(r),flush=True);subprocess.run(cmd,check=True)
binary=r/(('test-blackformula-' if a.upstream_tests else ('engine-' if a.engine else 'native-'))+a.mode)
link=['clang++',*objs,'-Wl,-dead_strip','-o',str(binary)];commands.append(link)
(r/'logs'/('commands-'+binary.name+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
subprocess.run(link,check=True);print('Built',binary.name)
