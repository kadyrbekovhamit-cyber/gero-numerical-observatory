#include <ql/pricingengines/blackformula.hpp>
#include <iostream>
#include <iomanip>
int main() {
 using namespace QuantLib;
 std::cout << std::setprecision(17);
 int family,kind; double k,f,s,shift;
 while (std::cin >> family >> kind >> k >> f >> s >> shift) {
  auto type = kind == 1 ? Option::Call : Option::Put;
  auto payoff = ext::make_shared<PlainVanillaPayoff>(type, k);
  try {
   if (family == 2) {
    std::cout << bachelierBlackFormulaAssetItmProbability(type,k,f,s) << " "
      << bachelierBlackFormulaAssetItmProbability(payoff,f,s) << " "
      << bachelierBlackFormulaForwardDerivative(type,k,f,s,1.0) << " "
      << bachelierBlackFormula(type,k,f,s,1.0) << "\n";
    continue;
   }
   std::cout << blackFormulaAssetItmProbability(type,k,f,s,shift) << " "
     << blackFormulaAssetItmProbability(payoff,f,s,shift) << " "
     << blackFormulaCashItmProbability(type,k,f,s,shift) << " "
     << blackFormula(type,k,f,s,1.0,shift) << "\n";
  } catch (const std::exception& e) { std::cerr << e.what() << "\n"; return 2; }
 }
}
