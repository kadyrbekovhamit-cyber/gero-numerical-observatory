import argparse,json,math,subprocess
from datetime import datetime,timezone
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('mode');a=p.parse_args()
cs=[dict(engine=engine,kind=kind,forward=f,strike=.05,volatility=v) for engine in [1,2] for kind in [1,-1] for f in [.04,.06] for v in ([0.,.2] if engine==1 else [0.,.01])]
data=''.join(f"{c['engine']} {c['kind']} {c['forward']:.17g} {c['strike']:.17g} {c['volatility']:.17g}\n" for c in cs)
p=subprocess.run([str(Path('engine-'+a.mode).resolve())],input=data,text=True,capture_output=True,check=True)
obs=[list(map(float,line.split())) for line in p.stdout.splitlines()];assert len(obs)==len(cs)
rows=[]
for c,(delta,unit_price,s,fd,price) in zip(cs,obs):
 f,k,kind=c['forward'],c['strike'],c['kind']
 z=(math.log(f/k)/s+.5*s) if c['engine']==1 and s>0 else ((f-k)/s if s>0 else 0.)
 expected=kind*float(kind*(f-k)>0) if s==0 else kind*.5*math.erfc(-kind*z/math.sqrt(2))
 rows.append(dict(**c,reported_delta=delta,expected_delta=expected,finite_difference_delta=fd,price=price,unit_price=unit_price,stddev=s,passed=math.isclose(delta,expected,rel_tol=2e-13,abs_tol=2e-13),fd_passed=math.isclose(fd,expected,rel_tol=2e-7,abs_tol=2e-7)))
out=dict(utc=datetime.now(timezone.utc).isoformat(),mode=a.mode,scope='Actual C++ BlackCapFloorEngine/BachelierCapFloorEngine with validated synthetic arguments; separate wheel test uses full Cap/Floor instruments.',total=len(rows),failures=sum(not r['passed'] for r in rows),fd_failures=sum(not r['fd_passed'] for r in rows),rows=rows)
Path('evidence/engine-'+a.mode+'-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
assert out['failures']==(0 if a.mode=='corrected' else 6) and out['fd_failures']==0
