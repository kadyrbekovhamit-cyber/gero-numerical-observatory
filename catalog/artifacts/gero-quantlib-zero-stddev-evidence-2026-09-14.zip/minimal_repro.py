import QuantLib as ql
print('QuantLib', ql.__version__)
# F=120 > K=100: deterministic call is in the money, probability must be 1.
for stddev in (0.0, 0.000001):
    print(stddev, ql.blackFormulaAssetItmProbability(ql.Option.Call, 100., 120., stddev))
# QuantLib 1.43: 0.0 -> 0.0; 0.000001 -> 0.9999999999999999.
# Bachelier's probability must also be 1, never the payoff amount 20.
print('Bachelier', ql.bachelierBlackFormulaAssetItmProbability(ql.Option.Call, 100., 120., 0.))
