"""Reconstruct the pinned native experiment without modifying upstream or system files."""
import hashlib,json,shutil,subprocess,tarfile,tempfile,urllib.request
from pathlib import Path
r=Path(__file__).resolve().parent
meta=json.loads((r/'PROVENANCE.json').read_text())
def check(p):
 assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['hashes'][str(p.relative_to(r))],p
source=r/'evidence/quantlib-current.tar.gz';check(source)
if not (r/'quantlib-current').exists():
 with tempfile.TemporaryDirectory(dir=r) as tmp:
  with tarfile.open(source) as t:t.extractall(tmp,filter='data')
  dirs=list(Path(tmp).iterdir());assert len(dirs)==1
  shutil.move(str(dirs[0]),str(r/'quantlib-current'))
boost=r/'evidence/boost_1_88_0.tar.bz2'
if not boost.exists(): urllib.request.urlretrieve(meta['boost_url'],boost)
check(boost)
if not (r/'boost_1_88_0/boost').exists():
 with tarfile.open(boost) as t:
  members=[m for m in t.getmembers() if m.name.startswith('boost_1_88_0/boost/') or m.name=='boost_1_88_0/LICENSE_1_0.txt']
  t.extractall(r,members=members,filter='data')
# Apply the recorded patch in an isolated replay and compare its output.
with tempfile.TemporaryDirectory(dir=r) as tmp:
 replay=Path(tmp)
 for name in ['ql/pricingengines/blackformula.cpp','test-suite/blackformula.cpp']:
  out=replay/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/'quantlib-current'/name,out)
 subprocess.run(['patch','-p1','-i',str(r/'candidate.patch')],cwd=replay,check=True)
 for src,target in [('ql/pricingengines/blackformula.cpp','blackformula.cpp'),('test-suite/blackformula.cpp','blackformula-test.cpp')]:
  assert (replay/src).read_bytes()==(r/'corrected'/target).read_bytes()
assert (r/'mutation/blackformula.cpp').read_bytes()==(r/'quantlib-current/ql/pricingengines/blackformula.cpp').read_bytes()
print('Verified pinned source, Boost, patch replay and mutation.')
