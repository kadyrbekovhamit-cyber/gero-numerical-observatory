# Reproduce the CIR audit

Use Python 3.12. The recorded environment is Python 3.12.14 on macOS arm64, NumPy 2.3.5 and Numba 0.62.1. The dependency list pins the environment used here. Installing dependencies requires network access unless already cached; this archive is not an offline Python/dependency distribution.

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r environment-requirements.txt
.venv/bin/python minimal.py baseline
.venv/bin/python minimal.py release
.venv/bin/python reproduce.py --work-dir ../cir-fresh-run
```

The minimal example prints the actual FinancePy result and an independently calculated 120-digit reference rounded to float64. Expected on the recorded environment: original/released price `2.2407257971155513e96`, reference `0.6882687528140472`.

The full runner requires a **new** work directory. It copies the bundled unchanged source and released package, recomputes the high-precision reference and separate Riccati checks, creates the candidate and a source-restoration mutation, and runs all four variants in separate processes. It also runs the two bundled original upstream CIR test files. Numba and numerical-library thread counts are one. Caches go into the new work directory; no existing evidence is overwritten. The recorded dependency environment was reused for the clean rerun; it was not freshly reinstalled.

Expected summary: **1,168 → 0 → 1,168** failures out of **4,536** original/candidate/restored prices, with **1,168** released-version failures; **40** upstream tests pass in both original and candidate. The initial run's four raw result JSON files should match the fresh rerun byte-for-byte on the recorded environment. Other platforms may differ in the exact erroneous original value or last bits; the mathematical bounds and declared oracle tolerance remain the criteria.

`baseline/` contains all 230 original FinancePy package files. `release/` contains the official wheel's 219 package files. `vendor/` contains that wheel, with its published hash recorded in `evidence/release-verification.json`. These bundled packages are imported directly; no installed FinancePy is used. `SOURCE_MANIFEST.json` records pre-run hashes. `prepare_variants.py` reconstructs the one-file correction and restored source from the baseline; `candidate.patch` is also provided for review.

No full-suite, installation, GPU, production or financial-loss guarantee is implied by the reproduced numerical tests.
