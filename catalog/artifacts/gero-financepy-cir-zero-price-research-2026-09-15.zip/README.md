# GERO FinancePy CIR zero-price research

A unit payment with a model price near 0.68827 is evaluated as 2.24e96 by the pinned FinancePy implementation under a small-volatility stress input.

This local research contains the executed source, released wheel, independent high-precision reference, candidate correction and source-restoration replay. A 4,536-vector grid gives 1,168 → 0 → 1,168 failures. No production impact or upstream acceptance is claimed; no external publication has been made for this case.

- `RESULTS_EN.md`: full technical report and scope.
- `РЕЗУЛЬТАТЫ.md`: Russian explanation.
- `REPRODUCE.md`: minimal and fresh-copy reproduction.
- `VALIDATION_PROTOCOL.md`, `inputs.json`: predeclared grid and criteria.
- `evidence/`: raw results, environment, source/duplicate review and receipts.
- `candidate.patch`: numerical reformulation in the pricing function.
- `SOURCE_MANIFEST.json`, `LICENSES.md`: source integrity and licensing.

Independent GERO research by Xamit Kadirbekov, 15 September 2026. AI-assisted investigation and preparation.
