from pathlib import Path
import shutil,difflib

root=Path(__file__).resolve().parent
shutil.copytree(root/'baseline',root/'candidate')
target='financepy/models/cir_montecarlo.py'
original=(root/'baseline'/target).read_text()
start=original.index('    if sigma == 0.0:',original.index('def zero_price('))
end=original.index('\n\n\n@njit',start)
replacement='''    # Factor the affine coefficients before evaluation. This removes the
    # enormous 1/sigma**2 exponent and exp(h*t), and extends continuously
    # to sigma=0 without an arbitrary volatility cutoff.
    h = np.hypot(a, np.sqrt(2.0) * sigma)
    u = -np.expm1(-h * t)
    x = (sigma / h) * (sigma / (h + a)) * u

    if x == 0.0:
        log_ratio = 1.0
    else:
        log_ratio = -np.log1p(-x) / x

    bb = (u / h) / (1.0 - x)
    log_aa = (2.0 * a * b / (h + a)) * ((u / h) * log_ratio - t)
    return np.exp(log_aa - r0 * bb)'''
candidate=original[:start]+replacement+original[end:]
(root/'candidate'/target).write_text(candidate)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),candidate.splitlines(True),fromfile='a/'+target,tofile='b/'+target)))
shutil.copytree(root/'candidate',root/'mutation')
(root/'mutation'/target).write_bytes((root/'baseline'/target).read_bytes())
assert (root/'mutation'/target).read_bytes()==(root/'baseline'/target).read_bytes()
print('Separate candidate and original-source mutation prepared.')
