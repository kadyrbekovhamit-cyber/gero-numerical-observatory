"""Repeat from copied source and a fresh cache, one numerical process at a time."""
from pathlib import Path
import argparse,subprocess,sys,os,shutil,json

parser=argparse.ArgumentParser()
parser.add_argument('--work-dir',type=Path,required=True)
args=parser.parse_args()
source=Path(__file__).resolve().parent
work=args.work_dir.resolve()
if work.exists(): raise SystemExit('Choose a new work directory; existing evidence is preserved.')
work.mkdir(parents=True);(work/'evidence').mkdir()
for v in ['baseline','release','upstream_tests']: shutil.copytree(source/v,work/v)
for f in ['SOURCE_MANIFEST.json','inputs.json','prepare_variants.py','oracle.py','grid.py','verify.py','minimal.py']:
    shutil.copy2(source/f,work/f)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMBA_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',MPLBACKEND='Agg')
steps=[('oracle',[sys.executable,'oracle.py']),('variants',[sys.executable,'prepare_variants.py'])]
steps += [(v,[sys.executable,'grid.py',v]) for v in ['baseline','candidate','mutation','release']]
for label,cmd in steps:
    env['NUMBA_CACHE_DIR']=str(work/('cache-'+label))
    proc=subprocess.run(cmd,cwd=work,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (work/'evidence'/(label+'.log')).write_text(proc.stdout)
    print(label+': '+('PASS' if proc.returncode==0 else 'FAILED'),flush=True)
    if proc.returncode: print(proc.stdout[-3000:]);raise SystemExit(proc.returncode)
testcode="import sys;from pathlib import Path;sys.path.insert(0,sys.argv[1]);import financepy;assert Path(financepy.__file__).is_relative_to(Path(sys.argv[1]));import pytest;raise SystemExit(pytest.main(['-q','upstream_tests']))"
tests=[]
for v in ['baseline','candidate']:
    env['NUMBA_CACHE_DIR']=str(work/('cache-'+v))
    proc=subprocess.run([sys.executable,'-c',testcode,str(work/v)],cwd=work,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    tests.append(dict(variant=v,exit_code=proc.returncode,output=proc.stdout))
    (work/'evidence'/(v+'-upstream-tests.log')).write_text(proc.stdout)
    print(v+' upstream tests: '+str(proc.returncode),flush=True)
    if proc.returncode: print(proc.stdout[-3000:]);raise SystemExit(proc.returncode)
(work/'evidence/upstream-tests.json').write_text(json.dumps(tests,indent=2)+'\n')
proc=subprocess.run([sys.executable,'verify.py'],cwd=work,env=env,text=True,capture_output=True)
(work/'evidence/verification.log').write_text(proc.stdout+proc.stderr)
if proc.returncode:print(proc.stdout+proc.stderr);raise SystemExit(proc.returncode)
for v in ['baseline','candidate','mutation','release']:
    assert (work/'evidence'/(v+'.json')).read_bytes()==(source/'evidence'/(v+'.json')).read_bytes(),v
print('All four raw result files reproduced byte-for-byte with fresh caches.',flush=True)
