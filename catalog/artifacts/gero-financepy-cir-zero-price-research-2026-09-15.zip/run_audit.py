from pathlib import Path
import subprocess,sys,os
root=Path(__file__).resolve().parent
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMBA_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',MPLBACKEND='Agg')
steps=[('inputs',['prepare_grid.py']),('oracle',['oracle.py']),('variants',['prepare_variants.py'])]
steps += [(v,['grid.py',v]) for v in ['baseline','candidate','mutation','release']]
for label,args in steps:
    env['NUMBA_CACHE_DIR']=str(root/('cache-'+label))
    p=subprocess.run([sys.executable,*args],cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (root/'evidence'/(label+'.log')).write_text(p.stdout)
    print(label+': '+str(p.returncode),p.stdout[-1500:],flush=True)
    if p.returncode: raise SystemExit(p.returncode)
