# Licenses and provenance

The GERO-authored reports in this research bundle are offered under CC BY 4.0, attributed to Xamit Kadirbekov / GERO. Original GERO reproduction scripts are under the MIT license in GERO_SCRIPTS_LICENSE.txt.

FinancePy source, upstream tests, released wheel and candidate derivative code retain their original GPL license and notices; see UPSTREAM_LICENSE and the upstream repository. Their inclusion does not relicense them as MIT or CC BY. Third-party public API metadata and issue text are retained as limited evidence with source URLs, not as newly authored GERO work.

The complete FinancePy Python package source used for the tests is bundled, together with the readable candidate patch and generation script. Dependencies named in environment-requirements.txt are not bundled, other than the explicitly identified FinancePy wheel.
