# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

import numpy as np

from financepy.utils.global_types import CIRNumericalSchemeTypes
from financepy.models.cir_montecarlo import zero_price_mc, zero_price

r0 = 0.05
a = 0.20
b = 0.05
sigma = 0.20
t = 5.0

num_paths = 2000
dt = 0.05
seed = 1968

########################################################################################


def test_model_cir():

    p = zero_price(r0, a, b, sigma, t)
    p_mc1 = zero_price_mc(
        r0, a, b, sigma, t, dt, num_paths, seed, CIRNumericalSchemeTypes.EULER.value
    )
    p_mc2 = zero_price_mc(
        r0,
        a,
        b,
        sigma,
        t,
        dt,
        num_paths,
        seed,
        CIRNumericalSchemeTypes.LOGNORMAL.value,
    )
    p_mc3 = zero_price_mc(
        r0,
        a,
        b,
        sigma,
        t,
        dt,
        num_paths,
        seed,
        CIRNumericalSchemeTypes.MILSTEIN.value,
    )
    p_mc4 = zero_price_mc(
        r0,
        a,
        b,
        sigma,
        t,
        dt,
        num_paths,
        seed,
        CIRNumericalSchemeTypes.KAHLJACKEL.value,
    )
    p_mc5 = zero_price_mc(
        r0, 
        a, 
        b, 
        sigma, 
        t, 
        dt, 
        num_paths, 
        seed, 
        CIRNumericalSchemeTypes.EXACT.value
    )

    assert round(p, 4) == 0.7935
    assert round(p_mc1, 4) == 0.7868
    assert round(p_mc2, 4) == 0.7870
    assert round(p_mc3, 4) == 0.7868
    assert round(p_mc4, 4) == 0.7863
    assert round(p_mc5, 4) == 0.7932
