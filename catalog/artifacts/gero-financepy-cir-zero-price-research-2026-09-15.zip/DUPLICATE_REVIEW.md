# Bounded duplicate review — 15 September 2026

Current upstream `master` was checked through GitHub's API and remains `2b9227fea9d832c4033421d6cd53a54316414fca`. The raw `cir_montecarlo.py` at that commit matches the executed baseline exactly. PyPI's current release is 1.1.2; its separately executed wheel has the identical target file. The wheel digest and all 219 package members were checked against the saved official wheel and PyPI metadata.

The repository's complete returned issue/PR title-body corpus contains 253 records (pages of 100,100,53, `state=all`). Searches covered CIR/Cox, zero_price, cir_montecarlo, small/low volatility, and overflow. Four additional GitHub search queries returned: `CIR`=2, `zero_price`=0, `"volatility" "small"`=0, `"overflow"`=0. Raw responses are under evidence/.

The CIR matches were reviewed: #23 “Shifted CIR Tree” is an empty feature request, without comments; #167 implements finite differences for equity options. Its three comments include a comparison to a CIR tree, without a report of this affine zero-coupon numerical problem. The latest 12 target-file commits were reviewed for relevant fixes; the current function still uses the unstable expression. This is not a claim to have inspected all unrelated issue comments or all historical commit diffs.

The live canonical GERO GitHub catalog contains 97 report records, with no CIR zero-price report. The current local verified GERO deployment's article/report text was also searched for CIR, Cox–Ingersoll, cir_montecarlo and zero_price; no match was returned. The existing Merton, cash-annuity, mortgage, adjusted-binomial and double-no-touch cases concern other functions or models.

No exact duplicate was identified in this recorded scope. This is a newly documented implementation case within that search, not a claim to invent CIR pricing or floating-point stability techniques, and not a guarantee of worldwide priority. Refresh the review again before publication or maintainer submission. No new issue, PR or external post has been submitted for this case.
