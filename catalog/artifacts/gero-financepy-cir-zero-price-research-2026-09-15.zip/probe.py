import sys,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'baseline'))
from financepy.models import cir_montecarlo as c
rows=[]
for r,a,b,t in [(.03,.1,.05,10.),(.03,.2,.05,1.),(.03,1.,.05,30.),(.03,10.,.05,100.),(0.,.1,0.,10.)]:
 for s in [0.,.1,.01,1e-4,1e-6,1e-8,1e-10]:
  try:y=float(c.zero_price(r,a,b,s,t))
  except Exception as e:y=type(e).__name__+': '+str(e)
  z=math.exp(-(b*t+(r-b)*(-math.expm1(-a*t))/a))
  rows.append(dict(r=r,a=a,b=b,sigma=s,t=t,actual=y,deterministic=z))
for x in rows:print(x)
Path('evidence/probe.json').write_text(json.dumps(rows,indent=2))
