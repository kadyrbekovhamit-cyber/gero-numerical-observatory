# CIR zero-coupon pricing audit

Freeze this protocol and input grid before testing the candidate implementation.

Target: the actual Numba-compiled public `financepy.models.cir_montecarlo.zero_price`, current source pin `2b9227fea9d832c4033421d6cd53a54316414fca` and separately extracted PyPI 1.1.2. No simulated prices are used as ground truth.

Conventions: risk-neutral CIR `dr = a (b-r) dt + sigma sqrt(r) dW`; nonnegative initial rate and long-run level, positive mean reversion, nonnegative volatility and maturity. Price is the present value of a unit payment at maturity. Rates use annual units, maturity is in years. These are synthetic valid-domain tests, including extreme numerical stress parameters, not calibrated market portfolios.

Grid: Cartesian product of r0=[0,.03,.2], b=[0,.01,.05,.2], a=[1e-8,.001,.1,1,10,30], sigma=[0,1e-10,1e-8,1e-6,1e-4,.01,.1,.5,2], t=[0,1e-8,1e-4,.25,1,10,100]. Exactly 4536 distinct parameter vectors. Include the initial sigma=1e-10 probe as a separate minimal demonstration, without inflating grid counts.

Oracle: direct published affine closed form, evaluated with mpmath at 80 decimal digits on the exact binary64 inputs; independently repeat every oracle at 120 digits. A separate numerical solution of the affine Riccati ODE checks 48 parameter vectors. The candidate uses a different algebraic representation, not the oracle code.

Per-price criterion fixed before candidate execution: finite output and absolute error <= 2e-12 + 2e-12 * abs(oracle). Bounds use [-2e-15, 1+2e-15]. Do not relax these criteria after seeing results. Record individual raw rows and aggregate overlaps, not the sum of overlapping failure categories.

Invariants: price in [0,1], zero maturity price=1, absorbing r0=b=0 price=1, deterministic sigma=0 closed form, continuous small-volatility limit. Use regular positive-volatility cases to check that a numerical repair does not break ordinary results. Preserve all original source hashes; candidate and source-restoration mutation are separate copies and separate Python processes. Compare original/mutation/release rows exactly, including exception/NaN representation. Passing original cases must remain within the same fixed oracle tolerance; byte equality is reported separately.

No full-suite, Monte Carlo, calibration, Greeks, performance, production-bank or customer-loss claim. One numerical worker at a time; no sound playback.
