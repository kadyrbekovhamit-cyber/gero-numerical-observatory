from pathlib import Path
from collections import Counter
import hashlib,json,datetime

root=Path(__file__).resolve().parent
def read(name): return json.loads((root/name).read_text())
manifest=read('SOURCE_MANIFEST.json')
for v,files in manifest.items():
    for name,h in files.items():
        assert hashlib.sha256((root/v/name).read_bytes()).hexdigest()==h,(v,name)
for name in manifest['baseline']:
    assert (root/'baseline'/name).read_bytes()==(root/'mutation'/name).read_bytes(),name
    if name!='financepy/models/cir_montecarlo.py':
        assert (root/'baseline'/name).read_bytes()==(root/'candidate'/name).read_bytes(),name
original=read('evidence/baseline.json')
candidate=read('evidence/candidate.json')
mutation=read('evidence/mutation.json')
release=read('evidence/release.json')
assert original==mutation==release
assert len(original)==len(candidate)==4536
assert sum(r['oracle_failure'] for r in original)==1168
assert not any(r['oracle_failure'] or r['bounds_failure'] for r in candidate)
passing=[i for i,r in enumerate(original) if not r['oracle_failure']]
assert all(not candidate[i]['oracle_failure'] for i in passing)
tests=read('evidence/upstream-tests.json')
assert [x['exit_code'] for x in tests]==[0,0]
assert all('40 passed' in x['output'] for x in tests)
receipt=dict(
    verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    observations=4536, unique_parameter_vectors=4536,
    failures_original_candidate_mutation_release=[sum(x['oracle_failure'] for x in rows) for rows in [original,candidate,mutation,release]],
    bounds_original_candidate=[sum(x['bounds_failure'] for x in rows) for rows in [original,candidate]],
    original_nonfinite_or_exceptions=sum(isinstance(r['actual'],str) for r in original),
    all_mutation_and_release_rows_equal_original=True,
    previously_passing_rows=len(passing),
    previously_passing_rows_changed_binary_value=sum(original[i]['actual']!=candidate[i]['actual'] for i in passing),
    previously_passing_rows_still_pass=True,
    candidate_max_absolute_error=max(x['absolute_error'] for x in candidate),
    unchanged_source_files={v:len(files) for v,files in manifest.items()},
    candidate_changes_one_file=True,
    upstream_CIR_tests_original_candidate=[40,40],
    independent_riccati_checks=len(read('evidence/riccati-ode-check.json')),
    original_failures_by_sigma=dict(Counter(str(x['sigma']) for x in original if x['oracle_failure'])),
    input_sha256=hashlib.sha256((root/'inputs.json').read_bytes()).hexdigest(),
    public_publication=False, production_impact_measured=False)
(root/'evidence/paired-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
