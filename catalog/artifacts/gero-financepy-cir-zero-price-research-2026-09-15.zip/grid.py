from pathlib import Path
import sys,json,math,hashlib,platform,importlib.metadata

root=Path(__file__).resolve().parent
variant=sys.argv[1]
assert variant in ['baseline','candidate','mutation','release']
sys.path.insert(0,str(root/variant))
from financepy.models import cir_montecarlo as cir
assert Path(cir.__file__).is_relative_to(root/variant)
inputs=json.loads((root/'inputs.json').read_text())
refs=json.loads((root/'evidence/oracle.json').read_text())
rows=[]
for row,ref in zip(inputs,refs):
    assert row['id']==ref['id']
    expected=ref['expected']
    try:
        raw=float(cir.zero_price(*[row[k] for k in ['r0','a','b','sigma','t']]))
        value=raw if math.isfinite(raw) else repr(raw)
        error=abs(raw-expected) if math.isfinite(raw) else None
        fail=not math.isfinite(raw) or error > 2e-12+2e-12*abs(expected)
        bounds=not math.isfinite(raw) or raw < -2e-15 or raw > 1+2e-15
        rowout=dict(**row,actual=value,expected=expected,absolute_error=error,oracle_failure=fail,bounds_failure=bounds)
    except Exception as exc:
        rowout=dict(**row,actual=type(exc).__name__+': '+str(exc),expected=expected,absolute_error=None,oracle_failure=True,bounds_failure=True)
    rows.append(rowout)
out=root/'evidence'
(out/(variant+'.json')).write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
metadata=dict(variant=variant,python=sys.version,platform=platform.platform(),
              module=str(Path(cir.__file__).resolve()),source_sha256=hashlib.sha256(Path(cir.__file__).read_bytes()).hexdigest(),
              numba_nopython_signatures=[str(x) for x in cir.zero_price.nopython_signatures],
              versions={k:importlib.metadata.version(k) for k in ['numpy','numba','scipy','mpmath']})
(out/(variant+'-provenance.json')).write_text(json.dumps(metadata,indent=2)+'\n')
summary=dict(variant=variant,observations=len(rows),oracle_failures=sum(x['oracle_failure'] for x in rows),bounds_failures=sum(x['bounds_failure'] for x in rows),nonfinite_or_exceptions=sum(isinstance(x['actual'],str) for x in rows))
(out/(variant+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
