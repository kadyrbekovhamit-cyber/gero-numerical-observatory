from pathlib import Path
import os,sys,json
root=Path(__file__).resolve().parent
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:
    os.environ[name]='1'
os.environ.setdefault('NUMBA_CACHE_DIR',str(root/'minimal-cache'))
sys.dont_write_bytecode=True
variant=sys.argv[1] if len(sys.argv)>1 else 'baseline'
assert variant in ['baseline','candidate','mutation','release']
sys.path.insert(0,str(root/variant))
from financepy.models.cir_montecarlo import zero_price
from oracle import exact_price
row=dict(r0=.03,a=.1,b=.05,sigma=1e-10,t=10.)
expected=float(exact_price(row,120))
actual=float(zero_price(*[row[k] for k in ['r0','a','b','sigma','t']]))
print(json.dumps(dict(variant=variant,inputs=row,actual=actual,expected=expected,
                 unit_payment_price_must_be_between_zero_and_one=True),indent=2))
