# Source ledger

| Claim or artifact | Evidence |
|---|---|
| Actual FinancePy implementation and accepted input domain | Pinned official `cir_montecarlo.py`; baseline package; SOURCE.json; SOURCE_MANIFEST.json |
| Current source pin | https://github.com/domokane/FinancePy/commit/2b9227fea9d832c4033421d6cd53a54316414fca ; evidence/current-head.json |
| Released version and archive identity | https://pypi.org/project/financepy/1.1.2/ ; evidence/pypi-current.json; release-verification.json; bundled official wheel |
| Model price, independent reference and fixed criteria | oracle.py; VALIDATION_PROTOCOL.md; inputs.json; evidence/oracle.json; riccati-ode-check.json |
| 1168 → 0 → 1168, release1168 | evidence/baseline.json, candidate.json, mutation.json, release.json; paired-verification.json |
| Actual native Numba execution and selected module | Four evidence/*-provenance.json files |
| 40 upstream tests on each variant | upstream_tests/; evidence/upstream-tests.json and logs |
| Fresh-copy/cache rerun | evidence/fresh-reproduction.json and selected fresh-run logs |
| Duplicate scope and limitations | DUPLICATE_REVIEW.md; raw issues/search/history/catalog responses in evidence/ |
| Candidate reformulation | candidate.patch; prepare_variants.py; algebra derived in RESULTS_EN.md |

External reference formulas and related implementations were inspected as context, including https://github.com/lballabio/QuantLib/blob/master/ql/models/shortrate/onefactormodels/coxingersollross.cpp . QuantLib was not executed in this audit and is not claimed as an independent numerical oracle or an additional confirmed defect.

All public-facing claims must retain the synthetic-input, scope and lack-of-production-impact qualifications. No staged material or local archive constitutes external publication.
