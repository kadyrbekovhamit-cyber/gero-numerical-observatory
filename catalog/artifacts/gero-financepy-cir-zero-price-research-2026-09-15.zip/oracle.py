from pathlib import Path
import json, math
import mpmath as mp
from scipy.integrate import solve_ivp

root = Path(__file__).resolve().parent

def exact_price(row, digits):
    with mp.workdps(digits):
        r,a,b,s,t = [mp.mpf(row[k]) for k in ['r0','a','b','sigma','t']]
        if not t: return mp.mpf(1)
        if not s:
            return mp.exp(-b*t-(r-b)*(-mp.expm1(-a*t))/a)
        h = mp.sqrt(a*a+2*s*s)
        denominator = 2*h+(a+h)*mp.expm1(h*t)
        capital_a = (2*h*mp.exp((a+h)*t/2)/denominator)**(2*a*b/(s*s))
        capital_b = 2*mp.expm1(h*t)/denominator
        return capital_a*mp.exp(-r*capital_b)

def main():
    rows=json.loads((root/'inputs.json').read_text())
    values=[]
    for row in rows:
        x,y=exact_price(row,80),exact_price(row,120)
        assert abs(x-y) < mp.mpf('1e-55'), row
        values.append(dict(id=row['id'], exact_decimal=mp.nstr(y,70), expected=float(y)))
    (root/'evidence/oracle.json').write_text(json.dumps(values,indent=2)+'\n')
    ode=[]
    # A separate integration of the affine pricing ODE, with no affine
    # closed-form coefficients used by the solver.
    for a in [.001,.1,1.]:
        for s in [0.,1e-8,.1,2.]:
            for t in [.25,1.,10.,100.]:
                row=dict(r0=.03,a=a,b=.05,sigma=s,t=t)
                def rhs(_, y):
                    B,logA=y
                    return [1-a*B-.5*s*s*B*B, -a*.05*B]
                sol=solve_ivp(rhs,[0,t],[0.,0.],method='DOP853',rtol=3e-13,atol=2e-14)
                assert sol.success
                p=math.exp(sol.y[1,-1]-.03*sol.y[0,-1])
                ref=float(exact_price(row,120))
                err=abs(p-ref)
                assert err<=2e-12+2e-12*abs(ref),(row,p,ref)
                ode.append(dict(inputs=row,ode_price=p,oracle_price=ref,error=err,nfev=sol.nfev))
    (root/'evidence/riccati-ode-check.json').write_text(json.dumps(ode,indent=2)+'\n')
    print(json.dumps({'grid_oracles':len(values),'precision_digits':[80,120],
          'precision_agreement_absolute':'<1e-55','independent_ode_checks':len(ode),
          'max_ode_absolute_difference':max(x['error'] for x in ode)}))

if __name__=='__main__': main()
