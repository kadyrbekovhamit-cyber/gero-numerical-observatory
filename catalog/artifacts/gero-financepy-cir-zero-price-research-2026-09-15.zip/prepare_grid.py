from pathlib import Path
from itertools import product
import json, hashlib

root = Path(__file__).resolve().parent
rows = [dict(id=i, r0=r, a=a, b=b, sigma=s, t=t)
        for i, (r, b, a, s, t) in enumerate(product(
            [0., .03, .2], [0., .01, .05, .2],
            [1e-8, .001, .1, 1., 10., 30.],
            [0., 1e-10, 1e-8, 1e-6, 1e-4, .01, .1, .5, 2.],
            [0., 1e-8, 1e-4, .25, 1., 10., 100.]))]
assert len(rows) == 4536
target = root / 'inputs.json'
assert not target.exists(), 'Do not overwrite frozen inputs'
target.write_text(json.dumps(rows, indent=2)+'\n')
print({'inputs':len(rows), 'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
