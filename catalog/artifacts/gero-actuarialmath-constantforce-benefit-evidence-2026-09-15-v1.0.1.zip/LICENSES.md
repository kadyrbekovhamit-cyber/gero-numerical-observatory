# Component licensing

The original actuarialmath source archive and released wheel retain the upstream
MIT license and copyright notices. The candidate modifies MIT-licensed code.
The unmodified upstream license is included as ACTUARIALMATH_LICENSE.txt.

Original GERO report and explanatory diagrams: copyright 2026 Xamit Kadirbekov,
CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
Original GERO reproduction and verification scripts: MIT, copyright 2026
Xamit Kadirbekov. The complete license is in GERO_SCRIPTS_LICENSE.txt.

Public GitHub issue/PR metadata retains its original attribution. This bundle
does not override third-party rights or imply affiliation with a library author
or an insurer. See the original upstream license for its complete terms.
