"""Reproduce the real library in fresh copies; preserve all recorded evidence.

Python 3.12+. Install environment-requirements.txt first. No network is used.
The only output location is the new --work-dir directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--work-dir', required=True)
    args = parser.parse_args()
    work = Path(args.work_dir).resolve()
    if sys.version_info < (3, 12):
        raise SystemExit('Python 3.12+ is required')
    if work.exists():
        raise SystemExit('Use a new, nonexistent work directory')
    if ROOT == work or ROOT.is_relative_to(work):
        raise SystemExit('The work directory must not contain this evidence bundle')
    source_meta = json.loads((ROOT / 'SOURCE.json').read_text())
    recorded = json.loads((ROOT / 'evidence/paired-verification.json').read_text())
    archive = ROOT / 'upstream-source.tar.gz'
    wheel = ROOT / 'actuarialmath-1.1.0-py3-none-any.whl'
    assert sha(archive) == source_meta['archive_sha256']
    assert sha(wheel) == 'b19990e4378aaa19fe6bc1182b4269faec6617cb62b0677fea1e624fbbb3ff6f'
    frozen = {label: json.loads((ROOT / 'evidence' / (label + '.json')).read_text())
              for label in ('baseline', 'candidate', 'release', 'mutation')}
    for label, digest in recorded['result_hashes'].items():
        assert sha(ROOT / 'evidence' / (label + '.json')) == digest

    work.mkdir(parents=True)
    sources = work / 'sources'
    sources.mkdir()
    with tarfile.open(archive) as tar:
        tar.extractall(sources, filter='data')
    original = sources / ('actuarialmath-' + source_meta['pin'])
    manifest = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_text())
    assert all(sha(original / name) == digest for name, digest in manifest.items())
    candidate = sources / 'candidate'
    mutation = sources / 'mutation'
    shutil.copytree(original, candidate)
    shutil.copytree(original, mutation)
    release = sources / 'release'
    (release / 'src').mkdir(parents=True)
    with zipfile.ZipFile(wheel) as zip_file:
        for member in zip_file.infolist():
            path = Path(member.filename)
            assert not path.is_absolute() and '..' not in path.parts
        zip_file.extractall(release / 'src')
    name = 'src/actuarialmath/constantforce.py'
    old = 'return self.mu_ / (self.mu_ + delta) if self.mu_ > 0 else 0.'
    new = 'return b**moment * self.mu_ / (self.mu_ + delta) if self.mu_ > 0 else 0.'
    text = (candidate / name).read_text()
    assert text.count(old) == 1
    (candidate / name).write_text(text.replace(old, new))
    assert sha(candidate / name) == recorded['candidate_sha256']
    assert sha(original / name) == sha(release / name) == sha(mutation / name)
    assert sha(original / name) == recorded['source_sha256']

    env = dict(os.environ)
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        env[key] = '1'
    env.update(PYTHONDONTWRITEBYTECODE='1', MPLBACKEND='Agg',
               MPLCONFIGDIR=str(work / 'mpl-cache'),
               XDG_CACHE_HOME=str(work / 'cache'))
    results = {}
    for label, source in (('baseline', original), ('candidate', candidate),
                          ('release', release), ('mutation', mutation)):
        output = work / (label + '.json')
        result = subprocess.run(
            [sys.executable, str(ROOT / 'check_benefit.py'), '--source', str(source),
             '--output', str(output)], env=env, capture_output=True, text=True,
            timeout=120)
        (work / (label + '.log')).write_text(result.stdout + result.stderr)
        if result.returncode:
            raise SystemExit(f'{label} failed; see {work / (label + ".log")}')
        data = json.loads(output.read_text())
        assert data['rows'] == frozen[label]['rows'], label
        assert data['finite_controls'] == frozen[label]['finite_controls'], label
        assert data['implementation_sha256'] == frozen[label]['implementation_sha256']
        assert data['observations'] == 144 and data['finite_term_controls'] == 288
        assert data['finite_term_failures'] == 0
        assert data['failures']['age_pass'] == 0
        assert data['failures']['term_oracle_pass'] == 0
        results[label] = data
        print(label, data['failures'], flush=True)

    assert results['baseline']['rows'] == results['release']['rows'] == results['mutation']['rows']
    assert [results[k]['failures']['oracle_pass'] for k in results] == [120, 0, 120, 120]
    assert all(results[k]['finite_controls'] == results['baseline']['finite_controls']
               for k in results)
    assert [r for r in results['baseline']['rows'] if r['benefit'] == '1'] == [
        r for r in results['candidate']['rows'] if r['benefit'] == '1']
    assert all(sha(original / name) == digest for name, digest in manifest.items())
    changed = [name for name, digest in manifest.items() if sha(candidate / name) != digest]
    assert changed == ['src/actuarialmath/constantforce.py']
    receipt = dict(source_pin=source_meta['pin'], main_observations=144,
                   failures={k: v['failures']['oracle_pass'] for k, v in results.items()},
                   fresh_rows_match_recorded=True, finite_term_controls_unchanged=288,
                   unit_benefit_controls_unchanged=24, source_files_verified=len(manifest),
                   candidate_changed_files=changed, full_upstream_suite_run=False,
                   python=sys.version, outputs={k: sha(work / (k + '.json')) for k in results})
    (work / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
