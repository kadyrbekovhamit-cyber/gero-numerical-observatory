"""Execute real ConstantForce methods against an exact exponential-lifetime oracle."""
import argparse
from fractions import Fraction
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import sys

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--output', required=True)
args = p.parse_args()
source = Path(args.source).resolve()
sys.path.insert(0, str(source / 'src'))
import actuarialmath
from actuarialmath import ConstantForce
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)

def close(a, b):
    # Fixed before candidate execution; no tolerance tuning between runs.
    return math.isclose(a, b, rel_tol=2e-12, abs_tol=2e-14)

rows, finite = [], []
for mu_s in ['0.01', '0.02', '0.1']:
    for delta_s in ['0', '0.01', '0.03', '0.1']:
        mu, delta = Fraction(mu_s), Fraction(delta_s)
        life = ConstantForce(mu=float(mu)).set_interest(delta=float(delta))
        for b_s in ['0', '0.5', '1', '2', '100', '100000']:
            b = Fraction(b_s)
            for moment in [1, 2]:
                # T ~ Exp(mu), Z = b exp(-delta T).
                exact = b**moment * mu / (mu + moment * delta)
                actual = life.whole_life_insurance(35, b=float(b), moment=moment, discrete=False)
                other_age = life.whole_life_insurance(70, b=float(b), moment=moment, discrete=False)
                equivalent = life.term_insurance(35, t=life.WHOLE, b=float(b), moment=moment, discrete=False)
                unit = life.whole_life_insurance(35, b=1, moment=moment, discrete=False)
                rows.append(dict(mu=mu_s, delta=delta_s, benefit=b_s, moment=moment,
                    exact=str(exact), expected=float(exact), actual=actual,
                    equivalent_whole_term=equivalent, other_age=other_age,
                    oracle_pass=close(actual,float(exact)), term_oracle_pass=close(equivalent,float(exact)),
                    equivalent_formula_pass=close(actual,equivalent),
                    benefit_scaling_pass=close(actual,float(b**moment)*unit), age_pass=actual==other_age))
                for t in [1, 10]:
                    expected=float(exact)*(-math.expm1(-float(mu+moment*delta)*t))
                    actual_term=life.term_insurance(35,t=t,b=float(b),moment=moment,discrete=False)
                    finite.append(dict(mu=mu_s,delta=delta_s,benefit=b_s,moment=moment,term=t,
                        expected=expected,actual=actual_term,oracle_pass=close(actual_term,expected)))

result=dict(source=str(source), imported_from=actuarialmath.__file__, python=sys.version,
    platform=platform.platform(),dependencies={k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','matplotlib']},
    implementation_sha256=hashlib.sha256((source/'src/actuarialmath/constantforce.py').read_bytes()).hexdigest(),
    tolerance={'relative':2e-12,'absolute':2e-14},observations=len(rows),finite_term_controls=len(finite),
    failures={k:sum(not r[k] for r in rows) for k in ['oracle_pass','term_oracle_pass','equivalent_formula_pass','benefit_scaling_pass','age_pass']},
    finite_term_failures=sum(not r['oracle_pass'] for r in finite),rows=rows,finite_controls=finite,
    scope='Positive first and second continuous whole-life moments; mu>0 and delta>=0. Synthetic analytical contracts, no insurer deployment, premiums, customer loss or variance claims.')
out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['observations','finite_term_controls','failures','finite_term_failures']}))
