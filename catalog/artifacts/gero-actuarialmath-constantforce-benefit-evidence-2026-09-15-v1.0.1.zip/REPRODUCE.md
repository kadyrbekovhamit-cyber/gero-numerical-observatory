# Reproduce this evidence edition

Use Python 3.12+ and an isolated environment. From this extracted directory:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r environment-requirements.txt
.venv/bin/python portable_reproduce.py --work-dir ../constantforce-independent-run
```

Choose a new, nonexistent work directory. The runner uses no network after the
dependency installation. It verifies the bundled source archive and release
wheel hashes, extracts fresh source copies, verifies all 91 source files, applies
the one-line correction only in a separate copy, and runs original, candidate,
release and restored-original variants sequentially with numerical threads=1.

It compares all numerical rows to the recorded evidence and writes new results,
logs and verification.json only into the selected work directory. The archived
observations are never overwritten. Expected failures are 120/144 original,
0/144 candidate, 120/144 release and 120/144 restored-original; all 288 finite-term
and 24 unit-benefit controls stay unchanged. This is not the full upstream suite.

The fresh 15 September extraction run is retained under evidence/portable-run/.
Its verification.json output hashes refer to the four JSON files in that same
directory. Recorded JSON metadata includes original workstation paths; these
are provenance only and are not required locations for a new run. Numeric rows
and original evidence-file hashes were not rewritten for packaging.

SHA256SUMS covers every packaged file other than itself. Runtime dependencies
were tested on macOS arm64; cross-platform dependency installation has not been
verified. The report gives the tested versions, independent oracle and limits.
