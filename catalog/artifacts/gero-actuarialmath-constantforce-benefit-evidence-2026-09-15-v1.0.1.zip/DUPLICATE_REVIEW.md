# Duplicate review — 15 September 2026

Current upstream commit remains `7d18f11ad304898f177b7922b3c53f70e4c2b4f4`;
the latest PyPI distribution remains 1.1.0. The actual current and release
`constantforce.py` source bytes match in the recorded execution.

Fresh GitHub issue/PR searches: ConstantForce, whole_life_insurance, benefit,
scaling and moment. All results were complete, with at most one hit per query.
All three existing issues/PRs were inventoried, including closed items:
issue 1 (UDD monthly typo), PR 2 (fractional-age density), and issue 3 (generic
whole-life variance squares the first moment twice). Issue 3 concerns a different
method/branch from this positive-moment ConstantForce benefit-factor omission.
The canonical 95-material GERO catalog contained no exact report for this case.

No exact duplicate was found within that recorded scope. This does not prove
worldwide novelty. Source, complete API responses and timestamps are retained in
`evidence/fresh-review/`. No upstream acceptance or deployed impact is claimed.
