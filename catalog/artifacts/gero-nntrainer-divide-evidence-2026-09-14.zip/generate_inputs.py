from pathlib import Path
from fractions import Fraction
import math,struct,json,random
E=Path(__file__).resolve().parent/'evidence'
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def frac(x):return Fraction.from_float(x)
def rne_bits(x):
 if x==0:return 0
 sign=0x80000000 if x<0 else 0;x=abs(x);n,d=x.numerator,x.denominator
 e=n.bit_length()-d.bit_length()
 if (Fraction(2)**e)>x:e-=1
 unit=Fraction(2)**max(e-23,-149);v=x/unit;q,r=divmod(v.numerator,v.denominator)
 q+=2*r>v.denominator or (2*r==v.denominator and q%2)
 if e < -126:return sign|q
 if q==1<<24:q>>=1;e+=1
 if e>127:return sign|0x7f800000
 return sign|((e+127)<<23)|(q-(1<<23))
inputs=[];seen=set();limit=Fraction(2)**120;small=1/limit

def add(a,b,g,label):
 a,b,g=map(f32,(a,b,g));key=tuple(map(bits,(a,b,g)))
 if key in seen or not b or not all(math.isfinite(x) for x in (a,b,g)):return
 A,B,G=map(frac,(a,b,g));refs=[A/B,G/B,-G*A/(B*B)]
 if any(v!=0 and not small<=abs(v)<=limit for v in refs):return
 seen.add(key);inputs.append({'a':a,'b':b,'g':g,'bits':key,'expected_bits':[rne_bits(v) for v in refs],'exact':[str(v) for v in refs],'family':label})
for a,b,g in [(1e20,1e20,1),(1e-30,1e-30,1),(0,1e-30,0),(1e-30,1e-30,0),(2,4,-3)]:add(a,b,g,'decimal example')
for e in range(-120,121,4):
 for sign in [1,-1]:
  b=sign*math.ldexp(1.,e)
  for m in [0,1,-1,2,-2,0.5]:
   for g in [0,1,-3,2.**40,2.**-40]:add(b*m,b,g,'power-of-two scale')
r=random.Random(20260914)
while len(inputs)<4096:
 vals=[math.ldexp(r.choice([-1,1])*r.randint(4,15)/8,r.randint(-120,120)) for _ in range(3)]
 add(*vals,'seeded finite-range control')
inputs=inputs[:4096]
(E/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(E/'inputs.txt').write_text(str(len(inputs))+'\n'+'\n'.join(' '.join(map(str,x['bits'])) for x in inputs)+'\n')
print(len(inputs),'unique finite-normal-output triples; independent rational RNE reference')
