from pathlib import Path
import subprocess,json,hashlib,os,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;E=R/'evidence';S=R/'work/nntrainer';p=S/'nntrainer/layers/divide_layer.cpp';candidate=p.read_bytes();(E/'candidate-divide_layer.cpp').write_bytes(candidate)
original=(E/'original-divide_layer.cpp').read_bytes();p.write_bytes(original)
def tests(mode,failures):
 out=E/(mode+'-tests.xml');env=os.environ.copy()
 for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[k]='1'
 x=subprocess.run([str(S/'build/test/unittest/layers/unittest_layers'),'--gtest_filter=*Divide*:*divide*','--gtest_output=xml:'+str(out)],cwd=S/'build',env=env,capture_output=True,text=True);(E/'logs'/(mode+'-tests.log')).write_text(x.stdout+x.stderr)
 root=ET.parse(out).getroot();assert int(root.attrib['tests'])==25;assert int(root.attrib['failures'])==failures,root.attrib;assert (x.returncode==0)==(failures==0);return root.attrib
try:
 subprocess.run(['python3','build.py','mutation'],cwd=R,check=True)
 subprocess.run(['python3','run_validation.py','mutation'],cwd=R,check=True)
 assert (E/'baseline-raw.tsv').read_bytes()==(E/'mutation-raw.tsv').read_bytes()
 assert p.read_bytes()==original
 mtests=tests('mutation',3)
finally:
 p.write_bytes(candidate)
 subprocess.run(['python3','build.py','restored-candidate'],cwd=R,check=True)
subprocess.run(['python3','run_validation.py','restored-candidate'],cwd=R,check=True)
assert (E/'candidate-raw.tsv').read_bytes()==(E/'restored-candidate-raw.tsv').read_bytes()
ctests=tests('restored-candidate',0)
(E/'mutation-proof.json').write_text(json.dumps({'baseline_source_byte_restored':True,'baseline_and_mutation_raw_identical':True,'candidate_and_restored_raw_identical':True,'mutation_tests':mtests,'restored_candidate_tests':ctests,'original_source_sha256':hashlib.sha256(original).hexdigest(),'candidate_source_sha256':hashlib.sha256(candidate).hexdigest()},indent=2)+'\n');print('Mutation and restoration verified',flush=True)
