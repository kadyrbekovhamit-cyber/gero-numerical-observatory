from pathlib import Path
import hashlib,json,math,os,shlex,subprocess,sys,struct,datetime
R=Path(__file__).resolve().parent;E=R/'evidence';S=R/'work/nntrainer';B=S/'build';mode=sys.argv[1]
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[k]='1'
entry=next(x for x in json.loads((B/'compile_commands.json').read_text()) if x['file'].endswith('/divide_layer.cpp') and 'libnntrainer.dylib.p' in x['command'])
args=[];skip=False
for w in shlex.split(entry['command']):
 if skip:skip=False;continue
 if w in ['-o','-MQ','-MF','-c']:skip=True;continue
 if w in ['-MD','-MMD']:continue
 args.append(w)
exe=E/'divide_audit';args += [str(E/'divide_audit.cpp'),'-o',str(exe),'-L'+str(B/'nntrainer'),'-lnntrainer','-Wl,-rpath,'+str(B/'nntrainer')]
c=subprocess.run(args,cwd=B,env=env,capture_output=True,text=True);(E/'logs'/('compile-probe-'+mode+'.log')).write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
run=subprocess.run([str(exe)],input=(E/'inputs.txt').read_text(),cwd=B,env=env,capture_output=True,text=True);(E/(mode+'-raw.tsv')).write_text(run.stdout);(E/'logs'/('probe-'+mode+'.log')).write_text(run.stderr);assert run.returncode==0,run.stderr
rows=[list(map(int,l.split())) for l in run.stdout.splitlines()];inputs=json.loads((E/'inputs.json').read_text());assert len(rows)==6*len(inputs)
outputs={};bad=[];allbad=[]
def ordered(u):return (0x80000000-u) if u&0x80000000 else u+0x80000000
def distance(a,b):
 if (a&0x7fffffff)==0 and (b&0x7fffffff)==0:return 0
 if a&0x7f800000==0x7f800000:return 2**32
 return abs(ordered(a)-ordered(b))
for shape,rep,i,y,da,db,unchanged in rows:
 assert unchanged;out=[y,da,db];key=(shape,rep,i);assert key not in outputs;outputs[key]=out
 for j,(a,b) in enumerate(zip(out,inputs[i]['expected_bits'])):
  ulp=distance(a,b)
  if ulp>3:
   failure={'shape':shape,'repeat':rep,'input_index':i,'component':['y','da','db'][j],'actual_bits':a,'expected_bits':b,'ulp_distance':ulp};allbad.append(failure)
   if shape==0 and rep==0:bad.append(failure)
for shape in range(3):
 for rep in range(2):
  for i in range(len(inputs)):assert outputs[shape,rep,i]==outputs[0,0,i],('shape/repeat mismatch',shape,rep,i)
summary={'mode':mode,'unique_input_triples':len(inputs),'shapes':3,'backward_repeats_per_shape':2,'native_coordinate_observations':len(rows),'mismatching_unique_components':len(bad),'mismatching_unique_inputs':len({x['input_index'] for x in bad}),'components':{c:sum(x['component']==c for x in bad) for c in ['y','da','db']},'failure_observations':len(allbad),'shape_invariant':True,'repeat_invariant':True,'input_bits_preserved':True,'tolerance':'3 float32 ULP; signed zero ignored; nonfinite output fails against finite normal/zero oracle','oracle':'Exact Python Fraction, independent integer round-to-nearest-even float32 encoding','library_sha256':hashlib.sha256((B/'nntrainer/libnntrainer.dylib').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((S/'nntrainer/layers/divide_layer.cpp').read_bytes()).hexdigest(),'compile_command':args,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failures':bad}
(E/(mode+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['compile_command','failures']},indent=2))
