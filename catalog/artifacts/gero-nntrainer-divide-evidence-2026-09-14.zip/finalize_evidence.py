from pathlib import Path
import json, hashlib, struct, collections, difflib, datetime, decimal

R=Path(__file__).resolve().parent;E=R/'evidence';S=R/'work/nntrainer'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((E/'clean-source-manifest.json').read_text())
omitted={x['path'] for x in json.loads((E/'omitted-source-assets.json').read_text())['assets']} if (E/'omitted-source-assets.json').exists() else set()
changed=[p for p,h in manifest.items() if (not (S/p).is_file() and p not in omitted) or ((S/p).is_file() and sha(S/p)!=h)]
assert set(changed)=={'nntrainer/layers/divide_layer.cpp','test/unittest/layers/unittest_layers_divide.cpp'},changed
patch=''
for path,old in [('nntrainer/layers/divide_layer.cpp','original-divide_layer.cpp'),('test/unittest/layers/unittest_layers_divide.cpp','original-unittest_layers_divide.cpp')]:
 patch+=''.join(difflib.unified_diff((E/old).read_text().splitlines(True),(S/path).read_text().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(R/'candidate.patch').write_text(patch)
def rows(mode):return [list(map(int,l.split())) for l in (E/(mode+'-raw.tsv')).read_text().splitlines()]
base,cand=rows('baseline'),rows('candidate')
assert base==rows('mutation') and cand==rows('restored-candidate')
assert all(a[:5]==b[:5] for a,b in zip(base,cand))
inputs=json.loads((E/'inputs.json').read_text())
def value(u):return struct.unpack('<f',struct.pack('<I',u))[0]
def bit(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def ordered(u):return 0x80000000-(u&0x7fffffff) if u&0x80000000 else 0x80000000+u
# Independent cross-check: 200-digit Decimal arithmetic followed by the
# runtime's binary64/binary32 conversion, and adjacent-float midpoint checks.
decimal.getcontext().prec=200
checked=0;maximum=[0,0,0]
for x,row in zip(inputs,cand[:4096]):
 a,b,g=[decimal.Decimal.from_float(value(u)) for u in x['bits']]
 for j,v in enumerate([a/b,g/b,-g*a/(b*b)]):
  u=x['expected_bits'][j];f=decimal.Decimal.from_float(value(u))
  assert bit(float(v))&0x7fffffff==u&0x7fffffff
  if v:
   for adjacent in [u-1,u+1]:
    other=decimal.Decimal.from_float(value(adjacent))
    assert abs(v-f)<=abs(v-other)
  maximum[j]=max(maximum[j],abs(ordered(row[3+j])-ordered(u)))
  checked+=1
summary=json.loads((E/'baseline-summary.json').read_text())
categories=collections.Counter()
for f in summary['failures']:
 u=f['actual_bits'];v=value(u)
 categories['NaN' if v!=v else 'infinity' if abs(v)==float('inf') else 'zero_instead_of_nonzero' if v==0 else 'finite_inaccurate']+=1
result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'clean_source_files_checked':len(manifest),'only_changed_source_files':changed,'oracle_values_cross_checked':checked,'oracle_cross_check':'200-digit Decimal, standard binary conversions, adjacent binary32 distance checks','baseline_forward_and_numerator_gradient_byte_unchanged':True,'candidate_max_ulp_by_component':dict(zip(['y','da','db'],maximum)),'baseline_unique_failure_categories':dict(categories),'counts':{'unique_input_triples':4096,'baseline_failing_inputs':1302,'candidate_failing_inputs':0,'mutation_failing_inputs':1302,'restored_candidate_failing_inputs':0},'mutation_proof':json.loads((E/'mutation-proof.json').read_text()),'inputs_sha256':sha(E/'inputs.json'),'candidate_patch_sha256':sha(R/'candidate.patch')}
(R/'VALIDATION_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='mutation_proof'},indent=2))
