// SPDX-License-Identifier: Apache-2.0
/**
 * Copyright (C) 2024 SeungBaek Hong <sb92.hong@samsung.com>
 *
 * @file   divide_layer.cpp
 * @date   10 Oct 2024
 * @see    https://github.com/nntrainer/nntrainer
 * @author SeungBaek Hong <sb92.hong@samsung.com>
 * @bug    No known bugs except for NYI items
 * @brief  This is div layer class (operation layer)
 *
 */

#include <cmath>

#include <divide_layer.h>
#include <nntrainer_error.h>
#include <nntrainer_log.h>
#include <node_exporter.h>
#include <util_func.h>

#include <layer_context.h>

namespace nntrainer {

void DivideLayer::finalize(InitLayerContext &context) {
  context.setOutputDimensions({context.getInputDimensions()[0]});
}

void DivideLayer::forwarding_operation(const Tensor &input0,
                                       const Tensor &input1, Tensor &hidden) {
  input0.divide(input1, hidden);
}

void DivideLayer::calcDerivative(RunLayerContext &context) {
  context.getOutgoingDerivative(0).copy(
    context.getIncomingDerivative(SINGLE_INOUT_IDX)
      .divide(context.getInput(1)));

  const Tensor &incoming = context.getIncomingDerivative(SINGLE_INOUT_IDX);
  const Tensor &numerator = context.getInput(0);
  const Tensor &denominator = context.getInput(1);

  // Widen the intermediate products for the equal-shape FP32 path.
  // Products of finite FP32 inputs fit in double, even when b*b or g*a
  // would overflow or underflow in FP32 while the final derivative fits.
  if (incoming.getDataType() == TensorDim::DataType::FP32 &&
      numerator.getDataType() == TensorDim::DataType::FP32 &&
      denominator.getDataType() == TensorDim::DataType::FP32 &&
      incoming.getDim() == numerator.getDim() &&
      incoming.getDim() == denominator.getDim() && incoming.getContiguous() &&
      numerator.getContiguous() && denominator.getContiguous()) {
    incoming.checkContextCompatibility(numerator, "divide derivative");
    Tensor derivative(incoming.getDim(), true);
    incoming.inheritContextTo(derivative);
    const float *g = incoming.getData<float>();
    const float *a = numerator.getData<float>();
    const float *b = denominator.getData<float>();
    float *result = derivative.getData<float>();
    for (size_t i = 0; i < incoming.size(); ++i) {
      if (std::isfinite(g[i]) && std::isfinite(a[i]) && std::isfinite(b[i]) &&
          b[i] != 0.0f) {
        const double divisor = b[i];
        result[i] =
          static_cast<float>(-static_cast<double>(g[i]) *
                             static_cast<double>(a[i]) / (divisor * divisor));
      } else {
        result[i] = (g[i] * -a[i]) / std::pow(b[i], 2.0f);
      }
    }
    context.getOutgoingDerivative(1).copy(derivative);
    return;
  }

  context.getOutgoingDerivative(1).copy(
    incoming.multiply(numerator.multiply(-1)).divide(denominator.pow(2)));
}

void DivideLayer::setProperty(const std::vector<std::string> &values) {
  auto remain_props = loadProperties(values, divide_props);
  if (!remain_props.empty()) {
    std::string msg = "[DivideLayer] Unknown Layer Properties count " +
                      std::to_string(values.size());
    throw exception::not_supported(msg);
  }
}
} /* namespace nntrainer */
