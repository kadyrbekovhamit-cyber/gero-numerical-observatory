// SPDX-License-Identifier: Apache-2.0
// Independent preliminary probe; not a publication or an upstream test.
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
#include <divide_layer.h>
#include <layer_context.h>
#include <var_grad.h>

void number(long double v) {
  if (std::isnan(v)) std::cout << "\"NaN\"";
  else if (std::isinf(v)) std::cout << (v > 0 ? "\"Infinity\"" : "\"-Infinity\"");
  else std::cout << std::setprecision(18) << v;
}

int main() {
  const std::vector<float> a = {1, 2, 1e20f, 1e-30f, -1e20f, -1e-30f, 0, 0};
  const std::vector<float> b = {1, 4, 1e20f, 1e-30f, 1e20f, 1e-30f, 1e20f, 1e-30f};
  std::cout << "[";
  bool first = true;
  for (const auto &dim : {nntrainer::TensorDim({1, 1, 1, 8}),
                          nntrainer::TensorDim({2, 1, 2, 2})}) {
    for (float g : {0.0f, 1.0f, -3.0f}) {
      nntrainer::DivideLayer layer;
      nntrainer::InitLayerContext init({dim, dim}, {true}, false, "divide_triage");
      layer.finalize(init);
      nntrainer::Var_Grad left(dim, nntrainer::Initializer::NONE, true, true, "left");
      nntrainer::Var_Grad right(dim, nntrainer::Initializer::NONE, true, true, "right");
      nntrainer::Var_Grad output(dim, nntrainer::Initializer::NONE, true, true, "out");
      nntrainer::RunLayerContext context("divide_triage", true, 0.0f, false, 1.0f,
                                        nullptr, false, {}, {&left, &right}, {&output}, {});
      for (size_t i = 0; i < a.size(); ++i) {
        left.getVariableRef().getData<float>()[i] = a[i];
        right.getVariableRef().getData<float>()[i] = b[i];
        output.getGradientRef().getData<float>()[i] = g;
      }
      layer.forwarding(context, true);
      layer.calcDerivative(context);
      for (size_t i = 0; i < a.size(); ++i) {
        if (!first) std::cout << ",";
        first = false;
        std::cout << "{\"batch\":" << dim.batch() << ",\"index\":" << i << ",\"a\":";
        number(a[i]); std::cout << ",\"b\":"; number(b[i]);
        std::cout << ",\"g\":"; number(g);
        std::cout << ",\"y\":"; number(output.getVariableRef().getData<float>()[i]);
        std::cout << ",\"da\":"; number(left.getGradientRef().getData<float>()[i]);
        std::cout << ",\"db\":"; number(right.getGradientRef().getData<float>()[i]);
        std::cout << ",\"expected_y\":"; number((long double)a[i] / b[i]);
        std::cout << ",\"expected_da\":"; number((long double)g / b[i]);
        std::cout << ",\"expected_db\":"; number(-(long double)g * a[i] / ((long double)b[i] * b[i]));
        std::cout << ",\"inputs_preserved\":"
                  << ((left.getVariableRef().getData<float>()[i] == a[i] &&
                       right.getVariableRef().getData<float>()[i] == b[i] &&
                       output.getGradientRef().getData<float>()[i] == g) ? "true" : "false") << "}";
      }
    }
  }
  std::cout << "]\n";
}
