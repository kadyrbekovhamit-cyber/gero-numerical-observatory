"""Restore immutable baseline source from the compact archives, refusing overwrite."""
from pathlib import Path
import tarfile
R=Path(__file__).resolve().parent;S=R/'work/nntrainer'
if S.exists():raise SystemExit('work/nntrainer already exists; use a new extraction directory')
S.mkdir(parents=True)
for filename,target in [('nntrainer-build-source.tar.gz',S),('googletest-source.tar.gz',S/'subprojects/googletest'),('iniparser-source.tar.gz',S/'subprojects/iniparser')]:
 target.mkdir(parents=True,exist_ok=True)
 with tarfile.open(R/'evidence'/filename) as archive:archive.extractall(target,filter='data')
print('Baseline source restored. Python 3.12+ is required by this extraction helper.')
