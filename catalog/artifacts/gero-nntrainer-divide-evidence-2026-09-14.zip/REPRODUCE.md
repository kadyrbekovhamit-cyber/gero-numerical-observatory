# Reproduce the actual C++ DivideLayer audit

Recorded environment: macOS 15.5 arm64, Apple Clang 17, Meson 1.12.0, Ninja 1.13.2, CPU FP32, BLAS disabled, one worker. The supplied build script is configured for this recorded macOS environment; Linux/device builds have not been validated. Use Python 3.12 or newer for archive extraction. No model downloads, proprietary records or external inference API are needed.

The compact `evidence/nntrainer-build-source.tar.gz` preserves the pinned source except the explicitly listed large, unrelated assets in `omitted-source-assets.json`. The untouched original full archive hash is recorded in `source-archives.json`. Both required submodule archives are supplied. Original and candidate C++ files, raw outputs and test XML are already present if building is inconvenient.

From a new extraction of the evidence ZIP (with no existing `work/nntrainer`):

```sh
python3 restore_sources.py
# Put meson, ninja and clang on PATH, or set NNTRAINER_TOOLS to their bin directory.
python3 generate_inputs.py
python3 build.py baseline
python3 run_validation.py baseline
patch -d work/nntrainer -p1 < candidate.patch
python3 build.py candidate
python3 run_validation.py candidate
work/nntrainer/build/test/unittest/layers/unittest_layers --gtest_filter='*Divide*:*divide*'
python3 mutation_check.py
```

Expected failing-input counts: original 1,302; candidate 0; restored original 1,302; restored candidate 0. Expected focused tests: candidate 25 pass; mutation three new tests fail; restored candidate 25 pass. The mutation script restores the candidate in a `finally` block.

`evidence/divide_audit.cpp` constructs the real layer. It reads a count followed by uint32 bit patterns of `(a,b,g)` from `inputs.txt`. Each output row is `shape repeat input_index forward_bits da_bits db_bits input_bits_unchanged`. The three shapes are `[1,1,1,4096]`, `[2,1,1,2048]`, `[4,2,8,64]`. Expected values are independently computed in `generate_inputs.py`; the probe never receives them.

For the two headline examples, inspect input indices 0 and 1 in `inputs.json` and rows with shape 0/repeat 0 in the raw TSV. Index 3 checks a zero incoming gradient with a nonzero tiny denominator. Index 2 additionally checks zero numerator and zero incoming gradient.

The exact original run commands and local paths are retained in `commands.jsonl` and mode summaries. Those historical paths identify the recording environment; the runnable scripts resolve their source/build directory relative to the extracted package. Each validation run recompiles the probe and links the newly built local library.

`finalize_evidence.py` additionally checks the source manifest and oracle. The compact package intentionally omits 17 large unrelated assets listed in `omitted-source-assets.json`; the checker permits only those documented omissions. The original `VALIDATION_SUMMARY.json` records the full-tree comparison. Required Meson test datasets remain included, even though the focused tests do not consume them.

Scope: focused Divide layer tests only. No full-suite, FP16, broadcast-gradient, accelerator, performance or complete-model validation is claimed.
