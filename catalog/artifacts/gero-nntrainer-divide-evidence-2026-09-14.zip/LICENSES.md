# Rights and attribution

Original GERO report, diagrams and authored narration: CC BY 4.0, Xamit Kadirbekov, 2026. Original GERO probe and orchestration code: MIT, Copyright (c) 2026 Xamit Kadirbekov. Permission is granted to use, copy, modify, merge, publish, distribute, sublicense and/or sell copies, subject to retaining this notice. THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT; authors are not liable for claims or damages arising from its use.

nntrainer source and derived candidate patch retain Apache-2.0 and original copyright/notices, supplied inside the source archive. googletest retains its BSD-3-Clause license; iniparser retains its MIT license. Source subdirectories can contain additional third-party notices; those remain supplied and govern their respective files. No claim of ownership of upstream code is made. Root report licensing does not override third-party licenses.

No third-party footage, music or cloned personal voice is used. English narration uses preset Microsoft Jenny Neural through edge-tts, an online-service client. The client license does not imply ownership of Microsoft's synthesis service. AI-assisted preparation is disclosed. Only public report narration text is submitted for synthesis.
