from pathlib import Path
import subprocess,os,json,datetime,sys
R=Path(__file__).resolve().parent;S=R/'work/nntrainer';E=R/'evidence';L=E/'logs';L.mkdir(exist_ok=True)
env=os.environ.copy();local_tools=Path('/Users/khamit/Documents/math/software-audits/current-stack-2026-09-07/.venv/bin')
tool_path=env.get('NNTRAINER_TOOLS',str(local_tools) if local_tools.is_dir() else '')
if tool_path:env['PATH']=tool_path+os.pathsep+env['PATH']
env['PYTHONDONTWRITEBYTECODE']='1'
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[n]='1'
def run(args,name):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (L/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 with (E/'commands.jsonl').open('a') as f:f.write(json.dumps({'args':args,'cwd':str(S),'started_at':start,'exit_code':p.returncode,'log':name+'.log'})+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode:print((L/(name+'.log')).read_text()[-5000:]);sys.exit(p.returncode)
mode=sys.argv[1]
if not (S/'build/build.ninja').exists():
 flags=['-Denable-blas=false','-Denable-app=false','-Denable-ccapi=true','-Denable-capi=disabled','-Dml-api-support=disabled','-Denable-tflite-backbone=false','-Denable-tflite-interpreter=false','-Denable-nnstreamer-tensor-filter=disabled','-Denable-nnstreamer-tensor-trainer=disabled','-Denable-test=true','-Dnntr-num-threads=1','-Dwerror=false','-Dthread-backend=none','-Dcpp_args='+repr(['-include',str(E/'nntrainer-darwin-build.h')])]
 run(['meson','setup','build']+flags,'configure');(S/'build/nntrainer/malloc.h').write_text('#include <malloc/malloc.h>\n')
run(['ninja','-C','build','-j1','test/unittest/layers/unittest_layers'],'build-'+mode)
