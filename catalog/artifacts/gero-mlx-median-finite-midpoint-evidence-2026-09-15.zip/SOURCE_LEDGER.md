# Source and claim ledger

Prepared 15 September 2026, before English narration. All quantitative claims below derive from the archived native CPU evidence, not from chatbot responses.

| Claim | Classification and evidence |
| --- | --- |
| The median of two copies of exactly representable 60000 is 60000 | Mathematical identity; `reproduction/minimal.cpp` and `reproduction/verified-run/output/minimal-baseline.csv`. |
| Actual MLX float16 output is infinity for two copies and 60000 for three | Executed native C++ CPU result at pin d9add9d11f3154111a4c85f267ec2fd307ecd18e. Apple MLX names the public library, not deployment on Apple devices. |
| 540 → 0 → 540 incorrect outputs among 7488 observations of 624 base vectors | Recorded complete clean CPU build, exact stored-value rational oracle and three raw grid CSVs. Later publication work did not execute a new numerical grid. |
| 6948 previously passing observations and 36 separate controls unchanged | Recorded byte comparisons; the controls partly overlap the main grid. |
| Latest reviewed main retains the implementation | Main 8f76a0aa2bbf9c29698337078db333c9bea1c1bf has byte-identical complete ops.cpp. That later full tree was not executed. Release v0.32.2 median source was also reviewed, but its runtime was not executed. |
| Earlier work and duplicate review | NumPy issue 22688 is credited as an established analogue. Refreshed bounded MLX search returned the same 84 title/body records, including four median-specific records. Canonical catalog had 96 prior materials and no exact median report. This does not establish global novelty. |
| Limits | CPU forward only. No GPU, autodiff, compiled graph, performance, full upstream suite or real application impact claim. |

Primary sources: [MLX median documentation](https://ml-explore.github.io/mlx/build/html/python/_autosummary/mlx.core.median.html), [executed source](https://github.com/ml-explore/mlx/blob/d9add9d11f3154111a4c85f267ec2fd307ecd18e/mlx/ops.cpp), [release source](https://github.com/ml-explore/mlx/blob/1f8e74e3f12f31365464a6867c6579f0e9b29d85/mlx/ops.cpp), [NumPy 22688](https://github.com/numpy/numpy/issues/22688), [initial MLX implementation](https://github.com/ml-explore/mlx/pull/2705), [NaN correction](https://github.com/ml-explore/mlx/pull/4146).

Original GERO graphics, no borrowed footage, music or human avatar. Synthetic English narration: edge-tts 7.2.8, en-US-JennyNeural, rate -3%. Only authored narration is sent to the synthesis service. No audio or video playback under the user's standing instruction: verify full decode, images, actual word boundaries and independent ASR. No human listening claim.
