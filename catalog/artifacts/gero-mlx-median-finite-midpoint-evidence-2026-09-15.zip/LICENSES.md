# Attribution and licenses

Independent numerical audit and reproduction preparation: Xamit Kadirbekov /
GERO Research, with AI assistance. Original explanatory text is CC BY 4.0.
Original audit scripts and probes are MIT licensed; see `AUDIT_LICENSE.txt`.

MLX source and the derived candidate retain Apple's MIT license and notices
inside the pinned archive. The json and fmt archives retain their MIT
licenses. gguf-tools retains its original license and notices in its archive.
No blanket relicensing of bundled third-party content is intended.

The evidence describes local native CPU execution and a candidate correction.
It does not imply vendor endorsement, maintainer acceptance or peer review.
