# MLX finite-median midpoint overflow — GERO evidence

Read REPORT_EN.md for the bounded finding, SOURCE_LEDGER.md for claims and REPRODUCE.md for the offline native CPU runner. The reproduction/ directory retains all 53 original portable-package members unchanged. Reports are CC BY 4.0; original scripts are MIT; third-party licenses remain intact. No upstream acceptance or real application impact is claimed.
