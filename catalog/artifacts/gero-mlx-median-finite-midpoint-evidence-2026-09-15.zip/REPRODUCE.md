# Offline native CPU reproduction

Unzip the evidence archive. From its `reproduction` directory run:

```sh
python3 reproduce.py --work-dir ../median-clean-run
```

Requires macOS arm64, Python 3.9+, C++20 Apple developer tools, CMake 3.25+, Ninja and patch. The runner uses one compiler job and one thread per numerical library. Its exact source and dependency archives are included; no network or Python MLX installation is required.

See `reproduction/README.md` for paths and resume options. A full clean run has already completed and is recorded in `reproduction/verified-run/`: 540 → 0 → 540 incorrect outputs in 7488 observations. All 951 original source hashes and five expected CSV files matched. This publication package preserves all 53 files of that earlier portable archive byte for byte. Packaging checks do not constitute another full numerical run.

The top-level REPORT_EN.md updates the source-review date and catalog count. Older reports and provenance inside reproduction/ remain unchanged as historical execution records. No GPU, autodiff, full-suite, released-runtime or application-impact run is claimed.
