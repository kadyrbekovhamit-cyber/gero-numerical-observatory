# Reproduce the MLX finite-median range failure

This directory is a self-contained, offline source reproduction for macOS
arm64. It includes the pinned MLX source archive and its three CPU-build
dependencies (json, fmt and gguf-tools). Archive URLs and SHA-256 hashes are in
`VENDOR_LOCK.json`; their original licenses remain inside each archive.

Prerequisites: Python 3.9 or newer, Apple command-line developer tools with a
C++20 compiler, CMake 3.25 or newer, Ninja, and the standard `patch` command.
No Python MLX package, GPU, previous object files or previous static library is
used. No package installation or network request is made by the runner.

Run from this directory, choosing a new directory for generated files:

```sh
python3 reproduce.py --work-dir ../median-clean-run
```

If CMake and Ninja are outside PATH, pass `--cmake /path/to/cmake` and
`--ninja /path/to/ninja`. An interrupted run can continue with `--resume` and
the same work directory. The script never deletes an existing directory.

The runner checks the archive hashes, extracts and verifies all 951 pinned
source files, and configures a Release CPU-only build with the GPU backends,
Python bindings, examples and upstream test suite disabled. It compiles one
job at a time, with numerical library thread limits set to one. It builds
the original library from source. The candidate recompiles only `mlx/ops.cpp`
with the same recorded compiler flags and links that replacement object ahead
of the new archive. The mutation links the freshly compiled original object
in the same position. The source tree is checked again afterwards.

The minimal example, 7,488-row selected grid and separate 36-row controls run
sequentially on all three variants. `check_grid.py` computes the expected
median with exact rational arithmetic and explicit rounding. Successful
reproduction requires 540 -> 0 -> 540 grid failures, byte-identical baseline
and mutation output, unchanged special controls, and agreement with every
archived CSV in `expected/`. It writes:

- `CLEAN_REPRODUCTION_RECEIPT.json`: checked results and provenance;
- `commands.json` and `logs/`: actual commands, build logs and exit statuses;
- `output/`: new raw CSVs and exact-oracle summaries.

Counts describe repeated observations of 624 base vectors, not independent
data sets. This runner does not execute a separately tagged MLX release, the
complete upstream suite, GPU, autodiff, compiled graphs, performance tests or
applications. The candidate can still evaluate an unused overflowing branch;
the checked property is the selected forward output. See `RESULTS_EN.md` for
the bounded finding and established midpoint-overflow prior work.

A completed clean run, with all five archived CSVs reproduced byte-for-byte,
is included in `verified-run/`. The initial incremental evidence remains in
`evidence/`; read the dated clean-build receipt for the later execution.
`SHA256SUMS` covers every other file in this package.
