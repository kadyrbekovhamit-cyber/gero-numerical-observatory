#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;
std::vector<float> read(mx::array a) {
  a=mx::contiguous(mx::astype(a,mx::float32)); mx::eval(a);
  return {a.data<float>(),a.data<float>()+a.size()};
}
int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << "case,dtype,length,layout,keepdims,output_index,output_bits,input_bits\n";
  int id=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16}) {
    float maxv=dtype==mx::float16?65504.f:dtype==mx::bfloat16?
      std::bit_cast<float>(uint32_t(0x7f7f0000)):std::numeric_limits<float>::max();
    float prev=dtype==mx::float16?65472.f:dtype==mx::bfloat16?
      std::bit_cast<float>(uint32_t(0x7f7e0000)):std::nextafter(maxv,0.f);
    float tiny=std::ldexp(1.f,dtype==mx::float16?-24:dtype==mx::bfloat16?-133:-149);
    float normal=std::ldexp(1.f,dtype==mx::float16?-14:-126);
    std::vector<float> palette={0,tiny,2*tiny,3*tiny,1,-1,maxv/2,maxv,prev,-maxv/2,-maxv,normal,-normal};
    std::vector<std::vector<float>> cases;
    for(size_t i=0;i<palette.size();++i) {
      cases.push_back({palette[i]}); cases.push_back({palette[i],palette[i],palette[i]});
      for(size_t j=i;j<palette.size();++j) {
        cases.push_back({palette[i],palette[j]});
        cases.push_back({-maxv,palette[i],palette[j],maxv});
      }
    }
    for(auto values:cases) {
      int n=values.size();auto base=mx::astype(mx::array(values.data(),{n}),dtype);
      auto actual=read(base);
      for(int layout=0;layout<4;++layout) for(bool keep:{false,true}) {
        auto x=base;
        if(layout) x=mx::stack({base,mx::flip(base)});
        if(layout==2) x=mx::transpose(x);
        auto out=layout==1?mx::median(x,1,keep):layout==2?mx::median(x,0,keep):mx::median(x,keep);
        if(out.dtype()!=dtype) return 3;
        auto result=read(out);
        if(result.size()!=((layout==1||layout==2)?2:1)) return 4;
        auto logical=actual;
        if(layout==3) logical.insert(logical.end(),actual.begin(),actual.end());
        for(size_t k=0;k<result.size();++k) {
          std::cout<<id<<','<<dtype<<','<<n<<','<<layout<<','<<keep<<','<<k<<','<<std::bit_cast<uint32_t>(result[k])<<',';
          for(size_t j=0;j<logical.size();++j) {if(j)std::cout<<';';std::cout<<std::bit_cast<uint32_t>(logical[j]);}
          std::cout<<'\n';
        }
      }
      ++id;
    }
  }
}
