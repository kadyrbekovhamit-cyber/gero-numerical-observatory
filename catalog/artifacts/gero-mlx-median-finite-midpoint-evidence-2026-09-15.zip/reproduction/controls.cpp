#include <bit>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <vector>
#include "mlx/mlx.h"
namespace mx=mlx::core;
int main() {
  mx::set_default_device(mx::Device::cpu);
  float inf=std::numeric_limits<float>::infinity(),nan=std::numeric_limits<float>::quiet_NaN();
  int id=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16}) {
    for(auto values:std::vector<std::vector<float>>{{nan,1},{1,nan,3},{inf,inf},{-inf,-inf},{-inf,inf},{1,inf},{-inf,1},{-0.f,0.f},{0,0},{1,2}}) {
      auto x=mx::astype(mx::array(values.data(),{int(values.size())}),dtype);
      auto y=mx::astype(mx::median(x),mx::float32);mx::eval(y);
      std::cout<<id++<<','<<dtype<<','<<std::bit_cast<uint32_t>(y.item<float>())<<'\n';
    }
  }
  for(auto values:std::vector<std::vector<int>>{{0,0},{1,2},{-3,-2},{-3,0,3},{10000,10001},{-2147483647,2147483647}}) {
    auto y=mx::median(mx::array(values.data(),{int(values.size())}));mx::eval(y);
    if(y.dtype()!=mx::float32)return 3;
    std::cout<<id++<<",int32,"<<std::bit_cast<uint32_t>(y.item<float>())<<'\n';
  }
}
