#include <iomanip>
#include <iostream>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;
int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << std::setprecision(9);
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    float value = dtype == mx::float16 ? 60000.f : 2e38f;
    for (int n : {1, 2, 3, 4}) {
      std::vector<float> values(n,value);
      auto x=mx::astype(mx::array(values.data(), {n}),dtype);
      auto m=mx::astype(mx::median(x),mx::float32);
      auto first=mx::astype(mx::take(x,mx::array(0)),mx::float32);
      mx::eval(m,first);
      std::cout << dtype << ',' << n << ',' << first.item<float>()
                << ',' << m.item<float>() << '\n';
    }
  }
}
