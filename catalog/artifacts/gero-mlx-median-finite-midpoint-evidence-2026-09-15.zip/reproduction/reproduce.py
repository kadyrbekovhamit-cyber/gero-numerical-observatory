"""Build pinned CPU MLX from bundled source; preserve original evidence."""
import argparse
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
PIN = 'd9add9d11f3154111a4c85f267ec2fd307ecd18e'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def extract(archive, destination):
    destination.mkdir(parents=True, exist_ok=True)
    assert not any(destination.iterdir()), destination
    with tarfile.open(archive) as tf:
        for item in tf.getmembers():
            target = (destination / item.name).resolve()
            assert target.is_relative_to(destination.resolve()), item.name
            assert item.isfile() or item.isdir() or item.issym() or item.islnk(), item.name
            if item.issym() or item.islnk():
                link = (target.parent / item.linkname if item.issym() else destination / item.linkname).resolve()
                assert link.is_relative_to(destination.resolve()), item.name
        tf.extractall(destination)
    directories = [p for p in destination.iterdir() if p.is_dir()]
    assert len(directories) == 1, archive
    return directories[0]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir', type=Path, required=True)
    parser.add_argument('--cmake', default='cmake')
    parser.add_argument('--ninja', default='ninja')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    assert platform.system() == 'Darwin' and platform.machine() == 'arm64'
    work = args.work_dir.resolve()
    assert work != ROOT and not ROOT.is_relative_to(work)
    if work.exists():
        assert args.resume and (work / 'run-state.json').is_file(), 'Choose a new work directory or use --resume after an interrupted run.'
    else:
        work.mkdir(parents=True)
        dump(work / 'run-state.json', {'phase': 'started', 'source_pin': PIN})
    logs = work / 'logs'
    output = work / 'output'
    logs.mkdir(exist_ok=True)
    output.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', CMAKE_BUILD_PARALLEL_LEVEL='1')
    commands = []
    commands_path = work / 'commands.json'
    if commands_path.exists():
        commands = json.loads(commands_path.read_text())

    def run(argv, label, cwd=work, result=None):
        argv = list(map(str, argv))
        logfile = result or (logs / (label + '.log'))
        record = {'label': label, 'argv': argv, 'cwd': str(cwd), 'output': str(logfile)}
        print(label, flush=True)
        with logfile.open('wb') as stream:
            p = subprocess.run(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record['exit_code'] = p.returncode
        commands.append(record)
        dump(commands_path, commands)
        if p.returncode:
            raise RuntimeError(f'{label} failed ({p.returncode}); see {logfile}')

    lock = json.loads((ROOT / 'VENDOR_LOCK.json').read_text())
    roots = {}
    for item in lock['archives']:
        path = ROOT / 'vendor' / item['file']
        assert sha(path) == item['sha256'], path
        destination = work / ('source-' + item['name'])
        if destination.exists() and any(destination.iterdir()):
            assert args.resume
            roots[item['name']] = next(p for p in destination.iterdir() if p.is_dir())
        else:
            roots[item['name']] = extract(path, destination)
    source = roots['mlx']
    manifest = json.loads((ROOT / 'source-manifest.json').read_text())

    def verify_source():
        files = {p.relative_to(source).as_posix(): sha(p) for p in source.rglob('*') if p.is_file()}
        assert files == manifest, 'Pinned source tree changed.'
        return len(files)

    verify_source()
    candidate = work / 'candidate'
    (candidate / 'mlx').mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / 'mlx/ops.cpp', candidate / 'mlx/ops.cpp')
    run(['patch', '--batch', '-p1', '-i', ROOT / 'candidate.patch'], 'apply-candidate', cwd=candidate)
    build = work / 'build'
    cmake = shutil.which(args.cmake)
    ninja = shutil.which(args.ninja)
    assert cmake and ninja, 'Install CMake 3.25+ and Ninja or pass their paths.'
    config = [cmake, '-S', ROOT, '-B', build, '-G', 'Ninja', f'-DCMAKE_MAKE_PROGRAM={ninja}',
        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        f'-DMLX_SOURCE_DIR={source}', f'-DFETCHCONTENT_SOURCE_DIR_JSON={roots["json"]}',
        f'-DFETCHCONTENT_SOURCE_DIR_FMT={roots["fmt"]}', f'-DFETCHCONTENT_SOURCE_DIR_GGUFLIB={roots["gguflib"]}',
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON',
        '-DMLX_BUILD_TESTS=OFF', '-DMLX_BUILD_EXAMPLES=OFF', '-DMLX_BUILD_BENCHMARKS=OFF',
        '-DMLX_BUILD_PYTHON_BINDINGS=OFF', '-DMLX_BUILD_METAL=OFF', '-DMLX_BUILD_CUDA=OFF',
        '-DMLX_BUILD_CPU=ON', '-DMLX_USE_CCACHE=OFF', '-DBUILD_SHARED_LIBS=OFF']
    run(config, 'configure-clean-source')
    run([cmake, '--build', build, '--parallel', '1', '--target', 'median_minimal_baseline', 'median_grid_baseline', 'median_controls_baseline'], 'build-baseline')
    compiles = json.loads((build / 'compile_commands.json').read_text())
    ops = next(x for x in compiles if Path(x['file']) == source / 'mlx/ops.cpp')
    command = ops.get('arguments') or shlex.split(ops['command'])
    command = list(command)
    command[command.index('-o') + 1] = str(build / 'candidate-ops.o')
    command[command.index('-c') + 1] = str(candidate / 'mlx/ops.cpp')
    run(command, 'build-candidate-object', cwd=Path(ops['directory']))
    targets = ['median_' + p + '_' + v for v in ['candidate', 'mutation'] for p in ['minimal', 'grid', 'controls']]
    run([cmake, '--build', build, '--parallel', '1', '--target', *targets], 'link-candidate-and-mutation')
    for variant in ['baseline', 'candidate', 'mutation']:
        for probe in ['minimal', 'grid', 'controls']:
            name = variant + '.csv' if probe == 'grid' else probe + '-' + variant + '.csv'
            run([build / ('median_' + probe + '_' + variant)], probe + '-' + variant, result=output / name)
        run([sys.executable, ROOT / 'check_grid.py', output / (variant + '.csv')], 'check-' + variant)
    summaries = {v: json.loads((output / (v + '.summary.json')).read_text()) for v in ['baseline', 'candidate', 'mutation']}
    for variant, failures in [('baseline', 540), ('candidate', 0), ('mutation', 540)]:
        assert summaries[variant]['exact_rounded_failures'] == failures
        assert summaries[variant]['observations'] == 7488
    assert (output / 'baseline.csv').read_bytes() == (output / 'mutation.csv').read_bytes()
    for variant in ['baseline', 'candidate', 'mutation']:
        assert (output / ('controls-' + variant + '.csv')).read_bytes() == (output / 'controls-baseline.csv').read_bytes()
    checked = []
    for path in (ROOT / 'expected').glob('*.csv'):
        assert (output / path.name).read_bytes() == path.read_bytes(), path.name
        checked.append(path.name)
    receipt = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_pin': PIN,
        'fresh_complete_cpu_library_build': True, 'previous_library_or_object_reused': False,
        'source_files_unchanged': verify_source(), 'compiler': subprocess.check_output([command[0], '--version'], text=True),
        'cmake_version': subprocess.check_output([cmake, '--version'], text=True),
        'ninja_version': subprocess.check_output([ninja, '--version'], text=True).strip(),
        'thread_environment': {k: env[k] for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']},
        'library_sha256': sha(build / 'mlx-build/libmlx.a'), 'candidate_source_sha256': sha(candidate / 'mlx/ops.cpp'),
        'build_jobs': 1, 'gpu_tested': False, 'full_upstream_suite_run': False,
        'summaries': summaries, 'previous_csvs_byte_reproduced': checked,
        'output_sha256': {p.name: sha(p) for p in output.glob('*.csv')}, 'dependency_archives': lock['archives']}
    dump(work / 'CLEAN_REPRODUCTION_RECEIPT.json', receipt)
    dump(work / 'run-state.json', {'phase': 'complete', 'receipt': 'CLEAN_REPRODUCTION_RECEIPT.json'})
    print(json.dumps({'complete': True, 'failure_counts': [540, 0, 540], 'prior_csvs_matched': checked, 'source_files_unchanged': len(manifest)}, indent=2))

if __name__ == '__main__':
    main()
