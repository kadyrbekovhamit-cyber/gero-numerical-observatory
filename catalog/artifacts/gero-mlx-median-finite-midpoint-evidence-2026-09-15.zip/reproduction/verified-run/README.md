# Verified clean run

This directory records the completed macOS arm64 CPU run at 04:01 UTC on
15 September 2026. The full baseline library was built from bundled source;
no earlier audit library or object was used. Candidate and mutation link
against that newly built library. The five historical grid/control CSVs are
byte-identical to their fresh counterparts here.

Absolute local workspace paths in commands, logs and provenance copies are
replaced with `<WORK_DIR>`, `<BUNDLE_DIR>`, `<AUDIT_ROOT>`, `<BUILD_TOOLS>` and
`<USER_HOME>`. Raw numerical CSVs are copied without modification. Compiler
and library hashes describe this machine and need not match a different build.

Setup history is retained in commands.json: the first configure attempt failed
because the offline gguf-tools dependency had not yet been included. The
runner was updated to include it, then configuration, all compilation and all
numerical checks passed. That configure log filename was reused, so the
packaged configure log is the successful attempt. An earlier extraction guard
was also adjusted to allow the upstream archive's safe internal symlink before
building. No numerical result was obtained from either failed setup attempt.

The receipt's MLX archive URL has a documented metadata correction to the exact
codeload URL, verified by a fresh matching download. Archive bytes, source
manifest and results are unchanged. Other evidence records distinguish the
initial incremental run from this later complete clean build.
