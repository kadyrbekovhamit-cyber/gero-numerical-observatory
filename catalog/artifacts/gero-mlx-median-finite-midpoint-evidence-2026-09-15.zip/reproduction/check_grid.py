"""Exact-rational median with explicit ties-to-even format rounding."""
from fractions import Fraction
from pathlib import Path
import csv, json, math, struct, sys

def decode(bits):
    return struct.unpack('!f',struct.pack('!I',int(bits)))[0]

def power2(exponent):
    return Fraction(2)**exponent

def rounded(q,dtype):
    if not q:return q
    sign=-1 if q<0 else 1;q=abs(q)
    precision,minimum={'float32':(24,-126),'float16':(11,-14),'bfloat16':(8,-126)}[dtype]
    exponent=q.numerator.bit_length()-q.denominator.bit_length()
    if q<power2(exponent):exponent-=1
    unit=power2(max(exponent-precision+1,minimum-precision+1))
    scaled=q/unit;n,r=divmod(scaled.numerator,scaled.denominator)
    if 2*r>scaled.denominator or (2*r==scaled.denominator and n%2):n+=1
    return sign*n*unit

path=Path(sys.argv[1]);rows=list(csv.DictReader(path.open()))
failed=[];cases=set();counts={};range_fail=0
for row in rows:
    xs=sorted(Fraction.from_float(decode(x)) for x in row['input_bits'].split(';'))
    mid=len(xs)//2;exact=xs[mid] if len(xs)%2 else (xs[mid-1]+xs[mid])/2
    expected=rounded(exact,row['dtype']);actual=decode(row['output_bits'])
    good=math.isfinite(actual) and Fraction.from_float(actual)==expected
    if not good:failed.append(row);cases.add(row['case']);counts[row['dtype']]=counts.get(row['dtype'],0)+1
    if not math.isfinite(actual) or not (xs[0]<=Fraction.from_float(actual)<=xs[-1]):range_fail+=1
summary={'observations':len(rows),'unique_input_cases':len({r['case'] for r in rows}),
    'exact_rounded_failures':len(failed),'failing_unique_input_cases':len(cases),
    'convex_hull_failures':range_fail,'failures_by_dtype':counts,
    'oracle':'Exact Fraction sort/central average, explicit nearest-even target rounding; signed zero ignored.',
    'scope':'Native CPU forward median; layout/keepdims observations reuse the same 624 input vectors.'}
path.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
