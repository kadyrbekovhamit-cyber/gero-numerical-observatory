# Pre-publication packaging correction

The first local prepared ZIP retained hashes for pre-normalized JSON metadata. This edition distinguishes original_workstation_hashes from hashes of the packaged JSON files. Numeric results, tolerances, solver statuses and upstream sources are unchanged. The first prepared archive was never published.
