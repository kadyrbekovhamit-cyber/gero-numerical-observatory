"""Independent round-trip and unit-invariance checks for Merton calibration."""
import argparse
from collections import Counter
import hashlib
import importlib.metadata
import itertools
import json
import math
from pathlib import Path
import sys
import warnings

parser=argparse.ArgumentParser()
parser.add_argument('source',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
sys.path.insert(0,str(args.source.resolve()))
import numpy as np
from scipy import optimize
from financepy.models.merton_firm_mkt import MertonFirmMkt

cdf=lambda z:math.erfc(-z/math.sqrt(2))/2
scales=[1e-6,1e-3,1.0,1e3,1e6]
tol={'relative_parameters_and_repricing':2e-5,'absolute_default_probability':2e-6,
     'scale_invariance_absolute':2e-6,'batch_invariance_relative':1e-10}
calls=[]
original_minimize=optimize.minimize
def recorded_minimize(*a,**kw):
    result=original_minimize(*a,**kw)
    calls.append({'success':bool(result.success),'status':int(result.status),
                  'message':str(result.message),'fun':float(result.fun),'nit':int(result.nit)})
    return result
optimize.minimize=recorded_minimize

def analytic(A,L,T,R,MU,V):
    d1=(math.log(A/L)+(R+V*V/2)*T)/(V*math.sqrt(T))
    d2=d1-V*math.sqrt(T)
    E=A*cdf(d1)-L*math.exp(-R*T)*cdf(d2)
    return E,A/E*cdf(d1)*V,cdf(-(math.log(A/L)+(MU-V*V/2)*T)/(V*math.sqrt(T)))

def scalar(x):
    v=float(x)
    return v if math.isfinite(v) else str(v)

rows=[]
for case,(ratio,vol,T,R) in enumerate(itertools.product([1.1,1.4,2.0],[0.2,0.4],[0.5,2.0],[-0.01,0.05])):
    A,L,MU=100*ratio,100.0,0.03
    E,VE,PD=analytic(A,L,T,R,MU,vol)
    scalar_rows=[]
    for scale in scales:
        row={'case':case,'scale':scale,'known':{'asset':A,'debt':L,'time':T,'rate':R,'growth':MU,'volatility':vol},
             'expected':{'equity':E,'equity_volatility':VE,'default_probability':PD}}
        with warnings.catch_warnings(record=True) as messages:
            warnings.simplefilter('always')
            try:
                model=MertonFirmMkt(E*scale,L*scale,T,R,MU,VE)
                actual={'asset':float(model.asset_value()[0])/scale,'volatility':float(model.asset_vol()[0]),
                        'default_probability':float(model.prob_default()[0]),
                        'equity':float(model.equity_value()[0])/scale,'equity_volatility':float(model.equity_vol()[0])}
                good_domain=all(math.isfinite(v) for v in actual.values()) and actual['asset']>0 and actual['volatility']>0 and 0<=actual['default_probability']<=1
                checks={'valid_domain':good_domain}
                if good_domain:
                    independent=analytic(actual['asset'],L,T,R,MU,actual['volatility'])
                    checks.update(asset_roundtrip=math.isclose(actual['asset'],A,rel_tol=2e-5,abs_tol=1e-8),
                        vol_roundtrip=math.isclose(actual['volatility'],vol,rel_tol=2e-5,abs_tol=1e-8),
                        default_probability=math.isclose(actual['default_probability'],PD,rel_tol=0,abs_tol=2e-6),
                        independent_equity_repricing=math.isclose(independent[0],E,rel_tol=2e-5,abs_tol=1e-8),
                        independent_vol_repricing=math.isclose(independent[1],VE,rel_tol=2e-5,abs_tol=1e-8))
                row['actual']={k:scalar(v) for k,v in actual.items()}
                row['checks']=checks
                row['passed']=all(checks.values())
            except Exception as e:
                row.update(exception=type(e).__name__,message=str(e),passed=False)
            row['optimizer']=dict(calls[-1]) if calls else None
            row['warnings']=dict(Counter(str(w.message) for w in messages))
        scalar_rows.append(row)
        rows.append(row)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        batch=MertonFirmMkt(np.array([E*s for s in scales]),np.array([L*s for s in scales]),T,R,MU,VE)
    for i,row in enumerate(scalar_rows):
        a=row.get('actual',{})
        row['batch_equivalent']=all(
            (isinstance(a.get(key),float) and math.isclose(a[key],value,rel_tol=1e-10,abs_tol=1e-10)) or
            (a.get(key)==str(value) and not math.isfinite(value))
            for key,value in [('asset',float(batch.asset_value()[i])/scales[i]),
                              ('volatility',float(batch.asset_vol()[i])),
                              ('default_probability',float(batch.prob_default()[i]))])
    ref=scalar_rows[2].get('actual',{})
    for row in scalar_rows:
        a=row.get('actual',{})
        row['scale_equivalent']=all(isinstance(a.get(k),float) and isinstance(ref.get(k),float) and
                math.isclose(a[k],ref[k],rel_tol=2e-5,abs_tol=2e-6)
                for k in ['asset','volatility','default_probability'])

optimize.minimize=original_minimize
summary={'scenarios':len(rows),'economic_parameter_sets':len(rows)//len(scales),
         'failed_roundtrip_scenarios':sum(not r['passed'] for r in rows),
         'failed_scale_comparisons':sum(not r['scale_equivalent'] for r in rows),
         'failed_batch_comparisons':sum(not r['batch_equivalent'] for r in rows),
         'unsuccessful_optimizer_statuses':sum(not r['optimizer']['success'] for r in rows),
         'failures_by_scale':{str(s):sum(not r['passed'] for r in rows if r['scale']==s) for s in scales}}
tested=args.source/'financepy/models/merton_firm_mkt.py'
result={'source':str(args.source.resolve()),'source_sha256':hashlib.sha256(tested.read_bytes()).hexdigest(),
        'tolerances':tol,'dependencies':{x:importlib.metadata.version(x) for x in ['numpy','scipy','numba','llvmlite','pandas']},
        'summary':summary,'rows':rows}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(summary,indent=2))
