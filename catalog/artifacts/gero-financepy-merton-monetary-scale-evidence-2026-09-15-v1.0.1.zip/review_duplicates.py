"""Archive public upstream and GERO catalog checks without publishing."""
import base64
import datetime
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
dest=ROOT/'evidence/duplicate-review'
dest.mkdir(exist_ok=True)
def get(name,endpoint,q=None):
    argv=['gh','api','-X','GET',endpoint]
    if q: argv+=['-f','q='+q,'-f','per_page=100']
    d=json.loads(subprocess.check_output(argv,text=True))
    (dest/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
    return d
head=get('current-master','repos/domokane/FinancePy/commits/master')
queries=['repo:domokane/FinancePy Merton', 'repo:domokane/FinancePy "MertonFirmMkt"',
         'repo:domokane/FinancePy "monetary"', 'repo:domokane/FinancePy "scale" "calibration"',
         'repo:domokane/FinancePy "minimize"', '"FinancePy" "Merton" "calibration"']
results=[]
for i,q in enumerate(queries):
    d=get('search-%02d'%i,'search/issues',q)
    results.append({'query':q,'total_count':d['total_count'], 'incomplete_results':d.get('incomplete_results'),
        'items':[{'number':x['number'],'title':x['title'],'url':x['html_url']} for x in d['items']]})
d=get('github-catalog-envelope','repos/kadyrbekovhamit-cyber/gero-numerical-observatory/contents/catalog/publications.json')
catalog=json.loads(base64.b64decode(d['content']))
(dest/'github-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
items=catalog if isinstance(catalog,list) else catalog.get('publications',[])
report={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head['sha'],
        'same_pin':head['sha']=='2b9227fea9d832c4033421d6cd53a54316414fca', 'queries':results,
        'gero_catalog_count':len(items),'gero_merton_matches':[x for x in items if 'merton' in str(x).lower()]}
(ROOT/'evidence/duplicate-review-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
