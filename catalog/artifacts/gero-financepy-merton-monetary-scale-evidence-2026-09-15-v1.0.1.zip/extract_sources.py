"""Verify and unpack bundled sources; Python 3.12+. No network."""
from pathlib import Path
import hashlib, json, tarfile, zipfile
P=Path(__file__).resolve().parent
s=json.loads((P/'SOURCE.json').read_text());a=P/'financepy-source.tar.gz'
assert hashlib.sha256(a.read_bytes()).hexdigest()==s['archive_sha256']
w=P/'downloads/financepy-1.1.2-py3-none-any.whl'
r=json.loads((P/'evidence/release-provenance.json').read_text())
assert hashlib.sha256(w.read_bytes()).hexdigest()==r['sha256']
assert not (P/'source').exists() and not (P/'release').exists(), 'Use a fresh directory'
(P/'source').mkdir();(P/'release').mkdir()
with tarfile.open(a) as t:t.extractall(P/'source',filter='data')
with zipfile.ZipFile(w) as z:z.extractall(P/'release')
print('Pinned source and released wheel verified and extracted.')
