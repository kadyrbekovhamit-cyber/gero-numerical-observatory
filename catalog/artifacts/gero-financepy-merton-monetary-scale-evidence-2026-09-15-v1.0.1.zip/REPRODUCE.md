# Reproduce the Merton monetary-unit check

Use Python 3.12 on macOS arm64 for the recorded environment. Create `.venv` and install `environment-requirements.txt`. This pins the packages used by the targeted tests, not every optional FinancePy feature. No API keys or private data are needed.

Run `python3 extract_sources.py` once to verify hashes and extract the bundled source archive and released wheel. This creates `source/` and `release/`. Its prefix is `domokane-FinancePy-2b9227f`; the original upstream commit and archive hash are in `SOURCE.json`. The packaged SOURCE.json uses a relative path; the packaged builder and verifier resolve it against this directory. Unpack the included/downloaded `financepy-1.1.2-py3-none-any.whl` into `release/` for the released-version check.

Set cache and thread controls:

```sh
export PYTHONDONTWRITEBYTECODE=1
export NUMBA_CACHE_DIR="$PWD/numba-cache"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
```

The short standalone illustration:

```sh
.venv/bin/python -B minimal_probe.py source/domokane-FinancePy-2b9227f evidence/minimal-baseline.json
```

The complete targeted experiment:

```sh
.venv/bin/python -B build_candidate.py
.venv/bin/python -B grid_probe.py source/domokane-FinancePy-2b9227f evidence/grid-baseline.json
.venv/bin/python -B grid_probe.py release evidence/grid-release.json
.venv/bin/python -B grid_probe.py variants/candidate evidence/grid-candidate.json
.venv/bin/python -B grid_probe.py variants/mutation evidence/grid-mutation.json
PYTHONPATH=variants/candidate .venv/bin/python -B -m pytest -q -p no:cacheprovider variants/candidate/unit_tests/test_FinModelMerton.py > evidence/candidate-upstream-merton-tests.log 2>&1
.venv/bin/python -B verify_results.py
```

`build_candidate.py` refuses to overwrite existing variants. Run it once in a fresh working copy. The probe wraps SciPy's existing `minimize` only to record its returned status and objective; it forwards the original arguments unchanged. It does not replace FinancePy's equations or bypass its public calibration class.

The verifier requires the original/current, release and mutation rows to be identical; 94 original failures and zero candidate failures under fixed tolerances; no batch mismatches; and an unchanged source manifest. No original mismatch is accepted as a candidate pass by widening a tolerance. Optimizer statuses are retained separately from the numerical checks.

`review_duplicates.py` uses read-only `gh api` requests. It archives its query strings, result counts and the then-current GERO catalog. Its results are dated, not a perpetual novelty guarantee.

## Publication packaging

Only absolute workstation paths in metadata were replaced with `$AUDIT_ROOT`. Numeric rows, tolerances, optimizer statuses, patches and upstream source bytes were preserved. The packaged builder and verifier resolve the relative source path; this does not change the calibration or probes. `SHA256SUMS` covers the complete evidence edition.
