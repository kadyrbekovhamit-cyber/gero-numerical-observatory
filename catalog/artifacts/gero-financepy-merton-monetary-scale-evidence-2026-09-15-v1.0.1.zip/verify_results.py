"""Verify recorded source, release, candidate and mutation evidence."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
data={k:json.loads((ROOT/'evidence'/('grid-'+k+'.json')).read_text())
      for k in ['baseline','release','candidate','mutation']}
for k,d in data.items():
    assert len(d['rows'])==120
    assert d['summary']['economic_parameter_sets']==24
    assert d['summary']['failed_batch_comparisons']==0
    assert d['tolerances']==data['baseline']['tolerances']
assert data['baseline']['summary']['failed_roundtrip_scenarios']==94
assert data['candidate']['summary']['failed_roundtrip_scenarios']==0
assert data['candidate']['summary']['failed_scale_comparisons']==0
assert data['baseline']['rows']==data['mutation']['rows']==data['release']['rows']
assert data['baseline']['source_sha256']==data['mutation']['source_sha256']==data['release']['source_sha256']
source=Path(json.loads((ROOT/'SOURCE.json').read_text())['source'])
if not source.is_absolute(): source=ROOT/source
manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
assert all(hashlib.sha256((source/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
assert '1 passed' in (ROOT/'evidence/candidate-upstream-merton-tests.log').read_text()
result={'baseline_release_mutation_rows_identical':True,'original_source_files_verified':len(manifest),
        'summaries':{k:d['summary'] for k,d in data.items()},
        'candidate_remaining_optimizer_non_success_statuses':data['candidate']['summary']['unsuccessful_optimizer_statuses'],
        'limitation':'Normalization removes the tested monetary-unit dependence; it does not replace BFGS or guarantee convergence outside this grid. Non-success status alone is not used as a numerical accuracy verdict.',
        'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'evidence').glob('grid-*.json')}}
(ROOT/'evidence/paired-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
