"""Test common monetary rescaling of FinancePy's public Merton calibration."""
import argparse
import importlib.metadata
import json
import math
from pathlib import Path
import sys
import warnings

parser = argparse.ArgumentParser()
parser.add_argument('source', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.source.resolve()))
from financepy.models.merton_firm_mkt import MertonFirmMkt

# Independently derive synthetic market observations from known positive parameters.
A, L, T, R, MU, SIGMA = 140.0, 100.0, 1.0, 0.05, 0.05, 0.25
cdf = lambda z: math.erfc(-z / math.sqrt(2.0)) / 2.0
d1 = (math.log(A/L) + (R+SIGMA*SIGMA/2)*T) / (SIGMA*math.sqrt(T))
d2 = d1-SIGMA*math.sqrt(T)
E = A*cdf(d1)-L*math.exp(-R*T)*cdf(d2)
VE = A/E*cdf(d1)*SIGMA
PD = cdf(-(math.log(A/L)+(MU-SIGMA*SIGMA/2)*T)/(SIGMA*math.sqrt(T)))
rows = []
for scale in [1e-6,1e-3,1.0,1e3,1e6]:
    with warnings.catch_warnings(record=True) as messages:
        warnings.simplefilter('always')
        try:
            model = MertonFirmMkt(float(E*scale),float(L*scale),T,R,MU,VE)
            row = {'scale':scale, 'asset_value_in_base_units':float(model.asset_value()[0])/scale,
                'asset_volatility':float(model.asset_vol()[0]), 'prob_default':float(model.prob_default()[0]),
                'reconstructed_equity_in_base_units':float(model.equity_value()[0])/scale,
                'reconstructed_equity_volatility':float(model.equity_vol()[0])}
        except Exception as e:
            row = {'scale':scale,'exception':type(e).__name__,'message':str(e)}
        row['warnings'] = sorted(set(str(w.message) for w in messages))
        rows.append(row)
result = {'source':str(args.source.resolve()), 'python':sys.version,
          'dependencies':{x:importlib.metadata.version(x) for x in ['numpy','scipy','numba','llvmlite','pandas']},
          'known_parameters':{'asset':A,'debt':L,'time':T,'rate':R,'growth':MU,'asset_volatility':SIGMA},
          'expected':{'equity':E,'equity_volatility':VE,'prob_default':PD},'rows':rows}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
