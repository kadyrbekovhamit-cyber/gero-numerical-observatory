"""Create an isolated normalization-only candidate and a source mutation."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SOURCE = Path(json.loads((ROOT/'SOURCE.json').read_text())['source'])
if not SOURCE.is_absolute(): SOURCE = ROOT/SOURCE
REL = Path('financepy/models/merton_firm_mkt.py')
original = (SOURCE/REL).read_text()
before = '            # I initialise asset value and vol to equity value and vol\n'
after = ('            # Normalize monetary amounts by the debt face before calibration.\n'
         '            monetary_scale = argtuple[2]\n'
         '            argtuple = (argtuple[0] / monetary_scale, argtuple[1],\n'
         '                        1.0, argtuple[3], argtuple[4])\n\n' + before)
assert original.count(before) == 1
candidate = original.replace(before, after).replace(
    'self._a.append(result.x[0])', 'self._a.append(result.x[0] * monetary_scale)')
for name, text in [('candidate',candidate),('mutation',original)]:
    dest=ROOT/'variants'/name
    if dest.exists(): raise RuntimeError('Variant already exists: '+str(dest))
    shutil.copytree(SOURCE,dest)
    if name == 'mutation':
        (dest/REL).write_bytes((SOURCE/REL).read_bytes())
    else:
        (dest/REL).write_text(text)
(ROOT/'candidate.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(True),candidate.splitlines(True),fromfile='a/'+str(REL),tofile='b/'+str(REL))))
print('Candidate and mutation created; baseline untouched.')
