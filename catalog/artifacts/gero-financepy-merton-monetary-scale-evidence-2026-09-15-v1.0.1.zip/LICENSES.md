# Rights and attribution

FinancePy source and modified FinancePy code retain GPL-3.0-or-later, copyright and notices from upstream. The original source archive and release wheel are included unchanged. The candidate patch is a modification to that GPL-covered code; it is not relicensed under Creative Commons.

Original GERO report, diagrams and explanatory text: © 2026 Xamit Kadirbekov, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Original reproducer and verification scripts: GPL-3.0-or-later. The included upstream license gives the complete GPL terms. Third-party issue metadata retains its original attribution. No license here overrides a third party's rights.

This mixed-license evidence bundle is distributed with explicit component licensing, not a blanket Creative Commons license for the library. No affiliation with FinancePy or a financial institution is implied.
