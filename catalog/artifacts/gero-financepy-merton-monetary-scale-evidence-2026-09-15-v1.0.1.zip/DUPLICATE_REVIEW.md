# Bounded duplicate review — FinancePy Merton calibration

Checked 14 September UTC / 15 September 2026 Asia/Tashkent. Saved raw results are in `evidence/duplicate-review/`; the summary records the precise check time.

- Fresh upstream master remains `2b9227fea9d832c4033421d6cd53a54316414fca`.
- GitHub all-state issue/PR searches for `Merton`, `MertonFirmMkt`, `monetary`, and `scale calibration` in `domokane/FinancePy` returned no entries.
- The broader `minimize` search returned [SSVI issue #90](https://github.com/domokane/FinancePy/issues/90) and [interest-rate curve PR #214](https://github.com/domokane/FinancePy/pull/214). The inspected PR changes concern curve calibration and do not modify either Merton model file. SSVI is a different volatility-surface problem.
- A cross-repository search for FinancePy/Merton/calibration found [pragmatista/FinancePy PR #1](https://github.com/pragmatista/FinancePy/pull/1). Its 58 changed files were inspected for the Merton paths. They contain automated expression/loop refactoring, leaving the mixed-unit objective and unnormalized optimizer inputs unchanged. It is not a report or fix of the demonstrated unit-scaling failure.
- The saved canonical GERO catalog contains 93 publications and no Merton report. That count is a snapshot: the independently managed MLX accumulation publication was being added concurrently. Prior FinancePy cash-annuity, FX digital, day-count, vector expiry, mortgage, BAW and bond-principal reports are different cases.

No exact duplicate surfaced in this bounded search. This is not proof of global novelty: unindexed material, private reports and alternative descriptions may be missed. Repeat the current-source and catalog check immediately before any later publication or maintainer submission. No submission has been made from this investigation.
