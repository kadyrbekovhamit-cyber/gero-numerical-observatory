"""Check native QMM outputs against an exact analytical dot product."""
import collections
import csv
from fractions import Fraction
import json
from pathlib import Path
import sys

path = Path(sys.argv[1])
coefficients = [Fraction(x) for x in (6,-6,3,-3,1.5,-1.5,0,0)]
failures = collections.Counter()
by_dtype = collections.defaultdict(collections.Counter)
bad_scenarios = collections.defaultdict(set)
bad_configs = collections.defaultdict(set)
scenarios = set()
configs = set()
observed = {}
examples = []
rows = 0
for row in csv.DictReader(path.open()):
    K, exponent, pattern, layout, output_row, col = (int(row[x]) for x in ('K','scale_exponent','pattern','layout','row','col'))
    expected = Fraction(2)**exponent * (K if pattern == 0 else 2 if pattern == 3 else 0)
    expected *= (Fraction(1), Fraction(-1), Fraction(1,2))[output_row] * coefficients[col%8]
    assert Fraction(row['expected']) == expected
    key = (row['dtype'],row['mode'],K,exponent,pattern,output_row,col)
    config = (row['dtype'],row['mode'],K,exponent,pattern,layout)
    values = {k: Fraction(row[k]) for k in ('transposed','direct','explicit')}
    for kind,value in values.items():
        if value != expected:
            failures[kind] += 1
            by_dtype[row['dtype']][kind] += 1
            bad_scenarios[kind].add(row['scenario'])
            bad_configs[kind].add(config)
            if kind == 'direct' and len(examples) < 12:
                examples.append(dict(row))
    if key in observed and observed[key] != values:
        failures['layout_repeat_invariance'] += 1
    observed.setdefault(key, values)
    rows += 1
    scenarios.add(row['scenario'])
    configs.add(config)
result = {'file':str(path),'scenario_executions':len(scenarios),
          'configurations_without_repeat':len(configs),'coordinate_observations':rows,
          'coordinate_failures':dict(failures),
          'failing_scenario_executions':{k:len(v) for k,v in bad_scenarios.items()},
          'failing_configurations_without_repeat':{k:len(v) for k,v in bad_configs.items()},
          'failures_by_dtype':{k:dict(v) for k,v in by_dtype.items()},
          'examples':examples,
          'oracle':'Exact Fraction expression from K, power-of-two scale, sign-pattern sum and fixed exactly represented column coefficient; all decoded weights checked by C++ probe.'}
path.with_suffix('.summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'examples'},indent=2))
assert rows == 241920
assert len(scenarios) == 3240
assert len(configs) == 1620
assert not failures['transposed']
assert not failures['explicit']
assert not failures['layout_repeat_invariance']
