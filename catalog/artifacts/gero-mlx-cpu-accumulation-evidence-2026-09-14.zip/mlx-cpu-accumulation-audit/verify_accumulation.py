"""Check candidate and accumulator-reversion results against the saved baseline."""
import argparse
import csv
import datetime
import hashlib
import itertools
import json
import os
from fractions import Fraction
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
ENV = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           VECLIB_MAXIMUM_THREADS='1', MLX_ENABLE_TF32='0')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(binary, output):
    with output.open('w') as out:
        subprocess.run([str(binary)], cwd=ROOT, env=ENV, stdout=out, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reuse-native', action='store_true')
    args = parser.parse_args()
    if not args.reuse_native:
        execute(ROOT / 'variants/mutation/qmm_orientation_grid', EVIDENCE / 'mutation-orientation-grid.csv')
        execute(ROOT / 'variants/candidate/quantization_matrix_probe', EVIDENCE / 'candidate-rounding-matrix.csv')
    for name in ['candidate-orientation-grid.csv', 'mutation-orientation-grid.csv']:
        subprocess.run([sys.executable, '-B', 'check_orientation_grid.py', 'evidence/' + name], cwd=ROOT, check=True)
    subprocess.run([sys.executable, '-B', 'check_matrix.py', 'evidence/candidate-rounding-matrix.csv'], cwd=ROOT, check=True)
    names = ['baseline-orientation-grid.csv', 'candidate-orientation-grid.csv', 'mutation-orientation-grid.csv']
    readers = [csv.DictReader((EVIDENCE / n).open()) for n in names]
    counts = dict(observations=0, baseline_wrong=0, candidate_wrong=0,
                  mutation_wrong=0, mutation_differs_from_baseline=0,
                  float32_coordinates=0, float32_changed=0, controls_changed=0)
    for before, after, mutant in itertools.zip_longest(*readers):
        assert before is not None and after is not None and mutant is not None
        assert {k: v for k, v in before.items() if k != 'direct'} == {
            k: v for k, v in after.items() if k != 'direct'}
        counts['observations'] += 1
        for prefix, row in [('baseline', before), ('candidate', after), ('mutation', mutant)]:
            counts[prefix + '_wrong'] += Fraction(row['direct']) != Fraction(row['expected'])
        counts['mutation_differs_from_baseline'] += before != mutant
        if before['dtype'] == 'float32':
            counts['float32_coordinates'] += 1
            counts['float32_changed'] += before != after
        counts['controls_changed'] += any(before[k] != after[k] for k in ('explicit', 'transposed'))
    assert counts == dict(observations=241920, baseline_wrong=24192, candidate_wrong=0,
                         mutation_wrong=24192, mutation_differs_from_baseline=0,
                         float32_coordinates=80640, float32_changed=0, controls_changed=0), counts
    rounding_unchanged = sha(EVIDENCE / 'baseline-rounding-matrix.csv') == sha(EVIDENCE / 'candidate-rounding-matrix.csv')
    assert rounding_unchanged
    result = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'counts': counts, 'rounding_observation_byte_identical': rounding_unchanged,
              'source_commit': 'd9add9d11f3154111a4c85f267ec2fd307ecd18e',
              'backend': 'Native CPU C++ / macOS arm64 / Metal and CUDA disabled',
              'variants': ['Original source', 'FP32 row accumulator', 'Accumulator reverted to T'],
              'sha256': {name: sha(EVIDENCE / name) for name in names + ['baseline-rounding-matrix.csv', 'candidate-rounding-matrix.csv']}}
    (EVIDENCE / 'paired-accumulation-verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
