"""Explain native outputs with an independent rational rounding model."""
import csv
from fractions import Fraction
from functools import lru_cache
import json
from pathlib import Path
import sys


@lru_cache(maxsize=65536)
def round_binary(value, fraction_bits):
    if value == 0:
        return Fraction(0)
    sign = -1 if value < 0 else 1
    value = abs(value)
    exponent = value.numerator.bit_length() - value.denominator.bit_length()
    if value < Fraction(2) ** exponent:
        exponent -= 1
    spacing = Fraction(2) ** (exponent - fraction_bits)
    return sign * round(value / spacing) * spacing


@lru_cache(maxsize=None)
def model(dtype, K, exponent, pattern, output_row, coefficient):
    bits = {'float32': 23, 'float16': 10, 'bfloat16': 7}[dtype]
    row_scale = Fraction(2) ** exponent * (Fraction(1), Fraction(-1), Fraction(1, 2))[output_row]
    total = Fraction(0)
    first_stagnation = None
    for k in range(K):
        sign = 1 if pattern == 0 else (1 if k < K // 2 else -1) if pattern == 1 else (1 if k % 2 == 0 else -1)
        if pattern == 3 and k == K - 1:
            sign = 1
        product = row_scale * sign * coefficient
        assert round_binary(product, bits) == product
        previous = total
        total = round_binary(total + product, bits)
        if total == previous and product != 0 and first_stagnation is None:
            first_stagnation = k + 1
    return total, first_stagnation


def main():
    path = Path(sys.argv[1])
    coefficients = [Fraction(x) for x in (6, -6, 3, -3, 1.5, -1.5, 0, 0)]
    assert round_binary(Fraction(2048 + 6), 7) == 2048
    assert round_binary(Fraction(2056), 7) == 2048
    assert round_binary(Fraction(2072), 7) == 2080
    assert round_binary(Fraction(-2056), 7) == -2048
    observed = mismatches = 0
    representatives = []
    for r in csv.DictReader(path.open()):
        answer, first_stagnation = model(r['dtype'], int(r['K']), int(r['scale_exponent']),
                                         int(r['pattern']), int(r['row']), coefficients[int(r['col']) % 8])
        observed += 1
        mismatches += answer != Fraction(r['direct'])
        if (r['K'], r['scale_exponent'], r['layout'], r['repeat'], r['row'], r['col'], r['mode']) == ('1024', '0', '0', '0', '0', '0', 'nvfp4'):
            representatives.append({k: r[k] for k in ('dtype', 'pattern', 'expected', 'direct')} | {
                'model': str(answer), 'first_stagnation_term': first_stagnation})
    result = {'coordinate_observations': observed, 'native_model_mismatches': mismatches,
              'independent_cached_cases': model.cache_info().currsize,
              'model': 'Exact rational additions rounded after each term to the target significand width, nearest-even. Inputs/products remain exactly representable; no underflow or overflow occurs in this dataset.',
              'representatives': representatives}
    path.with_name('accumulation-model.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    assert observed == 241920 and mismatches == 0


if __name__ == '__main__':
    main()
