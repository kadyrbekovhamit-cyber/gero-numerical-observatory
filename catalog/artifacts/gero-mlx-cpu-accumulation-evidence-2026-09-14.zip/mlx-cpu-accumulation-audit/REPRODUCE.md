# Reproduce the MLX CPU accumulation audit

Tested platform: macOS 15.5 arm64, Apple Clang 17, CMake/Ninja, Python 3.9+. This exercises the public C++ API. The Python MLX package is not required. Run from the extracted archive root. CMake can download MLX's pinned dependencies if they are not cached.

## Baseline

The included source archive has SHA-256 `f3ff5fa6dfe738d7a79663fd7a2815dd558bf521163ba0aa867b77a54b0ed8b3`.

```sh
tar -xzf source/mlx-d9add9d.tar.gz -C source
cmake -S . -B build -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DBUILD_SHARED_LIBS=OFF \
  -DMLX_BUILD_CPU=ON -DMLX_BUILD_METAL=OFF -DMLX_BUILD_CUDA=OFF \
  -DMLX_BUILD_PYTHON_BINDINGS=OFF -DMLX_BUILD_TESTS=OFF \
  -DMLX_BUILD_EXAMPLES=OFF -DMLX_BUILD_BENCHMARKS=OFF \
  -DMLX_BUILD_GGUF=OFF -DMLX_BUILD_SAFETENSORS=OFF
cmake --build build --parallel 1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MLX_ENABLE_TF32=0
./build/qmm_orientation_probe
./build/qmm_orientation_grid > evidence/baseline-orientation-grid.csv
python3 -B check_orientation_grid.py evidence/baseline-orientation-grid.csv
python3 -B model_accumulation.py evidence/baseline-orientation-grid.csv
./build/quantization_matrix_probe > evidence/baseline-rounding-matrix.csv
python3 -B check_matrix.py evidence/baseline-rounding-matrix.csv
```

The small probe prints the first coordinate of 54 cases. The full grid checks every coordinate. `check_orientation_grid.py` deliberately permits baseline direct-path errors while asserting control behavior; the paired verifier below enforces the correction and mutation outcomes.

## Candidate and mutation

```sh
python3 -B build_accumulation_variant.py candidate
./variants/candidate/qmm_orientation_grid > evidence/candidate-orientation-grid.csv
python3 -B build_accumulation_variant.py mutation
python3 -B verify_accumulation.py
```

The builder checks all 951 original files and uses the original compiler arguments in `build/compile_commands.json`. Only a copy of `quantized.cpp` is compiled. The replacement object appears before the unchanged static `libmlx.a` when linking, so the archive's original object is not extracted. Exact compiler/linker commands and binary hashes are recorded in `evidence/candidate-build.json` and `evidence/mutation-build.json`.

Expected paired counts: original 24,192 mismatching coordinates; candidate zero; mutation 24,192. Original and mutation CSVs must be byte-identical. All float32 coordinates and transposed/dense controls remain unchanged. The separate rounding-matrix CSV also remains byte-identical after the candidate.

To recheck the shipped raw measurements without rebuilding or executing native probes:

```sh
python3 -B verify_accumulation.py --reuse-native
```

## Additional layout/width grid

After building the candidate and mutation above:

```sh
python3 -B run_stride_probe.py
python3 -B check_strides.py
```

This runs the additional native probe against the existing original library and both replacement objects. Expected coordinate mismatches: 116,640 → 0 → 116,640 out of 559,872 observations per variant. The checker also validates actual strides, shared-coordinate invariance and byte-identical original/mutation CSVs. To check only the supplied measurements, run `check_strides.py` without the build/run step.

## Integrity and portability

Before rerunning, compare the archive contents to `SHA256SUMS.json`. A rerun intentionally replaces CSVs and summaries. Published build receipts contain `<AUDIT_ROOT>` in place of the original local directory; commands are historical evidence, not scripts to paste verbatim. The builder derives current paths automatically.

The package excludes compiled binaries, external CMake caches and private project notes. Linux linking needs adaptation of the macOS framework flags; Linux was not tested. The complete MLX test suite and GPU backends were not run.
