"""Verify analytic answers, physical layouts and paired causal controls."""
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
coefficients = [Fraction(x) for x in (6,-6,3,-3,1.5,-1.5,0,0)]
paths = {v: ROOT / 'evidence' / (v + '-strides.csv') for v in ['baseline', 'candidate', 'mutation']}
summaries = {}
for variant, path in paths.items():
    failures, dtype_failures, scenarios, bad_scenarios = Counter(), Counter(), set(), set()
    layouts, widths = set(), set()
    observations = 0
    seen = {}
    measured_strides = defaultdict(set)
    with path.open() as src:
        for row in csv.DictReader(src):
            K, N, pattern, m, n = (int(row[k]) for k in ['K','N','pattern','row','col'])
            expected = coefficients[n%8] * (K if pattern == 0 else 0)
            assert Fraction(row['expected']) == expected
            vals = tuple(Fraction(row[k]) for k in ['direct', 'transposed', 'dense'])
            for name, value in zip(['direct', 'transposed', 'dense'], vals):
                if value != expected:
                    failures[name] += 1
                    if name == 'direct':
                        dtype_failures[row['dtype']] += 1
                        bad_scenarios.add(row['scenario'])
            key = (row['dtype'], row['mode'], K, pattern, m, n)
            if key in seen:
                assert seen[key] == vals, ('width/layout invariance', variant, row)
            else:
                seen[key] = vals
            sx = tuple(map(int, row['x_strides'].split(':')))
            expected_strides = {'contiguous': (K,1), 'row_step': (2*K,1),
                'column_step': (2*K,2), 'column_major': (1,3), 'broadcast': (0,1), 'packed_steps': (K,1)}
            assert sx == expected_strides[row['layout']], row
            if row['layout'] == 'packed_steps':
                assert int(row['w_strides'].split(':')[1]) == 2
            measured_strides[row['layout']].add(row['x_strides'])
            widths.add(N)
            layouts.add(row['layout'])
            scenarios.add(row['scenario'])
            observations += 1
    assert observations == 559872, observations
    assert len(scenarios) == 1620, len(scenarios)
    assert len(layouts) == 6
    assert widths == {32,64,96,128,256}
    assert failures['transposed'] == failures['dense'] == 0
    assert dtype_failures['float32'] == 0
    if variant == 'candidate':
        assert failures['direct'] == 0
    else:
        assert failures['direct'] > 0
    summaries[variant] = {'scenario_executions': len(scenarios), 'coordinate_observations': observations,
        'coordinate_failures': dict(failures), 'direct_failures_by_dtype': dict(dtype_failures),
        'failing_scenarios': len(bad_scenarios), 'measured_x_strides': {k: sorted(v) for k,v in measured_strides.items()},
        'output_widths': sorted(widths), 'width_and_layout_invariance': True}
assert paths['baseline'].read_bytes() == paths['mutation'].read_bytes()
result = {'variants': summaries, 'mutation_identical_to_baseline': True,
          'oracle': 'Exact Fraction calculation; decoded weights and all transformed arrays checked in native code.',
          'additional_accumulator_bytes': {str(n): 4*n for n in [32,64,96,128,256]},
          'file_sha256': {v: hashlib.sha256(p.read_bytes()).hexdigest() for v,p in paths.items()}}
(ROOT / 'evidence/stride-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
