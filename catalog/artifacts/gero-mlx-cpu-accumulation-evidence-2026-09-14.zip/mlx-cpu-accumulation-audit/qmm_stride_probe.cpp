#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;

mx::array columns(mx::array a) {
  int m = a.shape(0), n = a.shape(1);
  auto storage = mx::contiguous(mx::reshape(mx::stack({a, mx::zeros_like(a)}, -1), {m, 2*n}));
  mx::eval(storage);
  return mx::slice(storage, {0,0}, {m,2*n}, {1,2});
}

mx::array rows(mx::array a) {
  int m = a.shape(0), n = a.shape(1);
  auto storage = mx::contiguous(mx::reshape(mx::stack({a, mx::zeros_like(a)}, 1), {2*m, n}));
  mx::eval(storage);
  return mx::slice(storage, {0,0}, {2*m,n}, {2,1});
}

std::vector<float> values(mx::array a) {
  a = mx::contiguous(mx::astype(a, mx::float32));
  mx::eval(a);
  return {a.data<float>(), a.data<float>() + a.size()};
}

std::string strides(const mx::array& a) {
  return std::to_string(a.strides(0)) + ":" + std::to_string(a.strides(1));
}

int main() {
  mx::set_default_device(mx::Device::cpu);
  const float coefficients[] = {6,-6,3,-3,1.5,-1.5,0,0};
  const char* layouts[] = {"contiguous", "row_step", "column_step", "column_major", "broadcast", "packed_steps"};
  int scenario = 0;
  constexpr int M = 3;
  std::cout << std::setprecision(9);
  std::cout << "scenario,dtype,mode,K,N,pattern,layout,x_strides,w_strides,s_strides,row,col,expected,direct,transposed,dense\n";
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    const char* name = dtype == mx::float32 ? "float32" : dtype == mx::float16 ? "float16" : "bfloat16";
    for (const std::string mode : {"nvfp4", "mxfp4", "mxfp8"}) {
      for (int K : {64,256,1024}) {
        for (int N : {32,64,96,128,256}) {
          std::vector<float> weight_data(K*N);
          for (int k=0; k<K; ++k)
            for (int n=0; n<N; ++n) weight_data[k*N+n] = coefficients[n%8];
          auto w = mx::astype(mx::array(weight_data.data(), {K,N}), dtype);
          auto qn = mx::quantize(w, {}, {}, mode);
          auto qt = mx::quantize(mx::transpose(w), {}, {}, mode);
          auto wn = mx::dequantize(qn[0], qn[1], {}, {}, {}, mode, {}, dtype);
          auto wt = mx::dequantize(qt[0], qt[1], {}, {}, {}, mode, {}, dtype);
          if (!mx::all(mx::equal(w, wn)).item<bool>() ||
              !mx::all(mx::equal(w, mx::transpose(wt))).item<bool>()) return 2;
          for (int pattern : {0,1}) {
            std::vector<float> input_data(M*K);
            for (int m=0; m<M; ++m)
              for (int k=0; k<K; ++k) input_data[m*K+k] = pattern == 0 || k<K/2 ? 1.f : -1.f;
            auto plain = mx::astype(mx::array(input_data.data(), {M,K}), dtype);
            for (int layout=0; layout<6; ++layout) {
              auto x = plain;
              auto qw = qn[0], qs = qn[1], tw = qt[0], ts = qt[1];
              if (layout == 1) x = rows(plain);
              if (layout == 2) x = columns(plain);
              if (layout == 3) {
                auto storage = mx::contiguous(mx::transpose(plain));
                mx::eval(storage);
                x = mx::transpose(storage);
              }
              if (layout == 4) x = mx::broadcast_to(mx::slice(plain, {0,0}, {1,K}), {M,K});
              if (layout == 5) {
                qw = columns(qw); qs = rows(qs);
                tw = columns(tw); ts = rows(ts);
              }
              mx::eval(x, qw, qs, tw, ts);
              if (!mx::all(mx::equal(x, plain)).item<bool>() ||
                  !mx::all(mx::equal(qw, qn[0])).item<bool>() ||
                  !mx::all(mx::equal(qs, qn[1])).item<bool>() ||
                  !mx::all(mx::equal(tw, qt[0])).item<bool>() ||
                  !mx::all(mx::equal(ts, qt[1])).item<bool>()) return 3;
              if (layout > 0 && layout < 5 && x.flags().row_contiguous) return 4;
              if (layout == 5 && (qw.flags().row_contiguous || qs.flags().row_contiguous ||
                                  tw.flags().row_contiguous || ts.flags().row_contiguous)) return 5;
              auto direct = mx::quantized_matmul(x, qw, qs, {}, false, {}, {}, mode);
              auto transposed = mx::quantized_matmul(x, tw, ts, {}, true, {}, {}, mode);
              auto dense = mx::matmul(plain, w);
              if (direct.shape()!=mx::Shape{M,N} || transposed.shape()!=mx::Shape{M,N} ||
                  dense.shape()!=mx::Shape{M,N}) return 6;
              auto d=values(direct), t=values(transposed), r=values(dense);
              for (int m=0; m<M; ++m)
                for (int n=0; n<N; ++n)
                  std::cout << scenario << ',' << name << ',' << mode << ',' << K << ',' << N << ',' << pattern << ',' << layouts[layout] << ','
                            << strides(x) << ',' << strides(qw) << ',' << strides(qs) << ',' << m << ',' << n << ','
                            << (pattern == 0 ? K*coefficients[n%8] : 0.f) << ',' << d[m*N+n] << ',' << t[m*N+n] << ',' << r[m*N+n] << '\n';
              ++scenario;
            }
          }
        }
      }
    }
  }
}
