"""Build and run the additional native probe against three existing libraries."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
from build_accumulation_variant import verify_source

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'variants/strides'
DEST.mkdir(exist_ok=True)
verify_source()
env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           VECLIB_MAXIMUM_THREADS='1', MLX_ENABLE_TF32='0')
build_record = json.loads((ROOT / 'evidence/candidate-build.json').read_text())
argv = list(build_record['compile_argv'])
obj = DEST / 'qmm_stride_probe.cpp.o'
argv[argv.index('-o') + 1] = str(obj)
argv[argv.index('-c') + 1] = str(ROOT / 'qmm_stride_probe.cpp')
with (DEST / 'compile.log').open('w') as log:
    subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
record = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'compile_argv': argv, 'runs': {}, 'environment': {k: env[k] for k in
          ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'MLX_ENABLE_TF32']}}
for variant in ['baseline', 'candidate', 'mutation']:
    binary = DEST / variant
    replacement = [] if variant == 'baseline' else [str(ROOT / 'variants' / variant / 'quantized.cpp.o')]
    link = ['/usr/bin/c++', '-O3', '-DNDEBUG', '-Wl,-search_paths_first',
            '-Wl,-headerpad_max_install_names', str(obj)] + replacement + [
            '-o', str(binary), str(ROOT / 'build/mlx-build/libmlx.a'), '-framework', 'Accelerate']
    with (DEST / (variant + '.link.log')).open('w') as log:
        subprocess.run(link, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    output = ROOT / 'evidence' / (variant + '-strides.csv')
    with output.open('w') as out, (DEST / (variant + '.stderr.log')).open('w') as err:
        subprocess.run([str(binary)], cwd=ROOT, env=env, stdout=out, stderr=err, check=True)
    record['runs'][variant] = {'link_argv': link, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'output_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'output_bytes': output.stat().st_size}
    print(variant + ' native execution complete', flush=True)
verify_source()
record['probe_sha256'] = hashlib.sha256((ROOT / 'qmm_stride_probe.cpp').read_bytes()).hexdigest()
(ROOT / 'evidence/stride-build-and-run.json').write_text(json.dumps(record, indent=2) + '\n')
