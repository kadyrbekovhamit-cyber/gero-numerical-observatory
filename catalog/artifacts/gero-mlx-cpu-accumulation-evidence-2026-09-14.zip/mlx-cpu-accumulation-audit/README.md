# MLX CPU accumulation audit

Start with [the English report](REPORT_EN.md) and [reproduction guide](REPRODUCE.md). The primary grid and additional layout/width grid are both included.
