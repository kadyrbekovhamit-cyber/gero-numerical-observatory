#include <iomanip>
#include <iostream>
#include <string>
#include "mlx/mlx.h"

namespace mx = mlx::core;

int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << std::setprecision(9);
  std::cout << "dtype,mode,K,expected,transposed,direct,explicit\n";
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    const char* name = dtype == mx::float32 ? "float32" : dtype == mx::float16 ? "float16" : "bfloat16";
    for (const std::string mode : {"nvfp4", "mxfp4", "mxfp8"}) {
      for (int K : {32, 64, 128, 256, 512, 1024}) {
        auto x = mx::ones({1, K}, dtype);
        auto w = mx::full({32, K}, 6.f, dtype);
        auto qt = mx::quantize(w, {}, {}, mode);
        auto qn = mx::quantize(mx::transpose(w), {}, {}, mode);
        auto y_t = mx::quantized_matmul(x, qt[0], qt[1], {}, true, {}, {}, mode);
        auto y_n = mx::quantized_matmul(x, qn[0], qn[1], {}, false, {}, {}, mode);
        auto wt = mx::dequantize(qt[0], qt[1], {}, {}, {}, mode, {}, dtype);
        auto wn = mx::dequantize(qn[0], qn[1], {}, {}, {}, mode, {}, dtype);
        auto control = mx::all(mx::equal(wt, mx::transpose(wn)));
        auto control2 = mx::all(mx::equal(wt, w));
        if (!control.item<bool>() || !control2.item<bool>()) return 2;
        auto reference = mx::matmul(x, mx::transpose(wt));
        auto t = mx::astype(y_t, mx::float32);
        auto n = mx::astype(y_n, mx::float32);
        auto r = mx::astype(reference, mx::float32);
        mx::eval(t, n, r);
        std::cout << name << ',' << mode << ',' << K << ',' << 6*K << ','
                  << t.data<float>()[0] << ',' << n.data<float>()[0] << ',' << r.data<float>()[0] << '\n';
      }
    }
  }
}
