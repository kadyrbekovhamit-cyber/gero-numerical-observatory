#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;

void show(const std::string& label, mx::array a) {
  a = mx::astype(a, mx::float32);
  mx::eval(a);
  std::cout << label;
  for (int i = 0; i < a.size(); ++i) std::cout << ' ' << a.data<float>()[i];
  std::cout << '\n';
}

int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << std::setprecision(9);
  std::vector<float> values = {0.25f, 0.75f, 1.25f, 1.75f, 2.5f, 3.5f, 5.f, 6.f,
                            -0.25f, -0.75f, -1.25f, -1.75f, -2.5f, -3.5f, -5.f, -6.f};
  auto second_group = values;
  values.insert(values.end(), second_group.begin(), second_group.end());
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    auto x = mx::astype(mx::array(values.data(), {1, 32}), dtype);
    auto w = mx::multiply(mx::eye(32), mx::array(6.f));
    w = mx::astype(w, dtype);
    auto xq = mx::quantize(x, {}, {}, "nvfp4");
    auto wq = mx::quantize(w, {}, {}, "nvfp4");
    auto xhat = mx::dequantize(xq[0], xq[1], {}, {}, {}, "nvfp4", {}, dtype);
    auto what = mx::dequantize(wq[0], wq[1], {}, {}, {}, "nvfp4", {}, dtype);
    auto explicit_y = mx::matmul(xhat, mx::transpose(what));
    auto fused_y = mx::qqmm(x, wq[0], wq[1], {}, {}, "nvfp4");
    auto qmm_y = mx::quantized_matmul(xhat, wq[0], wq[1], {}, true, {}, {}, "nvfp4");
    std::cout << "dtype " << dtype << '\n';
    show("input", x);
    show("decoded", xhat);
    show("explicit", explicit_y);
    show("fused", fused_y);
    show("qmm_control", qmm_y);
  }
}
