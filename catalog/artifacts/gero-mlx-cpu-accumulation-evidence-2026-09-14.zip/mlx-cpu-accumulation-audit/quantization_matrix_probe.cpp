#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;

float neighbor(float x, mx::Dtype dtype, int direction) {
  if (direction == 0) return x;
  if (dtype == mx::float32)
    return std::nextafter(x, direction > 0 ? INFINITY : -INFINITY);
  uint16_t bits = dtype == mx::float16
      ? std::bit_cast<uint16_t>(mx::float16_t(x))
      : std::bit_cast<uint16_t>(mx::bfloat16_t(x));
  bits += ((x > 0) == (direction > 0)) ? 1 : -1;
  return dtype == mx::float16
      ? float(std::bit_cast<mx::float16_t>(bits))
      : float(std::bit_cast<mx::bfloat16_t>(bits));
}

std::vector<float> read(mx::array x) {
  x = mx::contiguous(mx::astype(x, mx::float32));
  mx::eval(x);
  return {x.data<float>(), x.data<float>() + x.size()};
}

int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << std::setprecision(9);
  std::cout << "scenario,dtype,scale_exponent,layout,permutation,repeat,index,input,decoded,explicit,fused,qmm\n";
  const std::vector<float> midpoints = {.25f, .75f, 1.25f, 1.75f, 2.5f, 3.5f, 5.f};
  const std::vector<float> levels = {0.f, .5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 6.f};
  const std::vector<mx::Shape> shapes = {{64}, {1,64}, {1,1,64}, {1,1,1,64}};
  int scenario = 0;
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    const char* name = dtype == mx::float32 ? "float32" : dtype == mx::float16 ? "float16" : "bfloat16";
    auto w = mx::astype(mx::multiply(mx::eye(64), mx::array(6.f)), dtype);
    auto wq = mx::quantize(w, {}, {}, "nvfp4");
    auto what = mx::dequantize(wq[0], wq[1], {}, {}, {}, "nvfp4", {}, dtype);
    auto wd = read(what);
    for (int i = 0; i < 64; ++i)
      for (int j = 0; j < 64; ++j)
        if (wd[i*64+j] != (i == j ? 6.f : 0.f)) return 2;
    for (int exponent = -4; exponent <= 4; ++exponent) {
      float scale = std::ldexp(1.f, exponent);
      std::vector<float> base;
      for (int direction : {0, -1, 1}) {
        for (int sign : {1, -1})
          for (float midpoint : midpoints)
            base.push_back(neighbor(sign * midpoint * scale, dtype, direction));
        base.push_back(0.f);
        base.push_back(6.f * scale);
      }
      for (int sign : {1, -1})
        for (float level : levels) base.push_back(sign * level * scale);
      for (int permutation = 0; permutation < 2; ++permutation) {
        auto values = base;
        if (permutation)
          for (int i = 0; i < 64; i += 16)
            std::reverse(values.begin()+i, values.begin()+i+16);
        for (int layout = 0; layout < 4; ++layout) {
          for (int repeat = 0; repeat < 2; ++repeat) {
            auto x = mx::astype(mx::array(values.data(), {1,64}), dtype);
            auto xq = mx::quantize(x, {}, {}, "nvfp4");
            auto xhat = mx::dequantize(xq[0], xq[1], {}, {}, {}, "nvfp4", {}, dtype);
            auto explicit_y = mx::matmul(xhat, mx::transpose(what));
            auto fused_y = mx::qqmm(mx::reshape(x, shapes[layout]), wq[0], wq[1], {}, {}, "nvfp4");
            if (fused_y.shape() != shapes[layout]) return 3;
            auto qmm_y = mx::quantized_matmul(xhat, wq[0], wq[1], {}, true, {}, {}, "nvfp4");
            auto inputs = read(x), decoded = read(xhat), ey = read(explicit_y), fy = read(fused_y), qy = read(qmm_y);
            for (int i = 0; i < 64; ++i)
              std::cout << scenario << ',' << name << ',' << exponent << ',' << layout << ',' << permutation << ',' << repeat << ',' << i << ','
                        << inputs[i] << ',' << decoded[i] << ',' << ey[i] << ',' << fy[i] << ',' << qy[i] << '\n';
            ++scenario;
          }
        }
      }
    }
  }
}
