#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include "mlx/mlx.h"

namespace mx = mlx::core;

std::vector<float> read_grid(mx::array x) {
  x = mx::contiguous(mx::astype(x, mx::float32));
  mx::eval(x);
  return {x.data<float>(), x.data<float>() + x.size()};
}

int main() {
  mx::set_default_device(mx::Device::cpu);
  std::cout << std::setprecision(9);
  std::cout << "scenario,dtype,mode,K,scale_exponent,pattern,layout,repeat,row,col,expected,transposed,direct,explicit\n";
  const float coefficients[] = {6.f,-6.f,3.f,-3.f,1.5f,-1.5f,0.f,0.f};
  int scenario = 0;
  for (auto dtype : {mx::float32, mx::float16, mx::bfloat16}) {
    const char* name = dtype == mx::float32 ? "float32" : dtype == mx::float16 ? "float16" : "bfloat16";
    for (const std::string mode : {"nvfp4", "mxfp4", "mxfp8"}) {
      for (int K : {64,128,256,512,1024}) {
        std::vector<float> weights(K*32);
        for (int k=0; k<K; ++k)
          for (int n=0; n<32; ++n) weights[k*32+n] = coefficients[n%8];
        auto w = mx::astype(mx::array(weights.data(), {K,32}), dtype);
        auto qt = mx::quantize(mx::transpose(w), {}, {}, mode);
        auto qn = mx::quantize(w, {}, {}, mode);
        auto wt = mx::dequantize(qt[0], qt[1], {}, {}, {}, mode, {}, dtype);
        auto wn = mx::dequantize(qn[0], qn[1], {}, {}, {}, mode, {}, dtype);
        if (!mx::all(mx::equal(mx::transpose(wt), w)).item<bool>() ||
            !mx::all(mx::equal(wn, w)).item<bool>()) return 2;
        for (int exponent : {-4,0,2}) {
          const float scale = std::ldexp(1.f, exponent);
          for (int pattern=0; pattern<4; ++pattern) {
            for (int layout=0; layout<3; ++layout) {
              const int M = layout == 0 ? 1 : 3;
              std::vector<float> inputs(M*K);
              std::vector<double> sums(M,0.0);
              for (int m=0; m<M; ++m) {
                const float row_scale = scale * (m == 1 ? -1.f : m == 2 ? .5f : 1.f);
                for (int k=0; k<K; ++k) {
                  int sign = pattern == 0 ? 1 : pattern == 1 ? (k<K/2 ? 1 : -1) : (k%2 == 0 ? 1 : -1);
                  if (pattern == 3 && k == K-1) sign = 1;
                  inputs[m*K+k] = row_scale*sign;
                  sums[m] += inputs[m*K+k];
                }
              }
              auto shape = layout == 2 ? mx::Shape{M,1,K} : mx::Shape{M,K};
              auto expected_shape = layout == 2 ? mx::Shape{M,1,32} : mx::Shape{M,32};
              for (int repeat=0; repeat<2; ++repeat) {
                auto x = mx::astype(mx::array(inputs.data(), shape), dtype);
                auto t = mx::quantized_matmul(x, qt[0], qt[1], {}, true, {}, {}, mode);
                auto n = mx::quantized_matmul(x, qn[0], qn[1], {}, false, {}, {}, mode);
                auto ref = mx::matmul(x, w);
                if (t.shape()!=expected_shape || n.shape()!=expected_shape || ref.shape()!=expected_shape) return 3;
                auto td=read_grid(t), nd=read_grid(n), rd=read_grid(ref);
                for (int m=0; m<M; ++m)
                  for (int col=0; col<32; ++col)
                    std::cout << scenario << ',' << name << ',' << mode << ',' << K << ',' << exponent << ',' << pattern << ',' << layout << ',' << repeat << ',' << m << ',' << col << ','
                              << sums[m]*coefficients[col%8] << ',' << td[m*32+col] << ',' << nd[m*32+col] << ',' << rd[m*32+col] << '\n';
                ++scenario;
              }
            }
          }
        }
      }
    }
  }
}
