# Rights and attribution

The included MLX source snapshot is Copyright Apple Inc. and contributors, distributed under the MIT License included inside `source/mlx-d9add9d.tar.gz`. Retain its copyright and license notices. The candidate patch modifies that MIT-licensed source and remains subject to those notices.

The original report and diagrams are Copyright 2026 Xamit Kadirbekov, licensed under Creative Commons Attribution 4.0 International: https://creativecommons.org/licenses/by/4.0/ . Original audit probes and verification scripts are licensed under the MIT License below. Public source links do not imply affiliation or endorsement.

MIT License — original audit code

Copyright (c) 2026 Xamit Kadirbekov

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
