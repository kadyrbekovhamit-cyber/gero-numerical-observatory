"""Build a single CPU source replacement against the untouched MLX archive."""
import argparse
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/mlx-d9add9d11f3154111a4c85f267ec2fd307ecd18e'
REL = 'mlx/backend/cpu/quantized.cpp'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_source():
    manifest = json.loads((ROOT / 'evidence/clean-source-manifest.json').read_text())
    changed = [name for name, checksum in manifest.items()
               if sha(SOURCE / name) != checksum]
    if changed:
        raise RuntimeError('Original source changed: ' + repr(changed))
    return len(manifest)


def candidate_source(original):
    start = original.index('template <typename T, int group_size, int bits>\nvoid fp_qmm(')
    end = original.index('\ntemplate <typename T, int group_size, int bits>\nvoid fp_qmm_t(', start)
    body = original[start:end]
    edits = {
        '  for (int m = 0; m < M; m++) {':
        '  std::vector<float> accum(N);\n  for (int m = 0; m < M; m++) {',
        '    std::fill(result, result + N, 0);':
        '    std::fill(accum.begin(), accum.end(), 0.0f);',
        '      T* result_local = result;':
        '      float* result_local = accum.data();',
        '    result += N;':
        '    for (int n = 0; n < N; n++) {\n      result[n] = static_cast<T>(accum[n]);\n    }\n    result += N;',
    }
    for before, after in edits.items():
        assert body.count(before) == 1
        body = body.replace(before, after)
    result = original[:start] + body + original[end:]
    return result.replace('#include "mlx/backend/common/quantized.h"',
                          '#include <vector>\n\n#include "mlx/backend/common/quantized.h"', 1)


def run_logged(argv, log, cwd):
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', MLX_ENABLE_TF32='0')
    with log.open('w') as out:
        subprocess.run(argv, cwd=cwd, env=env, stdout=out,
                       stderr=subprocess.STDOUT, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('variant', choices=['candidate', 'mutation'])
    args = parser.parse_args()
    verified = verify_source()
    original = (SOURCE / REL).read_text()
    candidate = candidate_source(original)
    (ROOT / 'fp-qmm-float-accumulation.patch').write_text(''.join(difflib.unified_diff(
        original.splitlines(True), candidate.splitlines(True),
        fromfile='a/' + REL, tofile='b/' + REL)))
    text = candidate
    if args.variant == 'mutation':
        text = text.replace('std::vector<float> accum(N);', 'std::vector<T> accum(N);')
        text = text.replace('float* result_local = accum.data();', 'T* result_local = accum.data();')
    dest = ROOT / 'variants' / args.variant
    dest.mkdir(parents=True, exist_ok=True)
    source_file = dest / 'quantized.cpp'
    source_file.write_text(text)
    object_file = dest / 'quantized.cpp.o'
    compile_db = json.loads((ROOT / 'build/compile_commands.json').read_text())
    entry = next(x for x in compile_db if x['file'] == str(SOURCE / REL))
    argv = shlex.split(entry['command'])
    argv[argv.index('-o') + 1] = str(object_file)
    argv[argv.index('-c') + 1] = str(source_file)
    run_logged(argv, dest / 'compile.log', Path(entry['directory']))
    binaries = {}
    for target in ['qmm_orientation_grid', 'qmm_orientation_probe', 'quantization_matrix_probe']:
        binary = dest / target
        object_input = ROOT / 'build/CMakeFiles' / (target + '.dir') / (target + '.cpp.o')
        link = ['/usr/bin/c++', '-O3', '-DNDEBUG', '-Wl,-search_paths_first',
                '-Wl,-headerpad_max_install_names', str(object_input), str(object_file),
                '-o', str(binary), str(ROOT / 'build/mlx-build/libmlx.a'), '-framework', 'Accelerate']
        run_logged(link, dest / (target + '.link.log'), ROOT)
        binaries[target] = {'sha256': sha(binary), 'link_argv': link}
    record = {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'variant': args.variant, 'original_source_files_verified': verified,
        'original_source_sha256': sha(SOURCE / REL),
        'replacement_source_sha256': sha(source_file),
        'replacement_object_sha256': sha(object_file),
        'baseline_static_library_sha256': sha(ROOT / 'build/mlx-build/libmlx.a'),
        'compile_argv': argv, 'binaries': binaries,
        'method': 'Replacement quantized.cpp object linked before unchanged static MLX archive. Original source and baseline binaries are untouched.',
        'scope': 'Only fp_qmm accumulator storage and final output conversion change; product expressions and other kernels remain unchanged.',
    }
    (ROOT / 'evidence' / (args.variant + '-build.json')).write_text(json.dumps(record, indent=2) + '\n')
    verify_source()
    print(json.dumps({'variant': args.variant, 'built': list(binaries), 'source_verified': verified}))


if __name__ == '__main__':
    main()
