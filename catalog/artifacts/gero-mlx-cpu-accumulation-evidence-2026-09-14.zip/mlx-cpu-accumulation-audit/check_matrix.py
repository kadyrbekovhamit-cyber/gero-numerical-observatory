"""Check recorded C++ outputs with exact rational E2M1 nearest-even rounding."""
import collections
import csv
from fractions import Fraction
import json
from pathlib import Path
import struct
import sys


def exact_f32(text):
    value = struct.unpack('<f', struct.pack('<f', float(text)))[0]
    return Fraction(value)


def e2m1(code):
    exponent, mantissa = divmod(code, 2)
    if exponent == 0:
        return Fraction(mantissa, 2)
    return Fraction(2 + mantissa, 2) * Fraction(2) ** (exponent - 1)


def nearest_even(value, scale):
    normalized = abs(value) / scale
    code = min(range(8), key=lambda c: (abs(e2m1(c) - normalized), c % 2, c))
    return (-1 if value < 0 else 1) * e2m1(code) * scale


path = Path(sys.argv[1])
counts = collections.Counter()
by_type = collections.defaultdict(collections.Counter)
observations = {}
examples = []
scenarios = set()
unique = set()
for row in csv.DictReader(path.open()):
    dtype = row['dtype']
    exponent = int(row['scale_exponent'])
    index = int(row['index'])
    if int(row['permutation']):
        index = index // 16 * 16 + 15 - index % 16
    key = (dtype, exponent, index)
    values = {name: exact_f32(row[name]) for name in ('input', 'decoded', 'explicit', 'fused', 'qmm')}
    scale = Fraction(2) ** exponent
    rounded = nearest_even(values['input'], scale)
    expected = 6 * rounded
    checks = {
        'explicit_quantize_vs_nearest_even': values['decoded'] != rounded,
        'explicit_product_vs_nearest_even': values['explicit'] != expected,
        'fused_product_vs_nearest_even': values['fused'] != expected,
        'fused_vs_explicit': values['fused'] != values['explicit'],
        'qmm_vs_explicit_control': values['qmm'] != values['explicit'],
        'explicit_product_arithmetic_control': values['explicit'] != 6 * values['decoded'],
        'layout_permutation_repeat_invariance': key in observations and values != observations[key],
    }
    for check, fails in checks.items():
        counts[check] += int(fails)
        by_type[dtype][check] += int(fails)
    counts['coordinate_observations'] += 1
    by_type[dtype]['coordinate_observations'] += 1
    scenarios.add(row['scenario'])
    if key not in observations and checks['fused_vs_explicit']:
        unique.add(key)
        if len(examples) < 12:
            examples.append({'dtype': dtype, 'scale_exponent': exponent, 'index': index,
                             **{k: str(v) for k, v in values.items()}, 'nearest_even_product': str(expected)})
    observations.setdefault(key, values)

result = {'file': str(path), 'scenarios': len(scenarios),
          'distinct_dtype_scale_position_coordinates': len(observations),
          'distinct_dtype_scale_position_disagreements': len(unique),
          'failures': dict(counts), 'by_dtype': {k: dict(v) for k,v in by_type.items()},
          'examples': examples,
          'oracle': 'Exact Fraction input values after float32 round-trip; E2M1 values decoded from exponent and mantissa; nearest distance, ties to even code.'}
out = path.with_suffix('.summary.json')
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('file', 'scenarios', 'distinct_dtype_scale_position_coordinates', 'distinct_dtype_scale_position_disagreements', 'failures')}, indent=2))
assert len(scenarios) == 432
assert len(observations) == 1728
assert counts['coordinate_observations'] == 27648
assert not counts['qmm_vs_explicit_control']
assert not counts['explicit_product_arithmetic_control']
assert not counts['layout_permutation_repeat_invariance']
