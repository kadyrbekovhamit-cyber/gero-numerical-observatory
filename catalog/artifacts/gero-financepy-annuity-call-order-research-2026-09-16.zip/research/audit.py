"""Public API call-order checks, with independent dated-cash-flow oracle."""
import contextlib, io, itertools, json, math, sys
from datetime import date
from pathlib import Path
import mpmath as mp
from financepy.products.bonds.bond_annuity import BondAnnuity
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.utils.date import Date
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes

OUT = Path(sys.argv[1])
freqs = ['ANNUAL', 'SEMI_ANNUAL', 'QUARTERLY', 'MONTHLY']
rows = []

def dt(x):
    return date(x.y, x.m, x.d)

def cash_oracle(dates, settle, coupon, rate, precision):
    # Schedule dates are taken as declared input; calendar generation is not audited.
    with mp.workdps(precision):
        c = mp.mpf(coupon); r = mp.mpf(rate)
        pv = mp.mpf(0)
        flows = [mp.mpf(0)]
        for prev, end in zip(dates, dates[1:]):
            alpha = mp.mpf((dt(end)-dt(prev)).days)/360
            flow = c * alpha
            t = mp.mpf((dt(end)-dt(settle)).days)/365
            pv += flow * mp.exp(-r*t)
            flows.append(flow)
        return float(100*pv), [float(x) for x in flows]

def close(x,y):
    return math.isfinite(x) and abs(x-y) <= 2e-11*max(1,abs(y))

for days, years, freq, coupon, rate, face in itertools.product(
    [(20,6,2018),(29,2,2024),(1,1,2026)], [1,5], freqs,
    [0.0,0.01,0.05], [-0.02,0.0,0.03], [0.0,1.0,100.0,1e6]):
    settle = Date(*days); maturity = settle.add_years(years)
    curve = FlatDiscountCurve(settle, rate)
    def make():
        return BondAnnuity(maturity,coupon,getattr(FrequencyTypes,freq),DayCountTypes.ACT_360)
    a=make(); fresh=a.dirty_price_from_discount_curve(settle,curve)
    oracle, flows=cash_oracle(a.cpn_dts,settle,coupon,rate,80)
    oracle120,_=cash_oracle(a.cpn_dts,settle,coupon,rate,120)
    dates = [str(x) for x in a.cpn_dts]
    b=make();b.calculate_payments(settle,face)
    fresh_face=list(b.flow_amounts)
    prepriced=b.dirty_price_from_discount_curve(settle,curve)
    repriced=b.dirty_price_from_discount_curve(settle,curve)
    c=make();c.calculate_payments(settle,1.0);c.calculate_payments(settle,face)
    repeated_face=list(c.flow_amounts)
    d=make()
    with contextlib.redirect_stdout(io.StringIO()): d.print_payments(settle,face)
    printed_price=d.dirty_price_from_discount_curve(settle,curve)
    e=make(); e.dirty_price_from_discount_curve(settle,curve)
    with contextlib.redirect_stdout(io.StringIO()): e.print_payments(settle,face)
    price_then_print=list(e.flow_amounts)
    f=make(); f.calculate_payments(settle,face)
    clean=f.clean_price_from_discount_curve(settle,curve)
    expected_face=[x*face for x in flows]
    failures=[]
    for label,value in [('prepared_price',prepriced),('repeated_price',repriced),
                        ('printed_then_price',printed_price),('clean_after_preparation',clean)]:
        if not close(value,oracle): failures.append(label)
    for label,vector in [('face_after_face1',repeated_face),('print_after_price',price_then_print)]:
        if not all(close(x,y) for x,y in zip(vector,expected_face)):failures.append(label)
    controls={'fresh_price':close(fresh,oracle),
              'fresh_face_payments':all(close(x,y) for x,y in zip(fresh_face,expected_face)),
              'same_schedule':dates==[str(x) for x in b.cpn_dts]==[str(x) for x in c.cpn_dts],
              'oracle_precision':close(oracle,oracle120)}
    rows.append(dict(id=len(rows),settle=days,years=years,frequency=freq,coupon=coupon,
        rate=rate,face=face,payment_dates=dates,oracle_price=oracle,oracle_price120=oracle120,
        fresh_price=fresh,prepared_price=prepriced,repeated_price=repriced,
        printed_then_price=printed_price,clean_after_preparation=clean,
        expected_face_flows=expected_face,fresh_face_flows=fresh_face,
        face_after_face1=repeated_face,print_after_price=price_then_print,
        failures=failures,controls=controls))
OUT.write_text(json.dumps(rows,indent=2)+'\n')
summary={'scenarios':len(rows),'failing_scenarios':sum(bool(x['failures']) for x in rows),
         'control_failures':sum(not all(x['controls'].values()) for x in rows),
         'failed_checks':sum(len(x['failures']) for x in rows)}
OUT.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
