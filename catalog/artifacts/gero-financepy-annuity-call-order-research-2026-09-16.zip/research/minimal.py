"""Run against an explicitly selected FinancePy checkout on PYTHONPATH."""
import json
from financepy.products.bonds.bond_annuity import BondAnnuity
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.utils.date import Date
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes

settle = Date(20, 6, 2018)
maturity = Date(20, 6, 2019)
curve = FlatDiscountCurve(settle, 0.0)

def make():
    return BondAnnuity(maturity, 0.05, FrequencyTypes.SEMI_ANNUAL,
                       DayCountTypes.ACT_360)

a = make()
fresh = a.dirty_price_from_discount_curve(settle, curve)
b = make()
b.calculate_payments(settle, 100.0)
prepared = b.dirty_price_from_discount_curve(settle, curve)
c = make()
c.calculate_payments(settle, 1.0)
one = list(c.flow_amounts)
c.calculate_payments(settle, 100.0)
hundred = list(c.flow_amounts)
print(json.dumps({'fresh_dirty_price': fresh,
                  'dirty_price_after_face100_payments': prepared,
                  'face1_flows': one, 'face100_flows_after_face1': hundred,
                  'expected_dirty_price': 100 * 0.05 * 365 / 360}, indent=2))
