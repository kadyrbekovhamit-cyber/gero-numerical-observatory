`BondAnnuity.calculate_payments()` returns early when the settlement date is
unchanged, without checking the requested face amount. A prior payment or
printing call can therefore change a subsequent price quote by an arbitrary
face multiplier.

Reproduced on current master `2b9227fea9d832c4033421d6cd53a54316414fca` and
the official PyPI 1.1.2 package; their target-file bytes are identical.

```python
from financepy.products.bonds.bond_annuity import BondAnnuity
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.utils.date import Date
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes

settle = Date(20, 6, 2018)
curve = FlatDiscountCurve(settle, 0.0)

def make():
    return BondAnnuity(Date(20, 6, 2019), 0.05,
                       FrequencyTypes.SEMI_ANNUAL, DayCountTypes.ACT_360)

a = make()
print(a.dirty_price_from_discount_curve(settle, curve))  # 5.069444444444445
b = make()
b.calculate_payments(settle, 100.0)
print(b.dirty_price_from_discount_curve(settle, curve))  # 506.94444444444446
```

Both calls price the same instrument per 100 of par. With zero discounting, the
independent expected price is `100 * 0.05 * (183 + 182) / 360`.
`print_payments(settle, 100.0)` before pricing gives the same wrong quote.
Calling `calculate_payments(settle, 1.0)` followed by face 100 also leaves the
payment amounts at face 1.

The pricing methods request face 1 before multiplying by `self.par=100`, but
the date-only early return retains the previous face's cash flows.

Conservative candidate in `financepy/products/bonds/bond_annuity.py`:

```diff
-        # No need to generate flows if settlement date has not changed
-        if settle_dt == self.settle_dt:
-            return
-
+        # Rebuild amounts for the requested face, even at the same settlement.
```

This regenerates the schedule as well as amounts. A later optimization could
cache dates separately; I have not benchmarked performance.

Executed checks:

- 864 distinct synthetic scenarios, including leap-date settlement, four
  frequencies, zero/positive coupons, negative/zero/positive discount rates,
  and faces 0/1/100/1,000,000. Failing scenarios: **432 original → 0 candidate →
  432 restored original**; the released package also fails 432.
- Independent dated-cash-flow oracle at 80 and 120 digits, with fixed tolerance.
  Emitted schedule dates are held as given; calendar generation is not audited.
- All 432 previously passing scenarios and all fresh prices, fresh-face payments
  and payment dates remain unchanged. Original/restored/release rows match exactly.
- 5 existing annuity tests pass on original and candidate. 14 new regressions
  pass candidate; restoring the early return gives 12 failures and 2 passing controls.

The bounded duplicate review covered 257 public issue/PR records, focused
searches, target-file history and the 98-report GERO catalog. PR #93 discusses test
migration; PR #256 concerns different classes and accrued-interest scaling.
I found no exact match for this date-only payment cache defect.

No full-suite, real-bank exposure or customer-loss claim. Source, raw results,
scripts and correction are retained for review. AI-assisted investigation;
all stated numerical results were executed.

Xamit Kadirbekov / GERO
