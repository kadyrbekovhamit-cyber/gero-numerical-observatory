# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

import numpy as np
from numba import njit, float64, int64

from ..utils.error import FinError
from ..utils.math import accrued_interpolator
from ..market.curves.interpolator import InterpTypes, _uinterpolate
from ..utils.helpers import label_to_string
from ..utils.global_types import ExerciseTypes
from ..utils.global_vars import G_SMALL

INTERP_TYPE = InterpTypes.FLAT_FWD_RATES.value

# ISSUE: PUT CALL PARITY IS NOT EXACTLY OBSERVED FOR BERMUDAN SWAPTIONS WHEN
#       VOL IS TURNED UP. SMALL EFFECT. $3 OUT OF $1m.

########################################################################################


def option_exercise_types_to_int(option_exercise_type: ExerciseTypes) -> int:
    """Convert the option exercise type to an integer for use in the tree."""
    if option_exercise_type == ExerciseTypes.EUROPEAN:
        return 1
    if option_exercise_type == ExerciseTypes.BERMUDAN:
        return 2
    if option_exercise_type == ExerciseTypes.AMERICAN:
        return 3

    raise FinError("Unknown option exercise type.")


########################################################################################


@njit(
    float64(float64, int64, float64[:, :], float64[:, :], float64, float64, float64),
    fastmath=True,
    cache=True,
)
def f(
    x0: float,
    m: int,
    q_matrix: np.ndarray,
    rt: np.ndarray,
    df_end: float,
    dt: float,
    sigma: float,
) -> float:

    # x is the middle value on the short-rate on the tree
    midm = int(m / 2)
    rt[m, midm] = x0

    for i in range(midm, 0, -1):
        rt[m, i - 1] = rt[m, i] * np.exp(-2.0 * sigma * np.sqrt(dt))

    for i in range(midm + 1, m + 1, 1):
        rt[m, i] = rt[m, i - 1] * np.exp(2.0 * sigma * np.sqrt(dt))

    sum_inner = 0.0
    for i in range(0, m + 1):
        r = rt[m, i]
        next_period_df = np.exp(-r * dt)
        q = q_matrix[m, i]
        sum_inner += q * next_period_df

    obj_fn = sum_inner - df_end
    return obj_fn


########################################################################################


@njit(
    float64(float64, int64, float64[:, :], float64[:, :], float64, float64, float64),
    fastmath=True,
    cache=True,
)
def search_root(
    x0: float,
    m: int,
    q_matrix: np.ndarray,
    rt: np.ndarray,
    df_end: float,
    dt: float,
    sigma: float,
) -> float:
    """Search for the root of the function using a numerical method."""
    max_iter = 50
    max_error = 1e-10

    if abs(x0) < 1e-10:
        x1 = 1e-4
    else:
        x1 = x0 * 1.0001

    f0 = f(x0, m, q_matrix, rt, df_end, dt, sigma)
    f1 = f(x1, m, q_matrix, rt, df_end, dt, sigma)

    for _ in range(0, max_iter):

        df = f1 - f0

        if abs(df) < 1e-14:
            raise FinError("Search for alpha fails due to zero derivative")

        x = x1 - f1 * (x1 - x0) / df
        x = max(x, 1e-10)  # require positivity

        x0, f0 = x1, f1
        x1 = x
        f1 = f(x1, m, q_matrix, rt, df_end, dt, sigma)

        if abs(f1) <= max_error:
            return x1

    raise FinError("Search root derivative FAILED to find alpha.")


########################################################################################


@njit(fastmath=True, cache=True)
def bermudan_swaption_tree_fast(
    t_exp: float,
    t_mat: float,
    strike_price: float,
    face_amount: float,
    cpn_times: np.ndarray,
    cpn_flows: np.ndarray,
    exercise_type_int: int,
    df_times: np.ndarray,
    df_values: np.ndarray,
    tree_times: np.ndarray,
    qq: np.ndarray,
    rt: np.ndarray,
    dt: float,
) -> tuple[float, float]:
    """Option to enter into a swap that can be exercised on coupon payment
    dates after the start of the exercise period. Due to non-analytical bond
    price we need to extend tree out to bond maturity and take into account
    cash flows through time."""
    pu = 0.50
    pd = 0.50

    num_time_steps, num_nodes = qq.shape
    expiry_step = int(t_exp / dt + 0.50)
    maturity_step = int(t_mat / dt + 0.50)

    fixed_leg_flows = np.zeros(num_time_steps)
    float_leg_values = np.zeros(num_time_steps)
    num_cpns = len(cpn_times)

    # Tree flows go all the way out to the swap maturity date
    for i in range(0, num_cpns):
        t_cpn = cpn_times[i]
        n = int(t_cpn / dt + 0.50)
        ttree = tree_times[n]
        df_flow = _uinterpolate(t_cpn, df_times, df_values, INTERP_TYPE)
        df_tree = _uinterpolate(ttree, df_times, df_values, INTERP_TYPE)
        fixed_leg_flows[n] += cpn_flows[i] * 1.0 * df_flow / df_tree
        float_leg_values[n] = strike_price  # * df_flow / df_tree

    # Mapped times stores the mapped times and flows and is used to calculate
    # accrued interest in a consistent manner as using actual flows will
    # result in some convergence noise issues as it is inconsistent

    mapped_times = np.array([0.0])
    mapped_amounts = np.array([0.0])

    for n in range(1, len(tree_times)):

        accd_at_expiry = 0.0
        if tree_times[n - 1] < t_exp and tree_times[n] >= t_exp:
            mapped_times = np.append(mapped_times, t_exp)
            mapped_amounts = np.append(mapped_amounts, accd_at_expiry)

        if fixed_leg_flows[n] > 0.0:
            mapped_times = np.append(mapped_times, tree_times[n])
            mapped_amounts = np.append(mapped_amounts, fixed_leg_flows[n])

    accrued = np.zeros(num_time_steps)
    for m in range(0, maturity_step + 1):
        ttree = tree_times[m]
        accrued[m] = accrued_interpolator(ttree, mapped_times, mapped_amounts)
        accrued[m] *= face_amount

        # This is a bit of a hack for when the interpolation does not put the
        # full accrued on flow date. Another scheme may work but so does this
        if fixed_leg_flows[m] > G_SMALL:
            accrued[m] = fixed_leg_flows[m] * face_amount

    # The value of the swap at each time and node. Principal is exchanged.
    fixed_leg_values = np.zeros(shape=(num_time_steps, num_nodes))
    # The value of the option to enter into a payer swap
    pay_values = np.zeros(shape=(num_time_steps, num_nodes))
    # The value of the option to enter into a receiver swap
    rec_values = np.zeros(shape=(num_time_steps, num_nodes))

    # Start with the value of the fixed leg at maturity
    for k in range(0, num_nodes):
        flow = 1.0 + fixed_leg_flows[maturity_step]
        fixed_leg_values[maturity_step, k] = flow * face_amount

    # Now step back to today considering early exercise on coupon dates
    for m in range(maturity_step - 1, -1, -1):

        nm = m

        flow = fixed_leg_flows[m] * face_amount

        for k in range(0, nm + 1):
            short_rate = rt[m, k]
            df = np.exp(-short_rate * dt)

            vu = fixed_leg_values[m + 1, k + 1]
            vd = fixed_leg_values[m + 1, k]
            v = (pu * vu + pd * vd) * df

            fixed_leg_values[m, k] = v
            fixed_leg_values[m, k] += flow

            vpay = 0.0
            vrec = 0.0

            vu = pay_values[m + 1, k + 1]
            vd = pay_values[m + 1, k]
            vpay = (pu * vu + pd * vd) * df
            pay_values[m, k] = vpay

            vu = rec_values[m + 1, k + 1]
            vd = rec_values[m + 1, k]
            vrec = (pu * vu + pd * vd) * df
            rec_values[m, k] = vrec

            hold_pay = pay_values[m, k]
            hold_rec = rec_values[m, k]

            # The floating value is clean and so must be the fixed value
            fixed_leg_value = fixed_leg_values[m, k] - accrued[m]
            float_leg_value = float_leg_values[m]

            pay_exercise = max(float_leg_value - fixed_leg_value, 0.0)
            rec_exercise = max(fixed_leg_value - float_leg_value, 0.0)

            if m == expiry_step:

                pay_values[m, k] = max(pay_exercise, hold_pay)
                rec_values[m, k] = max(rec_exercise, hold_rec)

            elif exercise_type_int == 2 and flow > G_SMALL and m > expiry_step:

                pay_values[m, k] = max(pay_exercise, hold_pay)
                rec_values[m, k] = max(rec_exercise, hold_rec)

            elif exercise_type_int == 3 and m > expiry_step:

                raise FinError("American optionality not completed.")

                # Need to define floating value on all grid dates

                # pay_values[m, k] = max(pay_exercise, hold_pay)
                # rec_values[m, k] = max(rec_exercise, hold_rec)

    return (pay_values[0, 0], rec_values[0, 0])


########################################################################################


@njit(fastmath=True, cache=True)
def american_bond_option_tree_fast(
    t_exp: float,
    t_mat: float,
    strike_price: float,
    face_amount: float,
    cpn_times: np.ndarray,
    cpn_flows: np.ndarray,
    exercise_type_int: int,
    _df_times: np.ndarray,
    _df_values: np.ndarray,
    _tree_times: np.ndarray,
    _rt: np.ndarray,
    _dt: float,
) -> tuple[float, float]:
    """Option to buy or sell bond at a specified strike price that can be
    exercised over the exercise period depending on choice of exercise type.
    Due to non-analytical bond price we need to extend tree out to bond
    maturity and take into account cash flows through time."""

    debug = False

    pu = 0.50
    pd = 0.50

    if debug:
        print("COUPON TIMES", cpn_times)
        print("COUPON AMOUNTS", cpn_flows)

    num_time_steps, num_nodes = _rt.shape
    expiry_step = int(t_exp / _dt + 0.50)
    maturity_step = int(t_mat / _dt + 0.50)

    tree_flows = np.zeros(num_time_steps)
    num_cpns = len(cpn_times)

    # Tree flows go all the way out to the bond maturity date
    # Do not include first coupon as it is the previous coupon and is negative
    for i in range(1, num_cpns):
        t_cpn = cpn_times[i]

        if t_cpn < 0.0:
            print(cpn_times)
            raise FinError("Coupon times must be positive.")

        n = int(t_cpn / _dt + 0.50)
        ttree = _tree_times[n]
        df_flow = _uinterpolate(t_cpn, _df_times, _df_values, INTERP_TYPE)
        df_tree = _uinterpolate(ttree, _df_times, _df_values, INTERP_TYPE)
        tree_flows[n] += cpn_flows[i] * 1.0 * df_flow / df_tree

    # mapped_times = np.zeros(0)   # CHANGE
    # mapped_amounts = np.zeros(0)  # CHANGE
    # for n in range(0, len(_tree_times)):
    #     if tree_flows[n] > 0.0:
    #         mapped_times = np.append(mapped_times, _tree_times[n])
    #         mapped_amounts = np.append(mapped_amounts, tree_flows[n])
    # if debug:
    #     print("MAPPED TIMES", mapped_times)
    #     print("MAPPED AMOUNTS", mapped_amounts)
    #    if mapped_times[0] > G_SMALL:
    #        raise FinError("Mapped times [0] must be <= 0 for first coupon > 0")

    if debug:
        print(_tree_times)
        print(tree_flows)

    accrued = np.zeros(num_time_steps)
    for m in range(0, maturity_step + 1):
        ttree = _tree_times[m]
        accrued[m] = accrued_interpolator(ttree, cpn_times, cpn_flows)
        accrued[m] *= face_amount

        # This is a bit of a hack for when the interpolation does not put the
        # full accrued on flow date. Another scheme may work but so does this
        if tree_flows[m] > G_SMALL:
            accrued[m] = tree_flows[m] * face_amount

    if debug:
        for i in range(0, expiry_step + 1):
            print(i, tree_flows[i], accrued[i])

    call_option_values = np.zeros(shape=(num_time_steps, num_nodes))
    put_option_values = np.zeros(shape=(num_time_steps, num_nodes))
    bond_values = np.zeros(shape=(num_time_steps, num_nodes))

    # Start with the value of the bond at maturity
    for k in range(0, num_nodes):
        bond_values[maturity_step, k] = (1.0 + tree_flows[maturity_step]) * face_amount

    if debug:
        dirty_price = bond_values[maturity_step, 0]
        clean_price = dirty_price - accrued[maturity_step]
        print(m, _tree_times[m], accrued[m], dirty_price, clean_price, 0, 0)

    # Step back from maturity to expiry date but with no exercise allowed.
    for m in range(maturity_step - 1, expiry_step, -1):

        nm = m
        flow = tree_flows[m] * face_amount

        for k in range(0, nm + 1):

            r = _rt[m, k]
            df = np.exp(-r * _dt)

            vu = bond_values[m + 1, k + 1]
            vd = bond_values[m + 1, k]
            v = (pu * vu + pd * vd) * df

            bond_values[m, k] = v
            bond_values[m, k] += flow
            dirty_price = bond_values[m, k]
            clean_price = dirty_price - accrued[m]

        if debug:
            print(m, _tree_times[m], accrued[m], dirty_price, clean_price, 0, 0)

    # Now step back to today from the expiry date considering early exercise
    for m in range(expiry_step, -1, -1):
        nm = m
        flow = tree_flows[m] * face_amount

        for k in range(0, nm + 1):

            r = _rt[m, k]
            df = np.exp(-r * _dt)

            vu = bond_values[m + 1, k + 1]
            vd = bond_values[m + 1, k]
            v = (pu * vu + pd * vd) * df

            bond_values[m, k] = v
            bond_values[m, k] += flow

            vcall = 0.0
            vput = 0.0

            vu = call_option_values[m + 1, k + 1]
            vd = call_option_values[m + 1, k]
            vcall = (pu * vu + pd * vd) * df

            call_option_values[m, k] = vcall

            vu = put_option_values[m + 1, k + 1]
            vd = put_option_values[m + 1, k]
            vput = (pu * vu + pd * vd) * df

            put_option_values[m, k] = vput

            dirty_price = bond_values[m, k]
            clean_price = dirty_price - accrued[m]
            call_exercise = max(clean_price - strike_price, 0.0)
            put_exercise = max(strike_price - clean_price, 0.0)

            hold_call = call_option_values[m, k]
            hold_put = put_option_values[m, k]

            if m == expiry_step:

                call_option_values[m, k] = max(call_exercise, hold_call)
                put_option_values[m, k] = max(put_exercise, hold_put)

            elif exercise_type_int == 3 and m < expiry_step:

                call_option_values[m, k] = max(call_exercise, hold_call)
                put_option_values[m, k] = max(put_exercise, hold_put)

        if debug:
            print(
                m,
                _tree_times[m],
                accrued[m],
                dirty_price,
                clean_price,
                call_exercise,
                put_exercise,
            )

    return (call_option_values[0, 0], put_option_values[0, 0])


########################################################################################


@njit(fastmath=True, cache=True)
def callable_puttable_bond_tree_fast(
    cpn_times: np.ndarray,
    cpn_flows: np.ndarray,
    call_times: np.ndarray,
    call_prices: np.ndarray,
    put_times: np.ndarray,
    put_prices: np.ndarray,
    face_amount: float,
    _rt: np.ndarray,
    _dt: float,
    _tree_times: np.ndarray,
    _df_times: np.ndarray,
    _df_values: np.ndarray,
):
    """Value a bond with embedded put and call options that can be exercised
    at any time over the specified list of put and call dates.
    Due to non-analytical bond price we need to extend tree out to bond
    maturity and take into account cash flows through time."""

    # binomial tree with equal up-down probabilities
    pu = 0.50
    pd = 0.50

    num_time_steps, num_nodes = _rt.shape
    dt = _dt
    t_mat = cpn_times[-1]
    maturity_step = int(t_mat / dt + 0.50)

    # Map coupons onto tree while preserving their present value
    tree_flows = np.zeros(num_time_steps)

    num_cpns = len(cpn_times)
    for i in range(0, num_cpns):
        t_cpn = cpn_times[i]
        n = int(t_cpn / _dt + 0.50)
        ttree = _tree_times[n]
        df_flow = _uinterpolate(t_cpn, _df_times, _df_values, INTERP_TYPE)
        df_tree = _uinterpolate(ttree, _df_times, _df_values, INTERP_TYPE)
        tree_flows[n] += cpn_flows[i] * 1.0 * df_flow / df_tree

    # Mapped times stores the mapped times and flows and is used to calculate
    # accrued interest in a consistent manner as using actual flows will
    # result in some convergence noise issues as it is inconsistent

    mapped_times = np.array([0.0])
    mapped_amounts = np.array([0.0])
    for n in range(1, len(_tree_times)):
        if tree_flows[n] > 0.0:
            mapped_times = np.append(mapped_times, _tree_times[n])
            mapped_amounts = np.append(mapped_amounts, tree_flows[n])

    accrued = np.zeros(num_time_steps)
    for m in range(0, num_time_steps):
        ttree = _tree_times[m]
        accrued[m] = accrued_interpolator(ttree, mapped_times, mapped_amounts)
        accrued[m] *= face_amount

        # This is a bit of a hack for when the interpolation does not put the
        # full accrued on flow date. Another scheme may work but so does this
        if tree_flows[m] > 0.0:
            accrued[m] = tree_flows[m] * face_amount

    # map call onto tree - must have no calls at high value

    tree_call_value = np.ones(num_time_steps) * face_amount * 1000.0
    num_calls = len(call_times)
    for i in range(0, num_calls):
        call_time = call_times[i]
        n = int(call_time / dt + 0.50)
        tree_call_value[n] = call_prices[i]

    # map puts onto tree
    tree_put_value = np.zeros(num_time_steps)
    num_puts = len(put_times)
    for i in range(0, num_puts):
        put_time = put_times[i]
        n = int(put_time / dt + 0.50)
        tree_put_value[n] = put_prices[i]

    # Value the bond by backward induction starting at bond maturity
    call_put_bond_values = np.zeros(shape=(num_time_steps, num_nodes))
    bond_values = np.zeros(shape=(num_time_steps, num_nodes))

    debug = False
    if debug:
        df = 1.0
        px = 0.0
        for i in range(0, maturity_step + 1):
            flow = tree_flows[i]
            t = _tree_times[i]
            df = _uinterpolate(t, _df_times, _df_values, INTERP_TYPE)
            px += flow * df
        px += df

    # Now step back to today considering early exercise

    m = maturity_step
    nm = maturity_step
    vcall = tree_call_value[m]
    vput = tree_put_value[m]
    vhold = (1.0 + tree_flows[m]) * face_amount
    vclean = vhold - accrued[m]
    value = min(max(vclean, vput), vcall) + accrued[m]

    for k in range(0, nm + 1):
        bond_values[m, k] = (1.0 + tree_flows[m]) * face_amount
        call_put_bond_values[m, k] = value

    for m in range(maturity_step - 1, -1, -1):
        nm = m
        flow = tree_flows[m] * face_amount
        vcall = tree_call_value[m]
        vput = tree_put_value[m]

        for k in range(0, nm + 1):

            rt = _rt[m, k]
            df = np.exp(-rt * dt)

            vu = bond_values[m + 1, k + 1]
            vd = bond_values[m + 1, k]
            v = (pu * vu + pd * vd) * df

            bond_values[m, k] = v
            bond_values[m, k] += flow

            vu = call_put_bond_values[m + 1, k + 1]
            vd = call_put_bond_values[m + 1, k]

            vhold = (pu * vu + pd * vd) * df
            # Need to make add on coupons paid if we hold
            vhold = vhold + flow
            value = min(max(vhold - accrued[m], vput), vcall) + accrued[m]
            call_put_bond_values[m, k] = value

    return (call_put_bond_values[0, 0], bond_values[0, 0])


########################################################################################


@njit(cache=True, fastmath=True)
def build_tree_fast(
    sigma: float,
    tree_times: np.ndarray,
    num_time_steps: int,
    discount_factors: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Unlike the BK and HW Trinomial trees, this Tree is packed into the lower
    diagonal of a square matrix because of its binomial nature. This means
    that the indexing of the arrays is different."""

    tree_maturity = tree_times[-1]
    dt = tree_maturity / (num_time_steps + 1)

    # The short rate goes out one step extra to have the final short rate
    # as it follows HW code, but I am not sure if this is needed. EXAMINE
    # NOTE HW code uses this to have short rate at expiry, so it can use
    # analytical solutions for the zero coupon bond price
    # This is the BDT model so x = log(r)

    # Some implementations use continuous compounding. Does not affect results.
    # Useful if you want to make direct comparisons of the tree.
    cont_compounded = True

    qq = np.zeros(shape=(num_time_steps + 2, num_time_steps + 2))
    rt = np.zeros(shape=(num_time_steps + 2, num_time_steps + 2))

    if cont_compounded:
        r0 = -np.log(discount_factors[1]) / dt
    else:
        r0 = (1.0 / discount_factors[1] - 1.0) / dt

    rt[0, 0] = r0
    qq[0, 0] = 1.0

    if cont_compounded:
        qq[1, 0] = 0.50 * np.exp(-rt[0, 0] * dt)
        qq[1, 1] = 0.50 * np.exp(-rt[0, 0] * dt)
    else:
        qq[1, 0] = 0.50 / ((1.0 + rt[0, 0]) ** dt)
        qq[1, 1] = 0.50 / ((1.0 + rt[0, 0]) ** dt)

    # The short rate goes out one step extra to have the final short rate
    # as it follows HW code, but I am not sure if this is needed. EXAMINE
    for m in range(1, num_time_steps + 1):

        df_end = discount_factors[m + 1]
        r0 = search_root(r0, m, qq, rt, df_end, dt, sigma)

        if cont_compounded:
            qq[m + 1, 0] = 0.50 * qq[m, 0] * np.exp(-rt[m, 0] * dt)
        else:
            qq[m + 1, 0] = 0.50 * qq[m, 0] / ((1.0 + rt[m, 0]) ** dt)

        for n in range(1, m + 1):

            if cont_compounded:
                qq[m + 1, n] = 0.50 * qq[m, n - 1] * np.exp(
                    -rt[m, n - 1] * dt
                ) + 0.50 * qq[m, n] * np.exp(-rt[m, n] * dt)
            else:
                qq[m + 1, n] = 0.50 * qq[m, n - 1] / (
                    (1.0 + rt[m, n - 1]) ** dt
                ) + 0.50 * qq[m, n] / ((1.0 + rt[m, n]) ** dt)

        if cont_compounded:
            qq[m + 1, m + 1] = 0.50 * qq[m, m] * np.exp(-rt[m, m] * dt)
        else:
            qq[m + 1, m + 1] = 0.50 * qq[m, m] / ((1.0 + rt[m, m]) ** dt)

    return (qq, rt, dt)


########################################################################################


class BDTTree:

    ####################################################################################

    def __init__(self, sigma: float, num_time_steps: int = 100) -> None:
        """Constructs the Black-Derman-Toy rate model in the case when the
        volatility is assumed to be constant. The short rate process simplifies
        and is given by d(log(r)) = theta(t) * dt + sigma * dW."""

        if sigma < 0.0:
            raise FinError("Negative volatility not allowed.")

        self.sigma = sigma

        if num_time_steps < 3:
            raise FinError("Drift fitting requires at least 3 time steps.")

        self.num_time_steps = num_time_steps

        self.qq = None
        self.rt = None

        self.discount_curve = None

        self._dt = None
        self._df_times = None
        self._df_values = None
        self._tree_times = None

    ####################################################################################

    def build_tree(
        self,
        tree_mat: float,
        df_times: np.ndarray,
        df_values: np.ndarray,
    ) -> None:

        if isinstance(df_times, np.ndarray) is False:
            raise FinError("DF TIMES must be a numpy vector")

        if isinstance(df_values, np.ndarray) is False:
            raise FinError("DF VALUES must be a numpy vector")

        interp = InterpTypes.FLAT_FWD_RATES.value

        tree_maturity = tree_mat * (self.num_time_steps + 1) / self.num_time_steps
        tree_times = np.linspace(0.0, tree_maturity, self.num_time_steps + 2)
        self._tree_times = tree_times

        df_tree = np.zeros(shape=self.num_time_steps + 2)
        df_tree[0] = 1.0

        for i in range(1, self.num_time_steps + 2):
            t = tree_times[i]
            df_tree[i] = _uinterpolate(t, df_times, df_values, interp)

        self._df_times = df_times
        self._df_values = df_values

        self.qq, self.rt, self._dt = build_tree_fast(
            self.sigma, tree_times, self.num_time_steps, df_tree
        )

        return

    ####################################################################################

    def bond_option(
        self,
        t_exp: float,
        strike_price: float,
        face_amount: float,
        cpn_times: np.ndarray,
        cpn_flows: np.ndarray,
        exercise_type: ExerciseTypes,
    ):
        """Value a bond option that can have European or American exercise
        using the Black-Derman-Toy model. The model uses a binomial tree."""

        exercise_type_int = option_exercise_types_to_int(exercise_type)

        t_mat = cpn_times[-1]

        if t_exp > t_mat:
            raise FinError("Option expiry after bond matures.")

        if t_exp < 0.0:
            raise FinError("Option expiry time negative.")

        if self.rt is None or self.qq is None:
            raise FinError("Tree has not been built.")

        call_value, put_value = american_bond_option_tree_fast(
            t_exp,
            t_mat,
            strike_price,
            face_amount,
            cpn_times,
            cpn_flows,
            exercise_type_int,
            self._df_times,
            self._df_values,
            self._tree_times,
            self.rt,
            self._dt,
        )

        return (call_value, put_value)

    ####################################################################################

    def bermudan_swaption(
        self,
        t_exp: float,
        t_mat: float,
        strike: float,
        face_amount: float,
        cpn_times: np.ndarray,
        cpn_flows: np.ndarray,
        exercise_type: ExerciseTypes,
    ):
        """Swaption that can be exercised on specific dates over the exercise
        period. Due to non-analytical bond price we need to extend tree out to
        bond maturity and take into account cash flows through time."""

        exercise_type_int = option_exercise_types_to_int(exercise_type)

        t_mat = cpn_times[-1]

        if t_exp > t_mat:
            raise FinError("Option expiry after bond matures.")

        if t_exp < 0.0:
            raise FinError("Option expiry time negative.")

        pay_value, rec_value = bermudan_swaption_tree_fast(
            t_exp,
            t_mat,
            strike,
            face_amount,
            cpn_times,
            cpn_flows,
            exercise_type_int,
            self._df_times,
            self._df_values,
            self._tree_times,
            self.qq,
            self.rt,
            self._dt,
        )

        return (pay_value, rec_value)

    ####################################################################################

    def callable_puttable_bond_tree(
        self,
        cpn_times: np.ndarray,
        cpn_flows: np.ndarray,
        call_times: np.ndarray,
        call_prices: np.ndarray,
        put_times: np.ndarray,
        put_prices: np.ndarray,
        face_amount: float,
    ):
        """Option that can be exercised at any time over the exercise period.
        Due to non-analytical bond price we need to extend tree out to bond
        maturity and take into account cash flows through time."""

        call_times = np.array(call_times)
        put_times = np.array(put_times)

        call_prices = np.array(call_prices)
        put_prices = np.array(put_prices)

        v = callable_puttable_bond_tree_fast(
            cpn_times,
            cpn_flows,
            call_times,
            call_prices,
            put_times,
            put_prices,
            face_amount,
            self.rt,
            self._dt,
            self._tree_times,
            self._df_times,
            self._df_values,
        )

        return v

    ####################################################################################

    def __repr__(self) -> str:
        """Return string with class details."""

        s = "Black-Derman-Toy Model\n"
        s += label_to_string("Sigma", self.sigma)
        s += label_to_string("num_time_steps", self.num_time_steps)
        return s
