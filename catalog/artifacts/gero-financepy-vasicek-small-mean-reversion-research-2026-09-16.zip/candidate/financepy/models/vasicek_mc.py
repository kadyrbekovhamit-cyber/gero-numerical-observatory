# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

from math import sqrt, exp, expm1
from numba import njit, float64, int64
import numba as nb
import numpy as np

from ..utils.helpers import label_to_string

# dr = a(b-r) + sigma dW

# TO DO - DECIDE WHETHER TO OO MODEL

########################################################################################



from typing import Any

class ModelRatesVasicek:

    ####################################################################################

    def __init__(self, a: float, b: float, sigma: float) -> None:

        self._a = a
        self._b = b
        self._sigma = sigma

    ####################################################################################

    def __repr__(self) -> str:

        s = label_to_string("OBJECT_TYPE", type(self).__name__)
        s += label_to_string("a", self._a)
        s += label_to_string("b", self._b)
        s += label_to_string("sigma", self._sigma)
        return s


########################################################################################


@njit(fastmath=True, cache=True)
def meanr(
    r0: float,
    a: float,
    b: float,
    t: float
) -> float:
    """Expectation of short rate at later time t"""
    mr = r0 * exp(-a * t) + b * (1 - exp(-a * t))
    return mr


########################################################################################


@njit(fastmath=True, cache=True)
def variancer(
    a: float,
    sigma: float,
    t: float
) -> float:
    """Variance of short rate at later time t"""
    vr = sigma * sigma * (1.0 - exp(-2.0 * a * t)) / 2.0 / a
    return vr


########################################################################################


@njit(fastmath=True, cache=True)
def zero_price(
    r0: float,
    a: float,
    b: float,
    sigma: float,
    t: float
) -> float:
    """Generate zero price analytically using Vasicek model"""
    # For small a*t the conventional affine expression cancels large terms.
    # Integrating the Gaussian short rate gives log(P) = -mean + variance/2.
    x = a * t
    if abs(x) < 0.5:
        bb = t if x == 0.0 else -t * expm1(-x) / x
        # Integral_0^t B(s)^2 ds / t^3, in powers of x = a*t.
        # Coefficient n: ((-2)^(n+2)-2*(-1)^(n+2))/((n+2)!*(n+3)).
        coefficients = (
            0.3333333333333333,
            -0.25,
            0.11666666666666667,
            -0.041666666666666664,
            0.012301587301587301,
            -0.003125,
            0.0006999559082892416,
            -0.00014054232804232804,
            2.5603254769921436e-05,
            -4.2713844797178134e-06,
            6.574572546794769e-07,
            -9.394540644540644e-08,
            1.2527583625467223e-08,
            -1.5660435427300506e-09,
            1.8424603970627936e-10,
            -2.0472094573725967e-11,
            2.1549737648205952e-12,
            -2.1549819854558418e-13,
            2.052367710260443e-14,
            -1.865790606867772e-15,
        )
        integral_factor = coefficients[-1]
        for i in range(len(coefficients) - 2, -1, -1):
            integral_factor = coefficients[i] + x * integral_factor
        variance = sigma * sigma * t * t * t * integral_factor
        mean = b * t + (r0 - b) * bb
        return exp(-mean + 0.5 * variance)

    bb = (1.0 - exp(-a * t)) / a
    aa = exp(
        (b - sigma * sigma / 2.0 / a / a) * (bb - t) - bb * bb * sigma * sigma / 4.0 / a
    )
    zcb = aa * exp(-r0 * bb)
    return zcb


########################################################################################


@njit(
    float64[:](float64, float64, float64, float64, float64, float64, int64),
    parallel=False,
    fastmath=True,
    cache=True,
)
def rate_path_mc(
    r0: float,
    a: float,
    b: float,
    sigma: float,
    t: float,
    dt: float,
    seed: int
) -> np.ndarray:
    """Generate a path of short rates using Vasicek model"""

    np.random.seed(seed)
    num_steps = int(t / dt)
    rate_path = np.zeros(num_steps)
    rate_path[0] = r0
    num_paths = 1

    sigmasqrt_dt = sigma * sqrt(dt)

    for _ in nb.prange(num_paths):

        r = r0
        z = np.random.normal(0.0, 1.0, size=num_steps - 1)

        for i_step in range(1, num_steps):
            r = r + a * (b - r) * dt + z[i_step - 1] * sigmasqrt_dt
            rate_path[i_step] = r

    return rate_path


########################################################################################


@njit(
    float64(float64, float64, float64, float64, float64, float64, int64, int64),
    cache=True,
    parallel=False,
)
def zero_price_mc(
    r0: float,
    a: float,
    b: float,
    sigma: float,
    t: float,
    dt: float,
    num_paths: int,
    seed: int
) -> float:
    """Generate zero price by Monte Carlo using Vasicek model"""
    np.random.seed(seed)
    num_steps = int(t / dt)
    sigmasqrt_dt = sigma * sqrt(dt)
    zcb = 0.0
    for _ in nb.prange(num_paths):
        z = np.random.normal(0.0, 1.0, size=num_steps)
        rsum = 0.0
        r = r0
        for i_step in range(0, num_steps):
            r += a * (b - r) * dt + z[i_step] * sigmasqrt_dt
            rsum += r * dt
        zcb += exp(-rsum)
    zcb /= num_paths
    return zcb
