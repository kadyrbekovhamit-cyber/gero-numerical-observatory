# FinancePy Vasicek small-mean-reversion audit

Read REPORT_EN.md for results and limitations. This archive contains public source and synthetic inputs only. FinancePy code retains GPLv3 and its original copyright. Independent research by Xamit Kadirbekov / GERO, with AI-assisted investigation and preparation.

Reproduction: Python 3.12 and requirements-reproduction.txt, then `python reproduce.py --output /path/to/new-directory`. Git is required for the clean patch check. The runner requires a fresh output directory and uses one numerical thread. It does not install dependencies or contact the network.

Historical preparation scripts are retained under historical_scripts/ and are not the portable entry point. Some historical logs contain original local paths; no access credentials are included.
