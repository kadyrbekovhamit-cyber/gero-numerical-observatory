# Sources and provenance

Executed baseline: https://github.com/domokane/FinancePy/tree/2b9227fea9d832c4033421d6cd53a54316414fca

Latest reviewed target: https://github.com/domokane/FinancePy/blob/87779f5e1bd99b1a0d2eae241d2c453488b0c76d/financepy/models/vasicek_mc.py

Official released package: https://pypi.org/project/financepy/1.1.2/ . Its target bytes match the baseline; the whole source package differs on 14 paths, recorded in evidence/package-verification.json.

Independent oracle: integrated Gaussian short-rate moments, implemented in oracle.py; 80/120-digit agreement and 48 separate quadrature controls.

Duplicate scope: 258 official upstream issue/PR title/body records, focused searches, earlier target history and fresh 99-publication GERO catalog. The CIR issue264 is separate. No claim to global novelty of stable arithmetic or guaranteed correctness outside tested regimes.

Published GERO catalog: https://www.gero.uz/research/publication-records.html

This study and the candidate are not an upstream-accepted correction.
