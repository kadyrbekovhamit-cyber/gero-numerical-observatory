import numpy as np
import matplotlib.pyplot as plt

from financepy.utils.date import Date
from financepy.utils.global_vars import G_BASIS_POINT
from financepy.utils.global_types import SwapTypes
from financepy.utils.calendar import CalendarTypes
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes
from financepy.market.curves.interpolator import InterpTypes
from financepy.products.rates.ibor_deposit import IborDeposit
from financepy.products.rates.ibor_fra import IborFRA
from financepy.products.rates.ibor_swap import IborSwap
from financepy.products.rates.ibor_single_curve import IborSingleCurve
import financepy.products.rates.ibor_curve_risk_engine as re

from unit_tests.helpers import build_ibor_single_curve

# when set to True this file can be run standalone and will produce some useful output.
# Set to False to use as part of a testing framework
diagnostics_mode = False

########################################################################################


def test_par_rate_risk_report_cubic_zero():

    valuation_date = Date(6, 10, 2001)
    cal = CalendarTypes.LONDON
    interp_type = InterpTypes.FINCUBIC_ZERO_RATES

    depo_dcc_type = DayCountTypes.ACT_360
    fra_dcc_type = DayCountTypes.ACT_360
    swap_type = SwapTypes.PAY
    fixed_dcc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL

    settle_dt, base_curve = _generate_base_curve(
        valuation_date,
        cal,
        interp_type,
        depo_dcc_type,
        fra_dcc_type,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
    )
    trades = _generate_trades(
        valuation_date,
        cal,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # size of bump to apply. In all cases par risk is reported as change in value to 1 bp rate bump
    par_rate_bump = 1 * G_BASIS_POINT

    # run the report
    base_values, risk_report = re.par_rate_risk_report(
        base_curve, trades, bump_size=par_rate_bump
    )

    expected_totals = [
        0.00122854,
        -0.25323828,
        -0.24271177,
        -0.01423219,
        0.31617136,
        4.0262114,
        2.03409619,
        -0.3957559,
    ]

    # Revised values
    expected_totals = [
        1.49548616e-03,
        -2.53270142e-01,
        -2.41647351e-01,
        -1.73299248e-02,
        3.23081731e-01,
        4.01797349e00,
        2.03919974e00,
        -3.98092480e-01,
    ]

    actual_totals = risk_report["total"].values

    if diagnostics_mode:
        trade_labels = list(base_values.keys())
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report["total"].values)
        print(risk_report[trade_labels + ["total"]].sum(axis=0))

    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def test_par_rate_risk_report_flat_forward():

    valuation_date = Date(6, 10, 2022)
    base_curve = build_ibor_single_curve(valuation_date, "10Y")
    settle_dt = base_curve.used_swaps[0].effective_dt
    cal = base_curve.used_swaps[0].fixed_leg.cal_type
    fixed_day_count = base_curve.used_swaps[0].fixed_leg.accrual_dc_type
    fixed_freq_type = base_curve.used_swaps[0].fixed_leg.freq_type

    trades = _generate_trades(
        valuation_date,
        cal,
        SwapTypes.PAY,
        fixed_day_count,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # size of bump to apply. In all cases par risk is reported as change in value to 1 bp rate bump
    par_rate_bump = 1 * G_BASIS_POINT

    # run the report
    base_values, risk_report = re.par_rate_risk_report(
        base_curve, trades, bump_size=par_rate_bump
    )

    expected_totals = [
        -0.08618,
        -0.20570,
        -0.08617,
        -0.07783,
        -0.05001,
        0.000055,
        0.0000568,
        0.0000550,
        0.0000568,
        0.0000568,
        0.0000266,
        -0.00001650,
        -0.00001597,
        1.00523,
        1.5004,
        3.99996586,
        0,
        0,
        0,
        0,
        0,
        0,
    ]
    actual_totals = risk_report["total"].values

    if diagnostics_mode:
        trade_labels = list(base_values.keys())
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report["total"].values)
        print(risk_report[trade_labels + ["total"]].sum(axis=0))

#    for i in range(0, len(expected_totals)):
#        print(i, actual_totals[i], expected_totals[i])

    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def test_forward_rate_risk_report():

    valuation_date = Date(6, 10, 2001)
    cal = CalendarTypes.LONDON
    interp_type = InterpTypes.FLAT_FWD_RATES

    depo_dcc_type = DayCountTypes.ACT_360
    fra_dcc_type = DayCountTypes.ACT_360
    swap_type = SwapTypes.PAY
    fixed_dcc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL

    settle_dt, base_curve = _generate_base_curve(
        valuation_date,
        cal,
        interp_type,
        depo_dcc_type,
        fra_dcc_type,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
    )
    trades = _generate_trades(
        valuation_date,
        cal,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # the grid on which we generate the risk report
    grid_bucket = "3M"
    grid_last_date = max(t.maturity_dt for t in trades)

    # size of bump to apply. In all cases par risk is reported as change in value to 1 bp rate bump
    forward_rate_bump = 1 * G_BASIS_POINT

    # run the report
    base_values, risk_report = re.forward_rate_risk_report(
        base_curve,
        grid_last_date,
        grid_bucket,
        trades,
        bump_size=forward_rate_bump,
    )

    expected_totals = [
        0.25196322,
        0.24648603,
        0.48750647,
        0.49286362,
        0.48160453,
        0.47113499,
        0.46547237,
        0.47058739,
        0.45980829,
        0.45481044,
        0.23117766,
        0.22408547,
        0.2190641,
        0.21423566,
        0.21169689,
        0.21396794,
        0.0,
    ]

    # Revised values
    expected_totals = [
        0.25196322,
        0.24648603,
        0.48750632,
        0.49286346,
        0.48160521,
        0.47113566,
        0.46547385,
        0.47058889,
        0.45981059,
        0.45481271,
        0.23189803,
        0.22408462,
        0.21910605,
        0.2142347,
        0.21175048,
        0.21396686,
        0.00232576,
    ]

    actual_totals = risk_report[re.DV01_PREFIX + "total"].values

    if diagnostics_mode:
        dv01_trade_labels = [re.DV01_PREFIX + l for l in base_values.keys()]
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report)
        print(risk_report[re.DV01_PREFIX + "total"].values)
        print(
            risk_report[dv01_trade_labels + [re.DV01_PREFIX + "total"]].sum(
                axis=0
            )
        )

    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def test_forward_rate_custom_grid_risk_report():

    valuation_date = Date(6, 10, 2001)
    cal = CalendarTypes.LONDON
    interp_type = InterpTypes.FLAT_FWD_RATES

    depo_dcc_type = DayCountTypes.ACT_360
    fra_dcc_type = DayCountTypes.ACT_360
    swap_type = SwapTypes.PAY
    fixed_dcc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL

    settle_dt, base_curve = _generate_base_curve(
        valuation_date,
        cal,
        interp_type,
        depo_dcc_type,
        fra_dcc_type,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
    )
    trades = _generate_trades(
        valuation_date,
        cal,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # the grid on which we generate the risk report
    grid = [
        valuation_date,
        valuation_date.add_tenor("3M"),
        valuation_date.add_tenor("15M"),
        valuation_date.add_tenor("10Y"),
    ]

    # size of bump to apply. In all cases par risk is reported as change in value to 1 bp rate bump
    forward_rate_bump = 1 * G_BASIS_POINT

    # run the report
    base_values, risk_report, *_ = re.forward_rate_risk_report_custom_grid(
        base_curve, grid, trades, bump_size=forward_rate_bump
    )

    expected_totals = [0.24374713, 1.70089994, 3.65138343]
    expected_totals = [0.24374713, 1.70090029, 3.65452971]  # DOK REVISED

    actual_totals = risk_report[re.DV01_PREFIX + "total"].values

    if diagnostics_mode:
        dv01_trade_labels = [re.DV01_PREFIX + l for l in base_values.keys()]
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report)
        print(risk_report[re.DV01_PREFIX + "total"].values)
        print(
            risk_report[dv01_trade_labels + [re.DV01_PREFIX + "total"]].sum(
                axis=0
            )
        )

    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def test_carry_rolldown_report():

    valuation_date = Date(6, 10, 2001)
    cal = CalendarTypes.LONDON
    interp_type = InterpTypes.FLAT_FWD_RATES

    depo_dcc_type = DayCountTypes.ACT_360
    fra_dcc_type = DayCountTypes.ACT_360
    swap_type = SwapTypes.PAY
    fixed_dcc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL

    settle_dt, base_curve = _generate_base_curve(
        valuation_date,
        cal,
        interp_type,
        depo_dcc_type,
        fra_dcc_type,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
    )
    trades = _generate_trades(
        valuation_date,
        cal,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # the grid on which we generate the risk report
    grid_bucket = "6M"
    grid_last_date = max(t.maturity_dt for t in trades)

    # run the report
    base_values, risk_report, *_ = re.carry_rolldown_report(
        base_curve,
        grid_last_date,
        grid_bucket,
        trades,
    )

    if diagnostics_mode:
        roll_trade_labels = [re.ROLL_PREFIX + l for l in base_values.keys()]
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report)
        print(risk_report[re.ROLL_PREFIX + "total"].values)
        print(
            risk_report[roll_trade_labels + [re.ROLL_PREFIX + "total"]].sum(
                axis=0
            )
        )

    expected_totals = [
        -21.07588523,
        16.07402002,
        -27.27637637,
        -0.02469482,
        -104.29563056,
        0.32142506,
        35.98144427,
        0.28310627,
        0.0,
    ]

    # Revised values
    expected_totals = [
        -2.10821110e01,
        1.60740149e01,
        -2.72764149e01,
        -2.46948979e-02,
        -1.03975288e02,
        2.02494493e-12,
        3.60652676e01,
        3.79891312e-01,
        1.26130524e-02,
    ]

    actual_totals = risk_report[re.ROLL_PREFIX + "total"].values
    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def test_parallel_shift_ladder_report():

    valuation_date = Date(6, 10, 2001)
    cal = CalendarTypes.LONDON
    interp_type = InterpTypes.FLAT_FWD_RATES

    depo_dcc_type = DayCountTypes.ACT_360
    fra_dcc_type = DayCountTypes.ACT_360
    swap_type = SwapTypes.PAY
    fixed_dcc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL

    settle_dt, base_curve = _generate_base_curve(
        valuation_date,
        cal,
        interp_type,
        depo_dcc_type,
        fra_dcc_type,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
    )
    trades = _generate_trades(
        valuation_date,
        cal,
        swap_type,
        fixed_dcc_type,
        fixed_freq_type,
        settle_dt,
        base_curve,
    )

    # the curve shift grids on which we calculate the PV ladder
    curve_shifts = np.linspace(
        -400 * G_BASIS_POINT, 400 * G_BASIS_POINT, 17, endpoint=True
    )

    # run the report
    base_values, risk_report = re.parallel_shift_ladder_report(
        base_curve,
        curve_shifts,
        trades,
    )

    if diagnostics_mode:
        pv_trade_labels = [re.PV_PREFIX + l for l in base_values.keys()]
        np.set_printoptions(suppress=True)
        print(base_values)
        print(risk_report)
        print(risk_report[re.PV_PREFIX + "total"].values)
        print(
            risk_report[pv_trade_labels + [re.PV_PREFIX + "total"]].sum(axis=0)
        )

        # risk_report.plot('shift_bp', re.PV_PREFIX + 'total')
        x = risk_report["shift_bp"].values
        y = risk_report[re.PV_PREFIX + "total"].values
        plt.plot(x, y - x * (y[-1] - y[0]) / (x[-1] - x[0]))
        plt.show()

    expected_totals = [
        -2407.30636808,
        -2087.15913624,
        -1772.70446365,
        -1463.84150813,
        -1160.47126898,
        -862.49655251,
        -569.82193811,
        -282.35374508,
        -0.0,
        277.32959522,
        549.7236947,
        817.26933932,
        1080.05198694,
        1338.15554197,
        1591.66238438,
        1840.6533982,
        2085.20799948,
    ]

    # Revised values
    expected_totals = [
        -2.40876334e03,
        -2.08841087e03,
        -1.77375794e03,
        -1.46470351e03,
        -1.16114839e03,
        -8.62995206e02,
        -5.70148364e02,
        -2.82514009e02,
        -2.27373675e-13,
        2.77484124e02,
        5.50027177e02,
        8.17716355e02,
        1.08063727e03,
        1.33887397e03,
        1.59250898e03,
        1.84162332e03,
        2.08629655e03,
    ]

    actual_totals = risk_report[re.PV_PREFIX + "total"].values
    assert max(np.abs(actual_totals - expected_totals)) <= 1e-4


########################################################################################


def _generate_trades(
    valuation_date,
    cal,
    swap_type,
    fixed_dcc_type,
    fixed_freq_type,
    settle_dt,
    base_curve,
):
    trade1 = IborSwap(
        settle_dt,
        "4Y",
        swap_type,
        4.20 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
        notional=10000,
    )
    atm = trade1.swap_rate(valuation_date, base_curve)
    trade1.set_fixed_rate(atm)
    trade2 = IborSwap(
        settle_dt.add_tenor("6M"),
        "2Y",
        swap_type,
        4.20 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
        notional=10000,
    )
    atm = trade2.swap_rate(valuation_date, base_curve)
    trade2.set_fixed_rate(atm)
    trades = [trade1, trade2]
    return trades


########################################################################################


def _generate_base_curve(
    valuation_date,
    cal,
    interp_type,
    depo_dcc_type,
    fra_dcc_type,
    swap_type,
    fixed_dcc_type,
    fixed_freq_type,
    ########################################################################################
):
    depos = []
    spot_days = 2
    settle_dt = valuation_date.add_weekdays(spot_days)
    depo = IborDeposit(
        settle_dt, "3M", 4.2 / 100.0, depo_dcc_type, cal_type=cal
    )
    depos.append(depo)

    fras = []
    fra = IborFRA(
        settle_dt.add_tenor("3M"),
        "3M",
        4.20 / 100.0,
        fra_dcc_type,
        cal_type=cal,
    )
    fras.append(fra)

    swaps = []
    swap = IborSwap(
        settle_dt,
        "1Y",
        swap_type,
        4.20 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
    )
    swaps.append(swap)
    swap = IborSwap(
        settle_dt,
        "2Y",
        swap_type,
        4.30 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
    )
    swaps.append(swap)
    swap = IborSwap(
        settle_dt,
        "3Y",
        swap_type,
        4.70 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
    )
    swaps.append(swap)
    swap = IborSwap(
        settle_dt,
        "5Y",
        swap_type,
        4.70 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
    )
    swaps.append(swap)
    swap = IborSwap(
        settle_dt,
        "7Y",
        swap_type,
        4.70 / 100.0,
        fixed_freq_type,
        fixed_dcc_type,
        cal_type=cal,
    )
    swaps.append(swap)

    base_curve = IborSingleCurve(
        valuation_date,
        depos,
        fras,
        swaps,
        interp_type,
    )

    return settle_dt, base_curve


########################################################################################

########################################################################################

if __name__ == "__main__":
    test_par_rate_risk_report_cubic_zero()
    test_forward_rate_risk_report()
    test_forward_rate_custom_grid_risk_report()
    test_carry_rolldown_report()
    test_parallel_shift_ladder_report()
    test_par_rate_risk_report_flat_forward
