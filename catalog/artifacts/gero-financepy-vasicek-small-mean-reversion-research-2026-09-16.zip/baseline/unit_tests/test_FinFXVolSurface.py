# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

from financepy.utils.global_types import VolFuncTypes
from financepy.utils.date import Date
from financepy.utils.global_types import FXDeltaMethodTypes
from financepy.utils.global_types import FXATMMethodTypes
from financepy.market.volatility.fx_vol_surface import FXVolSurface
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve

import numpy as np

verbose_calibration = False

########################################################################################


def test_fin_fx_mkt_vol_surface1(capsys):

    # Example from Book extract by Iain Clarke using Tables 3.3 and 3.4
    # print("EURUSD EXAMPLE CLARK")

    value_dt = Date(10, 4, 2020)

    for_name = "EUR"
    dom_name = "USD"
    for_cc_rate = 0.03460  # EUR
    dom_cc_rate = 0.02940  # USD

    domestic_curve = FlatDiscountCurve(value_dt, dom_cc_rate)
    foreign_curve = FlatDiscountCurve(value_dt, for_cc_rate)

    currency_pair = for_name + dom_name
    spot_fx_rate = 1.3465

    tenors = ["1M", "2M", "3M", "6M", "1Y", "2Y"]
    atm_vols = np.array([21.00, 21.00, 20.750, 19.400, 18.250, 17.677])
    mkt_strangle_25d_vols = np.array([0.65, 0.75, 0.85, 0.90, 0.95, 0.85])
    rsk_reversal_25d_vols = np.array([-0.20, -0.25, -0.30, -0.50, -0.60, -0.562])

    notional_currency = for_name

    atm_method = FXATMMethodTypes.FWD_DELTA_NEUTRAL
    delta_method = FXDeltaMethodTypes.SPOT_DELTA
    vol_function_type = VolFuncTypes.CLARK

    fx_market = FXVolSurface(
        value_dt,
        spot_fx_rate,
        currency_pair,
        notional_currency,
        domestic_curve,
        foreign_curve,
        tenors,
        atm_vols,
        mkt_strangle_25d_vols,
        rsk_reversal_25d_vols,
        atm_method,
        delta_method,
        vol_function_type,
    )

    fx_market.check_calibration(verbose_calibration, tol=1e-5)
    captured = capsys.readouterr()
    assert captured.out == ""


########################################################################################


def test_fin_fx_mkt_vol_surface2(capsys):

    # Example from Book extract by Iain Clark using Tables 3.3 and 3.4
    # print("EURJPY EXAMPLE CLARK")

    value_dt = Date(10, 4, 2020)

    for_name = "EUR"
    dom_name = "JPY"
    for_cc_rate = 0.0294  # EUR
    dom_cc_rate = 0.0171  # USD

    domestic_curve = FlatDiscountCurve(value_dt, dom_cc_rate)
    foreign_curve = FlatDiscountCurve(value_dt, for_cc_rate)

    currency_pair = for_name + dom_name
    spot_fx_rate = 90.72

    tenors = ["1M", "2M", "3M", "6M", "1Y", "2Y"]
    atm_vols = np.array([21.50, 20.50, 19.85, 18.00, 15.95, 14.009])
    mkt_strangle_25d_vols = np.array([0.35, 0.325, 0.300, 0.225, 0.175, 0.100])
    rsk_reversal_25d_vols = np.array([-8.350, -8.650, -8.950, -9.250, -9.550, -9.500])

    notional_currency = for_name

    atm_method = FXATMMethodTypes.FWD_DELTA_NEUTRAL_PREM_ADJ
    delta_method = FXDeltaMethodTypes.SPOT_DELTA_PREM_ADJ

    fx_market = FXVolSurface(
        value_dt,
        spot_fx_rate,
        currency_pair,
        notional_currency,
        domestic_curve,
        foreign_curve,
        tenors,
        atm_vols,
        mkt_strangle_25d_vols,
        rsk_reversal_25d_vols,
        atm_method,
        delta_method,
    )

    fx_market.check_calibration(verbose_calibration)
    captured = capsys.readouterr()
    assert captured.out == ""


########################################################################################


def test_fin_fx_mkt_vol_surface3(capsys):

    # EURUSD Example from Paper by Uwe Wystup using Tables 4
    #        print("EURUSD EXAMPLE WYSTUP")

    value_dt = Date(20, 1, 2009)

    for_name = "EUR"
    dom_name = "USD"
    for_cc_rate = 0.020113  # EUR
    dom_cc_rate = 0.003525  # USD

    domestic_curve = FlatDiscountCurve(value_dt, dom_cc_rate)
    foreign_curve = FlatDiscountCurve(value_dt, for_cc_rate)

    currency_pair = for_name + dom_name
    spot_fx_rate = 1.3088

    tenors = ["1M"]
    atm_vols = np.array([21.6215])
    mkt_strangle_25d_vols = np.array([0.7375])
    rsk_reversal_25d_vols = np.array([-0.50])

    notional_currency = for_name

    atm_method = FXATMMethodTypes.FWD_DELTA_NEUTRAL
    delta_method = FXDeltaMethodTypes.SPOT_DELTA

    fx_market = FXVolSurface(
        value_dt,
        spot_fx_rate,
        currency_pair,
        notional_currency,
        domestic_curve,
        foreign_curve,
        tenors,
        atm_vols,
        mkt_strangle_25d_vols,
        rsk_reversal_25d_vols,
        atm_method,
        delta_method,
    )

    fx_market.check_calibration(verbose_calibration)
    captured = capsys.readouterr()
    assert captured.out == ""


########################################################################################


def test_fin_fx_mkt_vol_surface4(capsys):

    # USDJPY Example from Paper by Uwe Wystup using Tables 4

    value_dt = Date(20, 1, 2009)

    for_name = "USD"
    dom_name = "JPY"
    for_cc_rate = 0.003525  # USD
    dom_cc_rate = 0.0042875  # JPY

    domestic_curve = FlatDiscountCurve(value_dt, dom_cc_rate)
    foreign_curve = FlatDiscountCurve(value_dt, for_cc_rate)

    currency_pair = for_name + dom_name
    spot_fx_rate = 90.68

    tenors = ["1M"]
    atm_vols = np.array([21.00])
    mkt_strangle_25d_vols = np.array([0.184])
    rsk_reversal_25d_vols = np.array([-5.30])

    notional_currency = for_name

    atm_method = FXATMMethodTypes.FWD_DELTA_NEUTRAL
    delta_method = FXDeltaMethodTypes.SPOT_DELTA_PREM_ADJ

    fx_market = FXVolSurface(
        value_dt,
        spot_fx_rate,
        currency_pair,
        notional_currency,
        domestic_curve,
        foreign_curve,
        tenors,
        atm_vols,
        mkt_strangle_25d_vols,
        rsk_reversal_25d_vols,
        atm_method,
        delta_method,
    )

    fx_market.check_calibration(verbose_calibration)
    captured = capsys.readouterr()
    assert captured.out == ""
