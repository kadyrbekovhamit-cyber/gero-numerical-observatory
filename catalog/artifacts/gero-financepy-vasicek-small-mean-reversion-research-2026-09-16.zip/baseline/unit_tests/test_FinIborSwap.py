# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

import numpy as np

from financepy.market.curves.interpolator import InterpTypes
from financepy.market.curves.discount_curve import DiscountCurve
from financepy.utils.global_types import SwapTypes
from financepy.utils.date import Date
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes
from financepy.utils.calendar import CalendarTypes
from financepy.utils.calendar import DateGenRuleTypes
from financepy.utils.calendar import BusDayAdjustTypes
from financepy.products.rates.ibor_swap import IborSwap
from financepy.utils.math import ONE_MILLION

from .helpers import build_ibor_single_curve

########################################################################################


def _load_test_swap_and_curve(start_dt, end_dt):

    fixed_coupon = 0.015
    fixed_freq_type = FrequencyTypes.ANNUAL
    fixed_dc_type = DayCountTypes.THIRTY_E_360

    float_spread = 0.0
    float_freq_type = FrequencyTypes.SEMI_ANNUAL
    float_dc_type = DayCountTypes.ACT_360
    first_fixing = -0.00268

    swap_calendar_type = CalendarTypes.TARGET
    bus_day_adjust_type = BusDayAdjustTypes.FOLLOWING
    date_gen_rule_type = DateGenRuleTypes.BACKWARD
    fixed_leg_type = SwapTypes.RECEIVE

    notional = 10.0 * ONE_MILLION

    swap = IborSwap(
        start_dt,
        end_dt,
        fixed_leg_type,
        fixed_coupon,
        fixed_freq_type,
        fixed_dc_type,
        notional,
        float_spread,
        float_freq_type,
        float_dc_type,
        swap_calendar_type,
        bus_day_adjust_type,
        date_gen_rule_type,
    )

    """ Now perform a valuation after the swap has seasoned but with the
    same curve being used for discounting and working out the implied
    future Libor rates. """

    value_date = Date(30, 11, 2018)
    settle_dt = value_date.add_days(2)
    libor_curve = build_ibor_single_curve(value_date)
    return first_fixing, swap, settle_dt, libor_curve

########################################################################################


def test_libor_swap():

    # I have tried to reproduce the example from the blog by Ioannis Rigopoulos
    # https://blog.deriscope.com/index.php/en/excel-interest-rate-swap-price-dual-bootstrapping-curve

    start_dt = Date(27, 12, 2017)
    end_dt = Date(27, 12, 2067)

    # The swap is a long dated fixed vs Euribor interest rate swap that runs
    # until Dec 27, 2067. The exact details are shown below, along with its
    # Bloomberg valuation of 388,147.49 EUR as of Nov 30, 2018:

    first_fixing, swap, settle_dt, libor_curve = _load_test_swap_and_curve(
        start_dt, end_dt
    )

    v = swap.value(settle_dt, libor_curve, libor_curve, first_fixing)

    assert round(v, 0) == 392684.0


########################################################################################


def test_libor_swap_cashflow_report():

    # as test_LiborSwap but with extra output
    start_dt = Date(27, 12, 2017)
    end_dt = Date(27, 12, 2067)

    first_fixing, swap, settle_dt, libor_curve = _load_test_swap_and_curve(
        start_dt, end_dt
    )

    print(swap)

    v = swap.value(settle_dt, libor_curve, libor_curve, first_fixing, pv_only=False)

    sum_of_cashflows = v[1]["payment_pv"].sum()
    assert round(sum_of_cashflows - v[0], 4) == 0


########################################################################################


def test_dp_example():

    #  http://www.derivativepricing.com/blogpage.asp?id=8

    start_dt = Date(14, 11, 2011)
    end_dt = Date(14, 11, 2016)
    fixed_freq_type = FrequencyTypes.SEMI_ANNUAL
    swap_cal_type = CalendarTypes.TARGET
    bd_type = BusDayAdjustTypes.MODIFIED_FOLLOWING
    dg_type = DateGenRuleTypes.BACKWARD
    fixed_dc_type = DayCountTypes.THIRTY_E_360_ISDA
    fixed_leg_type = SwapTypes.PAY
    fixed_cpn = 0.0124
    notional = ONE_MILLION

    swap = IborSwap(
        start_dt,
        end_dt,
        fixed_leg_type,
        fixed_cpn=fixed_cpn,
        fixed_freq_type=fixed_freq_type,
        fixed_dc_type=fixed_dc_type,
        float_freq_type=FrequencyTypes.SEMI_ANNUAL,
        float_dc_type=DayCountTypes.ACT_360,
        notional=notional,
        cal_type=swap_cal_type,
        bd_type=bd_type,
        dg_type=dg_type,
    )

    dts = [
        Date(14, 11, 2011),
        Date(14, 5, 2012),
        Date(14, 11, 2012),
        Date(14, 5, 2013),
        Date(14, 11, 2013),
        Date(14, 5, 2014),
        Date(14, 11, 2014),
        Date(14, 5, 2015),
        Date(16, 11, 2015),
        Date(16, 5, 2016),
        Date(14, 11, 2016),
    ]

    dfs = [
        1.0,
        0.9966889,
        0.9942107,
        0.9911884,
        0.9880738,
        0.9836490,
        0.9786276,
        0.9710461,
        0.9621778,
        0.9514315,
        0.9394919,
    ]

    value_dt = start_dt

    curve = DiscountCurve(value_dt, dts, np.array(dfs), InterpTypes.FLAT_FWD_RATES)

    v = swap.value(value_dt, curve, curve)

    # This is essentially zero
    assert round(v, 1) == 15.7


########################################################################################

# if __name__ == '__main__':
#     test_libor_swap_cashflow_report()

test_libor_swap()
