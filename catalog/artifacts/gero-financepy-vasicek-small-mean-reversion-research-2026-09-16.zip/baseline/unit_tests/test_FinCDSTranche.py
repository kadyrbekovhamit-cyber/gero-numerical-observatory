# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

from financepy.utils.date import Date
from financepy.products.credit.cds_tranche import CDSTranche
from financepy.products.credit.cds_index_portfolio import CDSIndexPortfolio
from financepy.products.credit.cds_tranche import FinLossDistributionBuilder

from .helpers import (
    build_ibor_curve,
    load_hetero_spread_curves,
    load_homogeneous_cds_curves,
)

trade_dt = Date(1, 3, 2007)
step_in_dt = trade_dt.add_days(1)
value_dt = trade_dt.add_days(1)

libor_curve = build_ibor_curve(trade_dt)

tranche_maturity = Date(20, 12, 2011)
tranche1 = CDSTranche(value_dt, tranche_maturity, 0.00, 0.03)
tranche2 = CDSTranche(value_dt, tranche_maturity, 0.03, 0.06)
tranche3 = CDSTranche(value_dt, tranche_maturity, 0.06, 0.09)
tranche4 = CDSTranche(value_dt, tranche_maturity, 0.09, 0.12)
tranche5 = CDSTranche(value_dt, tranche_maturity, 0.12, 0.22)
tranche6 = CDSTranche(value_dt, tranche_maturity, 0.22, 0.60)
tranche7 = CDSTranche(value_dt, tranche_maturity, 0.00, 0.60)
tranches = [
    tranche1,
    tranche2,
    tranche3,
    tranche4,
    tranche5,
    tranche6,
    tranche7,
]

corr1 = 0.30
corr2 = 0.35
upfront = 0.0
spd = 0.0

cds_index = CDSIndexPortfolio()

########################################################################################


def test_homogeneous():

    num_credits = 125
    spd_3yr = 0.0012
    spd_5yr = 0.0025
    spd_7yr = 0.0034
    spd_10yr = 0.0046
    num_points = 40

    issuer_curves = load_homogeneous_cds_curves(
        value_dt, libor_curve, spd_3yr, spd_5yr, spd_7yr, spd_10yr, num_credits
    )

    intrinsic_spd = (
        cds_index.intrinsic_spread(
            value_dt, step_in_dt, tranche_maturity, issuer_curves
        )
        * 10000.0
    )

    assert round(intrinsic_spd, 3) == 23.977

    method = FinLossDistributionBuilder.RECURSION
    v = tranche1.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 3) == 582.505

    method = FinLossDistributionBuilder.ADJUSTED_BINOMIAL
    v = tranche3.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 3) == 29.980

    method = FinLossDistributionBuilder.GAUSSIAN
    v = tranche5.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 3) == 4.583

    method = FinLossDistributionBuilder.LHP
    v = tranche7.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 2) == 39.96


########################################################################################


def test_heterogeneous():

    num_points = 200

    issuer_curves = load_hetero_spread_curves(value_dt, libor_curve)

    intrinsic_spd = (
        cds_index.intrinsic_spread(
            value_dt, step_in_dt, tranche_maturity, issuer_curves
        )
        * 10000.0
    )

    assert round(intrinsic_spd, 4) == 34.331

    method = FinLossDistributionBuilder.RECURSION
    v = tranche1.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 3) == 868.479

    method = FinLossDistributionBuilder.ADJUSTED_BINOMIAL
    v = tranche2.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 2) == 173.46

    method = FinLossDistributionBuilder.GAUSSIAN
    v = tranche4.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 4) == 16.1757

    method = FinLossDistributionBuilder.LHP
    v = tranche6.value_bc(
        value_dt, issuer_curves, upfront, spd, corr1, corr2, num_points, method
    )
    assert round(v[3] * 10000, 3) == 0.338
