#!/usr/bin/env python3
"""Offline, one-worker native replay of the archived SplitLayer experiment.

Tested on macOS arm64. Requires a C++17 compiler, Meson and Ninja on PATH.
No dependency downloads, replacement math implementation, or frozen-file edits.
"""
from pathlib import Path
from fractions import Fraction
import argparse
import csv
import datetime
import hashlib
import json
import os
import platform
import shlex
import shutil
import subprocess
import sys
import tarfile

PACKAGE = Path(__file__).resolve().parent
PIN = "a7ea056e79ab8e14447ea305c1b634e233343258"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(archive, destination):
    destination.mkdir(parents=True, exist_ok=True)
    skipped = []
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            target = (destination / member.name).resolve()
            if not target.is_relative_to(destination.resolve()):
                raise ValueError("Unsafe archive path: " + member.name)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(member) as source:
                    data = source.read()
                if target.exists():
                    assert target.read_bytes() == data, str(target)
                else:
                    target.write_bytes(data)
                    target.chmod(member.mode & 0o777)
            elif member.issym() or member.islnk():
                skipped.append({"name": member.name, "target": member.linkname})
            else:
                raise ValueError("Unsupported archive member: " + member.name)
    return skipped


def assess(path):
    with path.open() as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    failures = {"full": 0, "incremental": 0, "input_preservation": 0}
    affected = set()
    controls = 0
    minimal = []
    for row in rows:
        b, c, h, w, axis, parts, pattern, out, index = [int(row[k]) for k in
            ("batch", "channels", "height", "width", "axis", "parts",
             "pattern", "output", "index")]
        dims = [b, c, h, w]
        out_dims = dims.copy()
        assert dims[axis] % parts == 0
        out_dims[axis] //= parts
        coords, remaining = [0] * 4, index
        for ax in (3, 2, 1, 0):
            coords[ax] = remaining % out_dims[ax]
            remaining //= out_dims[ax]
        assert remaining == 0
        coords[axis] += out * out_dims[axis]
        ix = 0
        for extent, coordinate in zip(dims, coords):
            assert 0 <= coordinate < extent
            ix = ix * extent + coordinate
        expected = Fraction(ix + 1)
        if pattern:
            expected *= Fraction(-1 if ix % 2 else 1, 4)
        for key in ("full", "incremental"):
            if Fraction(row[key]) != expected:
                failures[key] += 1
                affected.add(int(row["case"]))
        failures["input_preservation"] += row["input_preserved"] != "1"
        controls += c == 1 or axis != 3
        if (b, c, h, w, axis, parts, pattern) == (1, 2, 1, 2, 3, 2, 0):
            minimal.append({"output": out, "index": index,
                            "expected": str(expected), "full": row["full"],
                            "incremental": row["incremental"]})
    return rows, {"scenarios": len({r["case"] for r in rows}),
                  "output_coordinates": len(rows), "failures": failures,
                  "affected_scenarios": len(affected),
                  "control_coordinates": controls, "minimal": minimal,
                  "raw_sha256": sha(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path,
                        help="A new, nonexistent output directory")
    parser.add_argument("--tools-bin", type=Path,
                        help="Optional existing directory containing Meson/Ninja")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error("Output directory already exists; frozen results are never overwritten")
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        parser.error("This recorded build adapter is tested only on macOS arm64")
    if shutil.disk_usage(output.parent).free < 600 * 1024 * 1024:
        parser.error("At least 600 MiB of free working space is required")
    env = os.environ.copy()
    if args.tools_bin:
        env["PATH"] = str(args.tools_bin.resolve()) + os.pathsep + env.get("PATH", "")
    for name in ("meson", "ninja", "c++", "git"):
        if shutil.which(name, path=env["PATH"]) is None:
            parser.error("Missing existing build tool: " + name)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    output.mkdir()
    logs = output / "logs"
    logs.mkdir()
    source = output / "source"
    build = source / "build"
    commands = []

    def run(cmd, label, cwd, stdout_path=None):
        commands.append({"label": label, "argv": cmd, "cwd": str(cwd)})
        if stdout_path is None:
            stdout_path = logs / (label + ".log")
        with stdout_path.open("w") as out, (logs / (label + "-stderr.log")).open("w") as err:
            result = subprocess.run(cmd, cwd=cwd, env=env, stdout=out, stderr=err)
        print(label, "exit", result.returncode, flush=True)
        result.check_returncode()

    archive_hashes = json.loads((PACKAGE / "SOURCE_ARCHIVES.json").read_text())
    for name, expected in archive_hashes.items():
        assert sha(PACKAGE / "sources" / name) == expected, name
    skipped = {"main": extract(PACKAGE / "sources/nntrainer-build-source.tar.gz", source)}
    for name in ("googletest", "iniparser"):
        skipped[name] = extract(PACKAGE / "sources" / (name + "-source.tar.gz"),
                                source / "subprojects" / name)
    manifest = json.loads((PACKAGE / "sources/clean-source-manifest.json").read_text())
    present = {name: digest for name, digest in manifest.items() if (source / name).is_file()}
    for name, digest in present.items():
        assert sha(source / name) == digest, name
    required = [name for name in manifest if name.startswith(("nntrainer/", "api/"))
                and name.endswith((".h", ".c", ".cpp"))]
    assert len(required) == 603 and all(name in present for name in required)
    target = source / "nntrainer/layers/split_layer.cpp"
    assert target.read_bytes() == (PACKAGE / "evidence/split_layer.cpp").read_bytes()
    run(["git", "apply", "--check", str(PACKAGE / "candidate.patch")], "patch-check", source)
    run(["git", "apply", str(PACKAGE / "candidate.patch")], "patch-apply", source)
    assert target.read_bytes() == (PACKAGE / "candidate-split_layer.cpp").read_bytes()
    run(["git", "apply", "-R", str(PACKAGE / "candidate.patch")], "patch-restore", source)
    assert target.read_bytes() == (PACKAGE / "evidence/split_layer.cpp").read_bytes()

    run(["meson", "setup", "build", "--wrap-mode=nodownload", "-Denable-blas=false",
         "-Denable-app=false", "-Denable-ccapi=true", "-Denable-capi=disabled",
         "-Dml-api-support=disabled", "-Denable-tflite-backbone=false",
         "-Denable-tflite-interpreter=false", "-Denable-nnstreamer-tensor-filter=disabled",
         "-Denable-nnstreamer-tensor-trainer=disabled", "-Denable-test=true",
         "-Dnntr-num-threads=1", "-Dwerror=false", "-Dthread-backend=none",
         "-Dcpp_args=" + repr(["-include", str(PACKAGE / "sources/nntrainer-darwin-build.h")])],
        "configure", source)
    (build / "nntrainer/malloc.h").write_text("#include <malloc/malloc.h>\n")
    run(["ninja", "-C", "build", "-j1", "nntrainer/libnntrainer.dylib"], "native-core-build", source)
    library = build / "nntrainer/libnntrainer.dylib"
    record = next(x for x in json.loads((build / "compile_commands.json").read_text())
                  if x["file"].endswith("/split_layer.cpp"))
    raw = shlex.split(record["command"])
    flags, i = [], 1
    while i < len(raw):
        if raw[i] in ("-MQ", "-MF", "-o"):
            i += 2
        elif raw[i] in ("-MD", "-c") or raw[i] == record["file"]:
            i += 1
        else:
            flags.append(raw[i])
            i += 1
    summaries, matrices = {}, {}
    frozen = json.loads((PACKAGE / "evidence/clean-paired-verification.json").read_text())
    for mode in ("baseline", "candidate", "mutation"):
        unit = PACKAGE / ("candidate-split_layer.cpp" if mode == "candidate" else "evidence/split_layer.cpp")
        exe = output / ("probe-" + mode)
        run([raw[0], *flags, str(PACKAGE / "probe.cpp"), str(unit), "-L" + str(library.parent),
             "-lnntrainer", "-Wl,-rpath," + str(library.parent), "-o", str(exe)], "compile-" + mode, build)
        tsv = output / (mode + ".tsv")
        run([str(exe)], "execute-" + mode, build, tsv)
        rows, summary = assess(tsv)
        assert summary["raw_sha256"] == frozen["raw_sha256"][mode], mode
        assert summary["scenarios"] == 576 and summary["output_coordinates"] == 19296
        assert summary["failures"] == {"full": 0, "incremental": 0 if mode == "candidate" else 4320,
                                        "input_preservation": 0}
        assert summary["affected_scenarios"] == (0 if mode == "candidate" else 168)
        assert summary["control_coordinates"] == 12096
        summary.update(executable_sha256=sha(exe), translation_unit_sha256=sha(unit))
        matrices[mode], summaries[mode] = rows, summary
        (output / (mode + "-summary.json")).write_text(json.dumps(summary, indent=2) + "\n")
    prior, candidate = matrices["baseline"], matrices["candidate"]
    controls, already_correct, changed = 0, 0, 0
    for a, b in zip(prior, candidate):
        assert {k: v for k, v in a.items() if k != "incremental"} == {
            k: v for k, v in b.items() if k != "incremental"}
        if a["channels"] == "1" or a["axis"] != "3":
            assert a == b
            controls += 1
        if a["incremental"] == a["full"]:
            assert a == b
            already_correct += 1
        changed += a != b
    assert (controls, already_correct, changed) == (12096, 14976, 4320)
    assert (output / "baseline.tsv").read_bytes() == (output / "mutation.tsv").read_bytes()
    for name, digest in present.items():
        assert sha(source / name) == digest, name
    versions = {}
    for name, argv in {"compiler": ["c++", "--version"], "meson": ["meson", "--version"],
                       "ninja": ["ninja", "--version"]}.items():
        versions[name] = subprocess.check_output(argv, env=env, text=True).strip()
    result = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "status": "clean_portable_replay_verified", "source_pin": PIN,
              "platform": platform.platform(), "python": sys.version, "versions": versions,
              "commands": commands, "fresh_native_core_sha256": sha(library),
              "source_files_verified_before_and_after": len(present),
              "required_native_files_unchanged": len(required), "skipped_links": skipped,
              "archive_hashes": archive_hashes, "variants": summaries,
              "controls_unchanged": controls, "already_correct_unchanged": already_correct,
              "changed_coordinates": changed, "original_mutation_byte_identical": True,
              "three_raw_results_match_frozen_bytes": True, "patch_roundtrip_verified": True,
              "build_workers": 1, "configured_numerical_threads": 1,
              "scope": "FP32 NCHW full-prefill only. No release/model/GPU/FP16/backward/decode-range/full-suite/performance/device impact claim."}
    (output / "REPLAY_RECEIPT.json").write_text(json.dumps(result, indent=2) + "\n")
    print("VERIFIED: 576 scenarios, 19296 coordinates, 4320 -> 0 -> 4320; frozen bytes reproduced.")


if __name__ == "__main__":
    main()
