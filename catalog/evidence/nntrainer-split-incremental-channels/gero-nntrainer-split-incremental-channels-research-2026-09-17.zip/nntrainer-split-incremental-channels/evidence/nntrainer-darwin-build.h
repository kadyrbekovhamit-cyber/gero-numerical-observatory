// Build-only compatibility includes; no mathematical operations are changed.
#if defined(__APPLE__)
#include <mach/mach.h>
#include <sys/mman.h>
#include <unistd.h>
#endif
