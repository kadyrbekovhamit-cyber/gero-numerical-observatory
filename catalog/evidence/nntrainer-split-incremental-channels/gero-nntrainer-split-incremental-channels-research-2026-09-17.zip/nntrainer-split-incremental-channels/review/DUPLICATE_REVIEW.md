# SplitLayer duplicate and source refresh

Reviewed 2026-09-17T00:44:14.049787+05:00 Asia/Tashkent. Bounded public review, not a global novelty proof.

- Official main2d1e4974ae84e1e6d37784416bdfb52b647919a6; split_layer.cpp SHA2568262ffff22676f154b6761b4ca8c784b36ce9c4473331b1aea812cb9f577af48, byte-identical to executed a7ea056e79ab8e14447ea305c1b634e233343258. Source-only refresh, not a full execution of latest main.
- Existing own issue4337 is the exact report, open with zero comments. Do not create another issue or describe this as a first disclosure.
- Three GitHub issue/PR title+body searches returned123split records(two pages),43incremental_forwarding records and the channel-zero query.161distinct records total,22focusedSplitLayer records reviewed. The latest100updatedrecords and target30history records were also fetched. A focused web query produced no useful exact match; absence from search is not proof of absence.
- GERO canonical catalog102IDs, nine nntrainer-related publications reviewed; this SplitLayer case is absent. No repeat of Pow,Divide,loss,quantization or other registered cases.
- Existing issue4334M2 concerns invalid decode ranges exceeding tensor extents; issue4335F7 concerns FP16 byte-size misuse. Their cited code overlaps, but neither documents the missing-channel FP32 validfull-prefill behavior. Both current comment lists empty. Their risks are not claimed as new.
- IntroductionPR3998 is merged; retained file patch contains the channel-zero-only copy. PR4011 is merged but concerns other layer methods and does not changeSplitLayer. PR4054and4067 propose incremental API consolidation; both closed without merge, and currenttargetstillcontainsincremental branch. No accepted fix inferred from their titles.

Decision: proceed with an archival package of the existing own report, explicitly dated and sourced. No new numerical measurement or public post was made in this source/duplicate review. Refresh again immediately before publication if intervening source/catalog changes are possible.
