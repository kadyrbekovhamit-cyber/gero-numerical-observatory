// SPDX-License-Identifier: Apache-2.0
// GERO: real nntrainer SplitLayer probe, with an external exact indexing
// oracle.
#include <iostream>
#include <memory>
#include <split_layer.h>
#include <var_grad.h>

int main() {
  std::cout << "case\tbatch\tchannels\theight\twidth\taxis\tparts\tpattern\tout"
               "put\tindex\tfull\tincremental\tinput_preserved\n";
  unsigned scenario = 0;
  for (unsigned b : {1u, 2u})
    for (unsigned c : {1u, 2u, 3u})
      for (unsigned h : {1u, 2u, 5u})
        for (unsigned w : {2u, 4u, 6u})
          for (unsigned axis : {1u, 2u, 3u})
            for (unsigned parts : {1u, 2u, 3u})
              for (unsigned pattern : {0u, 1u}) {
                nntrainer::TensorDim dim({b, c, h, w});
                if (dim[axis] % parts)
                  continue;
                nntrainer::SplitLayer layer;
                layer.setProperty({"axis=" + std::to_string(axis),
                                   "split_number=" + std::to_string(parts)});
                nntrainer::InitLayerContext init(
                  {dim}, std::vector<bool>(parts, true), false, "split_probe");
                layer.finalize(init);
                nntrainer::Var_Grad input(dim, nntrainer::Initializer::NONE,
                                          true, true, "input");
                std::vector<std::unique_ptr<nntrainer::Var_Grad>> out;
                std::vector<nntrainer::Var_Grad *> out_ptrs;
                auto od = dim;
                od.setTensorDim(axis, dim[axis] / parts);
                for (unsigned n = 0; n < parts; ++n) {
                  out.emplace_back(new nntrainer::Var_Grad(
                    od, nntrainer::Initializer::NONE, true, true, "out"));
                  out_ptrs.push_back(out.back().get());
                }
                nntrainer::RunLayerContext context("split_probe", true, 0.f,
                                                   false, 1.f, nullptr, false,
                                                   {}, {&input}, out_ptrs, {});
                std::vector<float> original(input.getVariableRef().size());
                for (unsigned i = 0; i < original.size(); ++i) {
                  original[i] =
                    pattern ? (i % 2 ? -1.f : 1.f) * (i + 1) / 4.f : i + 1.f;
                  input.getVariableRef().getData<float>()[i] = original[i];
                }
                layer.forwarding(context, false);
                std::vector<std::vector<float>> full(parts);
                for (unsigned n = 0; n < parts; ++n) {
                  auto &v = out[n]->getVariableRef();
                  full[n].assign(v.getData<float>(),
                                 v.getData<float>() + v.size());
                  v.setValue(-99999.f);
                }
                // Full prefill: from zero through every height step. No invalid
                // ranges.
                layer.incremental_forwarding(context, 0, h, false);
                bool preserved = input.getVariableRef().getDim() == dim;
                for (unsigned i = 0; i < original.size(); ++i)
                  preserved =
                    preserved &&
                    input.getVariableRef().getData<float>()[i] == original[i];
                for (unsigned n = 0; n < parts; ++n) {
                  auto &v = out[n]->getVariableRef();
                  for (unsigned i = 0; i < v.size(); ++i)
                    std::cout
                      << scenario << '\t' << b << '\t' << c << '\t' << h << '\t'
                      << w << '\t' << axis << '\t' << parts << '\t' << pattern
                      << '\t' << n << '\t' << i << '\t' << full[n][i] << '\t'
                      << v.getData<float>()[i] << '\t' << preserved << '\n';
                }
                ++scenario;
              }
}
