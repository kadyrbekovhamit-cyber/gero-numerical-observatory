// Runs RQDecomp3x3 body verbatim (original: rq_body_a.inc, patched: rq_body_b.inc); only the Mat I/O
// lines were replaced by Matx assignments. Header-only OpenCV types. Input: 9 doubles per line.
#include <cstdio>
#include <cmath>
#include <cfloat>
#include <cassert>
#include <stdexcept>
#include <algorithm>
#include "opencv2/core/cvdef.h"
#include "opencv2/core/matx.hpp"
#include "opencv2/core/types.hpp"
#undef CV_Assert
#define CV_Assert(expr) do { if(!(expr)) throw std::runtime_error(#expr); } while(0)
using namespace cv;
namespace A { Vec3d RQ(const Matx33d& Min, Matx33d& Rout, Matx33d& Qout) {
#include "rq_body_a.inc"
} }
namespace B { Vec3d RQ(const Matx33d& Min, Matx33d& Rout, Matx33d& Qout) {
#include "rq_body_b.inc"
} }
template<class F> void run(F f, const Matx33d& M) {
    Matx33d R, Q;
    try { Vec3d e = f(M, R, Q);
        std::printf("OK");
        for (int i = 0; i < 9; i++) std::printf(" %.17g", R.val[i]);
        for (int i = 0; i < 9; i++) std::printf(" %.17g", Q.val[i]);
        std::printf(" %.17g %.17g %.17g", e[0], e[1], e[2]);
    } catch (const std::exception& ex) { std::printf("THROW %s", ex.what()); }
    std::printf("\n");
}
int main() {
    double v[9];
    while (std::scanf("%lf %lf %lf %lf %lf %lf %lf %lf %lf", v, v+1, v+2, v+3, v+4, v+5, v+6, v+7, v+8) == 9) {
        Matx33d M(v);
        run(A::RQ, M); run(B::RQ, M);
    }
}
