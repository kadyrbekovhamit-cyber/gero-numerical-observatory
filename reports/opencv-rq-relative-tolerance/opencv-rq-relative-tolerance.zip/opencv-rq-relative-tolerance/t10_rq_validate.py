"""RQDecomp3x3: original vs patched body (compiled harness) vs cv2 wheel."""
import sys, subprocess, numpy as np, cv2
H = sys.argv[1]
print("cv2", cv2.__version__)
def harness(Ms):
    inp = "\n".join(" ".join("%.17g" % x for x in np.asarray(M).ravel()) for M in Ms) + "\n"
    out = subprocess.run([H], input=inp, capture_output=True, text=True, check=True).stdout.splitlines()
    res = []
    for la, lb in zip(out[0::2], out[1::2]):
        def parse(l):
            if l.startswith("THROW"): return None
            v = np.array([float(x) for x in l.split()[1:]]); return v[:9].reshape(3, 3), v[9:18].reshape(3, 3), v[18:]
        res.append((parse(la), parse(lb)))
    return res
rng = np.random.default_rng(4)
A = np.array([[812.3, 0.7, 330.1], [0, 798.9, 251.2], [0, 0, 1]])
Ms = []; scales = []
for e in range(-9, 13):
    for _ in range(30):
        r = rng.normal(size=3); r *= rng.uniform(0.1, 3.0)/np.linalg.norm(r)
        R, _ = cv2.Rodrigues(r); Ms.append((10.0**e)*A @ R); scales.append(10.0**e)
# existing-test style inputs: permutation matrices (degenerate_cases) and bug_23733
for i in range(3):
    for j in range(2):
        P = np.zeros((3, 3)); P[0, i] = 1; P[1, (i+j+1) % 3] = 1; P[2, (i+2*j+2) % 3] = 1; Ms.append(P); scales.append(1.0)
Ms.append(1e-6*np.array([[52, -7, 4], [-6, 49, 12], [4, 17, 1.]])); scales.append(1e-6)
res = harness(Ms)
mism = 0; cvthrow = athrow = bthrow = 0; same_ab = 0; worst_b = 0; nb = 0
for M, s, (a, b) in zip(Ms, scales, res):
    try:
        e, Rc, Qc = cv2.RQDecomp3x3(M)[:3]; c_ok = True
    except cv2.error:
        c_ok = False
    cvthrow += not c_ok; athrow += a is None; bthrow += b is None
    if c_ok != (a is not None): mism += 1
    if c_ok and a is not None and (np.abs(Rc - a[0]).max() > 1e-9*s*1e3 or np.abs(Qc - a[1]).max() > 1e-12): mism += 1
    if a is not None and b is not None and np.array_equal(a[0], b[0]) and np.array_equal(a[1], b[1]): same_ab += 1
    if b is not None:
        Rb, Qb, _ = b; nb += 1
        err = max(np.abs(np.tril(Rb, -1)).max()/np.abs(M).max(), np.abs(Qb @ Qb.T - np.eye(3)).max(),
                  np.abs(Rb @ Qb - M).max()/np.abs(M).max(), abs(np.linalg.det(Qb) - 1))
        worst_b = max(worst_b, err)
print("inputs %d: exceptions cv2=%d original-port=%d patched=%d ; original-port vs cv2 mismatches=%d" % (len(Ms), cvthrow, athrow, bthrow, mism))
print("patched == original bit-for-bit wherever original does not throw: %d of %d" % (same_ab, len(Ms) - athrow))
print("patched outputs: worst of {lower part of R, Q orthogonality, |RQ-M|/|M|, det Q - 1} = %.2e" % worst_b)
# proposed C++ test logic
R, _ = cv2.Rodrigues(np.array([0.3, -1.1, 0.4]))
for s in [1e7, 1e9, 1e12]:
    a, b = harness([s*A @ R])[0]
    print("scale %g: original %s, patched %s" % (s, "THROWS" if a is None else "ok", "THROWS" if b is None else
          "ok, |R/scale - K|=%.1e, |Q - Rtrue|=%.1e" % (np.abs(b[0]/s - A).max(), np.abs(b[1] - R).max())))
