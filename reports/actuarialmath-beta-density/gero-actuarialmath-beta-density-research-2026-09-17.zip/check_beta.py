from pathlib import Path
import argparse,json,sys,math,hashlib,platform,importlib.metadata,warnings
import mpmath as mp
from scipy.integrate import quad
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);a=p.parse_args();source=Path(a.source).resolve();sys.path.insert(0,str(source/'src'))
import actuarialmath
from actuarialmath import Beta
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)
mp.mp.dps=80
m=lambda x:mp.mpf(float(x))
close=lambda x,y,rtol=2e-13,atol=1e-14:math.isclose(x,y,rel_tol=rtol,abs_tol=atol)
density=[];integrals=[];insurance=[];ws=[]
for alpha in [.5,1,1.5,2,3,5]:
 for L0 in [4,20,40,80]:
  for x in [0,30]:
   for s in [0,5]:
    omega=x+s+L0;life=Beta(omega=omega,alpha=alpha).set_interest(i=0)
    for r in [0,.5]:
     L=m(omega)-m(x)-m(s)-m(r)
     for q in [0,.125,.5,.875,.99]:
      t=float(L)*q;expected=float(m(alpha)/L*(1-m(t)/L)**(m(alpha)-1));actual=life.f_r(x,s=s,r=r,t=t);survival=life.p_r(x,s=s,r=r,t=t);hazard=life.mu_r(x,s=s,r=r+t)
      density.append(dict(alpha=alpha,omega=omega,x=x,s=s,r=r,t=t,expected=expected,actual=actual,pdf_pass=close(actual,expected),survival=survival,hazard=hazard,identity_pass=close(actual,survival*hazard),survival_pass=close(survival,float((1-m(t)/L)**m(alpha)))))
    with warnings.catch_warnings(record=True) as w:
     mass,err=quad(lambda z:life.f_r(x,s=s,t=z),0,L0,epsabs=1e-11,epsrel=1e-11)
    ws.extend(str(v.message) for v in w)
    integrals.append(dict(alpha=alpha,omega=omega,x=x,s=s,mass=mass,estimated_error=err,pass_mass=close(mass,1,0,2e-10)))
    for benefit in [1,100,100000]:
     for fraction in [.25,.5,.75]:
      t=L0*fraction;S=(1-m(t)/m(L0))**m(alpha);expected=float(m(benefit)*(1-S));whole=life.whole_life_insurance(x,s=s,b=benefit,discrete=False);term=life.term_insurance(x,s=s,t=t,b=benefit,discrete=False);direct=life.A_x(x,s=s,t=t,benefit=lambda age,z,b=benefit:b,discrete=False);surv=life.p_r(x,s=s,t=t);pure=life.E_x(x,s=s,t=t)
      insurance.append(dict(alpha=alpha,omega=omega,x=x,s=s,t=t,benefit=benefit,expected_term=expected,expected_whole=float(benefit),whole=whole,term=term,direct=direct,whole_pass=close(whole,float(benefit),2e-10,2e-10),term_pass=close(term,expected,2e-10,2e-10),direct_pass=close(direct,expected,2e-10,2e-10),equivalent_pass=close(term,direct,2e-10,2e-10),survival=surv,pure_endowment=pure,control_pass=close(surv,float(S)) and close(pure,float(S))))
summary={'density_observations':len(density),'density_failures':sum(not d['pdf_pass'] for d in density),'density_identity_failures':sum(not d['identity_pass'] for d in density),'density_integrals':len(integrals),'density_integral_failures':sum(not d['pass_mass'] for d in integrals),'insurance_scenarios':len(insurance),'insurance_scenarios_failing_oracle':sum(not all(d[k] for k in ['whole_pass','term_pass','direct_pass']) for d in insurance),'insurance_field_failures':{k:sum(not d[k] for d in insurance) for k in ['whole_pass','term_pass','direct_pass','equivalent_pass','control_pass']},'survival_control_failures':sum(not d['survival_pass'] for d in density),'warnings':sorted(set(ws))}
data={'source':str(source),'imported_from':actuarialmath.__file__,'python':sys.version,'platform':platform.platform(),'dependencies':{k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','matplotlib','mpmath','ipython']},'target_sha256':hashlib.sha256((source/'src/actuarialmath/mortalitylaws.py').read_bytes()).hexdigest(),'summary':summary,'density':density,'integrals':integrals,'insurance':insurance}
out=Path(a.output);out.parent.mkdir(exist_ok=True,parents=True);out.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(summary),flush=True)
