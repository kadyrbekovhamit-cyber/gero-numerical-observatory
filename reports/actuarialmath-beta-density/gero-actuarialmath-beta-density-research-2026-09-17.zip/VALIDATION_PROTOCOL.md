# Predeclared Beta density check — 15 September 2026

Target: real actuarialmath.Beta methods at source 7d18f11ad304898f177b7922b3c53f70e4c2b4f4 and separately extracted official 1.1.0 wheel. No monkeypatch of package methods.

For L=omega-(x+s+r)>0 and alpha>0, survival is S(t)=(1-t/L)^alpha on 0<=t<=L. Its density on the interior is -S'(t), must satisfy f=S*mu and integrate to one. A density is not itself constrained to [0,1]. At zero interest, a unit death benefit through t has price 1-S(t); a guaranteed whole-life unit payment has price one.

Density grid: alpha [0.5,1,1.5,2,3,5], initial remaining lifetime [4,20,40,80], x [0,30], s [0,5], r [0,0.5], t/(L-r) [0,0.125,0.5,0.875,0.99]: 960 observations. PDF oracle at 80 decimal digits for exact binary64 inputs; fixed rel 2e-13, abs 1e-14. The singular terminal PDF at t=L for alpha<1 is outside the point grid; its integral is tested separately.

96 density integrals on [0,L], fixed absolute tolerance 2e-10. 864 zero-interest insurance scenarios: same 96 (alpha,L,x,s) families, t/L [0.25,0.5,0.75], benefit [1,100,100000]. Check actual direct A_x, term_insurance and whole_life_insurance against 80-digit CDF / unit-guarantee oracles. Integration-aware fixed relative 2e-10 and absolute 2e-10. Report scenario and field failure counts separately, without adding overlapping categories. Pure-endowment and survival controls checked against CDF.

Run baseline first, then one-function density correction, original-source restoration and released wheel in sequential independent processes with one configured numerical thread. Preserve raw rows, logs, source hashes, and report residuals. Require alpha=1 and t=0 density controls to remain unchanged, all previous passing rows to remain within tolerance, and unchanged survival/pure-endowment controls. No variance, expectation-shortcut, full upstream suite, calibrated mortality table, premiums, deployed insurer, performance or customer-loss claim.
