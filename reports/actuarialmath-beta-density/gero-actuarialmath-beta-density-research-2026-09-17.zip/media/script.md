An insurance library returned one hundred fifty thousand where the expected benefit was seventy-five thousand.

At zero interest, a hundred-thousand benefit with a seventy-five percent death probability should give seventy-five thousand.

Correcting the probability density removed all seven hundred twenty discrepancies in eight hundred sixty-four scenarios.

The proposed correction is reported. Actual insurer impact was not measured.
