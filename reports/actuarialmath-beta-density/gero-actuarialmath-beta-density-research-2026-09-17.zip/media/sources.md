Source ledger — reviewed before narration

Report: https://www.gero.uz/research/articles/actuarialmath-beta-density.html
Evidence archive: 
Public artifact: https://github.com/terence-lim/actuarialmath/issues/5
Primary sources:
https://github.com/terence-lim/actuarialmath/issues/5
https://pypi.org/project/actuarialmath/1.1.0/

Scene 1: An insurance library returned one hundred fifty thousand where the expected benefit was seventy-five thousand.
Classification: Actual pinned Python API execution, independent survival-law expectation, bounded grid and mutation control; no new-discovery date or upstream acceptance claim.

Scene 2: At zero interest, a hundred-thousand benefit with a seventy-five percent death probability should give seventy-five thousand.
Classification: Actual pinned Python API execution, independent survival-law expectation, bounded grid and mutation control; no new-discovery date or upstream acceptance claim.

Scene 3: Correcting the probability density removed all seven hundred twenty discrepancies in eight hundred sixty-four scenarios.
Classification: Actual pinned Python API execution, independent survival-law expectation, bounded grid and mutation control; no new-discovery date or upstream acceptance claim.

Scene 4: The proposed correction is reported. Actual insurer impact was not measured.
Classification: Actual pinned Python API execution, independent survival-law expectation, bounded grid and mutation control; no new-discovery date or upstream acceptance claim.

Narration client: https://github.com/rany2/edge-tts . The client is open source; synthesis uses Microsoft's online service, not an open local model. Only reviewed public narration text was submitted.
