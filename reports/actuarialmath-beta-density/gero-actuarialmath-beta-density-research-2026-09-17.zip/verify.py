"""Verify recorded paired evidence without rerunning or changing the library."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
data = {label: json.loads((ROOT / 'evidence' / f'{label}.json').read_text())
        for label in ('baseline', 'candidate', 'mutation', 'release')}
base, fixed = data['baseline'], data['candidate']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_text())
for name, digest in manifest.items():
    assert sha(ROOT / 'source/baseline' / name) == digest, name
    assert sha(ROOT / 'source/mutation' / name) == digest, name
changed = [name for name, digest in manifest.items()
           if sha(ROOT / 'source/candidate' / name) != digest]
assert changed == ['src/actuarialmath/mortalitylaws.py'], changed
assert base['target_sha256'] == data['mutation']['target_sha256'] == data['release']['target_sha256']
for label in ('mutation', 'release'):
    for group in ('summary', 'density', 'integrals', 'insurance'):
        assert base[group] == data[label][group], (label, group)
for group, count in [('density', 960), ('integrals', 96), ('insurance', 864)]:
    assert len(base[group]) == len(fixed[group]) == count
    for original, corrected in zip(base[group], fixed[group]):
        for key in ('alpha', 'omega', 'x', 's', 'r', 't', 'benefit', 'expected', 'expected_term', 'expected_whole'):
            if key in original:
                assert original[key] == corrected[key], (group, key)
density_controls = 0
for original, corrected in zip(base['density'], fixed['density']):
    assert corrected['pdf_pass'] and corrected['identity_pass'] and corrected['survival_pass']
    assert original['survival'] == corrected['survival']
    assert original['hazard'] == corrected['hazard']
    if original['alpha'] == 1 or original['t'] == 0:
        assert original['actual'] == corrected['actual']
        density_controls += 1
assert density_controls == 320
insurance_controls = 0
for original, corrected in zip(base['insurance'], fixed['insurance']):
    assert all(corrected[k] for k in ('whole_pass', 'term_pass', 'direct_pass', 'equivalent_pass', 'control_pass'))
    assert original['survival'] == corrected['survival']
    assert original['pure_endowment'] == corrected['pure_endowment']
    if original['alpha'] == 1:
        for key in ('whole', 'term', 'direct'):
            assert original[key] == corrected[key]
        insurance_controls += 1
assert insurance_controls == 144
assert all(row['pass_mass'] for row in fixed['integrals'])
assert base['summary']['density_failures'] == 640
assert base['summary']['density_integral_failures'] == 80
assert base['summary']['insurance_scenarios_failing_oracle'] == 720
for key in ('density_failures', 'density_identity_failures', 'density_integral_failures', 'insurance_scenarios_failing_oracle', 'survival_control_failures'):
    assert fixed['summary'][key] == 0
minimal = {label: json.loads((ROOT / 'evidence' / f'minimal-{label}.json').read_text())
           for label in data}
assert minimal['baseline'] == minimal['mutation'] == minimal['release']
assert minimal['baseline']['actual']['term_value'] == 150000
assert minimal['baseline']['expected']['term_value'] == 75000
for key, expected in minimal['candidate']['expected'].items():
    assert math.isclose(minimal['candidate']['actual'][key], expected, rel_tol=2e-10, abs_tol=2e-10)
wheel_metadata = json.loads((ROOT / 'evidence/pypi-current.json').read_text())
wheel = next(item for item in wheel_metadata['urls']
             if item['filename'] == 'actuarialmath-1.1.0-py3-none-any.whl')
assert wheel['digests']['sha256'] == sha(ROOT / wheel['filename'])
receipt = {
    'verified_utc': datetime.now(timezone.utc).isoformat(),
    'source_pin': json.loads((ROOT / 'SOURCE.json').read_text())['pin'],
    'original_source_files_unchanged': len(manifest),
    'candidate_changed_files': changed,
    'restored_source_files_identical': len(manifest),
    'source_mutation_release_raw_rows_identical': True,
    'density_controls_unchanged': density_controls,
    'insurance_controls_unchanged': insurance_controls,
    'survival_density_controls_unchanged': 960,
    'insurance_survival_and_pure_endowment_controls_unchanged': 864,
    'all_previous_passing_rows_still_pass': True,
    'summaries': {k: v['summary'] for k, v in data.items()},
    'raw_sha256': {label: sha(ROOT / 'evidence' / f'{label}.json') for label in data},
    'wheel_sha256': sha(ROOT / 'actuarialmath-1.1.0-py3-none-any.whl'),
    'candidate_patch_sha256': sha(ROOT / 'candidate.patch'),
    'four_separate_minimal_replays_verified': True,
    'minimal_raw_sha256': {label: sha(ROOT / 'evidence' / f'minimal-{label}.json') for label in data},
    'wheel_matches_official_pypi_hash': True,
    'full_upstream_suite_run': False,
    'real_insurer_or_customer_impact_measured': False,
    'new_external_publications': 0,
}
(ROOT / 'evidence/paired-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'summaries'}, indent=2))
