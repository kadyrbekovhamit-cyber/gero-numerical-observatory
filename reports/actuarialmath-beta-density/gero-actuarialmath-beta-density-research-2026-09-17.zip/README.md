# Reproduce the actuarialmath Beta density report

Python 3.12 was used. From this extracted archive:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-repro.txt
.venv/bin/python reproduce.py --out replay
```

The runner refuses an existing output directory, verifies pinned archive and source hashes, extracts the official Git source and PyPI wheel, applies only the density candidate, restores the source for a mutation control, and executes four independent Python processes sequentially. It imports the actual extracted package, not an emulated API. It does not fetch source, modify an installed library, use a GPU, or play media. Dependency installation uses PyPI.

`recorded-evidence/` contains the September 17 results. Fresh evidence is written below your chosen output path. `verify.py` checks recorded counts, control values and restored-source identity. `check_beta.py` uses independent 80-digit mpmath expectations; `minimal_repro.py` uses exact rational arithmetic. SciPy quadrature is a supplementary density-integral check, not the insurance oracle.

Inputs, tolerances and exclusions: `VALIDATION_PROTOCOL.md`. Main report: `REPORT_EN.md`. Licenses: `LICENSES.md`. Review records are a bounded prior-work search, not proof that no unknown duplicate exists. The report extends the archive of our existing September 15 issue, not a second discovery.
