import sys,json,importlib.metadata,math
from pathlib import Path
from datetime import datetime,timedelta
source=Path(sys.argv[1]).resolve();sys.path.insert(0,str(source))
original=importlib.metadata.version
importlib.metadata.version=lambda n: 'source-check' if n=='curo' else original(n)
import pandas as pd
import curo
from curo import SeriesPayment,Frequency,DayCountTimePeriod,USAppendixJ
assert Path(curo.__file__).resolve().is_relative_to(source)
rows=[]
for freq,days in [(Frequency.WEEKLY,7),(Frequency.FORTNIGHTLY,14)]:
 for start in ['2026-01-22','2026-01-31','2024-02-29']:
  df=SeriesPayment(number_of=6,frequency=freq,amount=100,post_date_from=pd.Timestamp(start,tz="UTC")).to_cash_flows(pd.Timestamp(start,tz='UTC'))
  expected=[(datetime.fromisoformat(start)+timedelta(days=i*days)).date().isoformat() for i in range(6)]
  actual=[x.date().isoformat() for x in df['post_date']]
  rows.append(dict(frequency=freq.name,start=start,actual=actual,expected=expected,passed=actual==expected))
for start,end in [('2026-01-01','2026-02-02'),('2026-01-01','2026-01-15'),('2024-02-20','2024-03-08')]:
 days=(datetime.fromisoformat(end)-datetime.fromisoformat(start)).days
 got=USAppendixJ(DayCountTimePeriod.FORTNIGHT).compute_factor(pd.Timestamp(start,tz='UTC'),pd.Timestamp(end,tz='UTC'))
 rows.append(dict(start=start,end=end,whole=got.primary_period_fraction,partial=got.partial_period_fraction,expected_whole=days//14,expected_partial=(days%14)/14,passed=got.primary_period_fraction==days//14 and math.isclose(got.partial_period_fraction,(days%14)/14,abs_tol=1e-14)))
for freq,expected in [(Frequency.MONTHLY,['2026-01-22','2026-02-22','2026-03-22']),(Frequency.QUARTERLY,['2026-01-22','2026-04-22','2026-07-22'])]:
 df=SeriesPayment(number_of=3,frequency=freq,amount=100,post_date_from=pd.Timestamp('2026-01-22',tz='UTC')).to_cash_flows(pd.Timestamp('2026-01-22',tz='UTC'))
 actual=[x.date().isoformat() for x in df['post_date']]
 rows.append(dict(control=freq.name,actual=actual,expected=expected,passed=actual==expected))
result=dict(source=str(source),scope='Real SeriesPayment.to_cash_flows and USAppendixJ.compute_factor; package-version metadata substituted only',checks=len(rows),failures=sum(not x['passed'] for x in rows),rows=rows)
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
