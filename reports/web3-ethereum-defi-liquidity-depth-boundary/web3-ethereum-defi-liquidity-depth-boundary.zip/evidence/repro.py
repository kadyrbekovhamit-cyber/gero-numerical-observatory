"""web3-ethereum-defi @ 2407b6d: estimate_liquidity_depth_at_block executed verbatim
(ast-extracted) with get_pool_state_at_block stubbed (real one needs a subgraph key and
is also called without its required api_key argument). Oracle: piecewise integral of
the v3 whitepaper formulas (6.15/6.16) in mpmath, walking initialized ticks correctly."""
import ast, math, sys
from pprint import pp
import mpmath as mp
mp.mp.dps = 40
D = sys.argv[1]

def fns(path, names):
    tree = ast.parse(open(path).read())
    return {n.name: ast.unparse(n) for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names}

ns = {"math": math, "pp": pp, "DEFAULT_TICK_SPACINGS": {100: 1, 500: 10, 3000: 60, 10000: 200}}
for s in fns(f"{D}/utils.py", ["tick_to_price", "tick_to_sqrt_price", "get_token0_amount_in_range", "get_token1_amount_in_range"]).values():
    exec(s, ns)
exec("from __future__ import annotations\n" + fns(f"{D}/liquidity.py", ["estimate_liquidity_depth_at_block"])["estimate_liquidity_depth_at_block"], ns)

L = 10**18
STATE = {"liquidity": L, "tick": 0, "fee": 3000,
         "token0": {"symbol": "A", "decimals": "18"}, "token1": {"symbol": "B", "decimals": "18"},
         "ticks": [{"tickIdx": "-60", "liquidityNet": str(L)}, {"tickIdx": "60", "liquidityNet": str(-L)}]}
ns["get_pool_state_at_block"] = lambda addr, block: {**STATE, "ticks": list(STATE["ticks"])}

got = ns["estimate_liquidity_depth_at_block"]("0xPOOL", 1, depths=[-0.5, 0.5])
# oracle: single position [-60,60] with L, price at tick 0 (sqrtP=1); target stays inside the range
sp = mp.mpf(1)
for depth, g in zip([-0.5, 0.5], got):
    st = mp.sqrt(mp.mpf(1) * (100 + mp.mpf(depth)) / 100)
    exp = L * (sp - st) if depth < 0 else L * (st - sp) / (sp * st)
    print(f"depth {depth:+}%: library raw={g[1]!r}  oracle raw={mp.nstr(exp, 15)}")
