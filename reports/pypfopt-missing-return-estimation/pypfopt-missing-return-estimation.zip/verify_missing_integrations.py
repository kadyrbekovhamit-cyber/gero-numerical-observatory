"""Independent moment and optimization cross-check before refreshing six goldens."""
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import minimize
from sklearn.covariance import ledoit_wolf

root = Path(__file__).resolve().parent
sys.path.insert(0, sys.argv[1] if len(sys.argv) > 1 else str(root / "pypfopt-missing"))
from pypfopt import BlackLittermanModel, CLA, EfficientFrontier, expected_returns, objective_functions, risk_models
from tests.utilities_for_tests import get_data

df = get_data()
returns = df.pct_change(fill_method=None).dropna(how="all")
mu = expected_returns.mean_historical_return(df)
semi = np.empty((len(mu), len(mu)))
for i in range(len(mu)):
    for j in range(len(mu)):
        pairs = returns.iloc[:, [i, j]].dropna().to_numpy()
        semi[i, j] = np.mean(np.minimum(pairs[:, 0], 0) * np.minimum(pairs[:, 1], 0)) * 252
np.testing.assert_allclose(risk_models.semicovariance(df, benchmark=0), semi, atol=1e-12)
assert np.linalg.eigvalsh(semi).min() > 0
complete = returns.dropna().to_numpy()
lw, _ = ledoit_wolf(complete)
lw *= 252
np.testing.assert_allclose(risk_models.CovarianceShrinkage(df).ledoit_wolf(), lw, atol=1e-12)

prior = expected_returns.ema_historical_return(df)
bl = BlackLittermanModel(lw, pi=prior, Q=np.full(len(mu), 0.1))
precision = np.linalg.inv(0.05 * lw)
view_precision = np.diag(1 / np.diag(0.05 * lw))
posterior = np.linalg.solve(precision + view_precision, precision @ prior + view_precision @ np.full(len(mu), 0.1))
np.testing.assert_allclose(bl.bl_returns(), posterior, atol=1e-12)
result = {"test_bl_returns_all_views": posterior.tolist(), "optimizer_checks": {}}

def verify(name, model, objective, bounds, constraints):
    weights = model.weights
    ref = minimize(objective, np.full(len(mu), 1 / len(mu)), method="SLSQP",
                   bounds=bounds, constraints=constraints,
                   options={"ftol": 1e-12, "maxiter": 300})
    assert ref.success, ref.message
    gap = abs(objective(weights) - objective(ref.x))
    assert gap < 1e-7, (name, gap)
    ret = float(mu @ weights)
    vol = float(np.sqrt(weights @ model.cov_matrix @ weights))
    perf = [ret, vol, (ret - 0.02) / vol]
    np.testing.assert_allclose(model.portfolio_performance(risk_free_rate=0.02), perf)
    result[name] = perf
    result["optimizer_checks"][name] = {"objective_gap_vs_scipy": float(gap), "independent_solver_success": bool(ref.success)}

budget = {"type": "eq", "fun": lambda w: w.sum() - 1}
for name, lo, rf, cla in [("test_cla_max_sharpe_semicovariance", 0, 0, True),
                          ("test_max_sharpe_semicovariance", 0, .02, False),
                          ("test_max_sharpe_short_semicovariance", -1, .02, False)]:
    model = CLA(mu, semi) if cla else EfficientFrontier(mu, semi, weight_bounds=(lo, 1))
    model.max_sharpe() if cla else model.max_sharpe(risk_free_rate=rf)
    verify(name, model, lambda w: -(mu @ w - rf) / np.sqrt(w @ semi @ w), [(lo, 1)] * len(mu), [budget])
cc = risk_models.CovarianceShrinkage(df).ledoit_wolf("constant_correlation").to_numpy()
ef = EfficientFrontier(mu, cc)
ef.add_objective(objective_functions.L2_reg)
ef.min_volatility()
verify("test_min_volatility_shrunk_L2_reg", ef, lambda w: w @ cc @ w + w @ w, [(0, 1)] * len(mu), [budget])
sf = risk_models.CovarianceShrinkage(df).ledoit_wolf("single_factor").to_numpy()
ef = EfficientFrontier(mu, sf)
ef.efficient_return(0.22)
verify("test_efficient_return_shrunk", ef, lambda w: w @ sf @ w, [(0, 1)] * len(mu), [budget, {"type": "ineq", "fun": lambda w: mu @ w - .22}])
legacy = np.fmin(returns, 0).T @ np.fmin(returns, 0) / len(returns) * 252
old = EfficientFrontier(mu, legacy); old.min_volatility()
new = EfficientFrontier(mu, semi); new.min_volatility()
idx = list(mu.index).index("BABA")
result["fixture_BABA"] = {"old_semivariance": float(legacy.iloc[idx, idx]), "observed_semivariance": float(semi[idx, idx]), "ratio": float(semi[idx, idx]/legacy.iloc[idx, idx]), "old_min_risk_weight": float(old.weights[idx]), "new_min_risk_weight": float(new.weights[idx])}
(root / "independent-goldens-rerun.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
