import types,sys,json,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent
src=P/'source/python/shin/__init__.py'
# Native extension is unavailable; only Python optimiser is exercised.
package=types.ModuleType('shin');package.__path__=[str(src.parent)];sys.modules['shin']=package
fake=types.ModuleType('shin.shin');fake.optimise=lambda **k: (_ for _ in ()).throw(RuntimeError('native optimiser deliberately unavailable'))
sys.modules['shin.shin']=fake
spec=importlib.util.spec_from_file_location('shin',src,submodule_search_locations=[str(src.parent)])
mod=importlib.util.module_from_spec(spec);sys.modules['shin']=mod;spec.loader.exec_module(mod)
rows=[]
for odds in [[2.1,3.6,4.6],[2.7,2.3,4.4],[2.1,2.1]]:
 full=mod.calculate_implied_probabilities(odds,full_output=True,force_python_optimiser=True)
 plain=mod.calculate_implied_probabilities(odds,force_python_optimiser=True)
 rows.append({'odds':odds,'sum_inverse_odds':sum(1/o for o in odds),'probabilities':plain,'sum':sum(plain),'iterations':full.iterations,'delta':full.delta,'z':full.z})
print(json.dumps({'scope':'Unmodified current Python API with Python optimiser; native Rust extension not executed. Underround financial interpretation not asserted: rejection or explicit convergence failure is a valid fix.','rows':rows},indent=2))
