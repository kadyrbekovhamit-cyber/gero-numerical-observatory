# actuarialmath Uniform shortcut audit

This packet reproduces the source-pinned numerical audit described in `REPORT_EN.md`.

- Upstream commit: `7d18f11ad304898f177b7922b3c53f70e4c2b4f4`
- Official release checked: PyPI 1.1.0
- Developer report: https://github.com/terence-lim/actuarialmath/issues/9
- Oracle precisions retained: 80 and 120 decimal digits
- Per-variant comparisons: 468

Run from this extracted directory with a Python 3.12 environment containing NumPy,
SciPy and pandas:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
for variant in current candidate restored release; do
  python3 -B verify.py "$variant"
done
```

The retained JSON files are the outputs of the executed environment. Optional plotting
and notebook-display imports are stubbed by the verifier because none of the tested
numerical methods calls them. The packet does not claim a complete upstream test-suite,
production-policy impact, customer loss, regulatory breach, or upstream acceptance.
