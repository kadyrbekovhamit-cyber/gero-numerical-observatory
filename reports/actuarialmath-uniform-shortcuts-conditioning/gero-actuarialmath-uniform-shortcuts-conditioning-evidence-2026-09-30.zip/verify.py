#!/usr/bin/env python3
"""Verify Uniform-law public methods against independent closed forms."""

from __future__ import annotations

import json
import math
import os
import sys
import types
from collections import Counter
from decimal import Decimal, getcontext
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VARIANT = sys.argv[1]
SRC = ROOT / "source" / VARIANT
EVIDENCE = ROOT / "evidence"


def install_optional_import_stubs() -> None:
    """The numerical methods do not use plotting or notebook display."""
    mpl = types.ModuleType("matplotlib")
    mpl.__path__ = []
    pyplot = types.ModuleType("matplotlib.pyplot")
    for name in (
        "plot", "show", "figure", "subplots", "title", "xlabel", "ylabel",
        "legend", "grid", "hist", "bar", "scatter",
    ):
        setattr(pyplot, name, lambda *args, **kwargs: None)
    mpl.pyplot = pyplot
    sys.modules["matplotlib"] = mpl
    sys.modules["matplotlib.pyplot"] = pyplot

    ipython = types.ModuleType("IPython")
    ipython.__path__ = []
    ipython.get_ipython = lambda: None
    display = types.ModuleType("IPython.display")
    display.display_latex = lambda *args, **kwargs: None
    display.display_pretty = lambda *args, **kwargs: None
    ipython.display = display
    sys.modules["IPython"] = ipython
    sys.modules["IPython.display"] = display


def close(actual: float, expected: Decimal, scale: float = 1.0) -> bool:
    return math.isfinite(actual) and math.isclose(
        actual,
        float(expected),
        rel_tol=3e-12,
        abs_tol=3e-12 * max(1.0, scale),
    )


def discount(delta: Decimal, time: int) -> Decimal:
    return (-delta * Decimal(time)).exp()


def limited_expectation(remaining: Decimal, term: int) -> Decimal:
    h = min(Decimal(term), remaining)
    return h - h * h / (Decimal(2) * remaining)


def continuous_annuity(remaining: Decimal, term: int, delta: Decimal) -> Decimal:
    h = min(Decimal(term), remaining)
    if delta == 0:
        return h - h * h / (Decimal(2) * remaining)
    e = (-delta * h).exp()
    return ((Decimal(1) - e) / delta
            - (Decimal(1) - e * (Decimal(1) + delta * h))
            / (remaining * delta * delta))


def discrete_annuity(remaining: Decimal, term: int, delta: Decimal) -> Decimal:
    total = Decimal(0)
    for k in range(min(term, int(remaining))):
        kd = Decimal(k)
        total += (-delta * kd).exp() * (remaining - kd) / remaining
    return total


def main() -> None:
    getcontext().prec = int(os.environ.get("ORACLE_DECIMAL_PRECISION", "80"))
    install_optional_import_stubs()
    sys.path.insert(0, str(SRC))

    import actuarialmath  # type: ignore
    from actuarialmath import Uniform  # type: ignore

    assert Path(actuarialmath.__file__).resolve().is_relative_to(SRC.resolve())

    failures: list[dict[str, object]] = []
    observations: list[dict[str, object]] = []
    counts: Counter[str] = Counter()
    samples: dict[str, dict[str, object]] = {}

    def check(kind: str, actual: float, expected: Decimal, params: dict[str, object]) -> None:
        counts[f"checks_{kind}"] += 1
        passed = close(actual, expected, scale=abs(float(expected)))
        observations.append({
            "kind": kind,
            "params": params,
            "actual": actual,
            "expected": str(expected),
            "passed": passed,
        })
        if not passed:
            counts[f"failures_{kind}"] += 1
            row = {
                "kind": kind,
                "params": params,
                "actual": actual,
                "expected": str(expected),
                "absolute_error": str(abs(Decimal.from_float(actual) - expected)),
            }
            failures.append(row)
            samples.setdefault(kind, row)

    for x in (10, 40, 60):
        for s in (0, 5, 15):
            remaining = Decimal(100 - (x + s))
            life = Uniform(omega=100)

            check(
                "complete_expectation",
                life.e_x(x, s=s, curtate=False),
                remaining / Decimal(2),
                {"x": x, "s": s},
            )
            check(
                "complete_variance",
                life.e_x(x, s=s, curtate=False, moment=life.VARIANCE),
                remaining * remaining / Decimal(12),
                {"x": x, "s": s},
            )

            for term in (0, 1, 5, 10, 20):
                check(
                    "limited_expectation",
                    life.e_x(x, s=s, t=term, curtate=False),
                    limited_expectation(remaining, term),
                    {"x": x, "s": s, "t": term},
                )

                h = min(Decimal(term), remaining)
                survival = (remaining - h) / remaining
                for delta_text in ("0", "0.01", "0.05"):
                    delta_float = float(delta_text)
                    delta = Decimal.from_float(delta_float)
                    life.set_interest(delta=delta_float)

                    for moment in (1, 2):
                        expected = discount(delta, term) ** moment * survival
                        check(
                            "pure_endowment_raw_moment",
                            life.E_x(x, s=s, t=term, moment=moment),
                            expected,
                            {"x": x, "s": s, "t": term,
                             "delta": delta_text, "moment": moment},
                        )

                    # Unit benefits isolate the Uniform shortcut formulas.  A
                    # separate zero-interest benefit-scaling discrepancy is
                    # intentionally excluded from this candidate.
                    for benefit in (1,):
                        expected_continuous = Decimal(benefit) * continuous_annuity(
                            remaining, term, delta
                        )
                        check(
                            "temporary_continuous_annuity",
                            life.temporary_annuity(
                                x, s=s, t=term, b=benefit, discrete=False
                            ),
                            expected_continuous,
                            {"x": x, "s": s, "t": term,
                             "delta": delta_text, "b": benefit},
                        )

    result = {
        "variant": VARIANT,
        "package_file": str(Path(actuarialmath.__file__).resolve()),
        "python": sys.version,
        "thread_limits": {
            name: os.environ.get(name)
            for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        },
        "decimal_precision": getcontext().prec,
        "counts": dict(sorted(counts.items())),
        "total_checks": sum(value for key, value in counts.items() if key.startswith("checks_")),
        "total_failures": len(failures),
        "samples": samples,
        "observations": observations,
        "failures": failures,
    }
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    suffix = os.environ.get("EVIDENCE_SUFFIX", "")
    path = EVIDENCE / f"{VARIANT}{suffix}.json"
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "variant": VARIANT,
        "total_checks": result["total_checks"],
        "total_failures": result["total_failures"],
        "counts": result["counts"],
        "evidence": str(path),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
