# Separate observations excluded from the Uniform shortcut candidate

These were encountered during triage and must not be described as confirmed
findings until each receives its own oracle, patch, controls and duplicate
review.

1. `Annuity.whole_life_annuity` appears to ignore `b` in its zero-interest
   branch, so a payment rate of 1000 can return the same value as a unit rate.
2. The discrete zero-interest `Uniform.temporary_annuity` path reaches
   `Beta.e_x(..., t=...)`, while the base method accepts `n`, producing a
   `TypeError` in the checked call.
3. `Uniform.E_x` asserts `moment > 0` before a later branch that tests the
   negative variance selector, making that branch unreachable.

Next triage order: benefit scaling, discrete delegation, variance selector.

