import scipy
from scipy.stats import barnard_exact, poisson_means_test
print("SciPy", scipy.__version__)
for table in ([[3,3],[0,6]], [[5,0],[1,4]]):
    for pooled in (True,False):
        print(table, "pooled=",pooled, "original=",barnard_exact(table,pooled=pooled).pvalue, "rows reversed=",barnard_exact(table[::-1],pooled=pooled).pvalue)
for n in (1,10,50,100,365):
    print("exposure",n,poisson_means_test(7,n,2,n,alternative="greater").pvalue)
