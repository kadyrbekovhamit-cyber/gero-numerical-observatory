Report copyright 2026 Xamit Kadirbekov and Daniyal Kadirbekov, CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

Original witness and independent oracle scripts are available under the MIT License (MIT_LICENSE.txt). The patch modifies SciPy and remains subject to its BSD-3-Clause license (SCIPY_LICENSE.txt). No license override is asserted for upstream code.
