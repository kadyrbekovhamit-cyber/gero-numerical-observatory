from fractions import Fraction as F
from decimal import Decimal as D,localcontext
import json, math
# Barnard exact region for columns of sizes 6 and 4 at observed (5,0), unpooled.
def t2(a,b):
 d=F(a,6)-F(b,4);v=F(a,6)*(1-F(a,6))/6+F(b,4)*(1-F(b,4))/4
 return 0 if d==0 else (math.inf if not v else d*d/v)
region=[(a,b) for a in range(7) for b in range(5) if t2(a,b)>=t2(5,0)]
assert region==[(0,4),(1,4),(5,0),(6,0)]
# P(p)=q^4*(1+10q), q=p(1-p)<=1/4, increasing for q>=0; hence global maximum.
ref=F(1,4)**4*(1+10*F(1,4));assert ref==F(14,1024)
vals=[]
for prec in [80,110]:
 with localcontext() as c:
  c.prec=prec;mu=D('4.5');pmf=[(-mu).exp()]
  for n in range(1,80):pmf.append(pmf[-1]*mu/n)
  total=D(0)
  for a in range(80):
   for b in range(80):
    if a<=b:continue
    if F((a-b)**2,a+b)>=F(25,9):total+=pmf[a]*pmf[b]
  tail_bound=2*(-mu).exp()*(D(1).exp()*mu/80)**80
  vals.append({'precision':prec,'pvalue':str(total),'omitted_probability_upper_bound':str(tail_bound)})
assert abs(D(vals[0]['pvalue'])-D(vals[1]['pvalue']))<D('1e-75')
print(json.dumps({'barnard_region':region,'barnard_exact_p':str(ref),'poisson_greater_7_2':vals},indent=2))
