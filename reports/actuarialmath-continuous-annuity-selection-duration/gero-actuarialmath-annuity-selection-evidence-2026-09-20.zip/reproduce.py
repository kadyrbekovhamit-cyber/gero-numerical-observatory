"""Offline replay after installing requirements; run from a fresh extracted packet."""
from pathlib import Path
import os,sys,subprocess,hashlib,json,zipfile,shutil,datetime
R=Path(__file__).resolve().parent
assert sys.version_info>=(3,12)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((R/'SOURCE_MANIFEST.json').read_text())
wheel=R/'actuarialmath-1.1.0-py3-none-any.whl'
assert H(wheel)=='b19990e4378aaa19fe6bc1182b4269faec6617cb62b0677fea1e624fbbb3ff6f'
with zipfile.ZipFile(wheel) as z:
 for p in (R/'source/release/src/actuarialmath').glob('*.py'):
  assert p.read_bytes()==z.read('actuarialmath/'+p.name),p.name
for v in ['candidate','restored']:
 assert not (R/'source'/v).exists(),'Use a fresh extraction, not existing generated variants.'
shutil.copytree(R/'source/current',R/'source/candidate')
subprocess.run(['git','apply',str(R/'candidate-annuity-selection.patch')],cwd=R/'source/candidate',check=True)
shutil.copytree(R/'source/candidate',R/'source/restored')
subprocess.run(['git','apply','--reverse',str(R/'candidate-annuity-selection.patch')],cwd=R/'source/restored',check=True)
for row in manifest['files']:assert H(R/row['path'])==row['sha256'],row['path']
env=dict(os.environ)
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS']:env[n]='1'
env.update(MPLBACKEND='Agg',MPLCONFIGDIR=str(R/'mpl-cache'),XDG_CACHE_HOME=str(R/'cache'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
(R/'evidence').mkdir(exist_ok=True)
for script in ['run_selection.py','run_uniform.py']:
 subprocess.run([sys.executable,'-B',str(R/script)],cwd=R,env=env,check=True)
for v in ['current','release','candidate','restored']:
 a=json.loads((R/'expected/evidence'/('grid-'+v+'-final.json')).read_text());b=json.loads((R/'evidence'/('grid-'+v+'.json')).read_text())
 assert a['rows']==b['rows'],v+' numerical rows differ; inspect platform effects'
 assert a['downstream']==b['downstream'],v
 assert json.loads((R/'expected/evidence'/('uniform-'+v+'.json')).read_text())==json.loads((R/'evidence'/('uniform-'+v+'.json')).read_text())
 shutil.copy2(R/'evidence'/('grid-'+v+'.json'),R/'evidence'/('grid-'+v+'-final.json'))
subprocess.run([sys.executable,'-B',str(R/'consume_memos.py')],cwd=R,env=env,check=True)
a=json.loads((R/'expected/DOWNSTREAM_RECEIPT.json').read_text());b=json.loads((R/'DOWNSTREAM_RECEIPT.json').read_text());assert a['rows']==b['rows']
for v in ['current','release','candidate','restored']:assert (R/'expected/downstream'/(v+'-memo.json')).read_bytes()==(R/'downstream'/(v+'-memo.json')).read_bytes()
r={'status':'portable_packet_native_replay_verified','verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases_per_variant':2160,'failures_current_release_candidate_restored':[648,648,0,648],'four_numerical_grids_match_expected':True,'four_Uniform_controls_match_expected':True,'four_written_memos_and_readback_decisions_match_expected':True,'candidate_applied_and_reversed':True,'wheel_22_modules_verified':True,'audio_playback':False,'gpu':False,'configured_threads':1}
(R/'REPLAY_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print('PACKET REPLAY VERIFIED')
