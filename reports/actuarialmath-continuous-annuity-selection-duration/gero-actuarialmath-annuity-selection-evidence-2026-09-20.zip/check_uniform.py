from pathlib import Path
import sys,json,os
os.environ.update(MPLBACKEND='Agg',MPLCONFIGDIR=str(Path(__file__).resolve().parent/'mpl-cache'),XDG_CACHE_HOME=str(Path(__file__).resolve().parent/'cache'))
R=Path(__file__).resolve().parent;src=R/'source'/sys.argv[1];sys.path.insert(0,str(src/'src'))
import actuarialmath
from actuarialmath import Uniform
assert Path(actuarialmath.__file__).resolve().is_relative_to(src)
l=Uniform(omega=100).set_interest(i=0)
r={'variant':sys.argv[1],'direct_s20':l.a_x(40,s=20,t=10,discrete=False),'same_attained_age':l.a_x(60,s=0,t=10,discrete=False),'temporary_shortcut':l.temporary_annuity(40,s=20,t=10,discrete=False),'independent_expected':8.75,'s0_control':l.a_x(40,s=0,t=10,discrete=False),'discrete_control':l.a_x(40,s=20,t=10,discrete=True)}
(R/'evidence'/('uniform-'+sys.argv[1]+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
