import subprocess,sys
for v in ['current','release','candidate','restored']:subprocess.run([sys.executable,'-B','check_uniform.py',v],check=True)
