from pathlib import Path
import subprocess,sys,os,json,hashlib,datetime
R=Path(__file__).resolve().parent;res={}
for v in ['current','release','candidate','restored']:
 p=subprocess.run([sys.executable,'-B',str(R/'check_selection.py'),v],capture_output=True,text=True,timeout=90);(R/'evidence'/('grid-'+v+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr;print(p.stdout.strip(),flush=True);res[v]=json.loads((R/'evidence'/('grid-'+v+'.json')).read_text())
a=res['current'];b=res['candidate'];assert b['failures']==0
assert a['rows']==res['release']['rows']==res['restored']['rows']
passes=[(x,y) for x,y in zip(a['rows'],b['rows']) if x['pass']];assert all(x['actual']==y['actual'] for x,y in passes)
for r in json.loads((R/'SOURCE_MANIFEST.json').read_text())['files']:assert hashlib.sha256((R/r['path']).read_bytes()).hexdigest()==r['sha256']
rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'paired_runtime_confirmed_pending_prior_art_and_portable_replay','case_id':'actuarialmath-continuous-annuity-selection-duration','cases_per_variant':a['cases'],'failures':{k:v['failures'] for k,v in res.items()},'previously_passing_outputs_bit_identical':len(passes),'source_and_candidate_hashes_preserved':True,'oracle':'80-digit Decimal closed-form integral / independent discounted discrete sum; zero-rate rational polynomial','oracle_precision_repeat_controls_per_variant':a['oracle_80_vs_120_digit_controls'],'downstream':{v:res[v]['downstream'] for v in res},'full_upstream_suite_run':False,'real_customer_impact_measured':False,'published':False,'vendor_sent':False,'audio_playback':False,'gpu':False,'configured_local_worker_threads':1}
(R/'GRID_RECEIPT.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
