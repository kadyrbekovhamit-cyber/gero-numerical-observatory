Hello Terence,

The continuous branch of `Annuity.a_x` discards its documented `s` argument when calling the survival function. It uses `self.S(x, 0, t=t+u)` although `s` is years since selection. This is a different path from the density and insurance-moment reports #2–#6.

Reproduced on current main `7d18f11ad304898f177b7922b3c53f70e4c2b4f4` and the independently hash-verified official PyPI 1.1.0 wheel. Their `annuity.py` files match.

### Minimal public-API example

```python
from actuarialmath import Uniform
life = Uniform(omega=100).set_interest(i=0)
print(life.a_x(40, s=20, t=10, discrete=False))  # 9.166666666666666
print(life.a_x(60, s=0, t=10, discrete=False))   # 8.75
```

Both inputs describe the same attained age, 60, under this ultimate uniform-lifetime model. Remaining lifetime is uniform on `[0,40]`. A continuous payment rate of 1 per year over 10 years has expected present value

`integral_0^10 (1-y/40) dy = 10 - 100/80 = 8.75`.

The affected call instead uses remaining lifetime 60, yielding `10 - 100/120 = 9.166666666666666`. The discrete branch already passes `s` correctly.

### Narrow candidate

Only in the continuous integrand of `Annuity.a_x`:

```diff
- self.S(x, 0, t=t+u)
+ self.S(x, s, t=t+u)
```

### Executed checks and limits

I ran 2,160 public-method calls per variant: selection ages 20/40/60; durations 0/1/5/10/20; terms 0/1/5/10; deferrals 0/2/7; interest forces 0/.01/.05; constant payment rates 1/1000; continuous and discrete branches. All intervals stay inside the uniform lifetime support.

An independent 80-digit Decimal closed-form integral (and discounted finite sum for discrete controls) gives **648 failures on current, 648 on release, 0 with the candidate and 648 after restoration**. All 1,512 previously passing outputs remain exactly unchanged. Fifty-nine oracle cases per variant were repeated at 120 digits. Decimal rate literals are compared with their binary64 library representations using a predeclared absolute tolerance `2e-12 * max(1, payment_rate * term)`; this is not an exact-binary64 oracle claim.

A fresh package copy, with the candidate applied using `git apply`, reproduced all four numerical-row serializations. Separate checks with the package's actual `Uniform` class reproduce the minimal example. No full upstream suite or general correction of other annuity convenience methods is claimed.

For an explicitly synthetic GERO demonstration with a **continuous** payment rate of 1000 per year, the generated expected-value memo changes from 9166.67 to 8750.00. A separate consumer reads that JSON amount against a synthetic ceiling of 9000, changing `OVER_LIMIT` to `WITHIN_LIMIT`. Memo, formatting, ceiling and consumer are GERO adapters; no real insurer document, commercial quote, reserve requirement or customer loss is established.

The bounded duplicate review covered all six issue/PR bodies, comments, PR #2's diff, the guide repository's issues, eight `annuity.py` history records, focused searches and the current GERO catalog. No exact earlier report or correction was found in that scope. The source pattern is old; this is not described as a newly introduced regression.

Python 3.12.14, NumPy 2.5.3, SciPy 1.18.1, pandas 3.0.6, matplotlib 3.10.8 and IPython 9.17.1; one configured numerical worker. Investigation and writing were AI-assisted; the stated outputs are from executed public code and retained independent checks. The reproducible evidence packet will be linked here after publication.

Thank you,
Xamit Kadirbekov / GERO
