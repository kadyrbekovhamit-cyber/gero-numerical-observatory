from pathlib import Path
import json,decimal,datetime
R=Path(__file__).resolve().parent;D=R/'downstream';D.mkdir(exist_ok=True);out={}
for v in ['current','release','candidate','restored']:
 raw=json.loads((R/'evidence'/('grid-'+v+'-final.json')).read_text())['downstream']
 memo={k:x for k,x in raw.items() if k not in ['budget_decision','independent_expected_amount','equivalent_attained_age_library_value']}
 p=D/(v+'-memo.json');p.write_text(json.dumps(memo,indent=2)+'\n')
 # Separate read-back consumer. The written amount alone drives the ceiling decision.
 loaded=json.loads(p.read_text());amount=decimal.Decimal(loaded['expected_present_value_rounded']);limit=decimal.Decimal(loaded['synthetic_budget']);out[v]={'read_document':p.name,'amount':str(amount),'limit':str(limit),'decision':'WITHIN_LIMIT' if amount<=limit else 'OVER_LIMIT','independent_expected_amount':'8750.00'}
assert out['current']['decision']==out['release']['decision']==out['restored']['decision']=='OVER_LIMIT';assert out['candidate']['decision']=='WITHIN_LIMIT'
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'schema':'GERO synthetic EPV memo and independent read-back ceiling consumer','rows':out,'displayed_amount_difference':str(decimal.Decimal(out['current']['amount'])-decimal.Decimal(out['candidate']['amount'])),'upstream_component':'Uniform-model Annuity.a_x evaluated in actual native package run','GERO_components':['memo generation','currency-style formatting','synthetic ceiling of9000','read-back consumer'],'real_insurer_document':False,'commercial_quote':False,'real_customer_loss':False};(R/'DOWNSTREAM_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
