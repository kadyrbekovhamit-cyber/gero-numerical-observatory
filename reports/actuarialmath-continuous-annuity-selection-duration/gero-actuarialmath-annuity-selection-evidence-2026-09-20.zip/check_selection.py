from pathlib import Path
import os,sys,json,itertools,math,decimal,importlib.metadata
os.environ.update(MPLBACKEND='Agg',MPLCONFIGDIR=str(Path(__file__).resolve().parent/'mpl-cache'),XDG_CACHE_HOME=str(Path(__file__).resolve().parent/'cache'))
R=Path(__file__).resolve().parent;source=R/'source'/sys.argv[1];sys.path.insert(0,str(source/'src'))
import actuarialmath
from actuarialmath import Annuity
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)
def oracle(x,s,t,u,ds,b,discrete,precision=80):
 with decimal.localcontext() as ctx:
  ctx.prec=precision;D=decimal.Decimal;L=D(100-x-s);d=D(ds);lo=D(u);hi=D(u+t);B=D(b)
  if discrete:return B*sum(((-d*k).exp()*(1-D(k)/L) for k in range(u,u+t)),D(0))
  if not d:return B*((hi-lo)-(hi*hi-lo*lo)/(2*L))
  def F(y):return (-d*y).exp()*((y-L)/d+1/(d*d))/L
  return B*(F(hi)-F(lo))
rows=[]
for x,s,t,u,ds,b,discrete in itertools.product([20,40,60],[0,1,5,10,20],[0,1,5,10],[0,2,7],['0','0.01','0.05'],[1,1000],[False,True]):
 assert u+t<=100-x-s
 life=Annuity().set_survival(S=lambda x,s,t:max(0,1-t/(100-x-s)),maxage=100).set_interest(delta=float(ds))
 actual=life.a_x(x=x,s=s,t=t,u=u,benefit=lambda a,y:b,discrete=discrete)
 expected=float(oracle(x,s,t,u,ds,b,discrete));tol=2e-12*max(1,b*t)
 rows.append({'x':x,'s':s,'t':t,'u':u,'delta':ds,'benefit':b,'discrete':discrete,'actual':actual,'expected':expected,'tolerance':tol,'pass':math.isfinite(actual) and abs(actual-expected)<=tol})
precise=[row for i,row in enumerate(rows) if i%37==0]
assert all(float(oracle(r['x'],r['s'],r['t'],r['u'],r['delta'],r['benefit'],r['discrete'],120))==r['expected'] for r in precise)
# Independent exact zero-rate example plus executed synthetic budget document.
life=Annuity().set_survival(S=lambda x,s,t:max(0,1-t/(100-x-s)),maxage=100).set_interest(i=0)
a=life.a_x(40,s=20,t=10,benefit=lambda a,y:1000,discrete=False);equiv=life.a_x(60,s=0,t=10,benefit=lambda a,y:1000,discrete=False)
from decimal import Decimal as D,ROUND_HALF_UP
amount=str(D(str(a)).quantize(D('.01'),rounding=ROUND_HALF_UP));doc={'demonstration':'synthetic GERO continuous-annuity EPV memo; not an insurer document or commercial quote','continuous_payment_rate_per_year':1000,'years':10,'selection_age':40,'years_since_selection':20,'expected_present_value_rounded':amount,'synthetic_budget':9000,'budget_decision':'WITHIN_LIMIT' if D(amount)<=D(9000) else 'OVER_LIMIT','independent_expected_amount':'8750.00','actual_library_value':a,'equivalent_attained_age_library_value':equiv,'real_customer_impact_measured':False}
payload={'variant':sys.argv[1],'source_pin':'7d18f11ad304898f177b7922b3c53f70e4c2b4f4','python':sys.version,'dependencies':{k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','matplotlib','ipython']},'cases':len(rows),'failures':sum(not r['pass'] for r in rows),'continuous_failures':sum(not r['pass'] and not r['discrete'] for r in rows),'discrete_failures':sum(not r['pass'] and r['discrete'] for r in rows),'oracle_80_vs_120_digit_controls':len(precise),'rows':rows,'downstream':doc}
(R/'evidence'/('grid-'+sys.argv[1]+'.json')).write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n');print(sys.argv[1],payload['cases'],payload['failures'],amount,doc['budget_decision'])
