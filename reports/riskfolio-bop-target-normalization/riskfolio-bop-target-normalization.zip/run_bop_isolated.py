"""Run native tests on the unchanged mean_vector AST, without package imports.

Local evidence harness only, not part of the submitted patch. This executes the
real function body with numpy/pandas and does not test full-package integration.
"""
import ast
from pathlib import Path
import sys
import types
import numpy as np
import pandas as pd
import pytest

root = Path(__file__).parent / "Riskfolio-Lib"
path = root / "riskfolio/src/ParamsEstimation.py"
parsed = ast.parse(path.read_text(), filename=str(path))
function = next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == "mean_vector")
module = types.ModuleType("riskfolio.src.ParamsEstimation")
module.np, module.pd = np, pd
exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), "exec"), module.__dict__)
for name in ["riskfolio", "riskfolio.src"]:
    package = types.ModuleType(name)
    package.__path__ = []
    sys.modules[name] = package
sys.modules["riskfolio"].src = sys.modules["riskfolio.src"]
sys.modules["riskfolio.src"].ParamsEstimation = module
sys.modules[module.__name__] = module
print("Validation scope: actual mean_vector function only; full package not loaded.")
raise SystemExit(pytest.main([str(root / "tests/test_mean_vector_bop.py"), "-q"]))
