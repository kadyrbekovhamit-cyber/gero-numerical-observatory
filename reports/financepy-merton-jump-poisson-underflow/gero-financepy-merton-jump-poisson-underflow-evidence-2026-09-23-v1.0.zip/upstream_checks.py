from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parent
receipt={'at':datetime.datetime.now().astimezone().isoformat(),'checks':{}}
for variant in ['current','candidate']:
    root=R/('source' if variant=='current' else 'variants/'+variant)
    folder=root/'tests/regression'
    for name in ['compare','differences']:(folder/name).mkdir(exist_ok=True)
    script=folder/'TestFinModelMertonJumpDiffusion.py'
    module=ast.parse(script.read_text())
    tests=[n.name for n in module.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    direct_calls=[n.value.func.id for n in module.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name)]
    assert set(tests).issubset(direct_calls)
    env=dict(os.environ,PYTHONPATH=str(root)+os.pathsep+str(R/'runtime-overlay'),
             NUMBA_NUM_THREADS='1',NUMBA_CACHE_DIR=str(R/'cache'/variant),MPLCONFIGDIR=str(R/'cache/mpl'))
    process=subprocess.run([sys.executable,str(script)],cwd=folder,env=env,text=True,capture_output=True,timeout=240)
    (R/'evidence'/('upstream-'+variant+'.log')).write_text(process.stdout+process.stderr)
    receipt['checks'][variant]={'returncode':process.returncode,'test_functions_invoked':tests,
                                 'test_count':len(tests),'test_file_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
                                 'tail':(process.stdout+process.stderr)[-1300:]}
    print(variant,receipt['checks'][variant],flush=True)
(R/'evidence/UPSTREAM_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert all(x['returncode']==0 for x in receipt['checks'].values())
