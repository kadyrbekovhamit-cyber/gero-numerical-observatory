"""Independent high-precision conditional expectation, no FinancePy/SciPy import."""
from pathlib import Path
import json,math
import mpmath as mp
from cases import cases
R=Path(__file__).resolve().parent
mp.mp.dps=70

def normal_cdf(x): return mp.erfc(-x/mp.sqrt(2))/2

def bs(p, q, variance):
    s,k,t,r=map(mp.mpf,[p['S'],p['K'],p['T'],p['r']])
    q=mp.mpf(q)
    total_std=mp.sqrt(variance*t)
    d1=(mp.log(s/k)+(r-q)*t+variance*t/2)/total_std
    d2=d1-total_std
    sign=1 if p['side']=='call' else -1
    return sign*(s*mp.exp(-q*t)*normal_cdf(sign*d1)-k*mp.exp(-r*t)*normal_cdf(sign*d2))

rows=[]
for p in cases():
    lam,t=mp.mpf(p['lam']),mp.mpf(p['T'])
    variance=mp.mpf(p['sigma'])**2
    if p['group']=='null_jumps':
        value=bs(p,p['q'],variance)
        bounds=None
    else:
        lamt=lam*t
        mu,delta=mp.mpf(p['mu']),mp.mpf(p['delta'])
        log_ej=mu+delta**2/2
        compensator=mp.expm1(log_ej)
        left=max(0,int(mp.floor(lamt-14*mp.sqrt(lamt)-30)))
        right=int(mp.ceil(lamt+14*mp.sqrt(lamt)+30))
        weight=mp.exp(-lamt)*lamt**left/mp.factorial(left)
        total=mp.mpf(0)
        for n in range(left,right+1):
            qn=mp.mpf(p['q'])+lam*compensator-n*log_ej/t
            total+=weight*bs(p,qn,variance+n*delta**2/t)
            weight*=lamt/(n+1)
        value=total
        # Chernoff upper bounds for omitted Poisson tails; payoff <= S_T+K.
        def tail_bound(mean):
            def rate(k): return k*mp.log(k/mean)-k+mean
            return (mp.exp(-rate(left-1)) if left>1 else mp.mpf(0))+mp.exp(-rate(right+1))
        residual=p['S']*mp.exp(-mp.mpf(p['q'])*t)*tail_bound(lamt*mp.exp(log_ej))+p['K']*mp.exp(-mp.mpf(p['r'])*t)*tail_bound(lamt)
        assert residual < mp.mpf('1e-25')
        bounds={'first_n':left,'last_n':right,'omitted_price_upper_bound':mp.nstr(residual,30)}
    rows.append({'id':p['id'],'expected':mp.nstr(value,65),'tail':bounds})
(R/'evidence/oracle-70dps.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'oracle_rows':len(rows),'precision_decimal_digits':70}),flush=True)
