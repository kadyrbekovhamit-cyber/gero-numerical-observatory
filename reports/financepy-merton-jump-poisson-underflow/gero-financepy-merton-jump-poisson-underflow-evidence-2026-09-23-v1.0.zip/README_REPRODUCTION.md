# Reproduce the current-source Merton jump experiment

This archive contains FinancePy source pinned to7a68a8a8b3be507da6829793861d36865c98c547. It does not claim the released1.1.2 wheel contains the affected module.

Use Python3.12 and a fresh virtual environment. Install the exact packages from requirements.txt. No FinancePy package installation is necessary: the scripts import the archived source explicitly.

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 NUMBA_NUM_THREADS=1
.venv/bin/python run_checks.py
.venv/bin/python upstream_checks.py
.venv/bin/python measure_downstream.py
```

Run commands sequentially. The original research used a shared exclusive local-worker lock in addition to these thread settings. These variables are not an operating-system guarantee that every process on a computer uses only one core.

Expected results:112 observations per variant;52,0,52 discrepancies for original,candidate,restored. The12 upstream Merton test functions pass on both original and candidate. The synthetic worksheet changes from0.00/BELOW_THRESHOLD to2350.59/REVIEW and returns to0.00/BELOW_THRESHOLD after restoration.

The declared tolerance accommodates the existing FinancePy normal-CDF approximation. Exploratory probe flags are superseded by the formal grid counts; seeLOCAL_VERIFICATION.json. Patch scope and untested regimes are inREPORT_EN.md. A candidate is not an accepted fix.

SHA256SUMS records included files. The archive excludes interpreter wheels, installed environments, JIT caches, credentials and transient render/media files. Environment/log absolute workspace paths are replaced by `<case-root>` in this public copy; numerical output bytes are preserved.
