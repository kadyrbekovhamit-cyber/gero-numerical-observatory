from pathlib import Path
import datetime,hashlib,importlib.metadata,json,math,os,sys,warnings
from cases import cases

R=Path(__file__).resolve().parent
variant=sys.argv[1]
source=R/('source' if variant=='current' else 'variants/'+variant)
os.environ.update(NUMBA_NUM_THREADS='1',NUMBA_CACHE_DIR=str(R/'cache'/variant),
                  MPLCONFIGDIR=str(R/'cache/mpl'))
sys.path.insert(0,str(R/'runtime-overlay'))
sys.path.insert(0,str(source))
from financepy.models.merton_jump_diffusion import MertonJumpDiffusion
from financepy.utils.global_types import OptionTypes
assert importlib.metadata.version('numba')=='0.67.0'
assert importlib.metadata.version('llvmlite')=='0.49.0'
assert str(source) in sys.modules[MertonJumpDiffusion.__module__].__file__
rows=[]
for p in cases():
    model=MertonJumpDiffusion(p['sigma'],p['lam'],p['mu'],p['delta'],
                             poisson_tolerance=p['poisson_tolerance'],max_jumps=p['max_jumps'])
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            result=model.value(p['S'],p['T'],p['K'],p['r'],p['q'],
                OptionTypes.EUROPEAN_CALL if p['side']=='call' else OptionTypes.EUROPEAN_PUT)
            p.update(value=repr(result),value_hex=result.hex(),finite=math.isfinite(result))
        except Exception as e:
            p.update(exception=repr(e),finite=False)
        p['warnings']=[str(x.message) for x in caught]
    rows.append(p)
out=R/'evidence'/('grid-'+variant+'.json')
out.write_text(json.dumps(rows,indent=2)+'\n')
environment={'at':datetime.datetime.now().astimezone().isoformat(),
             'python':sys.version,'variant':variant,'api':sys.modules[MertonJumpDiffusion.__module__].__file__,
             'packages':{x:importlib.metadata.version(x) for x in ['numba','llvmlite','numpy','scipy','pandas','matplotlib','mpmath']},
             'configured_threads':1,'gpu':False,'playback':False}
(R/'evidence'/('environment-'+variant+'.json')).write_text(json.dumps(environment,indent=2)+'\n')
print(json.dumps({'variant':variant,'rows':len(rows),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}),flush=True)
