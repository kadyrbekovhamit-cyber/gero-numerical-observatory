"""GERO synthetic worksheet, separate from FinancePy's product API."""
from pathlib import Path
import csv,json
R=Path(__file__).resolve().parent
oracle={x['id']:x for x in json.loads((R/'evidence/oracle-70dps.json').read_text())}
records=[]
for variant in ['current','candidate','restored']:
    rows=json.loads((R/'evidence'/('grid-'+variant+'.json')).read_text())
    p=next(x for x in rows if x['group']=='null_jumps' and x['lam']==800 and x['S']==120 and x['side']=='call')
    unit=float(p['value']); expected=float(oracle[p['id']]['expected'])
    quantity=100;review_threshold=2000
    records.append({'variant':variant,'input_id':p['id'],'quantity_synthetic':quantity,
                    'unit_value':unit,'reference_unit_value':expected,
                    'worksheet_total':round(quantity*unit,2),'reference_total':round(quantity*expected,2),
                    'review_threshold':review_threshold,
                    'worksheet_decision':'REVIEW' if quantity*unit>review_threshold else 'BELOW_THRESHOLD',
                    'reference_decision':'REVIEW' if quantity*expected>review_threshold else 'BELOW_THRESHOLD',
                    'synthetic':True})
with (R/'evidence/synthetic-valuation-worksheet.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
receipt={'status':'executed_synthetic_document_and_decision','records':records,
         'boundaries':'Only model.value is FinancePy product code. CSV formatting, quantity, threshold and review rule are GERO demonstration logic, not a FinancePy feature or a real institution policy. No actual holdings, customer losses, deployment or regulatory findings.'}
(R/'evidence/DOWNSTREAM_MEASUREMENT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
