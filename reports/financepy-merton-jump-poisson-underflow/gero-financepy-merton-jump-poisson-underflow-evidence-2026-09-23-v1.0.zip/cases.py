"""Declared synthetic finite-domain checks, fixed before candidate replay."""
def cases():
    rows=[]
    for intensity_time in [0.,1.,10.,100.,500.,700.,720.,730.,740.,744.,745.,746.,800.,1000.]:
        for s in [80.,100.,120.]:
            for side in ['call','put']:
                rows.append(dict(group='null_jumps', S=s,K=100.,T=1.,r=.03,q=.01,
                                 sigma=.2,lam=intensity_time,mu=0.,delta=0.,side=side))
    for intensity_time in [1.,100.,700.,740.,746.,800.,1000.]:
        for delta in [.001,.01]:
            for side in ['call','put']:
                rows.append(dict(group='nonzero_jumps',S=120.,K=100.,T=1.,r=.03,q=.01,
                                 sigma=.2,lam=intensity_time,mu=-.5*delta*delta,
                                 delta=delta,side=side))
    for i,row in enumerate(rows):
        row.update(id=i,max_jumps=4000,poisson_tolerance=1.e-12,
                   absolute_tolerance=2.e-7*max(row['S'],row['K'],1.))
    return rows
