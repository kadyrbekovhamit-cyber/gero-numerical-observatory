from pathlib import Path
import json,math,subprocess,sys
R=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(R/'prepare_variants.py')],check=True)
for v in ['current','candidate','restored']:
    subprocess.run([sys.executable,str(R/'native_grid.py'),v],check=True)
subprocess.run([sys.executable,str(R/'oracle_grid.py')],check=True)
oracle={r['id']:r for r in json.loads((R/'evidence/oracle-70dps.json').read_text())}
all_rows={v:json.loads((R/'evidence'/('grid-'+v+'.json')).read_text()) for v in ['current','candidate','restored']}
assert all_rows['current']==all_rows['restored']
results={}
for v,rows in all_rows.items():
    failures=[r['id'] for r in rows if not r['finite'] or abs(float(r['value'])-float(oracle[r['id']]['expected']))>r['absolute_tolerance']]
    results[v]={'observations':len(rows),'failures':len(failures),'failure_ids':failures,
                'null_jump_failures':sum(r['group']=='null_jumps' and r['id'] in failures for r in rows),
                'nonzero_jump_failures':sum(r['group']=='nonzero_jumps' and r['id'] in failures for r in rows)}
assert results['current']['failures']>0
assert results['candidate']['failures']==0
assert results['current']['failure_ids']==results['restored']['failure_ids']
receipt={'status':'local_current_candidate_restoration_verified','variants':results,
         'restoration_byte_identical':True,
         'initial_probe_correction':'Its 1e-6 flag was too strict for upstream normal-CDF approximation (about 8e-6 in a control). Formal grid uses declared 2e-7*max(S,K,1); ordinary control error is not counted as this defect.',
         'scope':'Pinned current source only; latest published 1.1.2 wheel has no MertonJumpDiffusion module. No release defect claim.',
         'limits':['High Poisson exposure synthetic inputs; no real trade or loss.',
                   'max_jumps=4000 chosen to separate underflow from insufficient truncation budget.',
                   'Candidate only changes Poisson weight calculation; payoff-weighted tail stopping, cap handling and other extreme regimes are not fixed or comprehensively tested.',
                   'No full upstream suite or external submission in this script.']}
(R/'evidence/LOCAL_VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
