# Bounded duplicate and scope review — 23 September 2026

Current master `7a68a8a8b3be507da6829793861d36865c98c547` was fetched and all 222 selected package/test blobs verified against the Git tree. The submitted report rechecked the head before sending.

All-state GitHub searches: Merton (one result: issue263), jump (one result: PR247), Poisson, merton_jump_diffusion, underflow and intensity (zero results before the new issue). Saved exact JSON responses are in evidence/. The bodies of issue263 and PR247 were read: firm calibration monetary scaling and joint-calendar handling respectively, unrelated to this probability recurrence. The newest100 all-state PR titles and bodies were examined; no proposed jump/Poisson correction found. No plausible matching diff was identified. Do not describe this as exhaustive prior-art clearance.

The file history contains one introduction commit, bb10c3936e078a5212694d017746453175151c09 (2026-09-16). The current public GERO catalog contains120 entries and only the unrelated Merton-firm scale report under the searched Merton/jump/Poisson terms.

Official PyPI metadata still lists1.1.2. Its wheel SHA256 is3c32578b81f338741ac135bb05ff9aa9164d75f6aa89c4d5e7f6a96c8b6f37d9; the locally inspected wheel matches and has no merton_jump_diffusion.py. The source version banner is not proof of released-package impact.

The project has no AGENTS.md, CONTRIBUTING file or issue-template restriction in the examined tree. Current maintainer comments were reviewed. Prior cash-annuity PR271 is already approved/merged and recorded separately; do not announce it again here. No duplicate sales pitch, regulatory allegation, bounty application or payment claim.

New issue273 has been sent once and body-verified. Future discovery searches will now find our own report; use its existing thread for a material archive/patch follow-up, never open a second issue.
