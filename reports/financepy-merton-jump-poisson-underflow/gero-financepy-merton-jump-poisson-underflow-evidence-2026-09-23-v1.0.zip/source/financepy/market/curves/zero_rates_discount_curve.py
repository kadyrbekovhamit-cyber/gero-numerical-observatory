# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

from typing import Union

import numpy as np

from ...utils.format_graphs import *
from ...utils.frequency import FrequencyTypes
from ...utils.error import FinError
from ...utils.date import Date
from ...utils.day_count import DayCountTypes
from ...utils.math import test_monotonicity
from ...utils.helpers import label_to_string
from ...utils.helpers import times_from_dates
from ...market.curves.discount_curve import DiscountCurve
from ...utils.helpers import check_argument_types
from ...market.curves.interpolator import InterpTypes, Interpolator

import matplotlib.pyplot as plt

# TODO: Fix up __repr__ function

###############################################################################


class ZeroRatesDiscountCurve(DiscountCurve):
    """This is a curve calculated from a set of dates and zero rates. As we
    have rates as inputs, we need to specify the corresponding compounding
    frequency. Also to go from rates and dates to discount factors we need to
    compute the year fraction correctly and for this we require a day count
    convention. Finally, we need to interpolate the zero rate for the times
    between the zero rates given and for this we must specify an interpolation
    convention. The class inherits methods from DiscountCurve."""

    ###########################################################################

    def __init__(
        self,
        anchor_dt: Date,
        zero_dts: list,
        zero_rates: Union[list, np.ndarray],
        freq_type: FrequencyTypes = FrequencyTypes.ANNUAL,
        curve_dc_type: DayCountTypes = DayCountTypes.ACT_365F,
        interp_type: InterpTypes = InterpTypes.FLAT_FWD_RATES,
    ):
        """Create the discount curve from a vector of dates and zero rates
        factors. The first date is the curve anchor. Then a vector of zero
        dates and then another same-length vector of rates. The rate is to the
        corresponding date. We must specify the compounding frequency of the
        zero rates and also a day count convention for calculating times which
        we must do to calculate discount factors. Finally we specify the
        interpolation scheme for off-grid dates."""

        check_argument_types(self.__init__, locals())

        # Validate curve
        if len(zero_dts) == 0:
            raise FinError("Dates has zero length")

        if len(zero_dts) != len(zero_rates):
            raise FinError("Dates and Rates are not the same length")

        if freq_type not in FrequencyTypes:
            raise FinError("Unknown Frequency type " + str(freq_type))

        self.anchor_dt = anchor_dt
        self.freq_type = freq_type

        if not isinstance(curve_dc_type, DayCountTypes):
            raise FinError("Invalid time day count type.")

        if zero_dts[0] < anchor_dt:
            raise FinError("Zero rate dates must be on or after the valuation date.")

        self.curve_dc_type = curve_dc_type
        zero_rates = np.asarray(zero_rates, dtype=float)

        zero_times = times_from_dates(anchor_dt, zero_dts, self.curve_dc_type)
        zero_times = np.asarray(zero_times, dtype=float)

        if test_monotonicity(zero_times) is False:
            raise FinError("Times or dates are not sorted in increasing order")

        dfs = self._zero_to_df(zero_rates, zero_times, self.freq_type)

        # Add t=0 and df = 1.0 if not already included
        if zero_times[0] > 0.0:
            self._times = np.concatenate(([0.0], zero_times))
            self._dfs = np.concatenate(([1.0], dfs))
            self._df_dates = [anchor_dt] + list(zero_dts)
            self._zero_dts = [anchor_dt] + list(zero_dts)
            self._zero_rates = np.concatenate(([np.nan], zero_rates))
        else:
            self._times = zero_times
            self._dfs = dfs
            self._df_dates = list(zero_dts)
            self._zero_dts = list(zero_dts)
            self._zero_rates = zero_rates

        # We do not need a curve_dc_type as we have a rate dc_type but we specify it
        self.curve_dc_type = self.curve_dc_type
        self._interp_type = interp_type
        self._interpolator = Interpolator(self._interp_type)
        self.fit(self._times, self._dfs)

    ###########################################################################

    def bump_parallel(self, bump_size: float):
        """Return a new curve with all quoted zero rates bumped in parallel."""

        if not np.isscalar(bump_size):
            raise FinError("Bump size must be a scalar.")

        bump_size = float(bump_size)

        bumped_zero_rates = self._zero_rates[1:] + bump_size
        zero_dts = self._zero_dts[1:]

        return ZeroRatesDiscountCurve(
            anchor_dt=self.anchor_dt,
            zero_dts=zero_dts.copy(),
            zero_rates=bumped_zero_rates,
            freq_type=self.freq_type,
            curve_dc_type=self.curve_dc_type,
            interp_type=self._interp_type,
        )

    ###########################################################################

    def plot(
        self,
        title,
        times: np.ndarray = None,
        ymin: float = None,
        ymax: float = None,
        filename: str = None,
    ):
        """Display discount curve."""

        plt.rcParams.update(
            {
                "lines.linewidth": 3,
                "font.size": 14,
                "axes.labelsize": 14,
                "axes.titlesize": 16,
                "legend.fontsize": 14,
            }
        )

        plt.figure()
        plt.title(title)

        if times is None:
            tmax = np.max(self._times)
            times = np.linspace(0.0, tmax, int(tmax * 12.0))
        else:
            times = np.asarray(times, dtype=float)

        if np.any(times < 0.0):
            raise FinError("Plot times must be strictly positive.")

        times = np.maximum(times, 1e-8)

        # Annual zero rates
        zeros = self.zero_rate_t(times, self.freq_type)
        cc_fwds = self.fwd_rate_inst_t(times)

        # Bump the forwards by 1bp in case the curve is flat so they can be seen
        cc_fwds = cc_fwds + 1e-4

        plt.plot(times, zeros * 100, label="Zero Rates")
        plt.plot(times, cc_fwds * 100, label="Inst Fwd Rates")
        plt.plot(
            self._times,
            self._zero_rates * 100,
            "o",
            markersize=10,
            label="Input Zero Rates",
        )

        plt.xlabel("Time to Maturity (years)")
        plt.ylabel("Rate (%)")
        plt.legend()

        if ymin is not None and ymax is not None:
            plt.ylim(ymin, ymax)

        plt.grid(True, alpha=0.3)
        #        plt.tight_layout()

        if filename is not None:
            plt.savefig(filename, bbox_inches="tight", pad_inches=0.02)

        plt.show()

    ###########################################################################

    def __repr__(self):

        s = label_to_string("OBJECT TYPE", type(self).__name__)
        s += label_to_string("ZERO RATE FREQUENCY", self.freq_type)
        s += label_to_string("DATES", "ZERO RATES")

        for dt, rate in zip(self._zero_dts, self._zero_rates):
            s += label_to_string(str(dt), f"{rate:12.8f}")

        s += label_to_string("CURVE DC_TYPE", self.dc_type)

        s += "\n"
        s += super().__repr__()
        return s

    ###########################################################################

    def _print(self):
        """Simple print function for backward compatibility."""
        print(self)
