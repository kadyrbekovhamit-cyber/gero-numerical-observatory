The recently added `MertonJumpDiffusion.value` can return zero for a positive finite option value when the Poisson exposure is large, even with enough terms to cover the distribution.

Reproduced on current master `7a68a8a8b3be507da6829793861d36865c98c547`, Python 3.12.14, NumPy 2.3.5, SciPy 1.16.3, Numba 0.67.0 and llvmlite 0.49.0. The latest PyPI 1.1.2 wheel does **not** contain this module, so this report concerns the current source, not that released wheel.

```python
from financepy.models.merton_jump_diffusion import MertonJumpDiffusion
from financepy.utils.global_types import OptionTypes

for intensity in (0.0, 800.0):
    model = MertonJumpDiffusion(
        sigma=0.2,
        jump_intensity=intensity,
        jump_mean=0.0,
        jump_volatility=0.0,
        max_jumps=4000,
    )
    print(intensity, model.value(
        120.0, 1.0, 100.0, 0.03, 0.01, OptionTypes.EUROPEAN_CALL
    ))
```

Current output:

```text
0.0   23.505858962472935
800.0 0.0
```

With zero jump size, every jump multiplier is exactly one. The option must therefore retain its Black–Scholes value independently of jump intensity. A separate 70-digit calculation gives approximately `23.505867004864303`. The small difference from the first FinancePy output is its existing normal-CDF approximation; I am not counting that as this defect.

The first Poisson weight is `exp(-lambda*T)`. It rounds to zero for exposure 800, and the multiplicative recursion cannot recover subsequent nonzero probabilities. Subnormal first weights also distort prices before complete underflow: at exposures 740 and 745 this same call returns approximately 23.50770001 and 23.95368337. Increasing `max_jumps` does not recover information lost in the initial weight.

A local candidate computes each new weight from its log PMF:

```python
from scipy.special import gammaln

# Replace the recursive update for p_(n+1):
if lambda_t > 0.0:
    poisson_prob = np.exp(
        -lambda_t + (n + 1.0) * np.log(lambda_t) - gammaln(n + 2.0)
    )
else:
    poisson_prob = 0.0
```

This gives `23.505858962452724` for exposure 800. On 112 synthetic calls and puts, an independent 70-digit reference finds **52 → 0 → 52** discrepancies for current code, this candidate and restoration of the original code, using the same declared absolute tolerance `2e-7 * max(S, K, 1)`. This includes 84 zero-jump-size checks and 28 checks with nonzero jump volatility. The restored outputs are byte-identical to baseline. All 12 functions invoked by the existing `TestFinModelMertonJumpDiffusion.py` pass before and after the candidate change; the full library suite was not run.

For a downstream demonstration, a separate synthetic worksheet multiplies the exposure-800 call value by 100. It records 0.00 instead of 2350.59 and misses an explicitly chosen review threshold of 2000. The candidate restores both the rounded worksheet value and the decision. This worksheet and threshold are GERO demonstration logic, not FinancePy features or evidence of real positions, bank deployment or customer loss.

The candidate addresses the Poisson-weight underflow only. It does not establish general accuracy of the stopping criterion, handling of insufficient `max_jumps`, or all other extreme parameter regimes. Would a focused regression and correction along these lines be useful? AI-assisted analysis with actual current-source execution; reproducer, raw results and candidate patch are retained.
