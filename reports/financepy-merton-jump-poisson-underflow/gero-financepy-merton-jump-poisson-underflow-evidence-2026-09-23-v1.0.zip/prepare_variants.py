from pathlib import Path
import difflib
import hashlib
import json
import shutil

R = Path(__file__).resolve().parent
rel = Path('financepy/models/merton_jump_diffusion.py')
original = (R/'source'/rel).read_text()
patched = original.replace('from scipy.optimize import least_squares',
                           'from scipy.optimize import least_squares\nfrom scipy.special import gammaln', 1)
old = '            poisson_prob *= lambda_t / (n + 1.0)'
new = '''            if lambda_t > 0.0:
                poisson_prob = np.exp(
                    -lambda_t + (n + 1.0) * np.log(lambda_t) - gammaln(n + 2.0)
                )
            else:
                poisson_prob = 0.0'''
assert original.count(old) == 1
patched = patched.replace(old, new)
for variant in ['candidate', 'restored']:
    dest = R/'variants'/variant
    shutil.copytree(R/'source', dest, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__','*.nbc','*.nbi'))
    (dest/rel).write_text(patched)
    if variant == 'restored':
        restored = (dest/rel).read_text().replace(new, old).replace(
            '\nfrom scipy.special import gammaln', '', 1)
        assert restored == original
        (dest/rel).write_text(restored)
(R/'candidate.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(True), patched.splitlines(True),
    fromfile='a/'+str(rel), tofile='b/'+str(rel))))
hashes = {v: hashlib.sha256((R/('source' if v=='current' else 'variants/'+v)/rel).read_bytes()).hexdigest()
          for v in ['current','candidate','restored']}
assert hashes['current'] == hashes['restored']
(R/'evidence/variant-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(hashes)
