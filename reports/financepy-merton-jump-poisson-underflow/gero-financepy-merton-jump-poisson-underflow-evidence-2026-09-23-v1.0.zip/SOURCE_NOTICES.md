# Source notices

The FinancePy source is from domokane/FinancePy at the stated commit. Its copyright headers and GPL license in source/LICENSE are retained. No blanket replacement license is applied to the mixed evidence archive. GERO report and reproduction scripts are authored for this research by Xamit Kadirbekov with disclosed AI assistance.
