Public evidence for the PolicyEngine-US tips/overtime correction.

The script and output are historical evidence for 2.24.1. Release 2.60.3 was inspected, not installed or run. Full reproduction requires the historical package and its dependencies. No dependency installation was performed in this publication pass.

Report CC BY 4.0; original reproducer MIT.
