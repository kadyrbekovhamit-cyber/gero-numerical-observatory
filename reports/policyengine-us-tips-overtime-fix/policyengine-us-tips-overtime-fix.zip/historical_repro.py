# Historical witness for 2.24.1. Assertions intentionally expect the old behavior.
# Not a regression test expected to pass on the corrected release.
# SPDX-License-Identifier: MIT
import json, importlib.metadata, hashlib
from pathlib import Path
import policyengine_us
from policyengine_us import Simulation

def case(status,agi,tips=25000,ot=12500):
 people={'h':{'age':{'2025':40},'ssn_card_type':{'2025':'CITIZEN'},'treasury_tipped_occupation_code':{'2025':102},'tip_income':{'2025':tips},'fsla_overtime_premium':{'2025':ot}}}
 members=['h'];tu={'h':{'members':['h'],'filing_status':{'2025':status},'adjusted_gross_income':{'2025':agi}}}
 if status in ('JOINT','SEPARATE'):
  people['s']={'age':{'2025':39},'ssn_card_type':{'2025':'CITIZEN'}};members.append('s')
  if status=='JOINT':tu['h']['members']=['h','s']
  else:tu['s']={'members':['s'],'filing_status':{'2025':'SEPARATE'},'adjusted_gross_income':{'2025':0}}
 sit={'people':people,'tax_units':tu,'households':{'hh':{'members':members}},'families':{'f':{'members':members}},'spm_units':{'s':{'members':members}},'marital_units':{'m':{'members':members}}}
 sim=Simulation(situation=sit)
 got={v:float(sim.calculate(v,2025)[0]) for v in ['tip_income_deduction','overtime_income_deduction']}
 return {'filing_status':status,'agi':agi,'situation':sit,'actual':got}

results=[case('SEPARATE',80000),case('SINGLE',80000),case('JOINT',80000),case('SINGLE',150999),case('SINGLE',151000),case('SINGLE',151001)]
assert results[0]['actual']=={'tip_income_deduction':25000.,'overtime_income_deduction':12500.}
assert results[1]['actual']==results[2]['actual']==results[0]['actual']
assert results[4]['actual']=={'tip_income_deduction':24900.,'overtime_income_deduction':12400.}
module=Path(policyengine_us.__file__).parent
sha={str(p.relative_to(module)):hashlib.sha256(p.read_bytes()).hexdigest() for sub in ['tip_income','overtime_income'] for p in (module/'variables/gov/irs/income/taxable_income/deductions'/sub).glob('*.py')}
print(json.dumps({'package_version':importlib.metadata.version('policyengine-us'),'formula_sha256':sha,'year':2025,'scope':'Deduction variables with explicitly supplied AGI; no complete tax liability or real household data.','results':results},indent=2))
