Copyright 2026 Xamit Kadirbekov / GERO. Original text licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Third-party works retain their licenses.
