Apply each patch independently to the source base in REPORT_EN.md. These are public proposals with scoped validation, not accepted fixes. No private correspondence or private-case patch is included.
