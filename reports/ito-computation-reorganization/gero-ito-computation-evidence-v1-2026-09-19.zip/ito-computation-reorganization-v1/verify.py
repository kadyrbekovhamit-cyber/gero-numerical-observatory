#!/usr/bin/env python3
"""Bounded educational BSM audit; Python standard library, one process, no network.

Run: python3 verify.py
Not a production pricing engine. Quadrature is an independently evaluated
risk-neutral payoff integral, not a second call to the closed-form function.
"""
import hashlib
import itertools
import json
import math
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SQRT2 = math.sqrt(2.0)
SQRT2PI = math.sqrt(2.0 * math.pi)


def cdf(x):
    return 0.5 * math.erfc(-x / SQRT2)


def density(x):
    return math.exp(-0.5 * x * x) / SQRT2PI


def prices(s, k, r, vol, tau, q=0.0):
    vals = (s, k, r, vol, tau, q)
    if not all(math.isfinite(v) for v in vals):
        raise ValueError("All inputs must be finite")
    if min(s, k, vol, tau) < 0:
        raise ValueError("Spot, strike, volatility and maturity must be nonnegative")
    ds, dk = s * math.exp(-q * tau), k * math.exp(-r * tau)
    if tau == 0 or vol == 0 or s == 0 or k == 0:
        return max(ds - dk, 0.0), max(dk - ds, 0.0)
    a = vol * math.sqrt(tau)
    d1 = (math.log(s) - math.log(k) + (r - q + 0.5 * vol**2) * tau) / a
    d2 = d1 - a
    # Compute the OTM leg directly, recover the ITM leg using parity.
    if ds <= dk:
        call = ds * cdf(d1) - dk * cdf(d2)
        put = call + dk - ds
    else:
        put = dk * cdf(-d2) - ds * cdf(-d1)
        call = put + ds - dk
    return call, put


def greeks(s, k, r, vol, tau, q=0.0):
    if min(s, k, vol, tau) <= 0:
        raise ValueError("Greeks here require positive spot, strike, volatility and maturity")
    a = vol * math.sqrt(tau)
    d1 = (math.log(s / k) + (r - q + vol**2 / 2) * tau) / a
    d2 = d1 - a
    dq = math.exp(-q * tau)
    dk = k * math.exp(-r * tau)
    return {
        "delta": dq * cdf(d1),
        "gamma": dq * density(d1) / (s * a),
        "vega_per_unit_vol": s * dq * density(d1) * math.sqrt(tau),
        "rho_per_unit_rate": tau * dk * cdf(d2),
        "theta_per_year": -s * dq * density(d1) * vol / (2 * math.sqrt(tau))
        - r * dk * cdf(d2) + q * s * dq * cdf(d1),
    }


def adaptive_simpson(f, left, right, tol, max_depth=24):
    if left == right:
        return 0.0
    mid = (left + right) / 2
    fl, fm, fr = f(left), f(mid), f(right)
    whole = (right - left) * (fl + 4 * fm + fr) / 6

    def rec(a, b, fa, fc, fb, value, eps, depth):
        c = (a + b) / 2
        lm, rm = (a + c) / 2, (c + b) / 2
        flm, frm = f(lm), f(rm)
        lv = (c - a) * (fa + 4 * flm + fc) / 6
        rv = (b - c) * (fc + 4 * frm + fb) / 6
        diff = lv + rv - value
        if abs(diff) <= 15 * eps:
            return lv + rv + diff / 15
        if depth == 0:
            raise ArithmeticError("Quadrature depth exhausted")
        return rec(a, c, fa, flm, fc, lv, eps / 2, depth - 1) + rec(
            c, b, fc, frm, fb, rv, eps / 2, depth - 1)

    return rec(left, right, fl, fm, fr, whole, tol, max_depth)


def payoff_integral(s, k, r, vol, tau, q=0.0, tol=2e-10):
    if min(s, k, vol, tau) <= 0:
        raise ValueError("Independent quadrature restricted to interior inputs")
    a = vol * math.sqrt(tau)
    drift = (r - q - vol**2 / 2) * tau
    kink = (math.log(k / s) - drift) / a
    cut = max(-12.0, min(12.0, kink))

    def integrate_interval(f, left, right):
        pieces = max(1, math.ceil(right - left))
        return math.fsum(adaptive_simpson(
            f, left + (right - left) * i / pieces,
            left + (right - left) * (i + 1) / pieces, tol / pieces)
            for i in range(pieces))

    disc = math.exp(-r * tau)

    def value(z):
        return s * math.exp(drift + a * z)

    call = disc * integrate_interval(lambda z: max(value(z) - k, 0) * density(z), cut, 12)
    put = disc * integrate_interval(lambda z: max(k - value(z), 0) * density(z), -12, cut)
    # Analytic upper bounds on omitted tails; unlike Simpson tolerance,
    # these bounds follow from positivity and a Gaussian exponential tilt.
    call_tail_bound = s * math.exp(-q * tau) * (cdf(-12 - a) + cdf(a - 12))
    put_tail_bound = 2 * k * disc * cdf(-12)
    return call, put, call_tail_bound, put_tail_bound


def binomial_call(s, k, r, vol, tau, n, q=0.0):
    dt = tau / n
    h = vol * math.sqrt(dt)
    up, down = math.exp(h), math.exp(-h)
    p = (math.exp((r - q) * dt) - down) / (up - down)
    if not 0 < p < 1:
        raise ValueError("Tree does not satisfy strict one-step no-arbitrage")
    total = []
    for j in range(n + 1):
        st = s * math.exp((2 * j - n) * h)
        if st > k:
            logp = (math.lgamma(n + 1) - math.lgamma(j + 1) - math.lgamma(n - j + 1)
                    + j * math.log(p) + (n - j) * math.log1p(-p))
            total.append(math.exp(logp) * (st - k))
    return math.exp(-r * tau) * math.fsum(total)


def run():
    checks = []

    def check(name, observed, limit):
        if not math.isfinite(observed) or observed > limit:
            raise AssertionError(f"{name}: {observed} exceeds {limit}")
        checks.append({"name": name, "max_abs_error_or_violation": observed, "limit": limit})

    benchmark = (100.0, 100.0, 0.05, 0.2, 1.0, 0.0)
    call, put = prices(*benchmark)
    check("call benchmark", abs(call - 10.450583572185565), 1e-11)
    check("put benchmark", abs(put - 5.573526022256971), 1e-11)

    cases = [benchmark, (80, 100, -0.01, 0.35, 0.25, 0.02),
             (120, 100, 0.03, 0.4, 2.0, 0.05), (100, 100, 0.0, 0.01, 0.01, 0.0),
             (95, 110, 0.02, 0.18, 1.3, 0.01)]
    integrations = []
    for args in cases:
        formula = prices(*args)
        integral = payoff_integral(*args)
        refined = payoff_integral(*args, tol=1e-11)
        error = max(abs(formula[i] - refined[i]) for i in range(2))
        check(f"independent payoff integral {args}", error, 2e-8)
        check(f"quadrature refinement {args}", max(abs(integral[i] - refined[i]) for i in range(2)), 2e-8)
        integrations.append({"inputs": args, "closed_form": formula, "quadrature": refined[:2],
                             "max_abs_error": error, "omitted_tail_bounds": refined[2:]})

    parity_errors, bound_violations, homogeneity, mapping, pde = [], [], [], [], []
    grid = list(itertools.product((70., 100., 140.), (80., 110.), (-0.02, 0.05),
                                  (0.05, 0.3), (0.05, 1.5), (0., 0.03)))
    for s, k, r, vol, tau, q in grid:
        c, p = prices(s, k, r, vol, tau, q)
        ds, dk = s * math.exp(-q * tau), k * math.exp(-r * tau)
        parity_errors.append(abs(c - p - (ds - dk)))
        bound_violations.append(max(0, max(ds - dk, 0) - c, c - ds,
                                    max(dk - ds, 0) - p, p - dk))
        scaled = prices(s * 7, k * 7, r, vol, tau, q)
        homogeneity.append(max(abs(scaled[0] - 7 * c), abs(scaled[1] - 7 * p)))
        fwd, discount = s * math.exp((r - q) * tau), math.exp(-r * tau)
        forward_prices = prices(fwd, k, 0, vol, tau)
        mapping.append(max(abs(discount * forward_prices[0] - c), abs(discount * forward_prices[1] - p)))
        g = greeks(s, k, r, vol, tau, q)
        pde.append(abs(g["theta_per_year"] + (r - q) * s * g["delta"]
                       + 0.5 * vol**2 * s**2 * g["gamma"] - r * c))
    for name, values in (("put-call parity", parity_errors), ("arbitrage bounds", bound_violations),
                         ("homogeneity", homogeneity), ("spot-forward mapping", mapping),
                         ("analytic PDE residual", pde)):
        check(f"{name}: {len(grid)} grid points", max(values), 2e-10)

    finite_differences = []
    for args in cases:
        s, k, r, vol, tau, q = args
        g = greeks(*args)
        hs = s * 1e-5
        hv, hr, ht = vol * 1e-4, 1e-5, tau * 1e-4
        f = lambda ss=s, rr=r, vv=vol, tt=tau: prices(ss, k, rr, vv, tt, q)[0]
        approx = {
            "delta": (f(ss=s + hs) - f(ss=s - hs)) / (2 * hs),
            "gamma": (f(ss=s + hs) - 2 * f() + f(ss=s - hs)) / hs**2,
            "vega_per_unit_vol": (f(vv=vol + hv) - f(vv=vol - hv)) / (2 * hv),
            "rho_per_unit_rate": (f(rr=r + hr) - f(rr=r - hr)) / (2 * hr),
            "theta_per_year": -(f(tt=tau + ht) - f(tt=tau - ht)) / (2 * ht),
        }
        errors = {key: abs(approx[key] - g[key]) / max(1.0, abs(g[key])) for key in g}
        check(f"finite-difference Greeks {args}", max(errors.values()), 2e-5)
        finite_differences.append({"inputs": args, "analytic": g, "finite_difference": approx,
                                   "max_scaled_error": max(errors.values())})

    boundaries = []
    for args in ((100, 90, 0.05, 0.2, 0, 0), (100, 110, 0.05, 0, 1, 0),
                 (120, 100, -0.02, 0, 1, 0.03), (0, 100, 0.05, 0.2, 1, 0),
                 (100, 0, 0.05, 0.2, 1, 0.02), (0, 0, 0, 0, 0, 0)):
        c, p = prices(*args)
        s, k, r, vol, tau, q = args
        d = s * math.exp(-q * tau) - k * math.exp(-r * tau)
        check(f"boundary price {args}", max(abs(c - max(d, 0)), abs(p - max(-d, 0))), 1e-12)
        boundaries.append({"inputs": args, "call": c, "put": p})

    rejected = 0
    for args in ((100, 100, .05, -.2, 1), (100, 100, .05, .2, -1),
                 (-1, 100, .05, .2, 1), (100, -1, .05, .2, 1),
                 (float("nan"), 100, .05, .2, 1), (100, 100, float("inf"), .2, 1)):
        try:
            prices(*args)
        except ValueError:
            rejected += 1
    if rejected != 6:
        raise AssertionError("Invalid inputs were not all rejected")

    tree = [{"steps": n, "call": binomial_call(*benchmark[:5], n),
             "absolute_error": abs(binomial_call(*benchmark[:5], n) - call)} for n in (256, 1024, 4096)]
    check("4096-step independent binomial", tree[-1]["absolute_error"], 0.001)

    s, k, r, vol, tau, q = benchmark
    wrong_log_drift_mean = s * math.exp(vol**2 * tau / 2)
    wrong_mu_price = prices(s, k, 0.12, vol, tau)[0]
    d1 = (math.log(s / k) + (r + vol**2 / 2) * tau) / (vol * math.sqrt(tau))
    wrong_d2_price = s * cdf(d1) - k * math.exp(-r * tau) * cdf(d1 + vol * math.sqrt(tau))
    mutants = {
        "omitted_Ito_log_drift_correction": {
            "correct_discounted_stock_expectation": s,
            "wrong_discounted_stock_expectation": wrong_log_drift_mean,
            "absolute_error": wrong_log_drift_mean - s,
        },
        "substitute_mu_12_percent_for_r_5_percent": {
            "wrong_call": wrong_mu_price, "correct_call": call, "absolute_error": abs(wrong_mu_price - call)},
        "use_d2_equals_d1_plus_sigma_sqrt_tau": {
            "wrong_call": wrong_d2_price, "correct_call": call, "absolute_error": abs(wrong_d2_price - call)},
    }
    if not all(item["absolute_error"] > 0.1 for item in mutants.values()):
        raise AssertionError("Mutation controls did not detect intended errors")

    a = math.exp((r + vol**2) * tau)
    square = {"claim": "S_T^2, q=0", "A": a, "value": a * s**2,
              "delta": 2 * a * s, "cash_value": -a * s**2,
              "unfinanced_delta_stock_minus_claim_diffusion": 2 * a * vol * s**2}
    result = {
        "status": "PASS", "scope": "Synthetic educational checks only; no vendor implementation tested",
        "runtime": {"python": platform.python_version(), "workers": 1, "dependencies": "standard library"},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "benchmark": {"inputs_S_K_r_sigma_tau_q": benchmark, "call": call, "put": put,
                      "greeks": greeks(*benchmark)},
        "checks": checks, "numerical_check_groups": len(checks), "grid_points": len(grid),
        "independent_integrals": integrations, "finite_difference_checks": finite_differences,
        "boundaries": boundaries, "invalid_inputs_rejected": rejected,
        "binomial_convergence": tree, "intentional_mutation_controls": mutants,
        "self_financing_square_claim_example": square,
        "limitations": ["finite test domain; not a proof or production certification",
                        "Simpson error estimate not an interval arithmetic certificate",
                        "terminal lognormal integral shares the specified mathematical model",
                        "no empirical market validation or vendor defect established"],
    }
    target = ROOT / "verification.json"
    target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"status": result["status"], "check_groups": len(checks),
                      "grid_points": len(grid), "benchmark": result["benchmark"],
                      "max_integral_error": max(x["max_abs_error"] for x in integrations),
                      "binomial": tree, "mutations": mutants, "output": str(target)}, indent=2))


if __name__ == "__main__":
    run()
