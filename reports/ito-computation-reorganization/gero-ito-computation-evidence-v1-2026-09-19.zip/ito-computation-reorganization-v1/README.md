# Same Itô integral, fewer operations

Xamit Kadirbekov, GERO, 19 September 2026. Version 1.0.

Start with [the English report](REPORT_EN.md) or [the detailed Russian report](programme/REPORT_RU.md).
This is a reproducible study of known methods, not a new integral, correction to Itô's formula,
market-pricing improvement or vendor implementation defect. Not peer reviewed.

Run from this directory, sequentially with standard-library Python 3.9+:

```sh
python3 programme/benchmark.py
python3 programme/batch_moments.py
python3 area_enriched_check.py
```

The scripts replace their saved output JSON on a new run; preserve a copy before replay.
Timing and stochastic sample outcomes may differ. Exact identities, statistical diagnostics
and benchmark-specific speed measurements are distinct evidence classes. Negative controls
and the unfavorable observed option-pricing result are retained.

Saved-result source hashes were checked when packaging; no new numerical rerun was needed.
SHA256SUMS covers this immutable release. The original JSON source hashes are preserved.
Internal critic/auditor notes are included; those are not external peer review.
Historical named roles denote methodological perspectives, not attribution or endorsements.

This package is the research evidence. Publication and video links are maintained separately
in the repository release page so that adding a platform does not rewrite the archive.

Canonical release: https://github.com/kadyrbekovhamit-cyber/gero-numerical-observatory/tree/main/reports/ito-computation-reorganization

Text and authored figures: CC BY 4.0. Original code: MIT. External papers are linked only.
See LICENSE-CODE.txt and LICENSE-TEXT.md.
