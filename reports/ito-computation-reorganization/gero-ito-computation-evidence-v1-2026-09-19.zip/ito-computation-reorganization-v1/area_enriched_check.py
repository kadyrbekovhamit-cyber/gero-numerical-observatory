#!/usr/bin/env python3
"""Exact area-enriched Ito reconstruction audit, one process, no sampling.

The parabolic Brownian bridge construction is known (Foster/Lyons/Oberhauser
2020). This verifies its application to integral W^3 dW with independent
rational kernel integration and Gaussian polynomial moments.
"""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

from bridge_moment_check import add, multiply
from polynomial_projection import power, expectation

ROOT = Path(__file__).resolve().parent


def scale(poly, factor):
    return {key: factor * value for key, value in poly.items() if factor * value}


def triangle_integral(poly):
    """Integral over 0<z<t<1; the other triangle uses symmetric reflection."""
    return sum((c / ((i + 1) * (i + j + 2)) for (i, j), c in poly.items()), F(0))


def audit_kernel():
    # On z<=t, C0(z,t)=z(1-t), R=C0-3 z(1-z)t(1-t).
    c0 = {(1, 0): F(1), (1, 1): F(-1)}
    zz = {(1, 1): F(1)}
    pp = {(1, 1): F(1), (2, 1): F(-1), (1, 2): F(-1), (2, 2): F(1)}
    residual = add(c0, pp, F(-3))
    izz = 2 * triangle_integral(multiply(zz, residual))
    ipp = 2 * triangle_integral(multiply(pp, residual))
    trace_square = 2 * triangle_integral(multiply(residual, residual))
    conditional_coefficient = F(9, 4) * (4 * (izz + 3 * ipp) + 2 * trace_square)
    assert (izz, ipp, trace_square, conditional_coefficient) == (F(1, 720), F(1, 25200), F(11, 12600), F(7, 400))
    # Integral of residual variance: ∫[z(1-z)-3z²(1-z)²]dz=1/15.
    trace = F(1, 2) - F(4, 3) + F(6, 4) - F(3, 5)
    assert trace == F(1, 15)
    return {"I_zt_R": str(izz), "I_p_p_R": str(ipp), "I_R_squared": str(trace_square),
            "trace_R": str(trace), "cubic_MSE_per_interval_coefficient": str(conditional_coefficient)}


def build_estimators(widths, independent_areas=False):
    n = len(widths)
    dimension = (3 if independent_areas else 2) * n
    basis = [{tuple(int(j == i) for j in range(dimension)): F(1)} for i in range(dimension)]
    unit = {(0,) * dimension: F(1)}
    x, drift0, drift1, drift_star = {}, {}, {}, {}
    for i, h in enumerate(widths):
        dx, area = basis[i], basis[n + i]
        y = add(x, dx)
        edge_term = scale(add(add(multiply(x, x), multiply(x, y)), multiply(y, y)), h / 3)
        q0 = add(edge_term, unit, h*h / 6)
        def enriched(a):
            q = add(edge_term, multiply(add(x, y), a))
            q = add(q, multiply(a, a), F(6, 5) / h)
            return add(q, unit, h*h / 15)
        drift0 = add(drift0, q0)
        drift1 = add(drift1, enriched(area))
        if independent_areas:
            drift_star = add(drift_star, enriched(basis[2*n + i]))
        x = y
    terminal = scale(power(x, 4, dimension), F(1, 4))
    j0, j1 = add(terminal, drift0, F(-3, 2)), add(terminal, drift1, F(-3, 2))
    j_star = add(terminal, drift_star, F(-3, 2)) if independent_areas else None
    variances = list(widths) + [h**3 / 12 for h in widths]
    if independent_areas:
        variances += [h**3 / 12 for h in widths]
    return j0, j1, j_star, variances


def audit_grid(widths):
    j0, j1, j_star, variances = build_estimators(widths, independent_areas=True)
    horizon = sum(widths, F(0))
    exact_integral_variance = F(15, 4) * horizon**4  # Ito isometry ∫E W_t^6 dt.
    mse0 = exact_integral_variance - expectation(multiply(j0, j0), variances)
    mse1 = exact_integral_variance - expectation(multiply(j1, j1), variances)
    assert expectation(j0, variances) == expectation(j1, variances) == 0
    expected1 = F(7, 400) * sum((h**4 for h in widths), F(0))
    start, expected0 = F(0), F(0)
    for h in widths:
        expected0 += F(3, 4)*start*h**3 + h**4/4
        start += h
    assert mse0 == expected0 and mse1 == expected1
    improvement = add(j1, j0, F(-1))
    assert expectation(multiply(improvement, improvement), variances) == mse0 - mse1
    replacement = add(j1, j_star, F(-1))
    independent_resampling_mse = mse1 + expectation(multiply(replacement, replacement), variances)
    assert independent_resampling_mse == 2*mse0 - mse1 > mse0
    return {"widths": list(map(str, widths)), "target": "integral W_t^3 dW_t, W0=0",
            "endpoint_only_MSE": str(mse0), "endpoint_plus_true_area_MSE": str(mse1),
            "independent_area_resampling_MSE": str(independent_resampling_mse),
            "MSE_ratio_endpoint_to_enriched": str(mse0/mse1)}


def run():
    kernels = audit_kernel()
    grids = [[F(1, n)] * n for n in (1, 2, 3, 4)] + [[F(1, 7), F(2, 7), F(4, 7)], [F(2, 3)] * 3]
    checks = [audit_grid(grid) for grid in grids]
    n = 64
    endpoint = F(3*n-1, 8*n**3)
    enriched = F(7, 400*n**3)
    result = {"status": "PASS", "workers": 1, "arithmetic": "exact rational; no Monte Carlo",
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "dependency_hashes": {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                                    for name in ('bridge_moment_check.py', 'polynomial_projection.py')},
              "kernel_checks": kernels, "grid_checks": checks,
              "illustration_T1_n64": {"endpoint_MSE_exact": str(endpoint), "area_MSE_exact": str(enriched),
                  "endpoint_RMSE": float(endpoint)**.5, "area_RMSE": float(enriched)**.5,
                  "MSE_ratio": str(endpoint/enriched)},
              "scope": ["extra TRUE bridge-area information is essential",
                  "independently resampled areas worsen reconstruction of an existing hidden path",
                  "finite checks accompany general analytic proofs, not substitute for them",
                  "same Ito integral; known conditional parabolic method, no novelty claim",
                  "not an option-pricing or market-accuracy experiment"]}
    (ROOT/'research-group'/'area-enriched-check.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({"status": result['status'], "grid_checks": len(checks), "kernels": kernels,
                      "illustration": result['illustration_T1_n64']}, indent=2))


if __name__ == '__main__':
    run()
