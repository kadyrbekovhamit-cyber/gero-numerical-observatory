#!/usr/bin/env python3
"""Serial combinatorial cubature and alternative-model experiments.

No external dependencies; no Monte Carlo; no market data. These are numerical
approximations of a known model and a different specified risk-neutral model,
NOT a replacement for an exact Ito identity.
"""
import hashlib
import json
import math
from pathlib import Path

from verify import prices, binomial_call

ROOT = Path(__file__).resolve().parent


def lattice_probabilities(n):
    # Coefficients of (z^-1 + 4 + z)^n / 6^n, stored from exponent -n to n.
    p = [1.0]
    for _ in range(n):
        nxt = [0.0] * (len(p) + 2)
        for j, prob in enumerate(p):
            v = prob / 6.0
            nxt[j] += v
            nxt[j + 1] += 4 * v
            nxt[j + 2] += v
        p = nxt
    return p


def lattice_probabilities_linear(n):
    """Positive half-polynomial ratio recurrence, O(n) arithmetic and memory.

    (k+1)a[k+1] = 4(n-k)a[k] + (2n-k+1)a[k-1].
    Only k<n is used, so every operation in the ratios is nonnegative.
    Central normalization avoids a0=6**(-n) underflow.
    """
    if n < 1:
        raise ValueError("positive step count required")
    ratios = [0.0, float(4*n)]
    for k in range(1, n):
        ratios.append((4*(n-k) + (2*n-k+1)/ratios[k])/(k+1))
    weights = [0.0]*(n+1)
    weights[n] = 1.0
    for k in range(n, 0, -1):
        weights[k-1] = weights[k]/ratios[k]
    mass = 1 + 2*math.fsum(weights[:n])
    return [x/mass for x in weights + weights[-2::-1]]


def exact_integer_coefficients(n):
    coeff = [1]
    for _ in range(n):
        nxt = [0] * (len(coeff)+2)
        for j, value in enumerate(coeff):
            nxt[j] += value
            nxt[j+1] += 4*value
            nxt[j+2] += value
        coeff = nxt
    if sum(coeff) != 6**n:
        raise AssertionError("Exact polynomial normalization failed")
    return coeff


def cubature_call(args, n, probs, smoothing_fraction=0.0):
    s, k, r, sigma, tau, q = args
    remaining = smoothing_fraction * tau
    lattice_time = tau - remaining
    h = lattice_time / n
    step = sigma * math.sqrt(3 * h)
    # log E exp(sigma sqrt(h) xi), evaluated without cosh(a)-1 cancellation.
    correction = math.log1p((2 / 3) * math.sinh(step / 2)**2)
    logbase = math.log(s) + (r - q) * lattice_time - n * correction
    spots = [math.exp(logbase + (j - n) * step) for j in range(2 * n + 1)]
    if remaining:
        # Exact Gaussian conditional payoff over the final, fixed fraction.
        # This calls the known BSM kernel deliberately; not an independent oracle.
        payouts = [prices(x, k, r, sigma, remaining, q)[0] for x in spots]
    else:
        payouts = [max(x - k, 0.0) for x in spots]
    value = math.exp(-r * lattice_time) * math.fsum(p * v for p, v in zip(probs, payouts))
    expectation = math.fsum(p * x for p, x in zip(probs, spots))
    martingale_error = abs(math.exp(-(r - q) * lattice_time) * expectation - s)
    return value, martingale_error


def run():
    ns = (8, 16, 32, 64, 128, 256, 512)
    probs = {n: lattice_probabilities_linear(n) for n in ns}
    recurrence_checks = []
    for n in (1, 2, 3, 8, 16, 32, 64, 128, 512):
        p = lattice_probabilities_linear(n)
        dynamic = lattice_probabilities(n)
        error = max(abs(a-b) for a, b in zip(p, dynamic))
        exact_error = None
        if n <= 32:
            exact = exact_integer_coefficients(n)
            exact_error = max(abs(a-c/(6**n)) for a, c in zip(p, exact))
        if error > 5e-14 or (exact_error is not None and exact_error > 5e-14):
            raise AssertionError("Linear recurrence disagrees with independent polynomial construction")
        recurrence_checks.append({"n": n, "vs_convolution_max_error": error,
                                  "vs_exact_integer_coefficients_max_error": exact_error})
    max_mass_error = max(abs(math.fsum(p) - 1) for p in probs.values())
    min_probability = min(min(p) for p in probs.values())
    if max_mass_error > 5e-13 or min_probability < 0:
        raise AssertionError("Invalid probability distribution")
    moments = {m: ((-math.sqrt(3))**m + math.sqrt(3)**m) / 6 + (2/3 if m == 0 else 0)
               for m in range(7)}
    expected = (1., 0., 1., 0., 3., 0., 15.)
    for m in range(6):
        if abs(moments[m] - expected[m]) > 1e-12:
            raise AssertionError("Moment matching failed")

    cases = []
    for k in (80., 100., 120.):
        for sigma in (0.12, 0.35):
            for tau in (0.25, 1.0):
                for r, q in ((0.03, 0.0), (-0.01, 0.02)):
                    cases.append((100., k, r, sigma, tau, q))
    benchmark = (100., 100., .05, .2, 1., 0.)
    cases.append(benchmark)
    rows = []
    for args in cases:
        exact = prices(*args)[0]
        for n in ns:
            raw, mart = cubature_call(args, n, probs[n])
            smooth, smart = cubature_call(args, n, probs[n], smoothing_fraction=0.25)
            crr = binomial_call(*args[:5], n, q=args[5])
            rows.append({"inputs_S_K_r_sigma_tau_q": args, "n": n, "states": 2*n+1,
                         "exact_bsm": exact, "raw_trinomial": raw, "smoothed_trinomial": smooth,
                         "crr": crr, "raw_error": abs(raw-exact), "smoothed_error": abs(smooth-exact),
                         "crr_error": abs(crr-exact), "martingale_error": max(mart, smart)})
    mart_error = max(x["martingale_error"] for x in rows)
    if mart_error > 1e-9:
        raise AssertionError("Martingale consistency failed")

    summary = []
    for n in ns:
        selected = [x for x in rows if x["n"] == n]
        summary.append({"n": n, "parameter_cases": len(selected),
                        "raw_max_abs_error": max(x["raw_error"] for x in selected),
                        "smoothed_max_abs_error": max(x["smoothed_error"] for x in selected),
                        "crr_max_abs_error": max(x["crr_error"] for x in selected),
                        "raw_beats_crr_cases": sum(x["raw_error"] < x["crr_error"] for x in selected),
                        "smoothed_beats_crr_cases": sum(x["smoothed_error"] < x["crr_error"] for x in selected)})
    counter = max(rows, key=lambda x: x["raw_error"] - x["crr_error"])
    if counter["raw_error"] <= counter["crr_error"]:
        raise AssertionError("Expected at least one no-uniform-dominance counterexample")

    # Exact ex ante model: common volatility sigma0 until epsilon, then an
    # independent unspanned regime is revealed; all branches have drift r-q.
    s, r, tau, q = 100., .03, 1., 0.
    epsilon, sigma0 = .1, .2
    regimes = ((0.5, 0.1), (0.5, 0.4))
    integrated_variances = [(w, sigma0**2 * epsilon + v**2 * (tau-epsilon)) for w, v in regimes]
    mean_variance = math.fsum(w*v for w, v in integrated_variances)
    mixtures = []
    for k in (60., 80., 100., 120., 160.):
        components = [(w, math.sqrt(v/tau), prices(s, k, r, math.sqrt(v/tau), tau, q))
                      for w, v in integrated_variances]
        mix_call = math.fsum(w * cp[0] for w, _, cp in components)
        mix_put = math.fsum(w * cp[1] for w, _, cp in components)
        base_call = prices(s, k, r, math.sqrt(mean_variance/tau), tau, q)[0]
        parity = mix_call - mix_put - (s*math.exp(-q*tau)-k*math.exp(-r*tau))
        if abs(parity) > 1e-10:
            raise AssertionError("Mixture parity failed")
        mixtures.append({"strike": k, "mixture_call": mix_call, "mixture_put": mix_put,
                         "bsm_same_mean_integrated_variance": base_call,
                         "difference": mix_call-base_call, "parity_error": abs(parity)})
    differences = [x["difference"] for x in mixtures]
    if not min(differences) < 0 < max(differences):
        raise AssertionError("Mixture ordering counterexample not obtained")

    # Exact algebraic sums on a deterministic path: demonstrates identity only,
    # not Brownian sampling or an empirical convergence claim.
    increments = (.1, -.2, .05, .3, -.15)
    w, left_sum, midpoint_sum, realized_qv = 0., 0., 0., 0.
    for dw in increments:
        left_sum += w * dw
        midpoint_sum += (w + dw/2) * dw
        realized_qv += dw*dw
        w += dw
    discrete_identity_error = max(abs(left_sum - (w*w-realized_qv)/2), abs(midpoint_sum-w*w/2))
    if discrete_identity_error > 1e-14:
        raise AssertionError("Combinatorial sum identity failed")

    result = {
        "status": "PASS", "claim": "finite synthetic experiment, no market superiority or novel integral proved",
        "runtime": {"workers": 1, "dependencies": "Python standard library", "no_monte_carlo": True},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "oracle_script_sha256": hashlib.sha256((ROOT/'verify.py').read_bytes()).hexdigest(),
        "noise_moments": moments, "normal_moments_degree_0_to_6": expected,
        "linear_recurrence_checks": recurrence_checks,
        "max_probability_mass_error": max_mass_error, "min_probability": min_probability,
        "max_martingale_error": mart_error, "parameter_cases": len(cases), "rows": len(rows),
        "smoothing_fraction": .25, "summary": summary,
        "benchmark_convergence": [x for x in rows if tuple(x["inputs_S_K_r_sigma_tau_q"]) == benchmark],
        "raw_not_always_better_than_crr": counter,
        "alternative_regime_model": {"epsilon": epsilon, "sigma_before_reveal": sigma0,
                                      "risk_neutral_regimes_weight_sigma": regimes,
                                      "integrated_variances": integrated_variances,
                                      "same_mean_variance_sigma": math.sqrt(mean_variance/tau), "prices": mixtures},
        "finite_sum_identity": {"increments": increments, "endpoint": w, "sum_squared_increments": realized_qv,
                                "left_sum": left_sum, "midpoint_sum": midpoint_sum,
                                "max_identity_error": discrete_identity_error},
        "limitations": ["trinomial finite-step market is incomplete; weights are chosen, not uniquely forced",
                        "raw call payoff is nonsmooth: degree-5 moment matching alone is not a second-order guarantee",
                        "conditional smoothing uses a known BSM kernel, not an independent exact-price oracle",
                        "linear coefficient recurrence checked against O(n^2) convolution and exact small integer coefficients",
                        "state count and kernel operation cost differ from CRR: comparisons are not equal-work timing claims",
                        "regime model requires risk-neutral weights, not historical frequencies",
                        "no comparison with observed option quotes; no new Ito formula"],
        "detail": rows,
    }
    (ROOT/'research-group'/'experiment.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('status', 'parameter_cases', 'rows', 'max_probability_mass_error',
                                          'max_martingale_error', 'summary', 'raw_not_always_better_than_crr',
                                          'alternative_regime_model')}, indent=2))


if __name__ == '__main__':
    (ROOT/'research-group').mkdir(exist_ok=True)
    run()
