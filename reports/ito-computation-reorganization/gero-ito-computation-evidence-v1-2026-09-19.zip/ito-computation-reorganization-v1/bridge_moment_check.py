#!/usr/bin/env python3
"""Exact rational Gaussian-moment audit for a grid-conditional Ito estimator.

No sampled Brownian paths. Independent increments have variance h=1/n.
Polynomial moments use product Gaussian moments, equivalent to pairing/Wick
combinatorics. The independent Brownian-bridge area variance is added separately.
"""
from collections import defaultdict
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def add(a, b, scale=F(1)):
    out = defaultdict(F, a)
    for k, v in b.items():
        out[k] += scale*v
    return {k: v for k, v in out.items() if v}


def multiply(a, b):
    out = defaultdict(F)
    for x, vx in a.items():
        for y, vy in b.items():
            out[tuple(i+j for i, j in zip(x, y))] += vx*vy
    return dict(out)


def gaussian_expectation(poly, variance):
    value = F(0)
    for powers, coefficient in poly.items():
        moment = F(1)
        for power in powers:
            if power % 2:
                moment = 0
                break
            pairings = math.prod(range(1, power, 2))
            moment *= pairings * variance**(power//2)
        value += coefficient*moment
    return value


def audit(n):
    h = F(1, n)
    increments = [{tuple(int(j == i) for j in range(n)): F(1)} for i in range(n)]
    endpoint, left, trapezoid = {}, {}, {}
    for dx in increments:
        left = add(left, multiply(multiply(endpoint, endpoint), dx))
        next_endpoint = add(endpoint, dx)
        trapezoid = add(trapezoid, add(endpoint, next_endpoint), h/2)
        endpoint = next_endpoint
    cube = multiply(multiply(endpoint, endpoint), endpoint)
    conditional = add({k: v/3 for k, v in cube.items()}, trapezoid, -1)
    difference = add(conditional, left, -1)
    variance_between_estimators = gaussian_expectation(multiply(difference, difference), h)
    bridge_error = n*h**3/12
    total_left_error = variance_between_estimators + bridge_error
    target_left, target_conditional = F(1, n), F(1, 12*n*n)
    if total_left_error != target_left or bridge_error != target_conditional:
        raise AssertionError((n, total_left_error, bridge_error))
    if gaussian_expectation(conditional, h) != 0 or gaussian_expectation(left, h) != 0:
        raise AssertionError("Bias in estimator")
    return {"n": n, "h": str(h), "polynomial_difference_terms": len(difference),
            "E_squared_difference_J_minus_left": str(variance_between_estimators),
            "left_MSE_exact": str(total_left_error), "conditional_MSE_exact": str(bridge_error),
            "MSE_ratio": str(total_left_error/bridge_error)}


def run():
    checks = [audit(n) for n in (1, 2, 3, 4, 8)]
    result = {
        "status": "PASS", "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "target": "I=integral_0^T W_t^2 dW_t, standard Brownian W0=0",
        "estimator": "J=W_T^3/3 - sum_i h*(W_i+W_(i+1))/2",
        "claim": "J=E[I | all grid values], an approximation of the same Ito integral",
        "exact_proof": {
            "Ito_identity": "I=W_T^3/3 - integral_0^T W_t dt",
            "bridge_conditional_mean": "linear interpolation of each interval's endpoints",
            "single_bridge_area_variance": "h^3/12",
            "conditional_MSE": "T^3/(12*n^2)",
            "left_sum_MSE": "sum_i integral_0^h (4*t_i*u+3*u^2)du = T^3/n",
            "MSE_ratio": "12*n",
        },
        "exact_rational_checks_T1": checks,
        "illustrative_T1_n64": {"left_RMSE": 1/math.sqrt(64),
                                "conditional_RMSE": 1/(math.sqrt(12)*64), "MSE_ratio": 768},
        "scope": ["exact finite algebra confirms small n; general n follows stated proof",
                  "uses specific quadratic integrand and known Brownian conditional law",
                  "conditional expectation requires endpoint information; not a trading gain rule",
                  "not a new integral or a universally superior option model"],
    }
    (ROOT/'research-group'/'bridge-moments.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    (ROOT/'research-group').mkdir(exist_ok=True)
    run()
