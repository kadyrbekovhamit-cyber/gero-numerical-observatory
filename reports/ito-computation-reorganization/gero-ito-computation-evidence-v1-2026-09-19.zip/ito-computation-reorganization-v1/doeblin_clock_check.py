#!/usr/bin/env python3
"""Small serial audit of a known gamma-clock option model and a DDS pitfall.

No market data, fitting, Monte Carlo, numpy or parallel workers. Truncation
bounds below are analytic; Simpson tolerances/refinement are not proof bounds.
"""
import cmath
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

from verify import adaptive_simpson, prices

ROOT = Path(__file__).resolve().parent


def gamma_clock_price(s, k, r, q, t, sigma, nu, option, tol=1e-10):
    shape, scale = t / nu, nu * sigma * sigma
    if shape < 1 or not shape.is_integer():
        raise ValueError("This small auditor supports positive integer gamma shape only")
    cutoff = 60.0
    def integrand(z):
        if z == 0:
            return 0.0
        x = z * z
        gamma_density = math.exp((shape - 1) * math.log(x) - x - math.lgamma(shape))
        value = prices(s, k, r, math.sqrt(scale / t) * z, t, q)[option]
        return 2 * z * gamma_density * value
    # x=z² regularizes the near-zero square root in the conditional option.
    edges = (0.0, 0.5, 1.0, 2.0, 4.0, math.sqrt(cutoff))
    value = math.fsum(adaptive_simpson(integrand, a, b, tol / 5)
                      for a, b in zip(edges, edges[1:]))
    tail_mass = math.exp(-cutoff) * math.fsum(cutoff**j / math.factorial(j) for j in range(int(shape)))
    payoff_bound = s * math.exp(-q * t) if option == 0 else k * math.exp(-r * t)
    return value, payoff_bound * tail_mass


def exponential_clock_closed(s, k, r, q, t, sigma, nu):
    """Independent closed call from the asymmetric Laplace density, t/nu=1."""
    if abs(t / nu - 1) > 1e-14:
        raise ValueError("Closed control requires exponential clock")
    rate = 1 / (nu * sigma * sigma)
    root = math.sqrt(0.25 + 2 * rate)
    forward, discount = s * math.exp((r - q) * t), math.exp(-r * t)
    m = math.log(k / forward)
    if m >= 0:
        return discount * forward * math.exp(-(root - 0.5) * m) / (2 * root)
    put = discount * k * math.exp((root - 0.5) * m) / (2 * root)
    return put + discount * (forward - k)


def characteristic(u, t, r, q, sigma, nu):
    return cmath.exp(1j * u * (r - q) * t - t / nu * cmath.log(1 + nu * sigma**2 * (u*u + 1j*u) / 2))


def run():
    rows = []
    for t in (0.5, 1.0, 2.0):
        for k in (80.0, 100.0, 120.0):
            s, r, q, sigma, nu = 100.0, 0.03, 0.0, 0.2, 0.5
            call, tail = gamma_clock_price(s, k, r, q, t, sigma, nu, 0)
            refined, _ = gamma_clock_price(s, k, r, q, t, sigma, nu, 0, 2e-12)
            put, put_tail = gamma_clock_price(s, k, r, q, t, sigma, nu, 1)
            closed = exponential_clock_closed(s, k, r, q, t, sigma, nu) if t == nu else None
            parity_error = abs(call - put - s * math.exp(-q * t) + k * math.exp(-r * t))
            refin_error = abs(call - refined)
            if not all(math.isfinite(x) for x in (call, put, refined, parity_error, tail)):
                raise AssertionError("Nonfinite price")
            if max(parity_error, refin_error) > 5e-9 or (closed is not None and abs(closed - call) > 5e-9):
                raise AssertionError("Clock pricing consistency failed")
            lower = max(s * math.exp(-q * t) - k * math.exp(-r * t), 0)
            if not lower - 1e-9 <= call <= s * math.exp(-q * t) + 1e-9:
                raise AssertionError("Call bounds failed")
            rows.append({"S": s, "K": k, "r": r, "q": q, "T": t, "mean_clock_variance_rate": sigma*sigma,
                         "nu": nu, "gamma_shape": t / nu, "call": call, "put": put,
                         "bsm_same_mean_clock": prices(s, k, r, sigma, t, q)[0],
                         "call_tail_bound": tail, "put_tail_bound": put_tail,
                         "quadrature_refinement_difference": refin_error,
                         "parity_error": parity_error, "independent_exponential_clock_closed_call": closed})
    semigroup_error = max(abs(characteristic(u, 0.7, .03, 0, .2, .5)
                              * characteristic(u, 0.4, .03, 0, .2, .5)
                              - characteristic(u, 1.1, .03, 0, .2, .5))
                          for u in (-3., -1., 0., 1., 3.))
    if semigroup_error > 1e-14:
        raise AssertionError("Characteristic semigroup inconsistency")

    # M=integral W dW=(W1²-1)/2 has exact third moment 1, not 0 as any
    # centered conditionally Gaussian variance mixture would require.
    odd_moment = sum((Fraction(math.comb(3, j) * (-1)**(3-j) * math.prod(range(1, 2*j, 2)), 8)
                      for j in range(4)), Fraction(0))
    if odd_moment != 1:
        raise AssertionError("Gaussian pairing counterexample failed")
    result = {"status": "PASS", "workers": 1, "price_cases": len(rows),
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "oracle_script_sha256": hashlib.sha256((ROOT / 'verify.py').read_bytes()).hexdigest(),
              "model": "A independent gamma subordinator, shape=t/nu, scale=nu*sigma²; S=S0 exp((r-q)t+B_A-A/2)",
              "known_class": "variance gamma subclass; no novelty claim", "results": rows,
              "semigroup_characteristic_max_error": semigroup_error,
              "dependent_clock_negative_control": {"M": "(W1²-1)/2", "bracket": "integral_0^1 W_t²dt",
                  "exact_third_moment": str(odd_moment), "falsely_assumed_centered_normal_mixture_third_moment": 0},
              "limitations": ["finite synthetic checks, not market validation",
                  "analytic tail bounds do not bound floating-point or Simpson error",
                  "independent closed control only covers exponential clock shape=1",
                  "gamma clock has jumps; it is not the continuous Doeblin diffusion representation",
                  "single-risk-neutral-law model; not a complete-market replication proof"]}
    (ROOT / 'research-group' / 'doeblin-clock.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({"status": result['status'], "price_cases": len(rows),
                      "max_parity_error": max(x['parity_error'] for x in rows),
                      "max_refinement_difference": max(x['quadrature_refinement_difference'] for x in rows),
                      "shape1_closed_max_error": max(abs(x['call'] - x['independent_exponential_clock_closed_call'])
                                                     for x in rows if x['gamma_shape'] == 1),
                      "T1_ATM": rows[4]}, indent=2))


if __name__ == '__main__':
    run()
