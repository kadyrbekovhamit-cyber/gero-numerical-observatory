#!/usr/bin/env python3
"""Exact polynomial Brownian-bridge projection; serial, standard library only.

This estimates the SAME Ito integral from sampled endpoints. It is not a new
stochastic integral or a predictable self-financing trading rule.
"""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path

from bridge_moment_check import add, multiply

ROOT = Path(__file__).resolve().parent


def odd_double_factorial(even_power):
    return math.prod(range(1, even_power, 2))


def power(poly, exponent, dimension):
    result = {(0,) * dimension: F(1)}
    for _ in range(exponent):
        result = multiply(result, poly)
    return result


def beta_integer(a, b):
    return F(math.factorial(a - 1) * math.factorial(b - 1), math.factorial(a + b - 1))


def conditional_polynomial(coefficients, times, values):
    """Exact rational endpoint evaluator for f(x)=sum coefficients[d]*x**d.

    O(n D^3) arithmetic operations (not bit complexity), hence O(n) for a
    fixed polynomial degree. Deterministic grid only. Values are observed
    Brownian samples; rational arithmetic checks the formula, not Brownianity.
    """
    c, t, w = list(map(F, coefficients)), list(map(F, times)), list(map(F, values))
    if not c or len(t) < 2 or len(t) != len(w) or t[0] != 0:
        raise ValueError("Nonempty coefficients and matching grid from time zero required")
    if any(y <= x for x, y in zip(t, t[1:])):
        raise ValueError("Grid times must be strictly increasing")
    result = sum((a * (w[-1]**(d + 1) - w[0]**(d + 1)) / (d + 1)
                  for d, a in enumerate(c)), F(0))
    for i in range(len(t) - 1):
        h, x, dx = t[i + 1] - t[i], w[i], w[i + 1] - w[i]
        for d, a in enumerate(c[1:], 1):
            for k in range((d - 1) // 2 + 1):
                p = d - 1 - 2 * k
                scale = a * d * math.comb(d - 1, 2 * k) * odd_double_factorial(2 * k) * h**(k + 1)
                integral = sum((math.comb(p, ell) * x**(p - ell) * dx**ell
                                * beta_integer(k + ell + 1, k + 1)
                                for ell in range(p + 1)), F(0))
                result -= scale * integral / 2
    return result


def projection_monomial(degree, widths):
    """Return J=E[integral W**degree dW | grid] as polynomial in increments."""
    n = len(widths)
    increments = [{tuple(int(j == i) for j in range(n)): F(1)} for i in range(n)]
    endpoint, correction, left = {}, {}, {}
    for h, dx in zip(widths, increments):
        left = add(left, multiply(power(endpoint, degree, n), dx))
        for k in range((degree - 1) // 2 + 1):
            p = degree - 1 - 2 * k
            pair_factor = degree * math.comb(degree - 1, 2 * k) * odd_double_factorial(2 * k)
            for ell in range(p + 1):
                factor = (pair_factor * h**(k + 1) * math.comb(p, ell)
                          * beta_integer(k + ell + 1, k + 1))
                term = multiply(power(endpoint, p - ell, n), power(dx, ell, n))
                correction = add(correction, term, factor)
        endpoint = add(endpoint, dx)
    primitive = {key: value / (degree + 1) for key, value in power(endpoint, degree + 1, n).items()}
    return add(primitive, correction, F(-1, 2)), left


def expectation(poly, widths):
    total = F(0)
    for powers, coefficient in poly.items():
        moment = F(1)
        for exponent, h in zip(powers, widths):
            if exponent % 2:
                moment = F(0)
                break
            moment *= odd_double_factorial(exponent) * h**(exponent // 2)
        total += coefficient * moment
    return total


def evaluate(poly, increments):
    return sum((coefficient * math.prod(x**p for x, p in zip(increments, powers))
                for powers, coefficient in poly.items()), F(0))


def left_error_by_isometry(degree, widths):
    """Independent analytic moment integration of (W_t**d-W_left**d)**2."""
    horizon = sum(widths, F(0))
    total_variance = F(odd_double_factorial(2 * degree), degree + 1) * horizon**(degree + 1)
    left_variance, cross, t = F(0), F(0), F(0)
    for h in widths:
        left_variance += h * odd_double_factorial(2 * degree) * t**degree
        for k in range(degree // 2 + 1):
            cross += (math.comb(degree, 2 * k) * odd_double_factorial(2 * degree - 2 * k)
                      * t**(degree - k) * odd_double_factorial(2 * k) * h**(k + 1) / (k + 1))
        t += h
    return total_variance, total_variance + left_variance - 2 * cross


def audit(degree, widths):
    conditional, left = projection_monomial(degree, widths)
    variance, left_mse = left_error_by_isometry(degree, widths)
    conditional_mse = variance - expectation(multiply(conditional, conditional), widths)
    difference = add(conditional, left, F(-1))
    pythagoras = conditional_mse + expectation(multiply(difference, difference), widths)
    if expectation(conditional, widths) != 0 or pythagoras != left_mse:
        raise AssertionError("Projection/isometry disagreement")
    if not F(0) <= conditional_mse <= left_mse:
        raise AssertionError("Invalid mean-square error")
    if degree <= 1 and conditional_mse != 0:
        raise AssertionError("Affine integrand must be exact from endpoint")
    if degree == 2 and conditional_mse != sum((h**3 / 12 for h in widths), F(0)):
        raise AssertionError("Brownian bridge area variance disagreement")

    increments = [F((-1)**i * (i + 1), 5) for i in range(len(widths))]
    times, values = [F(0)], [F(0)]
    for h, dx in zip(widths, increments):
        times.append(times[-1] + h)
        values.append(values[-1] + dx)
    computed = conditional_polynomial([F(0)] * degree + [F(1)], times, values)
    if computed != evaluate(conditional, increments):
        raise AssertionError("Endpoint evaluator disagrees with symbolic polynomial")

    # Independent closed bridge formulas for degrees 0..3, rational data.
    if degree <= 3:
        x, correction = F(0), F(0)
        for h, dx in zip(widths, increments):
            y = x + dx
            if degree == 1:
                correction += h / 2
            elif degree == 2:
                correction += h * (x + y) / 2
            elif degree == 3:
                correction += h * (x*x + x*y + y*y) / 2 + h*h / 4
            x = y
        expected = x**(degree + 1) / (degree + 1) - correction
        if evaluate(conditional, increments) != expected:
            raise AssertionError("Closed polynomial bridge formula disagreement")
    return {"degree": degree, "widths": list(map(str, widths)),
            "projection_terms": len(conditional), "integral_variance": str(variance),
            "left_MSE": str(left_mse), "conditional_MSE": str(conditional_mse)}


def run():
    grids = [[F(1, n)] * n for n in (1, 2, 3)] + [[F(1, 7), F(2, 7), F(4, 7)]]
    checks = [audit(degree, widths) for widths in grids for degree in range(5)]
    result = {
        "status": "PASS", "workers": 1, "arithmetic": "exact fractions; Gaussian pairing moments",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "dependency_sha256": hashlib.sha256((ROOT / 'bridge_moment_check.py').read_bytes()).hexdigest(),
        "check_count": len(checks), "checks": checks,
        "scope": ["polynomial integrands f(W), not arbitrary adapted processes",
                  "general conditional-expectation proof is separate from these finite checks",
                  "uses future endpoint within each interval; not a trading gain prescription",
                  "endpoint evaluator has O(n D^3) arithmetic; symbolic auditor is a separate small-n check",
                  "no novelty, market accuracy or universal convergence-rate claim"]}
    (ROOT / 'research-group' / 'polynomial-projection.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({"status": result['status'], "check_count": len(checks)}, indent=2))


if __name__ == '__main__':
    run()
