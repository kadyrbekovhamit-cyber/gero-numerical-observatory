# Bounded experiment design

Written 19 September 2026 (Asia/Tashkent). Execution status is supplied by the coordinator's generated JSON, not by this design document. The experiment developer did not execute numerical code.

## Primary object and information

Approximate one realization of the Itô integral on [0,1] from deterministic Brownian grid endpoints. Integrands are t, W, W², and X=exp(W−t/2), where dX=X dW. All methods receive exactly the same endpoint values at their grid resolution. Exact X nodes are deterministic functions of these endpoints. No candidate receives hidden Brownian bridge areas. This is a pathwise L² integration experiment; the GBM example is not an assessment of numerical SDE propagation, and the separate BSM experiment estimates an expectation.

Seeds are fixed at 17, 43, 101, 271, 577; each supplies 256 paths. Nested deterministic grids have 8, 16, 32, and 64 intervals. Every finest interval draws an independent Gaussian increment of variance h and an independent true bridge integral A~N(0,h³/12). Consequently ∫W dt is sampled exactly in joint distribution with every endpoint by summing h(W_left+W_right)/2+A. There is no discretization bias in the reference integral. Pseudorandom generation and floating point arithmetic remain numerical limitations.

The four references are W₁−∫Wdt, (W₁²−1)/2, W₁³/3−∫Wdt, and exp(W₁−1/2)−1. Refining a grid reuses the identical sampled trajectory and reference.

## Methods and exact comparisons

All cases have a left-point baseline. The deterministic case also has the optimal midpoint-weight sum. For W, compare the original left sum with its quadratic-variation rearrangement, local Milstein, and the exact terminal formula. For W², compare the left sum, local Milstein, and both representations of the optimal endpoint conditional expectation:

J_local=Σ[x²d+x(d²−h)+d³/3−hd/2],

J_compressed=W₁³/3−(h/2)Σ(x+y).

These last two formulas are the **same estimator** in exact arithmetic. Their error must agree up to rounding; the experiment cannot treat their accuracy as independent evidence. The local formula is a useful reference implementation but is not claimed to be the fastest known implementation. The compressed formula is ordinary telescoping/Itô algebra, not a new method of stochastic integration.

For GBM, local Milstein uses exact X nodes and the strongest comparator is the exact terminal difference. This illustrates why a special-model exact solution must not be omitted merely to make an approximation look advantageous.

Analytic MSE checks, for T=1 and n intervals, are:

| Method | MSE |
|---|---:|
| t left | 1/(3n²) |
| t midpoint weight | 1/(12n²) |
| W left or quadratic-variation rearrangement | 1/(2n) |
| W Milstein or exact endpoint | 0 |
| W² left | 1/n |
| W² Milstein | 1/n² |
| W² optimal, either representation | 1/(12n²) |
| GBM left | Σexp(ih)[exp(h)−1−h] |
| GBM Milstein on exact X nodes | Σexp(ih)[exp(h)−1−h−h²/2] |
| GBM exact terminal | 0 |

The W² Milstein residual per interval is d³/3−hd/2−A. Its variance is h³; summing independent centered residuals gives 1/n². For GBM, conditional on X_i, the local exact increment has Wiener-chaos series X_iΣ_{k≥1}h^{k/2}H_k(Z)/k!, and Milstein retains k=1,2. Orthogonality gives the listed variance. Across disjoint intervals the centered local errors are martingale differences. These formulas provide independently checkable targets, not assumptions fitted to output.

## Metrics and uncertainty

For every seed/method/grid report MSE, RMSE, error mean (bias), sample error variance, and sample estimator variance. Aggregate MSE, bias and variances using five independent seed statistics. Intervals use mean±2.7764451052×sample_sd/√5; transform the MSE interval by square root, clipping its lower limit at zero, for RMSE. These are approximate descriptive intervals. Five observations, heavy tails and many simultaneous comparisons preclude a rigorous coverage claim.

An analytic MSE outside its approximate interval is a statistical diagnostic, not an automatic implementation failure. Deterministic gates check equal-estimator algebra, exact-terminal results, and zero-error cases at a scaled 2×10⁻¹² tolerance. The exit status concerns these deterministic gates only. Refinement differences in realized path errors represent discretization error; uncertainty of estimated MSE across finite trajectories is statistical error. Neither is a proof of convergence order.

## Cost model and fairness

One serial Python standard-library process; no numerical threads, BLAS, GPU, subprocesses, network or parameter search. Accuracy uses all 1,280 paths. Timing uses the first 64 paths of the first seed, fixed before results; five repetitions alternate forward/reverse method order, with three complete repeated queries per path. Report every timing, median/min/max and paired expanded/compressed ratios. Timings exclude tracemalloc, whose peak extra allocations are collected in a separate pass. These measurements describe this small workload and machine, without claiming a universal speedup.

The benchmark separately times dataset generation including validation oracles, endpoint extraction, and X-node preparation. Report kernel time, grid-setup-plus-query time, and generation-plus-setup-plus-query time. These latter totals are explicitly **accounted sums of separately measured components**, not contiguous end-to-end wall-clock runs. Shared full-path generation includes validation costs that a deployed estimator need not pay. Exact-terminal GBM is charged only the one exponential it actually needs. A standalone plain or antithetic BSM simulation does not need the grid at all.

The core source-level real-arithmetic count is 6n additions/subtractions, 7n multiplications and 2n divisions for the expanded expression, versus 2n+1 additions/subtractions, 3 multiplications and 2 divisions for the compressed expression. Counts exclude Python control/index operations and do not model bit complexity. Both require O(n) reads and O(1) additional working storage for arbitrary supplied endpoints. Integrand-value formations are distinguished from literal callbacks (the code inlines closed formulas). The full endpoint/X arrays are input memory, reported separately from temporary query allocations.

A generic memoization control precomputes each path's answer once for **each** representation and then repeats lookup/accumulation. Repeated identical queries can be cached for any deterministic estimator; the resulting O(1) query cost is not a special benefit of the proposed algebra.

The JSON contains every measured time/error point and an observed nondominated frontier within each integrand class. It does not interpolate to an unmeasured grid or claim that statistical/timing uncertainty establishes dominance. Equal-n expanded/compressed comparisons give equal error by algebra and test cost directly. Stronger accuracy comparisons use known Milstein, conditional projection, and exact-model comparators rather than only left sums. No tuning is selected from favorable seeds.

## BSM expectation control

European call parameters S=K=100, r=0.05, sigma=0.2, T=1. The existing `verify.prices` is the analytical control, not a newly implemented alternative formula. Simulate exact GBM terminal values from the same Brownian terminal samples. Plain MC uses 256 independent payoffs per seed. Antithetic MC uses 128 independent pairs (z,−z), again 256 payoff calls. Its statistical unit is a pair, not an individual payoff. Report seed estimates, approximate intervals, within-seed estimator-variance estimates, paired squared-error differences, and five alternating payoff-kernel timings. The Brownian generation cost is disclosed separately; antithetic intrinsically requires half as many normal draws for equal payoff calls. There is no lattice error to remove and no change to Black–Scholes assumptions.

## Reproduction and interpretation

Coordinator-only command:

```sh
python3 ./programme/benchmark.py
```

The JSON records source SHA-256 hashes for this benchmark and the imported analytical control, platform/Python details, complete fixed configuration, all numerical metrics and deterministic gate outcomes. No result is asserted until that file exists from an actual run. A small run is intended to stay within seconds and modest memory; this is not a stress benchmark, performance contest, or vendor-bug investigation.

The most defensible candidate is constant-factor compression of a known endpoint conditional estimator. A measured implementation speed difference does not establish novelty. A failure to beat the nearest known optimized method must be recorded as such. Any extension to generic integrands, adaptive sampling, option market accuracy, or nonsolvable SDEs requires separate proof and experiments.
