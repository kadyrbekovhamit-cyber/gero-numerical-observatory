# OpenCV RANSAC: preserve the camera-pose initial guess

Read REPORT_EN.md for scope and limitations. Upstream patch and tests: https://github.com/opencv/opencv/pull/30481.

This package is a source/evidence bundle; it contains no prebuilt executable. No full-library validation claim.
