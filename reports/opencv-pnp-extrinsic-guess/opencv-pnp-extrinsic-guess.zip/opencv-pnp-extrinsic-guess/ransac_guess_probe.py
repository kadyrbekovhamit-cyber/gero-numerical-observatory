"""Probe for witness A: make RANSAC find no consensus (tiny threshold + noise), so solvePnPRansac
returns false and outputs `rvec`/`tvec` = the internal copy of the user's guess (solvepnp.cpp 4.x:311-314).
This shows what the guess became after `_rvec.create(3, 1, CV_64FC1)` (line 248)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp

print("cv2", cv2.__version__)
K = np.array([[800., 0, 320], [0, 800, 240], [0, 0, 1]])
rng = np.random.default_rng(7)
X = rng.uniform(-1, 1, (12, 3))
rv_true = np.array([0.3, -0.2, 0.1]); tv_true = np.array([0.1, -0.2, 6.0])
img = project_mp(X, rv_true, tv_true, K) + rng.normal(0, 3.0, (12, 2))
g_r = np.array([0.11, 0.22, 0.33]); g_t = np.array([1.5, 2.5, 3.5])
for label, shape, dt in [("3x1 float64", (3, 1), np.float64), ("3x1 float32", (3, 1), np.float32),
                         ("1x3 float64", (1, 3), np.float64), ("1x3 float32", (1, 3), np.float32)]:
    r0 = g_r.reshape(shape).astype(dt); t0 = g_t.reshape(shape).astype(dt)
    ok, r, t, inl = cv2.solvePnPRansac(X, img, K, None, r0, t0, useExtrinsicGuess=True,
                                       iterationsCount=20, reprojectionError=1e-6, flags=cv2.SOLVEPNP_ITERATIVE)
    print(f"{label}: ok={ok}  returned rvec={np.ravel(r)}  tvec={np.ravel(t)}  (guess was {g_r}, {g_t})")
