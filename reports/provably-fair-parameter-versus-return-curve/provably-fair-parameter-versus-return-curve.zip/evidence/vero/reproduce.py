"""Algebra plus a Python binary64 translation, NOT a native Go run.
No network, bets, seed search, enumeration or installation.
"""
from fractions import Fraction as F
from pathlib import Path
import json, math, time

start=time.process_time()
E=2**52
def translated_mapper(h, edge):
    return math.floor(max(100, ((100.0*E-float(h))/(E-float(h)))*(1-edge/100)))

rows=[]
for edge in [0,5]:
    modifier=F(100-edge,100)
    for cents in [101,200,10000,1000000]:
        lo,hi=0,E
        while lo<hi:
            mid=(lo+hi)//2
            if translated_mapper(mid,edge)>=cents: hi=mid
            else: lo=mid+1
        assert lo>0 and lo<E
        assert translated_mapper(lo-1,edge)<cents<=translated_mapper(lo,edge)
        count=E-lo
        rtp=F(count*cents,100*E)
        # Independent exact algebra for real u=h/E:
        # M(100-u)/(1-u) >= cents iff u >= (cents-100M)/(cents-M).
        boundary=F(E)*(cents-100*modifier)/(cents-modifier)
        exact_first=math.ceil(boundary)
        assert abs(exact_first-lo)<=2
        continuous_rtp=F(cents,100)*99*modifier/(cents-modifier)
        rows.append(dict(edgeSettingPercent=edge,target=cents/100,
          firstWinningH=lo,winningCount=count,totalGridPoints=E,
          translatedBinary64RtpFraction=str(rtp),translatedBinary64Rtp=float(rtp),
          translatedBinary64EdgePercent=float((1-rtp)*100),
          realArithmeticFirstWinningH=exact_first,
          continuousRtpFraction=str(continuous_rtp),continuousRtp=float(continuous_rtp)))
result=dict(scope='Source formula proof and Python binary64 translation. Go was not executed. Settlement at result >= target is an explicit assumption; no deployed operator verified.',
  assumption='Uniform 52-bit h, positive targets strictly above 1x, inclusive settlement in cents; no entropy claim.',
  rows=rows,cpuSeconds=time.process_time()-start)
Path(__file__).with_name('RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
