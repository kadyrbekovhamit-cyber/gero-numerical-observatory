// Local mapper/rule audit only: no network, server, accounts or bets.
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { limbo } from './npm/package/dist/games/index.js';
import { limbo as sourceLimbo } from './source/packages/fair/src/games/limbo.ts';
import { limboWin, chipReceipt, publicRuleCatalog } from './source/apps/api/src/demo/rules.ts';

const start = process.cpuUsage();
const Q = 2 ** 32;
const gcd = (a,b) => b === 0n ? a : gcd(b,a%b);
const fraction = (a,b) => { const g=gcd(a,b); return `${a/g}/${b/g}`; };
const cases=[];
for (const cents of [101,200,10000,100000,1000000,10000000,100000000]) {
  const target=cents/100;
  assert(target>=1.01 && target<=1_000_000);
  const win=k=>limboWin(limbo(k/Q,0.01),target);
  let lo=0, hi=Q;
  while(lo<hi) { const mid=Math.floor((lo+hi)/2); if(win(mid)) lo=mid+1; else hi=mid; }
  const winningCount=lo;
  assert(win(winningCount-1)); assert(!win(winningCount));
  for(const k of [0,winningCount-1,winningCount,Q-1])
    assert.equal(limbo(k/Q,.01),sourceLimbo(k/Q,.01));
  // Independent exact-real-arithmetic inequality before binary64 rounding:
  // k <= Q * (9_900_000_000 - cents) / (100_000_000 * cents).
  const oracle=BigInt(Q)*(9900000000n-BigInt(cents))/(100000000n*BigInt(cents))+1n;
  assert(Math.abs(Number(oracle)-winningCount)<=1);
  const winReceipt=chipReceipt(100,target,true), lossReceipt=chipReceipt(100,target,false);
  assert.equal(winReceipt.returned,cents); assert.equal(lossReceipt.returned,0);
  cases.push({target,winningCount,totalGridPoints:Q,
    rtpFraction:fraction(BigInt(winningCount)*BigInt(cents),BigInt(Q)*100n),
    rtp:winningCount*target/Q,edge:1-winningCount*target/Q,
    lastWinningOutput:limbo((winningCount-1)/Q,.01),firstLosingOutput:limbo(winningCount/Q,.01),
    exactRealArithmeticWinningCount:String(oracle),winReceipt,lossReceipt});
}
assert.equal(cases.at(-1).winningCount,4210);
assert.equal(publicRuleCatalog().credits,'virtual; no monetary value');
assert.equal(publicRuleCatalog().limbo.houseEdge,0.01);
const result={at:new Date().toISOString(),node:process.version,
  scope:'Published npm mapper and unchanged source TS mapper/settlement rules; reference API target bound reviewed statically. No full API or site execution.',
  method:'Monotone mapper boundary search; adjacent outcomes checked; exact rational inequality cross-check. Uniform 32-bit integer assumption, not proof of deployed entropy.',
  cases,cpuUsageMicroseconds:process.cpuUsage(start)};
writeFileSync(new URL('./RESULTS.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
