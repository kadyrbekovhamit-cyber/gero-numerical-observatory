# MLX rsqrt directional-scale reproduction

Read REPORT_EN.md for the complete finding and limitations. This is one implementation finding, not 443 independent bugs.

## Run

Validated on macOS arm64 with a C++20 compiler, CMake >=3.25, Ninja and Python 3.12. Metal and CUDA are disabled. CMake and Ninja must already be installed. Other operating systems and toolchains have not been validated by this package; Linux may require its usual BLAS/LAPACK dependencies.

1. Create and activate a Python 3.12 environment.
2. Install the bundled reference dependency: `python -m pip install --no-index sources/mpmath-1.3.0-py3-none-any.whl`.
3. Run `python reproduce.py --work-dir /absolute/path/to/new-replay`. If needed, provide `--cmake /path/to/cmake --ninja /path/to/ninja`.

The runner verifies archived source against 2,176 Git blobs, regenerates the oracle at 100 and 150 decimal digits, builds the actual C++ implementation, runs the grid and controls, applies the candidate patch, repeats, restores the original and repeats again. Choose a fresh output directory. The build uses one compiler job. Source archives and reference dependencies are included; no GitHub or model API credential is needed. No GPU or media playback occurs.

Expected: 2,136 distinct input/seed pairs; 443 → 0 → 443 failures per layout. Three layouts are tested; JVP and VJP fail on the same pairs. There are no forward failures, all 39 derivative control checks pass, and 192 special-value compatibility outputs remain unchanged. In the validated environment the nine generated CSVs reproduce the saved observations exactly.

## Files

- REPORT_EN.md: result, mathematics, prior work and limits.
- reproduce.py: complete offline source build and replay, after installing the listed toolchain.
- check_rsqrt.py and the three C++ probes: independent oracle and real implementation checks.
- candidate.patch: the research correction; upstream source archives remain original.
- sources/: pinned MLX, fmt, json and mpmath archives.
- evidence/: Git inventories, source checks, bounded searches and clean replay logs.
- observed/: frozen numerical results for the original, corrected and restored code.
- SOURCE_LEDGER.md, LICENSES.md and SHA256SUMS: provenance, licenses and file integrity.

No full-suite, performance, GPU or real-model/device impact is claimed. This is an independent research correction; no upstream acceptance is implied. AI assisted research and preparation. No compiled binaries or videos are included.
