"""Execute each public implementation unchanged except the named candidate patch."""
from pathlib import Path
import datetime, hashlib, importlib, itertools, json, math, os, sys, warnings

R = Path(__file__).resolve().parent
variant = sys.argv[1]
root = R / ('source' if variant == 'current' else 'variants/' + variant)
os.environ['NUMBA_NUM_THREADS'] = '1'
os.environ['NUMBA_CACHE_DIR'] = str(R/'cache'/variant)
os.environ['MPLCONFIGDIR'] = str(R/'cache/mpl')
sys.path.insert(0, str(root))
from financepy.utils.date import Date
from financepy.utils.global_types import OptionTypes
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.products.equity.equity_float_lookback_option import EquityFloatLookbackOption
from financepy.products.fx.fx_float_lookback_option import FXFloatLookbackOption

start, end = Date(1, 1, 2026), Date(1, 1, 2027)
rows = []
for product, cls in [('equity', EquityFloatLookbackOption), ('fx', FXFloatLookbackOption)]:
    assert str(root) in sys.modules[cls.__module__].__file__
    params = [(side, s, ratio, vol, r, q)
              for side, ratios in [('call', [.1, .25, .4, .5, .8, .99, 1.]), ('put', [1., 1.5, 2.5])]
              for s, ratio, vol, (r, q) in itertools.product(
                  [1., 100.], ratios, [.005, .01, .02, .05, .2],
                  [(0.02, 0.07), (0.01, 0.03), (0.02, 0.005)])]
    for side, s, ratio, vol, r, q in params:
        c1, c2 = FlatDiscountCurve(start, r), FlatDiscountCurve(start, q)
        rr, qq = float(c1.zero_rate_cc(end)), float(c2.zero_rate_cc(end))
        df, dq = float(c1.df(end)), float(c2.df(end))
        opt = cls(end, OptionTypes.EUROPEAN_CALL if side == 'call' else OptionTypes.EUROPEAN_PUT)
        row = dict(id=len(rows), product=product, side=side, S=s, M=s*ratio,
                   sigma=vol, r_input=r, q_input=q, r=rr, q=qq, T=1., df=df, dq=dq)
        with warnings.catch_warnings(record=True) as warning_list:
            warnings.simplefilter('always')
            try:
                value = float(opt.value(start, s, c1, c2, vol, s*ratio))
                row.update(value=repr(value), value_hex=value.hex(), finite=math.isfinite(value))
            except Exception as exc:
                row.update(exception=type(exc).__name__+': '+str(exc), finite=False)
            row['warnings'] = [str(x.message) for x in warning_list]
        rows.append(row)
out = R/'evidence'/('grid-'+variant+'.json')
out.write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps({'variant':variant,'rows':len(rows),'nonfinite_or_exception':sum(not x['finite'] for x in rows),
                  'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}), flush=True)
