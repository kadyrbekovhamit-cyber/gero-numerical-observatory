"""A finite, bounded lookback payoff must produce a finite public quote."""
import math
import pytest
from financepy.utils.date import Date
from financepy.utils.global_types import OptionTypes
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.products.equity.equity_float_lookback_option import EquityFloatLookbackOption
from financepy.products.fx.fx_float_lookback_option import FXFloatLookbackOption

@pytest.mark.parametrize('cls',[EquityFloatLookbackOption,FXFloatLookbackOption])
@pytest.mark.parametrize('spot',[1.,100.])
def test_finite_floating_call_quote(cls,spot):
    start,expiry=Date(1,1,2026),Date(1,1,2027)
    domestic,foreign=FlatDiscountCurve(start,.02),FlatDiscountCurve(start,.07)
    actual=cls(expiry,OptionTypes.EUROPEAN_CALL).value(start,spot,domestic,foreign,.01,.4*spot)
    # Payoff is S_T-min(M,minimum future S). In this stress case the
    # independently computed omitted correction is below 1.4e-1632*spot.
    lower=spot*float(foreign.df(expiry))-.4*spot*float(domestic.df(expiry))
    assert math.isfinite(actual)
    assert abs(actual-lower)<=2e-14*spot
