"""GERO lookback packet replay; GPL-3.0-or-later. No network or publication."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('mode',choices=['native','oracle','tests']);p.add_argument('variants',nargs='*',choices=['current','candidate','restored','release']);p.add_argument('--strict',action='store_true',help='Require archived byte identity (same tested platform/runtime)');a=p.parse_args()
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','NUMBA_NUM_THREADS']:os.environ[n]='1'
W=R/'replay-work';W.mkdir(exist_ok=True);(W/'evidence').mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(W/'cache/mpl');os.environ['XDG_CACHE_HOME']=str(W/'cache')
for name in ['source','variants','upstream-checks']:shutil.copytree(R/name,W/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.nbc','*.nbi'))
for name in ['run_grid.py','verify_grid.py','test_regression.py']:shutil.copy2(R/name,W/name)
import numba
expected=lambda v:R/'evidence'/('original' if v=='release' else 'current-supported')/('grid-'+v+'.json')
if a.mode in ['native','tests']:
 if not a.variants:p.error('Select one or more variants')
 for v in a.variants:
  req='0.62.1' if v=='release' else '0.67.0'
  if numba.__version__!=req:raise SystemExit('Use documented '+('release' if v=='release' else 'current')+' environment: Numba '+req)
refs={x['id']:x for x in json.loads((R/'evidence/original/ORACLE.json').read_text())}
receipts={}
for v in a.variants:
 root=W/('source' if v=='current' else 'variants/'+v)
 env=dict(os.environ,PYTHONPATH=str(root)+os.pathsep+os.environ.get('PYTHONPATH',''),NUMBA_CACHE_DIR=str(W/'cache'/v))
 if a.mode=='native':
  subprocess.run([sys.executable,str(W/'run_grid.py'),v],env=env,cwd=W,check=True)
  b=(W/'evidence'/('grid-'+v+'.json')).read_bytes();rows=json.loads(b);old=json.loads(expected(v).read_bytes());assert len(rows)==600
  skip={'value','value_hex','finite','exception','warnings'}
  assert all({k:x[k] for k in x if k not in skip}=={k:y[k] for k in y if k not in skip} for x,y in zip(rows,old))
  bad=[x['id'] for x in rows if x['side']=='call' and (not x['finite'] or abs(float(x['value'])-float(refs[x['id']]['price']))>refs[x['id']]['tolerance'])]
  assert bad==([] if v=='candidate' else json.loads((R/'evidence/original/GRID_VERIFICATION.json').read_text())['failing_ids']['current'])
  same=b==expected(v).read_bytes()
  if a.strict:assert same,'Byte mismatch; inspect platform/runtime differences'
  receipts[v]={'rows':600,'failures':len(bad),'stored_byte_identity':same,'sha256':hashlib.sha256(b).hexdigest()}
 elif a.mode=='tests':
  q=subprocess.run([sys.executable,'-m','pytest','-q','-o','addopts=',str(W/'test_regression.py')],env=env,cwd=W,text=True,capture_output=True)
  print(q.stdout);print(q.stderr)
  good=v=='candidate';assert q.returncode==(0 if good else 1) and ('4 passed' if good else '4 failed') in q.stdout
  receipts[v]={'expected_exit':q.returncode,'summary':q.stdout.splitlines()[-1]}
if a.mode=='native' and all((W/'evidence'/('grid-'+v+'.json')).exists() for v in ['current','candidate','restored']):
 current=json.loads((W/'evidence/grid-current.json').read_text());candidate=json.loads((W/'evidence/grid-candidate.json').read_text());restored=json.loads((W/'evidence/grid-restored.json').read_text());assert current==restored;assert sum(x==y for x,y in zip(current,candidate))==548
if a.mode=='oracle':
 for v in ['current','candidate','restored','release']:shutil.copy2(R/'evidence/original'/('grid-'+v+'.json'),W/'evidence'/('grid-'+v+'.json'))
 subprocess.run([sys.executable,str(W/'verify_grid.py')],cwd=W,check=True)
 receipts=json.loads((W/'evidence/GRID_VERIFICATION.json').read_text())
 assert receipts['failures']=={'current':52,'candidate':0,'restored':52,'release':52}
out=R/('REPLAY-'+a.mode+'-'+numba.__version__+'.json');out.write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))
