from financepy.utils.date import Date
from financepy.utils.global_types import OptionTypes
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.products.equity.equity_float_lookback_option import EquityFloatLookbackOption
from financepy.products.fx.fx_float_lookback_option import FXFloatLookbackOption

start, expiry = Date(1, 1, 2026), Date(1, 1, 2027)
domestic, foreign = FlatDiscountCurve(start, 0.02), FlatDiscountCurve(start, 0.07)
for cls in [EquityFloatLookbackOption, FXFloatLookbackOption]:
    try:
        actual = cls(expiry, OptionTypes.EUROPEAN_CALL).value(
            start, 100.0, domestic, foreign, 0.01, 40.0)
        print(cls.__name__, actual)
    except Exception as exc:
        print(cls.__name__, type(exc).__name__, str(exc))
print("Independent expected value: approximately 54.031435058324617")
