The public floating-strike lookback call can lose a finite price to intermediate overflow. I reproduced this in both `EquityFloatLookbackOption.value()` and `FXFloatLookbackOption.value()` on current master `ee5749b9693f3b7c33f71e091a027402c3d3b303` and the official PyPI 1.1.2 wheel.

```python
from financepy.utils.date import Date
from financepy.utils.global_types import OptionTypes
from financepy.market.curves.flat_discount_curve import FlatDiscountCurve
from financepy.products.equity.equity_float_lookback_option import EquityFloatLookbackOption
from financepy.products.fx.fx_float_lookback_option import FXFloatLookbackOption

start, expiry = Date(1, 1, 2026), Date(1, 1, 2027)
domestic = FlatDiscountCurve(start, 0.02)
foreign = FlatDiscountCurve(start, 0.07)
for cls in [EquityFloatLookbackOption, FXFloatLookbackOption]:
    try:
        print(cls.__name__, cls(expiry, OptionTypes.EUROPEAN_CALL).value(
            start, 100.0, domestic, foreign, 0.01, 40.0))
    except Exception as exc:
        print(cls.__name__, type(exc).__name__, str(exc))
```

Expected: approximately **54.031435058324617** for each product. In my CPU environment, current equity/FX and released equity raise `OverflowError`; released FX returns `NaN` with overflow/invalid warnings. Scaling spot/minimum to `1.0 / 0.4` reproduces the problem.

The payoff `S_T - min(M, inf S_t)` is nonnegative and no greater than `S_T`, so this price must be finite. An independent 65-digit integral of the Brownian minimum's hitting probability gives the value above; seven 100-digit checks agree. For this input, the correction to `S*exp(-q*T) - M*exp(-r*T)` is below `2e-1630`.

The expression `(s0 / smin)**(-w) * normcdf(z)` forms an overflowing power before applying a tiny CDF. Here `w` is about -1000. The preceding branch checks `s0 < smin`, although input validation requires `smin <= s0`, making that branch unreachable for valid calls. The FX copy has the same condition using `s_min`.

A narrow local candidate replaces that unreachable branch with a log-space product when `log_weight = -w*log(s0/smin) > 500`:

```python
z = -a1 + 2.0*b*np.sqrt(t_exp)/v
term = np.exp(log_weight + scipy.special.log_ndtr(z)) - expbt*normcdf(-a1)
```

Other branches are unchanged. This preserves the combined term rather than simply dropping it or reversing the inequality.

Executed checks, one CPU worker:

- 600 native rows per variant: 420 call prices against the independent hitting-distribution oracle and 180 put preservation controls.
- Current / candidate / restored / released code: **52 / 0 / 52 / 52** exceptions or nonfinite prices. These are 26 parameter combinations exercised through two products, not 52 distinct defects.
- All 548 previously finite rows are byte-identical after the candidate; the entire original/restored output matches. Fixed oracle tolerance: `2e-6*max(1,S,M)`, consistent with the documented six-decimal CDF approximation.
- Four new finite-price regressions fail on original/restored/release and pass candidate. Four existing upstream lookback tests pass on original and candidate.
- Clean patch application matches the tested files; a fresh source/cache replay reproduces all four 600-row native outputs byte-for-byte.

Environment: Python 3.12.14, NumPy 2.3.5, SciPy 1.16.3, Numba 0.62.1, mpmath 1.3.0, macOS arm64. Official wheel SHA-256: `3c32578b81f338741ac135bb05ff9aa9164d75f6aa89c4d5e7f6a96c8b6f37d9`.

I noticed the existing TODO about the `w=100` threshold. This report specifically documents the unreachable floating-call guard and finite-price overflow; it does not claim that general numerical concerns were previously unknown. A bounded review of current issue/PR bodies, relevant diffs, 51 target history snapshots and the GERO catalogue found no exact prior report or proposed correction.

The inputs are synthetic. No real portfolio/customer loss, full-suite result, zero-volatility support, near-equal-rate fix or complete lookback-stability correction is claimed. The patch remains a local candidate; no upstream acceptance is implied. AI-assisted investigation and preparation; source, raw outputs, independent oracle, patch and execution logs are retained.
