# Bounded duplicate review — 20 September 2026

Result: no exact public issue, proposed correction or existing GERO report was found in this bounded review. This is not a global priority claim. The existing source TODO about tightening the w=100 threshold is prior awareness of numerical approximation concerns and must be acknowledged. This report is specifically about a valid floating-call input reaching an overflowing power through an unreachable guard, reproduced in both public equity/FX APIs.

- Current master remained ee5749b9693f3b7c33f71e091a027402c3d3b303 at the latest check; default branch is master, not main. A failed initial main lookup was a lookup error, not a source state.
- 260 public issue/PR title/body records, all states; 118 PR file lists, fully paginated (PR_PAGINATION_COMPLETE.json). Relevant target diffs inspected, including closed/unmerged changes.
- Source/history: 28 equity and23 FX target snapshots between2021-07-06 and2026-09-18. The unreachable s0<smin/s_min guard and direct power-times-CDF persist throughout; HISTORY_REVIEW.json records blob hashes and exact branch lines.
- PRs96,97,119: renaming/formatting; diffs retain the same branch and mathematical expression. PR124 wraps validation messages. PR85 renames variables and tests without repairing this calculation. PRs78,79,80,86,108,131,134 affect test organization, ordinary30%-volatility examples or formatting. PR194 only adds an unrelated FX import. Full fetched file records and bodies retained.
- Other matched stability reports264/269 concern CIR/Vasicek,261 concerns BAW and260 digital payoff currency, not floating lookback calls. Existing generic Power Options request12 is a different product. Dependabot189 and documentation181 are unrelated keyword matches.
- Focused public lookback search returned0 with incomplete_results=false. Prior stock_min_max/numeric searches likewise retained. The current canonical GitHub catalogue and GERO records contained no lookback report when checked.
- Changelog was fetched at the pin, Git-blob hash verified, and relevant numerical entries reviewed; no floating-lookback correction listed. PyPI currently1.1.2; official wheel SHA2563c32578b81f338741ac135bb05ff9aa9164d75f6aa89c4d5e7f6a96c8b6f37d9 was verified and executed.

No issue/PR/publication has been sent for this new case yet. Before disclosure, refresh mainline and focused duplicate search again. Existing issue262 has a maintainer request for a PR; address that concrete request before opening another contribution thread.
