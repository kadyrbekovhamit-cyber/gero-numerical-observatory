from pathlib import Path
import shutil, subprocess, sys, json, datetime, os
R=Path(__file__).resolve().parent
P=R/'portable-check'
assert not P.exists(), 'Do not overwrite an existing replay.'
P.mkdir()
for name in ['check_moments.py','run_checks.py','SOURCE_MANIFEST.json','candidate.patch']:
    shutil.copy2(R/name,P/name)
for v in ['current','release']:
    shutil.copytree(R/'source'/v,P/'source'/v)
shutil.copytree(P/'source/current',P/'source/candidate')
p=subprocess.run(['git','apply',str(P/'candidate.patch')],cwd=P/'source/candidate',capture_output=True,text=True)
assert p.returncode==0,p.stderr
shutil.copytree(P/'source/candidate',P/'source/restored')
p=subprocess.run(['git','apply','--reverse',str(P/'candidate.patch')],cwd=P/'source/restored',capture_output=True,text=True)
assert p.returncode==0,p.stderr
p=subprocess.run([sys.executable,'-B',str(P/'run_checks.py')],capture_output=True,text=True,timeout=180)
(R/'evidence/portable-replay.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
for v in ['current','release','candidate','restored']:
    a=json.loads((R/'evidence'/f'grid-{v}.json').read_text())
    b=json.loads((P/'evidence'/f'grid-{v}.json').read_text())
    assert a['rows']==b['rows'] and a['downstream']==b['downstream']
upstream={}
for v in ['current','candidate']:
    env=dict(os.environ)
    env['PYTHONPATH']=str(R/'source'/v/'src')+os.pathsep+env.get('PYTHONPATH','')
    env.update(MPLBACKEND='Agg',MPLCONFIGDIR='/private/tmp/gero-i02-mpl')
    p=subprocess.run([sys.executable,'-B',str(R/'review/test_changes.py')],env=env,capture_output=True,text=True,timeout=120)
    (R/'evidence'/f'upstream-example-{v}.log').write_text(p.stdout+p.stderr)
    upstream[v]={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    assert p.returncode==0,p.stderr
assert upstream['current']['stdout']==upstream['candidate']['stdout']
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),fresh_copy=True,
             git_apply_and_reverse_verified=True,source_manifest_verified=True,
             all_four_grid_rows_and_documents_reproduced=True,cases_per_variant=2880,
             failures_current_release_candidate_restored=[720,720,0,720],
             upstream_test_changes_script={'current_exit':0,'candidate_exit':0,'stdout_identical':True},
             full_upstream_suite_claimed=False,playback=False,gpu=False,configured_threads=1)
(R/'PORTABLE_REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
