"""Execute the real public API; independent finite-payout and analytic oracles."""
from pathlib import Path
import os, sys, json, math, itertools, importlib.metadata, platform
from fractions import Fraction as F
from decimal import Decimal as D, localcontext

R = Path(__file__).resolve().parent
variant = sys.argv[1]
source = R / 'source' / variant
sys.path.insert(0, str(source / 'src'))
os.environ.update(MPLBACKEND='Agg', MPLCONFIGDIR='/private/tmp/gero-i02-mpl',
                  XDG_CACHE_HOME='/private/tmp/gero-i02-cache')
import actuarialmath
from actuarialmath import Insurance, LifeTable
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)

def close(actual, expected):
    return math.isfinite(actual) and abs(actual - expected) <= 2e-11 * max(1, abs(expected))

def discrete_oracle(q, rate, term, defer, death, endowment, moment):
    v = 1 / (1 + rate)
    return sum(((death * v**(k+1))**moment * (1-q)**k*q
                for k in range(defer, defer+term)), F(0)) + (
                    endowment*v**(term+defer))**moment*(1-q)**(term+defer)

rows = []
for q, rate in itertools.product([F(0), F(1,4), F(1,2), F(3,4), F(1)],
                                 [F(0), F(1,20), F(1,4)]):
    table = {age: float(q) for age in range(40, 48)}
    table[48] = 1.0
    life = LifeTable().set_table(q=table).set_interest(i=float(rate))
    for term, defer, death, endowment, moment in itertools.product(
            [1,3], [0,2], [F(0),F(1),F(2),F(10)],
            [F(0),F(1,2),F(1),F(2),F(100)], [1,2]):
        actual = life.A_x(40, t=term, u=defer, benefit=lambda x,t:float(death),
                          endowment=float(endowment), moment=moment)
        exact = discrete_oracle(q,rate,term,defer,death,endowment,moment)
        rows.append(dict(kind='discrete',q=str(q),rate=str(rate),term=term,
                         defer=defer,death=str(death),endowment=str(endowment),
                         moment=moment,actual=actual,expected=float(exact),
                         exact_numerator=exact.numerator,exact_denominator=exact.denominator,
                         passed=close(actual,float(exact))))

def continuous_oracle(mu, delta, term, defer, death, endowment, moment, precision=80):
    with localcontext() as ctx:
        ctx.prec = precision
        mu,delta,death,endowment = map(D,[mu,delta,str(death),str(endowment)])
        a = mu + moment*delta
        lo, hi = D(defer), D(defer+term)
        return death**moment*mu*((-a*lo).exp()-(-a*hi).exp())/a + endowment**moment*(-a*hi).exp()

precision_controls = 0
for mu,delta in itertools.product(['0.02','0.2'],['0','0.03']):
    mf=float(mu)
    life=Insurance().set_survival(S=lambda x,s,t:math.exp(-mf*t),
                                 f=lambda x,s,t:mf*math.exp(-mf*t),maxage=200).set_interest(delta=float(delta))
    for term,defer,death,endowment,moment in itertools.product(
            [1,5],[0,2],[0,1,10],[0,0.5,1,2,100],[1,2]):
        actual=life.A_x(40,t=term,u=defer,benefit=lambda x,t:death,
                        endowment=endowment,moment=moment,discrete=False)
        expected=float(continuous_oracle(mu,delta,term,defer,death,endowment,moment))
        assert expected == float(continuous_oracle(mu,delta,term,defer,death,endowment,moment,120))
        precision_controls += 1
        rows.append(dict(kind='continuous',mu=mu,delta=delta,term=term,defer=defer,
                         death=death,endowment=endowment,moment=moment,actual=actual,
                         expected=expected,passed=close(actual,expected)))

life=LifeTable().set_table(q={40:0.25,41:1}).set_interest(i=0)
minimal=[life.A_x(40,t=1,benefit=lambda x,t:0,endowment=2,moment=m) for m in [1,2]]
e1,e2=[life.A_x(40,t=1,benefit=lambda x,t:0,endowment=100,moment=m) for m in [1,2]]
variance=life.insurance_variance(A2=e2,A1=e1)
percentile=life.portfolio_percentile(mean=e1,variance=variance,prob=.95,N=100)
doc=dict(label='Synthetic GERO risk worksheet; not an insurer product or regulatory calculation',
         policy_count=100,independence_assumed=True,survival_probability=.75,
         death_benefit=0,survival_benefit=100,mean=e1,second_raw_moment=e2,
         raw_variance=e2-e1**2,library_clamped_variance=variance,
         normal_approximation_portfolio_95_percentile=percentile,
         displayed_amount=format(percentile,'.2f'),synthetic_review_threshold='8000.00',
         real_customer_loss_measured=False)
out=R/'evidence';out.mkdir(exist_ok=True)
(out/f'worksheet-{variant}.json').write_text(json.dumps(doc,indent=2)+'\n')
# Separate consumer reads the generated document rather than using the producer variable.
readback=json.loads((out/f'worksheet-{variant}.json').read_text())
decision='REVIEW' if D(readback['displayed_amount'])>D(readback['synthetic_review_threshold']) else 'BELOW_THRESHOLD'
result=dict(variant=variant,imported_from=str(actuarialmath.__file__),python=sys.version,
            platform=platform.platform(),dependencies={n:importlib.metadata.version(n) for n in ['numpy','scipy','pandas','matplotlib','ipython']},
            cases=len(rows),failures=sum(not x['passed'] for x in rows),
            failures_by_kind={k:sum(not x['passed'] for x in rows if x['kind']==k) for k in ['discrete','continuous']},
            tolerance='abs(actual-expected)<=2e-11*max(1,abs(expected)); decimal inputs versus binary64 API inputs',
            continuous_oracle_80_120_precision_controls=precision_controls,
            minimal={'actual':minimal,'expected':[1.5,3.0]},downstream=doc,
            document_consumer_decision=decision,rows=rows)
(out/f'grid-{variant}.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ['variant','cases','failures','failures_by_kind','minimal','document_consumer_decision']},indent=2))
