Hello Terence,

`Insurance.A_x` multiplies its survival-endowment contribution by the amount only once, even for `moment=2`. This produces an incorrect second raw moment and can make the implied variance negative. It is separate from the convenience-method variance scaling in #6.

Reproduced on current main `7d18f11ad304898f177b7922b3c53f70e4c2b4f4` and the independently hash-verified official PyPI 1.1.0 wheel:

```python
from actuarialmath import LifeTable
life = LifeTable().set_table(q={40: 0.25, 41: 1}).set_interest(i=0)
for m in (1, 2):
    print(life.A_x(40, t=1, benefit=lambda x, t: 0,
                   endowment=2, moment=m))
# observed: 1.5, 1.5
# expected: 1.5, 3.0
```

Z is 2 with probability 3/4 and zero otherwise: E[Z²] = 4 × 3/4 = 3. The returned moments instead imply variance −0.75 rather than +0.75.

Narrow candidate, only in `A_x`:

```diff
- E = self.E_x(x, s=s, t=t+u, moment=moment) * endowment
+ E = self.E_x(x, s=s, t=t+u, moment=moment) * endowment**moment
```

Keeping the scale in this caller preserves compatibility with subclasses whose `E_x` does not accept an endowment argument.

**Executed checks:** 2,880 calls per variant; 720 disagreements on current, 720 on release, 0 with the candidate, and the same 720 after restoration. These comprise 2,400 discrete calls checked by an exact Fraction finite-payout sum and 480 continuous calls checked by an independent 80-digit Decimal closed form, repeated at 120 digits. Grids include no/unit/nonunit benefits, mortality endpoints, positive/zero interest and deferred terms. The tolerance is `2e-11 * max(1, abs(expected))`; decimal parameter literals are compared to binary64 API inputs. All 2,160 previously passing outputs remain exactly unchanged. A fresh copy applied and reversed the patch with `git apply` and reproduced every numerical row and document. The existing `tests/test_changes.py` example completes unchanged; no full-suite claim.

**Synthetic consequence:** for 100 independent one-year policies paying 100 on survival (p=.75), the real `A_x` → `insurance_variance` → `portfolio_percentile` APIs yield 7,500.00 instead of 8,212.24 for the normal-approximation 95th percentile. The incorrect negative variance is clamped to zero. An exact rational binomial reference is 8,200, so the correction preserves, rather than eliminates, the normal approximation. A GERO-generated JSON worksheet read against an example 8,000 threshold changes the review decision. The document, wiring and threshold are synthetic adapters; no insurer deployment, regulatory requirement or customer loss is established.

The bounded review read all seven issue/PR bodies and comments, PR #2's diff, guide issues, nine target-file history diffs and the GERO catalog. No exact earlier report/correction was found in that scope. The source expression is old; this completes a retained internal probe, not a new regression. First and second moments with the specified finite terms/survival laws were tested; no general correction of all insurance methods is claimed.

Python 3.12.14, NumPy 2.5.3, SciPy 1.18.1, pandas 3.0.6, matplotlib 3.10.8, IPython 9.17.1, macOS arm64. AI-assisted investigation and writing with executed public code and independent checks. A frozen evidence packet will be linked in this same issue after publication.

Thank you,
Xamit Kadirbekov / GERO
