from pathlib import Path
import sys,subprocess,json,hashlib,datetime,math
from fractions import Fraction as F
R=Path(__file__).resolve().parent
for row in json.loads((R/'SOURCE_MANIFEST.json').read_text())['files']:
    assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
result={}
for v in ['current','release','candidate','restored']:
    p=subprocess.run([sys.executable,'-B',str(R/'check_moments.py'),v],capture_output=True,text=True,timeout=120)
    (R/'evidence').mkdir(exist_ok=True)
    (R/'evidence'/f'{v}.log').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stderr
    result[v]=json.loads((R/'evidence'/f'grid-{v}.json').read_text());print(p.stdout,flush=True)
a=result['current'];b=result['candidate']
assert a['rows']==result['release']['rows']==result['restored']['rows']
assert b['failures']==0
controls=[(x,y) for x,y in zip(a['rows'],b['rows']) if x['passed']]
assert all(x['actual']==y['actual'] for x,y in controls)
# Independent exact binomial percentile, no scipy/binomial distribution helper.
cdf=F(0);q95=None
for k in range(101):
    cdf += math.comb(100,k)*F(3,4)**k*F(1,4)**(100-k)
    if cdf >= F(95,100):q95=k*100;break
rec=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         status='runtime_confirmed_novelty_review_pending',case_id='actuarialmath-direct-endowment-second-moment',
         cases_per_variant=a['cases'],failures={v:x['failures'] for v,x in result.items()},
         minimal={v:x['minimal'] for v,x in result.items()},
         previously_passing_outputs_bit_identical=len(controls),
         source_manifest_verified=True,restoration_and_release_rows_identical=True,
         downstream={v:{'mean':x['downstream']['mean'],'second_raw_moment':x['downstream']['second_raw_moment'],
                        'variance':x['downstream']['library_clamped_variance'],
                        'normal_approximation':x['downstream']['displayed_amount'],
                        'decision':x['document_consumer_decision']} for v,x in result.items()},
         exact_binomial_portfolio_percentile=q95,full_upstream_suite_run=False,
         real_insurer_impact_measured=False,published=False,vendor_sent=False,
         one_configured_worker=True,gpu=False,audio_playback=False)
(R/'GRID_RECEIPT.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
