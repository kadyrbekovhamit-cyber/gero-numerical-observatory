from pathlib import Path
import os, subprocess, sys
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS']:
    os.environ[name]='1'
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['MPLBACKEND']='Agg'
raise SystemExit(subprocess.call([sys.executable,'-B',str(Path(__file__).with_name('run_checks.py'))]))
