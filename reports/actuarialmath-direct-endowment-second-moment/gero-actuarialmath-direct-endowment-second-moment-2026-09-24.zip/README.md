# Reproduce actuarialmath direct endowment second moments

Read `REPORT_EN.md` for the measured scope and limitations. This is one public-library calculation error, distinct from the prior endowment-variance convenience-method report.

With Python 3.12:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-repro.txt
.venv/bin/python -B reproduce.py
```

The runner imports each complete preserved package in a separate process and verifies source hashes. Expected mismatches on 2,880 calls per variant: current 720, release 720, candidate 0, restored 720. Expected synthetic worksheet estimates: 7500.00, 7500.00, 8212.24, 7500.00. All cases are synthetic; no insurer deployment or customer loss is established.

For a separate fresh-directory patch/reversal replay:

```sh
.venv/bin/python -B portable_replay.py
```

This creates `portable-check` and will refuse to overwrite an existing replay. Run within the same one-thread environment as `reproduce.py`, or with an external single-worker wrapper. It also runs the upstream `tests/test_changes.py` example, not a claimed complete upstream suite. No plotting/audio playback is requested.

`source/current` contains all 22 package modules, metadata and the upstream MIT license, verified against the pinned Git tree. `source/release` contains the package modules extracted from the independently hash-verified official 1.1.0 wheel retained in `review/`. Current and release metadata versions are not conflated. `source/candidate` changes exactly one line; `source/restored` restores the original.

Raw outputs and JSON worksheets are in `evidence/`. Independent oracles are exact Fraction finite sums and an 80/120-digit Decimal analytic integral. `GRID_RECEIPT.json` and `PORTABLE_REPLAY_RECEIPT.json` record actual executions. `DUPLICATE_REVIEW.json` describes the bounded novelty review. The project issue is https://github.com/terence-lim/actuarialmath/issues/8 . Reporting does not imply developer acceptance.

Upstream source remains under its original license. GERO-authored report, tests and evidence preparation are provided under CC BY 4.0, except upstream code and quoted public-source records, which retain their original terms. AI assistance is disclosed; no paid call, local GPU or audible playback was used.
