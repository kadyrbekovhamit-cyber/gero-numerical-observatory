"""Independent oracle for PnP: exact pinhole + Brown-Conrady projection in mpmath (50 digits),
rotation from axis-angle by Rodrigues formula written here (not cv2.Rodrigues)."""
import numpy as np
import mpmath as mp

mp.mp.dps = 50


def rodrigues_mp(rvec):
    r = [mp.mpf(float(x)) for x in np.ravel(rvec)]
    th = mp.sqrt(r[0]**2 + r[1]**2 + r[2]**2)
    if th == 0:
        return mp.eye(3)
    k = [x / th for x in r]
    K = mp.matrix([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return mp.eye(3) + mp.sin(th) * K + (1 - mp.cos(th)) * (K * K)


def project_mp(X, rvec, tvec, K, dist=None):
    """Exact projection of Nx3 points. dist = (k1,k2,p1,p2[,k3[,k4,k5,k6]])."""
    R = rodrigues_mp(rvec)
    t = [mp.mpf(float(x)) for x in np.ravel(tvec)]
    fx, fy, cx, cy = [mp.mpf(float(v)) for v in (K[0][0], K[1][1], K[0][2], K[1][2])]
    d = [mp.mpf(0)] * 8
    if dist is not None:
        for i, v in enumerate(np.ravel(dist)):
            d[i] = mp.mpf(float(v))
    k1, k2, p1, p2, k3, k4, k5, k6 = d
    out = []
    for p in np.asarray(X, dtype=float).reshape(-1, 3):
        P = [mp.mpf(float(v)) for v in p]
        Xc = [sum(R[i, j] * P[j] for j in range(3)) + t[i] for i in range(3)]
        x, y = Xc[0] / Xc[2], Xc[1] / Xc[2]
        r2 = x * x + y * y
        rad = (1 + k1 * r2 + k2 * r2**2 + k3 * r2**3) / (1 + k4 * r2 + k5 * r2**2 + k6 * r2**3)
        xd = x * rad + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
        yd = y * rad + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
        out.append((float(fx * xd + cx), float(fy * yd + cy)))
    return np.array(out)


def rot_err_deg(r1, r2):
    """Angle between two rotations (deg), computed in mpmath."""
    A = rodrigues_mp(r1)
    B = rodrigues_mp(r2)
    M = A.T * B
    c = (M[0, 0] + M[1, 1] + M[2, 2] - 1) / 2
    c = max(min(c, mp.mpf(1)), mp.mpf(-1))
    return float(mp.degrees(mp.acos(c)))


def rms_mp(X, rvec, tvec, K, dist, img):
    p = project_mp(X, rvec, tvec, K, dist)
    e = (p - np.asarray(img, float).reshape(-1, 2))
    return float(np.sqrt((e**2).sum() / len(p))), float(np.sqrt((e**2).sum() / (2 * len(p))))


def random_scene(rng, n, planar=False, depth=5.0, spread=1.0):
    X = rng.uniform(-spread, spread, (n, 3))
    if planar:
        X[:, 2] = 0
    rvec = rng.uniform(-0.6, 0.6, 3)
    tvec = np.array([rng.uniform(-0.3, 0.3), rng.uniform(-0.3, 0.3), depth])
    return X, rvec, tvec
