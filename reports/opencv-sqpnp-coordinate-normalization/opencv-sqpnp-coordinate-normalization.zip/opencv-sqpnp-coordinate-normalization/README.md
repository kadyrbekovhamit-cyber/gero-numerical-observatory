# OpenCV SQPnP: conditioning across units and coordinate origins

Read REPORT_EN.md for scope and limitations. Upstream patch and tests: https://github.com/opencv/opencv/pull/30483.

This package is a source/evidence bundle; it contains no prebuilt executable. No full-library validation claim.
