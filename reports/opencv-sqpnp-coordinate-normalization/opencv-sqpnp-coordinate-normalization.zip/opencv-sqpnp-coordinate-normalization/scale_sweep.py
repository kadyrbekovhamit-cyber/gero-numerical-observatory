"""Scale covariance: multiplying object points AND t by s>0 leaves image projections unchanged
(x = (R X + t)_xy / (R X + t)_z is homogeneous of degree 0 in (X,t)). So a PnP solver must return
the same R and t*s for every s. Units are a user choice (m vs mm vs km). Oracle: mpmath projection."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp, rot_err_deg

print("cv2", cv2.__version__)
K = np.array([[800., 0, 320], [0, 800, 240], [0, 0, 1]])
rng = np.random.default_rng(21)
Xb = rng.uniform(-1, 1, (12, 3)); rv = np.array([0.4, -0.3, 0.2]); tb = np.array([0.2, -0.1, 5.0])
Xp = Xb.copy(); Xp[:, 2] = 0
img = project_mp(Xb, rv, tb, K); imgp = project_mp(Xp, rv, tb, K)
for s in [1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1, 1e2, 1e4, 1e6]:
    line = f"s={s:7.0e}:"
    for f in ["ITERATIVE", "EPNP", "SQPNP", "IPPE", "AP3P", "P3P"]:
        X, im = (Xp, imgp) if f == "IPPE" else (Xb, img)
        if f in ("AP3P", "P3P"):
            X, im = X[:4], im[:4]
        try:
            ok, rvs, tvs, re = cv2.solvePnPGeneric(X * s, im, K, None, flags=getattr(cv2, "SOLVEPNP_" + f))
            if ok == 0:
                line += f"  {f}: no solution"; continue
            i = min(range(ok), key=lambda j: rot_err_deg(rvs[j], rv))
            line += f"  {f}: {rot_err_deg(rvs[i], rv):.1e}deg/{np.linalg.norm(tvs[i].ravel()/s - tb)/np.linalg.norm(tb):.0e}"
        except cv2.error as e:
            line += f"  {f}: EXC({str(e).splitlines()[-1].strip()[:60]})"
    print(line, flush=True)
