"""Translation invariance: same local scene, object coordinates shifted by a constant offset.
A rigid shift of the object frame changes only t (t' = t - R*off); exact projections are identical.
Oracle: mpmath projection."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp, rot_err_deg, rodrigues_mp

print("cv2", cv2.__version__)
K = np.array([[1000., 0, 640], [0, 1000, 360], [0, 0, 1]])
rng = np.random.default_rng(5)
Xl = rng.uniform(-20, 20, (30, 3))
rv_true = np.array([1.2, -0.4, 0.3])
R = np.array(rodrigues_mp(rv_true).tolist(), dtype=float)
flags = ["ITERATIVE", "EPNP", "SQPNP"]
for mag in [0, 1e2, 1e3, 1e4, 1e5, 1e6, 5e6]:
    off = mag * np.array([0.3, 0.9, 0.8])
    X = Xl + off
    tv_true = np.array([0.5, -0.3, 60.0]) - R @ off
    img = project_mp(X, rv_true, tv_true, K)
    line = f"|offset|={np.linalg.norm(off):9.2e} m:"
    for f in flags:
        ok, rv, tv = cv2.solvePnP(X, img, K, None, flags=getattr(cv2, "SOLVEPNP_" + f))
        p = project_mp(X, rv, tv, K)
        rms = np.sqrt(((p - img) ** 2).sum(1).mean())
        line += f"  {f}: rot={rot_err_deg(rv, rv_true):.1e}deg rms={rms:.1e}px"
    print(line, flush=True)
