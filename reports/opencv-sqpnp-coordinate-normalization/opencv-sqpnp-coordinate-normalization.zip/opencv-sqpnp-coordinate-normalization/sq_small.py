"""Witness E: SOLVEPNP_SQPNP depends on the length unit. Same 10-point scene expressed in
millimetres (L_unit=1e-3 m -> coordinates x1) and in metres (coordinates x1e-3 ... x5e-4).
Images are identical (exact mpmath projection), so R must be identical and t must scale."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp, rot_err_deg
print("cv2", cv2.__version__)
K = np.array([[800., 0, 320], [0, 800, 240], [0, 0, 1]])
rng = np.random.default_rng(2)
B = rng.uniform(-.5, .5, (10, 3))     # 10 points in a unit cube
rv = np.array([0.3, 0.2, -0.1]); tB = np.array([0.05, -0.05, 4.0])
img = project_mp(B, rv, tB, K)
for L in [1.0, 1e-3, 5e-4, 2e-4]:
    X = B * L
    try:
        ok, rvs, tvs, re = cv2.solvePnPGeneric(X, img, K, None, flags=cv2.SOLVEPNP_SQPNP)
        print(f"L={L:6.0e}: n_sol={ok} rvec={np.round(rvs[0].ravel(), 6)} rot_err={rot_err_deg(rvs[0], rv):.2e} deg "
              f"t/L={np.round(tvs[0].ravel()/L, 6)} reprojErr={float(re[0][0]):.3e}px")
    except cv2.error as e:
        print(f"L={L:6.0e}: EXCEPTION {str(e).strip().splitlines()[-1].split('error: ')[-1]}")
    ok, r2, t2 = cv2.solvePnP(X, img, K, None, flags=cv2.SOLVEPNP_EPNP)
    print(f"          EPNP same input: rot_err={rot_err_deg(r2, rv):.2e} deg")
