import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp, rot_err_deg, rodrigues_mp

print("cv2", cv2.__version__)


def sqpnp_patched(X, img, K, D):
    X = np.asarray(X, np.float64).reshape(-1, 3)
    c = X.mean(0); Xc = X - c
    s = np.sqrt((Xc ** 2).sum() / len(X)) or 1.0
    n, rvs, tvs, re = cv2.solvePnPGeneric(Xc / s, img, K, D, flags=cv2.SOLVEPNP_SQPNP)
    out_t = []
    for r, t in zip(rvs, tvs):
        R = cv2.Rodrigues(r)[0]
        out_t.append((s * t.ravel() - R @ c).reshape(3, 1))
    return list(rvs), out_t
