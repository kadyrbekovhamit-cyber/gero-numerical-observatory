"""Python mirror of the proposed C++ regression tests (patch/test_solvepnp_additions.cpp), same
hard-coded data and the same pass criteria. Runs each test against the released cv2 ("before")
and against the emulated patch ("after", see validate_patches.py / validate_F.py)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from validate_patches_lib import sqpnp_patched
print("cv2", cv2.__version__)

K = np.array([[800., 0, 320], [0, 800, 240], [0, 0, 1]])
CUBE = np.array([[-.5, -.5, -.5], [.5, -.5, -.5], [.5, .5, -.5], [-.5, .5, -.5],
                 [-.5, -.5, .5], [.5, -.5, .5], [.5, .5, .5], [-.5, .5, .5],
                 [.1, .2, -.3], [-.2, .1, .25], [.3, -.15, .05], [-.35, -.25, -.1]])


def Rerr(r1, r2):
    return np.abs(cv2.Rodrigues(np.asarray(r1, float))[0] - cv2.Rodrigues(np.asarray(r2, float))[0]).max()


def iterative_patched(X, img, K, r0=None, t0=None):
    c = X.mean(0)
    if r0 is None:
        ok, r, t = cv2.solvePnP(X - c, img, K, None)
    else:
        r0 = np.asarray(r0, float).reshape(3, 1); tg = (np.ravel(t0) + cv2.Rodrigues(r0)[0] @ c).reshape(3, 1)
        ok, r, t = cv2.solvePnP(X - c, img, K, None, r0.copy(), tg.copy(), True)
    return ok, r, (t.ravel() - cv2.Rodrigues(r)[0] @ c).reshape(3, 1)


def test_A(patched):
    """Calib3d_SolvePnPRansac.extrinsicGuess_layout"""
    rgt = np.array([0.3, -0.2, 0.1]); tgt = np.array([0.1, -0.2, 6.0])
    img = cv2.projectPoints(CUBE, rgt, tgt, K, None)[0].reshape(-1, 2)
    ok_all = True
    for shp, dt in [((3, 1), np.float32), ((1, 3), np.float64), ((1, 3), np.float32)]:
        r0, t0 = rgt.reshape(shp).astype(dt), tgt.reshape(shp).astype(dt)
        if patched:
            r0, t0 = r0.astype(np.float64).reshape(3, 1), t0.astype(np.float64).reshape(3, 1)
        ok, r, t, _ = cv2.solvePnPRansac(CUBE, img, K, None, r0.copy(), t0.copy(), True, 100, 2.0, 0.99, flags=cv2.SOLVEPNP_ITERATIVE)
        ok_all &= bool(ok) and Rerr(r, rgt) < 1e-5 and np.abs(np.ravel(t) - tgt).max() < 1e-4
        # no-consensus path must hand back the guess unchanged
        g_r, g_t = np.array([0.11, 0.22, 0.33]), np.array([1.5, 2.5, 3.5])
        r0, t0 = g_r.reshape(shp).astype(dt), g_t.reshape(shp).astype(dt)
        if patched:
            r0, t0 = r0.astype(np.float64).reshape(3, 1), t0.astype(np.float64).reshape(3, 1)
        noisy = img.copy(); noisy[::2, 0] += 3.0; noisy[1::2, 1] -= 3.0
        ok, r, t, _ = cv2.solvePnPRansac(CUBE, noisy, K, None, r0.copy(), t0.copy(), True, 20, 1e-6, 0.99, flags=cv2.SOLVEPNP_ITERATIVE)
        ok_all &= (not ok) and np.abs(np.ravel(r) - g_r).max() < 1e-6 and np.abs(np.ravel(t) - g_t).max() < 1e-6
    return ok_all


def test_B(patched):
    """Calib3d_SolvePnPRansac.double_precision_large_coordinates (flag EPNP)"""
    off = np.array([500000.37, 4400000.71, 100.13])   # UTM-like; fractional part is lost in float32
    X = CUBE * 37.3 + off
    rgt = np.array([1.2, -0.4, 0.3]); R = cv2.Rodrigues(rgt)[0]
    tgt = np.array([0.5, -0.3, 120.0]) - R @ off
    img = cv2.projectPoints(X, rgt, tgt, K, None)[0].reshape(-1, 2)
    ok, r, t, inl = cv2.solvePnPRansac(X, img, K, None, flags=cv2.SOLVEPNP_EPNP, reprojectionError=2.0)
    if patched:
        idx = np.ravel(inl); ok, r, t = cv2.solvePnP(X[idx], img[idx], K, None, flags=cv2.SOLVEPNP_EPNP)
    print(f"    [B patched={patched}] max|R-Rgt|={Rerr(r, rgt):.2e}")
    return bool(ok) and Rerr(r, rgt) < 1e-6


def test_C(patched):
    """Calib3d_SolvePnP.sqpnp_units_and_origin"""
    rgt = np.array([0.3, 0.2, -0.1]); tgt = np.array([0.05, -0.05, 4.0])
    img = cv2.projectPoints(CUBE, rgt, tgt, K, None)[0].reshape(-1, 2)
    good = True
    for L in [1.0, 1e-3, 3e-4, 1e-4]:
        try:
            if patched:
                rs, ts = sqpnp_patched(CUBE * L, img, K, None); r, t = rs[0], ts[0]
            else:
                _, r, t = cv2.solvePnP(CUBE * L, img, K, None, flags=cv2.SOLVEPNP_SQPNP)
            good &= Rerr(r, rgt) < 1e-6 and np.abs(np.ravel(t) / L - tgt).max() < 1e-6
        except cv2.error:
            good = False
    off = np.array([3e5, 9e5, 8e5]); R = cv2.Rodrigues(rgt)[0]; X = CUBE * 20 + off
    t2 = np.array([0.5, -0.3, 80.0]) - R @ off
    img2 = cv2.projectPoints(X, rgt, t2, K, None)[0].reshape(-1, 2)
    if patched:
        rs, ts = sqpnp_patched(X, img2, K, None); r, t = rs[0], ts[0]
    else:
        _, r, t = cv2.solvePnP(X, img2, K, None, flags=cv2.SOLVEPNP_SQPNP)
    p = cv2.projectPoints(X, r, t, K, None)[0].reshape(-1, 2)
    good &= np.sqrt(((p - img2) ** 2).sum(1).mean()) < 1e-3
    return good


def test_F(patched):
    """Calib3d_SolvePnP.iterative_guess_far_origin"""
    off = np.array([3e5, 9e5, 8e5]); X = CUBE * 20 + off
    rgt = np.array([1.2, -0.4, 0.3]); R = cv2.Rodrigues(rgt)[0]
    tgt = np.array([0.5, -0.3, 80.0]) - R @ off
    img = cv2.projectPoints(X, rgt, tgt, K, None)[0].reshape(-1, 2)
    Rg = R @ cv2.Rodrigues(np.array([0.0035, 0, 0]))[0]; rg = cv2.Rodrigues(Rg)[0]
    c = X.mean(0); tg = (tgt + R @ c - Rg @ c + 0.05).reshape(3, 1)
    if patched:
        ok, r, t = iterative_patched(X, img, K, rg, tg)
    else:
        ok, r, t = cv2.solvePnP(X, img, K, None, rg.copy(), tg.copy(), True, cv2.SOLVEPNP_ITERATIVE)
    p = cv2.projectPoints(X, r, t, K, None)[0].reshape(-1, 2)
    return bool(ok) and Rerr(r, rgt) < 1e-6 and np.sqrt(((p - img) ** 2).sum(1).mean()) < 1e-3


for name, fn in [("A", test_A), ("B", test_B), ("C", test_C), ("F", test_F)]:
    print(f"test {name}: before patch -> {'PASS' if fn(False) else 'FAIL'};  after (emulated) -> {'PASS' if fn(True) else 'FAIL'}")
