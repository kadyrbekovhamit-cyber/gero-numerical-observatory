# Reproduction package

Pinned source: 9ef4c6d0a4ffe7831f6ebba6a5824fd33a90c05a.

https://github.com/ranaroussi/quantstats/pull/577
https://github.com/ranaroussi/quantstats/pull/578

The patches include regression tests. Apply each patch to a separate checkout of the pinned source. To observe failure before the fix, apply only the new test file first. The patch itself then makes the reported regressions pass. Run `python public_api_repro.py` with the selected checkout on PYTHONPATH. See VERIFICATION.json for scope and original/patched outcomes. These are synthetic examples. Report CC BY 4.0; original reproduction MIT; upstream code and patches retain Apache-2.0 terms. AI assistance disclosed.
