"""Small offline quantstats example with a rational-arithmetic reference."""
from fractions import Fraction
import json
import pandas as pd
import quantstats as qs

rates = [Fraction(-5, 100), Fraction(-5, 100), Fraction(2, 100)]
equity = Fraction(1)
peak = equity
drawdowns = []
for r in rates:
    equity *= 1 + r
    peak = max(peak, equity)
    drawdowns.append(equity / peak - 1)
reference_drawdown = min(drawdowns)
reference_recovery = sum(rates) / abs(reference_drawdown)
returns = pd.Series([float(r) for r in rates], index=pd.date_range("2024-01-01", periods=3))
details = qs.stats.drawdown_details(qs.stats.to_drawdown_series(returns))
print(json.dumps({"quantstats": qs.__version__,
                  "reference_max_drawdown_fraction": str(reference_drawdown),
                  "reference_recovery_factor_fraction": str(reference_recovery),
                  "max_drawdown": float(qs.stats.max_drawdown(returns)),
                  "recovery_factor": float(qs.stats.recovery_factor(returns)),
                  "drawdown_details": details.to_dict(orient="records")}, indent=2))
