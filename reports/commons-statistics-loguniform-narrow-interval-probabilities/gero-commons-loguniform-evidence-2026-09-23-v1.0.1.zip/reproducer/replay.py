from pathlib import Path
import subprocess,sys,os,json,hashlib
p=Path(__file__).resolve().parent
jdk=Path(os.environ.get('GERO_JAVA_HOME',''))
if not (jdk/'bin/java').is_file() or not (jdk/'bin/javac').is_file():raise SystemExit('Set GERO_JAVA_HOME to a JDK11+ directory containing bin/java and bin/javac.')
for f in p.glob('*.jar.sha1'):
 assert hashlib.sha1(Path(str(f)[:-5]).read_bytes()).hexdigest()==f.read_text().split()[0]
for script in ['run_probe.py','verify_variants.py','measure_impact.py']:
 r=subprocess.run([sys.executable,str(p/script)],cwd=p,text=True,capture_output=True,timeout=90)
 (p/(script+'.log')).write_text(r.stdout+r.stderr)
 if r.returncode:print(r.stdout,r.stderr);raise SystemExit(r.returncode)
 print(script,'PASS')
