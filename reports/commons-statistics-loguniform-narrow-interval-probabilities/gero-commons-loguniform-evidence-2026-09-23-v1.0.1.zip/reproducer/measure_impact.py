from pathlib import Path
from decimal import Decimal,localcontext
import csv,json,math,hashlib
p=Path(__file__).resolve().parent
out={};exposure=1000000;limit=400000
for variant,location in [('release',p),('candidate',p/'candidate'),('restored',p/'restored')]:
 seen=set();rows=[]
 for row in csv.DictReader((location/'RESULTS.csv').open()):
  key=tuple(row[k] for k in ['a_hex','b_hex','x_hex'])
  if key in seen:continue
  seen.add(key)
  a,b,x=map(float.fromhex,key)
  with localcontext() as ctx:
   ctx.prec=200;A,B,X=map(Decimal.from_float,[a,b,x])
   sf=Decimal(1) if x<=a else Decimal(0) if x>=b else (B/X).ln()/(B/A).ln()
   expected=sf*exposure;expected_label='REVIEW' if expected>limit else 'WITHIN_LIMIT'
  observed=float(row['sf']);cost=observed*exposure
  valid=math.isfinite(observed) and 0<=observed<=1 and math.isfinite(cost)
  rows.append({'id':row['id'],**dict(zip(['a_hex','b_hex','x_hex'],key)),'sf':row['sf'],'cost':str(cost),'reference_cost':str(expected),'reference_label':expected_label,'valid':valid})
 target=p/('worksheet-'+variant+'.csv')
 with target.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 # Separate consumer reads actual upstream-derived CSV values, including IEEE NaN.
 naive=[]
 for row in csv.DictReader(target.open()):
  decision='REVIEW' if float(row['cost'])>limit else 'WITHIN_LIMIT'
  naive.append({'id':row['id'],'actual':decision,'reference':row['reference_label'],'differs':decision!=row['reference_label']})
 nullable=[dict(row,cost=float(row['cost']) if row['valid'] else None) for row in rows]
 js=p/('worksheet-'+variant+'.json');js.write_text(json.dumps(nullable,indent=2,allow_nan=False)+'\n')
 guarded=[]
 for row in json.loads(js.read_text()):
  decision='BLOCKED_INVALID_NUMBER' if row['cost'] is None else 'REVIEW' if row['cost']>limit else 'WITHIN_LIMIT'
  guarded.append({'id':row['id'],'actual':decision,'reference':row['reference_label'],'differs':decision!=row['reference_label']})
 out[variant]={'unique_rows':len(rows),'invalid_rows':sum(not z['valid'] for z in rows),'naive_decision_mismatches':sum(z['differs'] for z in naive),'guarded_blocked':sum(z['actual']=='BLOCKED_INVALID_NUMBER' for z in guarded),'guarded_valid_decision_mismatches':sum(z['differs'] and z['actual']!='BLOCKED_INVALID_NUMBER' for z in guarded),'minimal':{'upstream_sf':rows[0]['sf'],'observed_cost':rows[0]['cost'],'reference_cost_rounded_2dp':str(Decimal(rows[0]['reference_cost']).quantize(Decimal('0.01'))),'naive':naive[0],'guarded':guarded[0]},'naive_decisions':naive,'guarded_decisions':guarded,'csv_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'json_sha256':hashlib.sha256(js.read_bytes()).hexdigest()}
assert (p/'worksheet-release.csv').read_bytes()==(p/'worksheet-restored.csv').read_bytes()
assert (p/'worksheet-release.json').read_bytes()==(p/'worksheet-restored.json').read_bytes()
summary={'exposure_units':exposure,'threshold_units':limit,'scope':'Synthetic GERO worksheet and CSV/JSON consumers; Apache computes only probabilities. No real bank/insurer/customer data, losses or deployed incidence measured. Unguarded comparison is a separate application choice.','variants':out,'restoration_documents_byte_identical':True,'gpu':False,'audio_playback':False}
(p/'IMPACT_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk not in ['naive_decisions','guarded_decisions']} for k,v in out.items()},indent=2))
