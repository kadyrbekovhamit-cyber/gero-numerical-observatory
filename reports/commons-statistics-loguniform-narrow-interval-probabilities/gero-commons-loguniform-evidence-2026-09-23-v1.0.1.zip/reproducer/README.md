# Offline replay

Requires Python 3.11+ and an installed JDK11+. Uses only standard Python libraries and the included official Maven artifacts. Set GERO_JAVA_HOME to the JDK root (directory containing bin/java and bin/javac), then run `python3 replay.py`. No downloads or remote requests are made by the replay. Java uses interpreted mode, one configured processor and Serial GC. Local GERO execution additionally uses its shared one_worker coordinator.

The release API, candidate class and restored class run sequentially. Candidate is a focused CDF/SF correction, not a full distribution fix. Application files are explicit synthetic GERO adapters; their outputs are not real customer documents. See IMPACT_RECEIPT.json and VERIFICATION_RECEIPT.json after execution.
