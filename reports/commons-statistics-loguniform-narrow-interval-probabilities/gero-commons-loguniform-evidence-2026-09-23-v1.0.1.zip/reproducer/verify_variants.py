from pathlib import Path
from decimal import Decimal,localcontext
import subprocess,os,csv,json,math,time,hashlib
p=Path(__file__).resolve().parent
jdk=Path(os.environ['GERO_JAVA_HOME']) / 'bin'
cp=os.pathsep.join(str(x) for x in sorted(p.glob('*.jar')) if not x.name.endswith('-sources.jar'))
flags=['-Xint','-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xms16m','-Xmx128m']
logs=[];start=time.monotonic()
for variant in ['candidate','restored']:
 d=p/variant;(d/'classes').mkdir(exist_ok=True)
 commands=[[str(jdk/'javac'),*['-J'+x for x in flags],'-cp',cp,'-d',str(d/'classes'),str(d/'src/LogUniformDistribution.java')],[str(jdk/'java'),*flags,'-cp',os.pathsep.join([str(p),str(d/'classes'),cp]),'Probe']]
 for idx,cmd in enumerate(commands):
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=30,cwd=p)
  logs.append({'variant':variant,'command':cmd,'returncode':r.returncode})
  (d/f'run-{idx}.stderr').write_text(r.stderr)
  if r.returncode:raise RuntimeError(r.stderr)
 (d/'RESULTS.csv').write_text(r.stdout)
assert (p/'RESULTS.csv').read_bytes()==(p/'restored/RESULTS.csv').read_bytes()
assert (p/'release-LogUniformDistribution.java').read_bytes()==(p/'restored/src/LogUniformDistribution.java').read_bytes()
results={};rows_by={}
for variant,path in [('release',p/'RESULTS.csv'),('candidate',p/'candidate/RESULTS.csv'),('restored',p/'restored/RESULTS.csv')]:
 rows=list(csv.DictReader(path.open()));rows_by[variant]=rows
 details=[];bad=invalid=0
 for row in rows:
  a,b,x=[float.fromhex(row[k]) for k in ['a_hex','b_hex','x_hex']]
  refs=[]
  for prec in [120,200]:
   with localcontext() as c:
    c.prec=prec;A,B,X=map(Decimal.from_float,[a,b,x])
    f=Decimal(0) if x<=a else Decimal(1) if x>=b else (X/A).ln()/(B/A).ln()
    refs.append((float(f),float(1-f)))
  assert refs[0]==refs[1]
  f,s=map(float,[row['cdf'],row['sf']]);expected=refs[1]
  inv=not(math.isfinite(f) and math.isfinite(s) and 0<=f<=1 and 0<=s<=1)
  fail=inv or abs(f-expected[0])>1e-12 or abs(s-expected[1])>1e-12
  bad+=fail;invalid+=inv
  details.append(dict(row,reference_cdf=expected[0],reference_sf=expected[1],invalid_probability=inv,failed_1e12_abs=fail))
 results[variant]={'calls':len(rows),'unique_inputs':len({(r['a_hex'],r['b_hex'],r['x_hex']) for r in rows}),'failures':bad,'invalid_probabilities':invalid,'rows':details}
controls=[i for i,r in enumerate(rows_by['release']) if r['id'].startswith('control_') or r['id'].startswith('lo_') or r['id'].startswith('hi_')]
control_equal=all(rows_by['release'][i]['cdf']==rows_by['candidate'][i]['cdf'] and rows_by['release'][i]['sf']==rows_by['candidate'][i]['sf'] for i in controls)
# GERO demonstration consumer: reject unavailable probability; it is not Apache application code.
impact={}
for variant in ['release','candidate','restored']:
 r=rows_by[variant][0];f=float(r['cdf'])
 doc={'upstream':'Apache Commons Statistics distribution 1.3','synthetic':True,'input':{k:r[k] for k in ['a_hex','b_hex','x_hex']},'cdf':f if math.isfinite(f) else None,'numeric_status':'finite' if math.isfinite(f) else 'NaN'}
 d=p/('demo-'+variant+'.json');d.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n')
 read=json.loads(d.read_text());status='CALCULATED' if read['cdf'] is not None else 'BLOCKED_MISSING_PROBABILITY'
 impact[variant]={'document':d.name,'consumer_status':status,'cdf':read['cdf'],'file_sha256':hashlib.sha256(d.read_bytes()).hexdigest()}
summary={'release':'1.3','source_main_pin':json.loads((p/'main-commit.json').read_text())['sha'],'current_main_execution':'not_built; exact target-class executable text unchanged, only Javadoc differs','variants':{k:{kk:vv for kk,vv in v.items() if kk!='rows'} for k,v in results.items()},'oracle_precisions':[120,200],'abs_tolerance':1e-12,'restoration_csv_byte_identical':True,'restoration_source_byte_identical':True,'endpoint_and_ordinary_controls':len(controls),'control_cdf_sf_strings_unchanged':control_equal,'candidate_scope':'CDF/SF on this grid; full release suite and inverse/moments/sampler not validated','impact':impact,'impact_scope':'Synthetic GERO JSON writer and validator, not a real financial service; no loss/exposure/frequency measured','elapsed_seconds':time.monotonic()-start,'commands':logs,'configured_processors':1,'gpu':False,'audio_playback':False}
(p/'VERIFICATION_RECEIPT.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'ORACLE_RESULTS.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='commands'},indent=2))
