import java.util.Locale;
import org.apache.commons.statistics.distribution.LogUniformDistribution;
public class Probe {
  static void row(String label,double a,double b,double x) {
    LogUniformDistribution d=LogUniformDistribution.of(a,b);
    System.out.printf(Locale.ROOT,"%s,%s,%s,%s,%s,%s,%s,%s%n",label,Double.toHexString(a),Double.toHexString(b),Double.toHexString(x),d.cumulativeProbability(x),d.survivalProbability(x),d.density(x),d.getMean());
  }
  public static void main(String[] args) {
    System.out.println("id,a_hex,b_hex,x_hex,cdf,sf,density,mean");
    row("minimal",0x1.0p100,0x1.0000000000002p100,0x1.0000000000001p100);
    int[] exponents={-1020,-500,-100,-1,0,1,100,500,900};
    int[] widths={2,4,16,1024,1048576};
    for(int e:exponents)for(int w:widths){
      double a=Math.scalb(1.0,e),u=Math.ulp(a),b=a+w*u;
      row("mid_"+e+"_"+w,a,b,a+(w/2)*u);
      row("lo_"+e+"_"+w,a,b,a);
      row("hi_"+e+"_"+w,a,b,b);
      if(w>=4)row("quarter_"+e+"_"+w,a,b,a+(w/4)*u);
    }
    row("control_unit",1,4,2);
    row("control_scaled",4,16,8);
    row("control_wide",1e-30,1e30,1);
    row("control_below",1,4,0.5);
    row("control_above",1,4,8);
  }
}
