from pathlib import Path
import subprocess,json,time,os
p=Path(__file__).resolve().parent
jdk=Path(os.environ['GERO_JAVA_HOME']) / 'bin'
jars=sorted(str(x) for x in p.glob('*.jar') if not x.name.endswith('-sources.jar'))
cp=os.pathsep.join(jars)
flags=['-Xint','-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xms16m','-Xmx128m']
start=time.monotonic()
commands=[[str(jdk/'java'),*flags,'-version'],[str(jdk/'javac'),*['-J'+x for x in flags],'-cp',cp,str(p/'Probe.java')],[str(jdk/'java'),*flags,'-cp',str(p)+os.pathsep+cp,'Probe']]
logs=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=p,text=True,capture_output=True,timeout=30)
 (p/f'run-{i}.stdout').write_text(r.stdout);(p/f'run-{i}.stderr').write_text(r.stderr)
 logs.append({'command':cmd,'returncode':r.returncode})
 if r.returncode:break
(p/'RUN_RECEIPT.json').write_text(json.dumps({'commands':logs,'elapsed_seconds':time.monotonic()-start,'network_during_test':False,'configured_processors':1,'vm_mode':'interpreted serial GC','gpu':False,'jar_count':len(jars)},indent=2)+'\n')
if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
(p/'RESULTS.csv').write_text(r.stdout)
print(r.stdout.splitlines()[1]);print('rows',len(r.stdout.splitlines())-1,'elapsed',time.monotonic()-start)
