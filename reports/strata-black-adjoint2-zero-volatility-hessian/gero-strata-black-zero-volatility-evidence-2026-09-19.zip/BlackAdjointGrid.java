import java.nio.file.Files;
import java.nio.file.Path;
import com.opengamma.strata.pricer.impl.option.BlackFormulaRepository;

public final class BlackAdjointGrid {
  public static void main(String[] args) throws Exception {
    System.out.println("id,group,F,K,T,vol,isCall,price,dF,dK,dT,dVol,hFF,hFK,hFV,hKF,hKK,hKV,hVF,hVK,hVV");
    for (String line : Files.readAllLines(Path.of(args[0])).subList(1, Files.readAllLines(Path.of(args[0])).size())) {
      String[] row = line.split(",");
      var result = BlackFormulaRepository.priceAdjoint2(
          Double.parseDouble(row[2]), Double.parseDouble(row[3]), Double.parseDouble(row[4]),
          Double.parseDouble(row[5]), Boolean.parseBoolean(row[6]));
      StringBuilder out = new StringBuilder(line).append(',').append(result.getFirst().getValue());
      for (double value : result.getFirst().getDerivatives().toArray()) out.append(',').append(value);
      for (double[] values : result.getSecond()) for (double value : values) out.append(',').append(value);
      System.out.println(out);
    }
  }
}
