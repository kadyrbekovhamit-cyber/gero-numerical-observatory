# Strata Black zero-volatility Hessian and native extrapolator failure

Read REPORT_EN.md for the measured chain, independent mathematical limit and limitations. Vendor-first disclosure: https://github.com/OpenGamma/Strata/issues/2797 . No upstream acceptance is claimed.

Run offline with Python3.9+ and a JDK (tested with JDK25.0.4.1):

```sh
python3 reproduce.py
```

If needed, set JAVA_HOME to your installed JDK directory. The official Strata2.12.74 report-tool JAR and mpmath1.3.0 are included with their notices. No network or package install is required. Java runs sequentially with ActiveProcessorCount=1, SerialGC and interpreted execution; thread environment variables are set to1. This configures this replay, not the whole computer.

The script executes the official release and separately compiles pinned affected classes, candidate and restored original. It verifies866 direct rows and21 downstream rows per state and compares eight CSV files byte-for-byte with expected/. It writes build/output files within this extracted directory. It is not a full main build or upstream JUnit run.

Direct failures:180/180/0/180;686 non-target rows unchanged. Downstream constructor failures with a synthetic constant-zero volatility fixture through Strata's public provider interface:6/6/0/6;15 non-target rows unchanged. Do not count rows as bugs.

Default Hagan/CMS is not shown to suffer this exact-zero Black failure. Tiny-positive stress failures and the separate default-alpha-zero failure remain. No bank/customer exposure, money loss or real transaction is measured. The native very-small-price fallback is approximate, not exactly zero. No audio, video or GPU code is run.

Source pin:987932ee95bf53e2baaff9a6b8e738a00f558b10. Original sources and notices are retained; candidate.patch is GERO's narrow proposal. Original local execution receipts may contain historical local paths; the replay itself uses this package and JAVA_HOME/PATH.
