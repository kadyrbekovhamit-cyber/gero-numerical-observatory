"""Portable offline replay; needs Python 3.9+ and a JDK (set JAVA_HOME if needed)."""
from pathlib import Path
import subprocess,sys,hashlib,json,datetime,os
R=Path(__file__).resolve().parent
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
commands=[]
for script in ['run_grid.py','downstream/run_downstream.py']:
 cmd=[sys.executable,str(R/script)];commands.append(cmd);subprocess.run(cmd,cwd=R,check=True)
verified={}
for state in ['release','current','candidate','restored']:
 for actual,expected in [(R/'evidence/grid'/f'{state}.csv',R/'expected/grid'/f'{state}.csv'),(R/'downstream/outputs'/f'{state}.csv',R/'expected/downstream'/f'{state}.csv')]:
  assert actual.read_bytes()==expected.read_bytes(),str(actual);verified[str(actual.relative_to(R))]=hashlib.sha256(actual.read_bytes()).hexdigest()
assert hashlib.sha256((R/'candidate.patch').read_bytes()).hexdigest()=='037104b2fa7d8b6f5099e3b272d71f769f4d0d57a8f67ef39f50575005920699'
r={'status':'portable_replay_passed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'direct_rows_per_state':866,'downstream_rows_per_state':21,'output_files_matching_expected':verified,'candidate_patch_sha256':'037104b2fa7d8b6f5099e3b272d71f769f4d0d57a8f67ef39f50575005920699','commands':commands,'full_build_or_junit':False,'production_customer_impact_measured':False}
(R/'PORTABLE_REPLAY_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print('PORTABLE REPLAY PASSED: 8 output files match, 866 direct and 21 downstream rows per state')
