"""Run sequentially under the shared one_worker wrapper. No full upstream-suite claim."""
from pathlib import Path
import csv
import datetime
import difflib
import hashlib
import json
import math
import subprocess
import sys

R = Path(__file__).resolve().parent
sys.path.insert(0, str(R / 'oracle-deps'))
import mpmath as mp
mp.mp.dps = 80
import os, shutil
E = R / 'evidence/grid'
E.mkdir(parents=True, exist_ok=True)
java = Path(os.environ['JAVA_HOME']) / 'bin/java' if os.environ.get('JAVA_HOME') else Path(shutil.which('java') or '/missing/java')
jar = R / 'artifacts/strata-report-tool.jar'
runtime = {'jar_sha256': '0fb4c6c778f25b7c6fe13c001f47a4e404868df55e4dd9841c752128bb864125'}
assert hashlib.sha256(jar.read_bytes()).hexdigest() == runtime['jar_sha256']
relative = Path('src/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.java')
original = (R / 'current' / relative).read_text()
assert hashlib.sha256(original.encode()).hexdigest() == json.loads((R / 'evidence/SOURCE_RECEIPT.json').read_text())['sha256']
marker = '    // Forward sweep\n'
assert original.count(marker) == 1
guard = '''    // At zero volatility and away from the payoff kink, the deterministic
    // payoff is locally linear in forward/strike; volatility derivatives
    // tend to zero as volatility approaches zero from above.
    if (lognormalVol == 0d && forward != strike &&
        forward > 0d && strike > 0d && timeToExpiry > 0d &&
        forward <= LARGE && strike <= LARGE && Math.abs(forward - strike) >= SMALL &&
        Double.isFinite(forward) && Double.isFinite(strike) && Double.isFinite(timeToExpiry)) {
      double sign = isCall ? 1d : -1d;
      double intrinsic = sign * (forward - strike);
      double delta = intrinsic > 0d ? sign : 0d;
      return Pair.of(
          ValueDerivatives.of(Math.max(intrinsic, 0d), DoubleArray.of(delta, -delta, 0d, 0d)),
          new double[3][3]);
    }
'''
candidate = original.replace(marker, guard + marker, 1)
for state, text in [('candidate', candidate), ('restored', original)]:
    file = R / state / relative
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(text)
(R / 'candidate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True),
    fromfile='a/modules/pricer/' + str(relative).replace('src/', 'src/main/java/', 1),
    tofile='b/modules/pricer/' + str(relative).replace('src/', 'src/main/java/', 1))))

inputs = []
def add(group, f, k, t, vol, call):
    inputs.append({'id': str(len(inputs)), 'group': group, 'F': str(f), 'K': str(k), 'T': str(t),
                   'vol': str(vol), 'isCall': str(call).lower()})
for k in [1.0, 100.0, 10000.0]:
    for ratio in [0.5, 0.9, 0.99, 1.0, 1.01, 1.1, 2.0]:
        for t in [0.001, 0.25, 1.0, 4.0, 30.0]:
            for call in [True, False]:
                if ratio != 1.0:
                    add('zero_non_atm', k * ratio, k, t, 0.0, call)
                for vol in [0.01, 0.2, 1.0]:
                    add('positive_oracle_control', k * ratio, k, t, vol, call)
# Actual input rows from upstream testPriceAdjoint2; oracle evaluated independently.
for f, k, vol, t in [(104, 94, .5, 4.5), (104, 124, .5, 4.5), (104, 104, .5, 4.5),
                      (.025, .015, .25, 10), (.025, .04, .25, 10),
                      (1700, 1500, 1, .01), (1700, 1900, 1, 20)]:
    for call in [True, False]: add('upstream_input_oracle_control', f, k, t, vol, call)
# These rows intentionally retain earlier conventions or residual stress failures.
for f in [90, 110]:
    for t in [.25, 1, 4]:
        for call in [True, False]: add('tiny_positive_stress_not_corrected', f, 100, t, 1e-200, call)
for call in [True, False]:
    for k in [1, 100, 10000]: add('atm_zero_convention_preserved', k, k, 1, 0, call)
    for f, k, t, vol in [(0,100,1,0), (100,0,1,0), (110,100,0,0), (100,100,0,0),
                          (1e-15,2e-15,1,.2), (110,100,1e-30,.2),
                          (1,math.nextafter(1,2),1,0), (math.nextafter(1,2),1,1,0),
                          (1e14,1e14+100,1,0), (1e14+100,1e14,1,0),
                          (1e14,100,1,0), (100,1e14,1,0)]:
        add('boundary_convention_preserved', f, k, t, vol, call)
with (E / 'inputs.csv').open('w') as file:
    writer = csv.DictWriter(file, fieldnames=list(inputs[0])); writer.writeheader(); writer.writerows(inputs)

names = ['price','dF','dK','dT','dVol','hFF','hFK','hFV','hKF','hKK','hKV','hVF','hVK','hVV']
def reference(row):
    f, k, t, vol = [mp.mpf(float(row[n])) for n in ['F','K','T','vol']]
    sign = 1 if row['isCall'] == 'true' else -1
    if vol == 0:
        delta = sign if sign * (f-k) > 0 else 0
        return [float(max(sign*(f-k),0)), delta, -delta, 0, 0] + [0] * 9
    sqrt_t = mp.sqrt(t)
    s = vol * sqrt_t
    d1 = mp.log(f/k)/s + s/2
    d2 = d1-s
    cdf = lambda x: mp.erfc(-x/mp.sqrt(2))/2
    phi = mp.exp(-d1*d1/2)/mp.sqrt(2*mp.pi)
    p = sign * (f*cdf(sign*d1)-k*cdf(sign*d2))
    ff = phi/(f*s)
    fk = -phi/(k*s)
    kk = f*phi/(k*k*s)
    fv = -phi*d2/vol
    kv = f*phi*d1/(k*vol)
    vv = f*phi*sqrt_t*d1*d2/vol
    return list(map(float,[p, sign*cdf(sign*d1), -sign*cdf(sign*d2), f*phi*vol/(2*sqrt_t),
                          f*phi*sqrt_t, ff,fk,fv,fk,kk,kv,fv,kv,vv]))
oracle = {r['id']: reference(r) for r in inputs if r['group'] in
          ['zero_non_atm','positive_oracle_control','upstream_input_oracle_control']}
(E / 'oracle.json').write_text(json.dumps({'mpmath':mp.__version__,'precision_digits':80,
    'ordering':names,'binary64_inputs_exactly_imported':True,'values':oracle},indent=2)+'\n')
results = {}
outputs = {}
commands = []
for state in ['release', 'current', 'candidate', 'restored']:
    classes = R / state / 'grid-classes'; classes.mkdir(parents=True, exist_ok=True)
    command = [str(java.with_name('javac')), '-J-XX:ActiveProcessorCount=1','-J-XX:+UseSerialGC','-J-Xint',
               '-cp', str(jar), '-d', str(classes), str(R/'BlackAdjointGrid.java')]
    if state != 'release': command.append(str(R/state/relative))
    commands.append(command)
    with (E/(state+'-compile.log')).open('w') as file:
        subprocess.run(command,stdout=file,stderr=subprocess.STDOUT,check=True)
    command = [str(java),'-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xint',
               '-Djava.util.concurrent.ForkJoinPool.common.parallelism=1', '-cp', str(classes)+':'+str(jar),
               'BlackAdjointGrid',str(E/'inputs.csv')]
    commands.append(command)
    with (E/(state+'.csv')).open('w') as out, (E/(state+'-stderr.log')).open('w') as err:
        subprocess.run(command,stdout=out,stderr=err,check=True)
    rows = list(csv.DictReader((E/(state+'.csv')).open())); outputs[state]=rows
    groups = {}; failures = []
    for row in rows:
        group = groups.setdefault(row['group'], {'observations':0,'oracle_checked':0,'oracle_failures':0,'nonfinite_hessian_rows':0})
        group['observations'] += 1
        group['nonfinite_hessian_rows'] += any(not math.isfinite(float(row[n])) for n in names if n.startswith('h'))
        if row['id'] in oracle:
            group['oracle_checked'] += 1
            expected = oracle[row['id']]
            bad = []
            for n, value in zip(names, expected):
                actual = float(row[n])
                passed = (actual == value) if row['group'] == 'zero_non_atm' else math.isclose(actual,value,rel_tol=2e-8,abs_tol=1e-10)
                if not passed: bad.append({'component':n,'actual':row[n],'expected':value})
            if bad:
                group['oracle_failures'] += 1; failures.append({'id':row['id'],'group':row['group'],'differences':bad})
    results[state]={'groups':groups,'failures':failures}
    print(state, {k:v['oracle_failures'] for k,v in groups.items()},flush=True)
assert len(inputs) == 866
for state, result in results.items():
    assert result['groups']['positive_oracle_control']['oracle_failures'] == 0
    assert result['groups']['upstream_input_oracle_control']['oracle_failures'] == 0
    assert result['groups']['zero_non_atm']['oracle_failures'] == (0 if state == 'candidate' else 180)
assert outputs['release'] == outputs['current'] == outputs['restored']
unchanged_other = sum(a==b for a,b in zip(outputs['current'],outputs['candidate']) if a['group']!='zero_non_atm')
other_count = sum(r['group']!='zero_non_atm' for r in inputs)
assert unchanged_other == other_count
assert results['candidate']['groups']['zero_non_atm']['oracle_failures'] == 0
receipt={'status':'narrow_zero_volatility_candidate_replayed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'input_rows':len(inputs),'groups':{g:sum(r['group']==g for r in inputs) for g in sorted({r['group'] for r in inputs})},
         'results':results,'release_current_restored_outputs_identical':True,'unchanged_non_target_rows':unchanged_other,
         'oracle_precision_digits':80,'positive_oracle_tolerance':{'relative':2e-8,'absolute':1e-10},
         'zero_volatility_comparison':'Exact equality including all finite components; signed zeros treated equal.',
         'patch_sha256':hashlib.sha256((R/'candidate.patch').read_bytes()).hexdigest(),'commands':commands,
         'full_project_build':False,'full_junit_suite':False,'upstream_input_rows_reused':14,
         'known_residual':'Tiny positive volatility1e-200 NaN Hessians intentionally unchanged; ATM zero-vol conventions unchanged.',
         'production_impact_measured':False,'audio_playback':False}
(E/'GRID_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Rows',len(inputs),'non-target unchanged',unchanged_other)
