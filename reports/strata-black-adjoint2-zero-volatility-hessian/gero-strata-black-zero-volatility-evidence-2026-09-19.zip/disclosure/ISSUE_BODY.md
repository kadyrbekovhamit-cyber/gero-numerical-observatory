## Summary

`BlackFormulaRepository.priceAdjoint2(110, 100, 1, 0, true)` returns price 10 and the correct first derivatives, but all nine entries of its second-derivative matrix are NaN. For positive finite forward/strike/maturity and ordinary non-ATM inputs, the zero-volatility limit has a zero Hessian. ATM is excluded.

I reproduced this on the official Strata 2.12.74 report-tool JAR and separately compiled current classes at `987932ee95bf53e2baaff9a6b8e738a00f558b10` against its dependencies. This is not a full build of main or a full JUnit run. Environment: macOS arm64, OpenJDK 25.0.4.1, one configured JVM processor, interpreted execution.

## Executed downstream consequence

The documented custom-provider overload of `SabrExtrapolationRightFunction` propagates this Hessian into `priceK[2]`. With a constant zero-volatility provider, the small-price fallback is missed, and construction throws:

```
com.opengamma.strata.math.MathException: Failed to bracket root: function invalid at x = -1.0 f(x) = NaN
```

Changing only the Black zero-volatility branch lets the same native extrapolator construct and return a call price of 0.015 at strike 0.015 and a put price of 0.06 at strike 0.09 (forward 0.03, cutoff 0.06, expiry 1, mu 4). Restoring the original Black source restores the exception.

The constant provider is a synthetic test fixture, not Hagan SABR. This does **not** demonstrate failure of the default Hagan/CMS path: its second-adjoint volatility is floored at 1e-6 or becomes NaN earlier. The default-alpha-zero failure remains unchanged with this candidate. No deployed bank or customer-loss claim is made.

## Minimal executable example

Compile with the official `strata-report-tool.jar` on the classpath:

```java
import java.util.Arrays;
import com.opengamma.strata.pricer.impl.option.BlackFormulaRepository;
import com.opengamma.strata.pricer.impl.option.SabrExtrapolationRightFunction;
import com.opengamma.strata.pricer.impl.volatility.smile.SabrFormulaData;
import com.opengamma.strata.pricer.impl.volatility.smile.VolatilityFunctionProvider;
import com.opengamma.strata.product.common.PutCall;

public class MinimalReproducer {
  public static void main(String[] args) {
    var direct = BlackFormulaRepository.priceAdjoint2(110d, 100d, 1d, 0d, true);
    System.out.println("price=" + direct.getFirst().getValue());
    System.out.println("Hessian=" + Arrays.deepToString(direct.getSecond()));
    var constantZero = new VolatilityFunctionProvider<SabrFormulaData>() {
      @Override public double volatility(double f, double k, double t, SabrFormulaData data) {
        return 0d;
      }
      @Override public double volatilityAdjoint2(double f, double k, double t, SabrFormulaData data,
          double[] first, double[][] second) {
        Arrays.fill(first, 0d);
        for (double[] row : second) Arrays.fill(row, 0d);
        return 0d;
      }
    };
    try {
      var extrapolator = SabrExtrapolationRightFunction.of(
          .03, SabrFormulaData.of(.05, .5, -.25, .5), .06, 1d, 4d, constantZero);
      System.out.println("call_below_cutoff=" + extrapolator.price(.015, PutCall.CALL));
      System.out.println("put_above_cutoff=" + extrapolator.price(.09, PutCall.PUT));
    } catch (RuntimeException ex) {
      System.out.println(ex.getClass().getName() + ": " + ex.getMessage());
    }
  }
}

```

Original: price 10, NaN Hessian, constructor exception. Candidate: price 10, zero Hessian, then `call_below_cutoff=0.015` and `put_above_cutoff=0.06`. I executed this exact snippet in both states.

## Boundary reasoning and narrow candidate

Away from F=K, the zero-volatility payoff is locally linear in forward and strike. As volatility approaches zero from above, normal density decays faster than inverse powers of volatility, so mixed and volatility second derivatives also tend to zero. The present backward sweep evaluates zero/infinite intermediates without this boundary branch.

The candidate is limited to finite positive forward, strike and expiry, exact zero volatility, levels <= LARGE and abs(forward-strike) >= SMALL. It leaves ATM, near-ATM/large-level reference conventions, positive volatility and other boundary cases untouched:

```diff
--- a/modules/pricer/src/main/java/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.java
+++ b/modules/pricer/src/main/java/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.java
@@ -220,6 +220,20 @@
       double timeToExpiry,
       double lognormalVol,
       boolean isCall) {
+    // At zero volatility and away from the payoff kink, the deterministic
+    // payoff is locally linear in forward/strike; volatility derivatives
+    // tend to zero as volatility approaches zero from above.
+    if (lognormalVol == 0d && forward != strike &&
+        forward > 0d && strike > 0d && timeToExpiry > 0d &&
+        forward <= LARGE && strike <= LARGE && Math.abs(forward - strike) >= SMALL &&
+        Double.isFinite(forward) && Double.isFinite(strike) && Double.isFinite(timeToExpiry)) {
+      double sign = isCall ? 1d : -1d;
+      double intrinsic = sign * (forward - strike);
+      double delta = intrinsic > 0d ? sign : 0d;
+      return Pair.of(
+          ValueDerivatives.of(Math.max(intrinsic, 0d), DoubleArray.of(delta, -delta, 0d, 0d)),
+          new double[3][3]);
+    }
     // Forward sweep
     double discountFactor = 1.0;
     double sqrttheta = Math.sqrt(timeToExpiry);

```

## Validation and retained limitations

- 866 direct input rows: 180 ordinary non-ATM zero-volatility failures on release/current/restored, zero under the candidate. All 686 non-target rows are identical.
- Among controls, 644 positive-volatility rows agree with an independent 80-digit analytical oracle within relative 2e-8 / absolute 1e-10 tolerances. Fourteen of these reuse existing upstream test inputs; this is not a claim that the upstream JUnit suite was run.
- 21 downstream rows: all six constant-zero-provider constructions fail on release/current/restored and succeed under the candidate. All 15 other rows are unchanged, including tiny-positive-volatility failures and the separate default-alpha-zero failure.
- The native small-price fallback returns [-100,0,0]; its extrapolated call tail is tiny positive, not exactly zero (5.6699831977150385e-40 in the example). Other fitting regions and SABR-parameter sensitivity are not claimed fixed or tested downstream.

The historical introduction in #843 and the Hagan floor/finite-difference work in #939 are acknowledged. I inspected bounded all-state issue/PR searches and relevant actual diffs, without finding an exact prior report/fix for this zero-volatility Black Hessian. This is separate from the Normal-IV initial-guess issue #2796.

Independent GERO research by Xamit Kadirbekov; AI-assisted source review, test/code preparation and documentation. The patch is a local candidate, with no upstream acceptance claimed. A versioned evidence archive is being prepared; I will add its link here rather than open another issue.
