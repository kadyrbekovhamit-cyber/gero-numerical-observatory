from pathlib import Path
import csv,datetime,hashlib,json,subprocess,math
import os,shutil
D=Path(__file__).resolve().parent;N=D.parent
java=Path(os.environ['JAVA_HOME'])/'bin/java' if os.environ.get('JAVA_HOME') else Path(shutil.which('java') or '/missing/java')
jar=N/'artifacts/strata-report-tool.jar';runtime={'jar_sha256':'0fb4c6c778f25b7c6fe13c001f47a4e404868df55e4dd9841c752128bb864125'}
assert hashlib.sha256(jar.read_bytes()).hexdigest()==runtime['jar_sha256']
(D/'outputs').mkdir(exist_ok=True);commands=[];outputs={}
source=D/'source/modules/pricer/src/main/java/com/opengamma/strata/pricer/impl';commands=[];outputs={}
for state in ['release','current','candidate','restored']:
 classes=D/'classes'/state;classes.mkdir(parents=True,exist_ok=True)
 cmd=[str(java.with_name('javac')),'-J-XX:ActiveProcessorCount=1','-J-XX:+UseSerialGC','-J-Xint','-cp',str(jar),'-d',str(classes),str(D/'ExtrapolationProbe.java')]
 if state!='release':
  cmd += [str(N/state/'src/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.java')]
  cmd += [str(source/p) for p in ['option/SabrExtrapolationRightFunction.java','volatility/smile/SabrFormulaData.java','volatility/smile/VolatilityFunctionProvider.java','volatility/smile/SabrHaganVolatilityFunctionProvider.java']]
 commands.append(cmd)
 with (D/'outputs'/f'{state}-compile.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
 cmd=[str(java),'-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xint','-Djava.util.concurrent.ForkJoinPool.common.parallelism=1','-cp',str(classes)+':'+str(jar),'ExtrapolationProbe'];commands.append(cmd)
 with (D/'outputs'/f'{state}.csv').open('w') as f,(D/'outputs'/f'{state}-stderr.log').open('w') as e:subprocess.run(cmd,stdout=f,stderr=e,check=True,timeout=60)
 outputs[state]=list(csv.DictReader((D/'outputs'/f'{state}.csv').open()));assert len(outputs[state])==21
# Negative attribution controls are preserved: default provider and tiny-positive residuals.
assert (D/'outputs/release.csv').read_bytes()==(D/'outputs/current.csv').read_bytes()==(D/'outputs/restored.csv').read_bytes()
unchanged=[r for r in outputs['current'] if not (r['provider']=='constant' and float(r['sigma'])==0)]
assert unchanged==[r for r in outputs['candidate'] if not (r['provider']=='constant' and float(r['sigma'])==0)]
summary={}
for state,rows in outputs.items():
 target=[r for r in rows if r['provider']=='constant' and float(r['sigma'])==0]
 summary[state]={'observations':len(rows),'zero_provider_constructor_failures':sum(r['status']=='ERROR' for r in target),'target_rows':target,'default_provider_rows':[r for r in rows if r['provider']=='default']}
 if state=='candidate':
  for r in target:
   assert r['status']=='OK';f=float(r['F']);k=3*f
   assert float(r['call_below'])==f*.5 and float(r['put_below'])==0 and float(r['call_cutoff'])==0
   assert 0<=float(r['call_above'])<1e-35
   assert abs(float(r['put_above'])-(k-f))<1e-15
   assert [float(r[x]) for x in ['a','b','c']]==[-100,0,0]
 else:assert summary[state]['zero_provider_constructor_failures']==6
receipt={'status':'executed_real_extrapolator_with_synthetic_constant_vol_provider','executed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':json.loads((D/'SOURCE_RECEIPT.json').read_text())['head'],'jar_sha256':runtime['jar_sha256'],'summary':summary,'unchanged_non_target_rows':len(unchanged),'commands':commands,'limits':'Public custom-provider overload with GERO constant-vol fixture, not the stock SABR/CMS path. Default provider and tiny positive vol residuals unchanged; no bank/deployment/customer exposure measured. Native extrapolation tiny-tail fallback is approximate, not exact zero. Full JUnit suite not run.','audio_playback':False}
(D/'DOWNSTREAM_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
for state,r in summary.items():print(state,'zero-provider failures',r['zero_provider_constructor_failures'],'of6; defaults',[(x['alpha'],x['status']) for x in r['default_provider_rows']])
print('Non-target rows unchanged:',len(unchanged))
