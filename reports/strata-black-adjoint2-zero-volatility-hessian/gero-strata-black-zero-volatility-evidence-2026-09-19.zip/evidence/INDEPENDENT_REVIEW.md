# Independent review: Strata Black zero-volatility second adjoint

Updated: 2026-09-18 18:30:24 UTC; local timezone Asia/Tashkent.
This agent performed only source, mathematical, documentation and history review. Root owns all numerical executions. No vendor message or publication was sent.

## Conclusion

**No mathematical blocker remains for the narrowed patch inspected here.** For finite positive forward, strike and maturity, away from ATM, a zero-volatility deterministic payoff has gradient `[delta, -delta, 0, 0]` and a zero Hessian in `[forward, strike, volatility]`. Volatility derivatives are understood from the right, within the nonnegative volatility domain.

The revised guard now explicitly limits forward and strike to `LARGE = 1e13` and requires `abs(forward - strike) >= SMALL = 1e-13`. This avoids changing the class's separate near-ATM and large-level reference conventions. Positive volatility is untouched, including the known tiny-positive residual failure.

## Why the boundary derivatives are zero

Let `m = log(F/K)`, `q = sigma sqrt(T)`, `d1 = m/q + q/2` and `d2 = d1 - q`. For fixed `F != K`, `m != 0`, and

`phi(d1) = exp(-m^2/(2q^2) - m/2 - q^2/8) / sqrt(2pi)`.

This density vanishes faster than every inverse power of sigma as sigma approaches zero from above. The six distinct second derivatives are:

- `FF = phi(d1)/(F q)`.
- `FK = -phi(d1)/(K q)`.
- `KK = F phi(d1)/(K^2 q)`.
- `F,sigma = -phi(d1) d2/sigma`.
- `K,sigma = F phi(d1) d1/(K sigma)`.
- `sigma,sigma = F phi(d1) sqrt(T) d1 d2/sigma`.

Each tends to zero. A neighbourhood of the fixed point can avoid the payoff kink, giving a smooth right-boundary extension. This is stronger than assigning zero derivatives by convention.

ATM must remain excluded. At `F=K, sigma=0`, the payoff is not differentiable in forward/strike, and the right vega is `F sqrt(T)/sqrt(2pi)`, not zero. Likewise, do not describe the price as constant at positive volatility; its derivatives vanish at the boundary.

## Documentation and reference conventions

The [official API](https://strata.opengamma.io/apidocs/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.html) documents price and first/second derivatives, with no strictly-positive volatility precondition for this method. The class also reserves reference values for ambiguous expressions. That reservation must be disclosed; the ordinary non-ATM inputs avoid its disputed regions.

Fresh main is still `987932ee95bf53e2baaff9a6b8e738a00f558b10`; [source blob](https://github.com/OpenGamma/Strata/blob/987932ee95bf53e2baaff9a6b8e738a00f558b10/modules/pricer/src/main/java/com/opengamma/strata/pricer/impl/option/BlackFormulaRepository.java) remains `81b38121ae44d6968530e9b31384f8e4630248e9`.

Standalone gamma/dualGamma use reference branches for tiny forward–strike differences and large levels. The first candidate covered those regimes; I flagged it, and the updated patch now bypasses them. The existing near-zero strike/sqrt(T) shortcut at zero volatility already uses the same intrinsic-value limit. Signed zeros are numerically equal; do not count changed zero signs as distinct mathematical errors.

## Independent inspection of the test oracle

I read `run_grid.py`, `BlackAdjointGrid.java` and the revised `candidate.patch`; I did not run them.

The analytical formulas in the mpmath oracle are correct, including the use of `F phi(d1) = K phi(d2)` for dual gamma and dual vanna. The maturity derivative is with respect to time-to-expiry holding forward fixed, so its positive sign is appropriate. The oracle does not call Strata or copy its backward-sweep operation chain.

`mp.mpf(float(...))` intentionally compares the same binary64 inputs parsed by Java. Eighty-digit calculation followed by relative tolerance `2e-8` and absolute tolerance `1e-10` supports agreement within those tolerances, not a universal correctly-rounded claim. I recommended explicit assertions for positive-oracle failures and row count as completion gates.

Root's initial probe receipt records 12/12 zero-volatility failures on release/current and identical outputs. Its nested `source.runtime_status` still says “not executed yet”; root was notified to resolve that stale metadata in the final record. The later expanded runs are root's work, and the revised guard requires its own final receipt. This review does not certify a full upstream build or JUnit run.

## Refreshed duplicate and contribution review

Seven fresh all-state searches across issue/PR titles, bodies and comments found no exact zero-volatility second-adjoint report or proposed correction. Exact `priceAdjoint2`, `getPriceAdjoint2`, Hessian and second-derivative searches had no hits. Public indexed forum searches also found none. This is a bounded search, not an exhaustive novelty guarantee.

[PR843](https://github.com/OpenGamma/Strata/pull/843/files) is the historical origin: it ports the same method from BlackPriceFunction. Its actual diff and available comments were rechecked; it does not fix or explicitly reject this zero-volatility behavior. [PR682](https://github.com/OpenGamma/Strata/pull/682/files) uses the old method in SABR extrapolation, without the missing guard. PR1422, 465 and 939 have no target-method implementation patch. [Issue1412](https://github.com/OpenGamma/Strata/issues/1412) and its actual comments concern breached barriers, not this Hessian. Relevant bodies and diffs were inspected, including closed work.

The current catalog filename search found the existing Normal-IV report and unrelated MLX Hessian reports, not this case. Do not repeat issue2796.

[Contribution rules](https://strata.opengamma.io/contributions/) and the current issue template allow a confirmed bug report with reproducer, versions, JDK and OS. Questions go to the [forum](https://strata.opengamma.io/support/). Patch acceptance requires preserved tests and compatibility; no acceptance is presumed. No AI attestation was found in inspected rules. The old webpage says master, while fresh repository metadata says main; verify the real base before any future PR.

No claim about production exposure, bank systems, customer losses or exhaustive novelty is supported. Full captured evidence is in `SOURCES.json`.
