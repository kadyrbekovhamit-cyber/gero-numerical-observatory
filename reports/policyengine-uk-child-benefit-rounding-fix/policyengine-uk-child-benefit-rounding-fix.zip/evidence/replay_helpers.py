"""Actual current helpers, independent Decimal staircase; not a full simulation."""
from pathlib import Path
import importlib.util,json
from decimal import Decimal, ROUND_FLOOR
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('upstream',P/'source/policyengine_uk/utils/child_benefit.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rows=[]
for income in ['59999','60000','60199','60199.99','60200','60399','60400','70150','79999.99','80000','81000']:
 for benefit in ['1354.60','4199.00','100.00']:
  I,B=Decimal(income),Decimal(benefit)
  points=min(Decimal(100),max(Decimal(0),(I-60000)/200)).to_integral_value(rounding=ROUND_FLOOR)
  expected=(B.to_integral_value(rounding=ROUND_FLOOR)*points/100).to_integral_value(rounding=ROUND_FLOOR)
  got=float(m.round_down_to_pounds(m.child_benefit_charge_percentage(float(I),60000,80000)*m.round_down_to_pounds(float(B))))
  assert got==float(expected),(income,benefit,got,str(expected))
  rows.append(dict(income=income,benefit=benefit,actual=got,expected=str(expected)))
print(json.dumps(dict(scope='Current helpers imported unchanged; Decimal oracle for 2024+ staircase. Complete PolicyEngine simulation and all fiscal policies not tested.',passed=len(rows),rows=rows),indent=2))
