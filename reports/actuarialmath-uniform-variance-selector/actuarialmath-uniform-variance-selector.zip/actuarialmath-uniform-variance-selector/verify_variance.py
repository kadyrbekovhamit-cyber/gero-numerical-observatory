#!/usr/bin/env python3
"""Real actuarialmath API vs exact Bernoulli pure-endowment oracle.

Only s=0 is tested, isolating the previously reported conditioning-age issue.
No graphical stubs or replacements of upstream numerical functions.
"""
import hashlib
import json
import math
import sys
from decimal import Decimal, getcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parent
variant = sys.argv[1]
sys.path.insert(0, str(ROOT / 'source' / variant))
import actuarialmath
from actuarialmath import Insurance, Uniform

assert Path(actuarialmath.__file__).resolve().is_relative_to((ROOT / 'source' / variant).resolve())
getcontext().prec = 80
rows = []

def record(kind, life, x, term, moment, expected):
    params = dict(x=x, s=0, t=term, moment=moment)
    try:
        value = life.E_x(**params)
        passed = math.isfinite(value) and math.isclose(value, float(expected), rel_tol=2e-12, abs_tol=2e-12)
        actual = value
    except Exception as error:
        actual = {'exception': type(error).__name__, 'message': str(error)}
        passed = False
    rows.append(dict(kind=kind, params=params, annual_interest_rate=life.interest.i, omega=getattr(life, 'omega_', None), actual=actual, expected=str(expected), passed=passed))

for remaining in (20, 60, 90):
    x = 100 - remaining
    for rate in ('0', '0.03', '0.1'):
        life = Uniform(omega=100).set_interest(i=float(rate))
        for term in (0, 1, remaining // 2, remaining):
            p = (Decimal(remaining) - term) / Decimal(remaining)
            v = (Decimal(1) + Decimal(rate)) ** (-term)
            for moment in (life.VARIANCE, 1, 2, 3):
                expected = v*v*p*(1-p) if moment == life.VARIANCE else v**moment*p
                record('uniform_variance' if moment == life.VARIANCE else 'uniform_positive_moment_control', life, x, term, moment, expected)

# Base-class zero-term behavior is an additional observation, kept distinct.
base = Insurance().set_survival(mu=lambda x, s: 0.02).set_interest(i=0.03)
record('base_zero_term_variance_observation', base, 40, 0, base.VARIANCE, Decimal(0))

result = {
    'variant': variant,
    'checks': len(rows),
    'failures': sum(not r['passed'] for r in rows),
    'failure_counts': {k: sum(not r['passed'] for r in rows if r['kind'] == k) for k in sorted({r['kind'] for r in rows})},
    'mortalitylaws_sha256': hashlib.sha256((ROOT/'source'/variant/'actuarialmath'/'mortalitylaws.py').read_bytes()).hexdigest(),
    'python': sys.version,
    'source_root': str(Path(actuarialmath.__file__).resolve()),
    'rows': rows,
}
(ROOT/'evidence').mkdir(exist_ok=True)
(ROOT/'evidence'/f'{variant}.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}, indent=2))
