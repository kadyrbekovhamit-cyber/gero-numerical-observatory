# actuarialmath: the variance selector rejected before its own branch

Reproduced; no reply visible on issue 11 as of 22 October 2026; candidate not accepted

See REPORT_EN.md. Run the included Python harness against the source version named there with the package dependencies installed. For actuarialmath place the checkout package in source/current/actuarialmath and a patched copy in source/candidate/actuarialmath, then run verify_variance.py current and candidate. For bond_pricing: check_perpetuity.py PATH_TO_PACKAGE_PARENT result.json. For curo: check_curo.py CHECKOUT result.json. Tests intentionally record discrepancies rather than return a failing exit code; inspect the JSON failure counts.

Report CC BY 4.0; original harness MIT; upstream-derived patches retain MIT terms. AI assistance disclosed. No private messages or customer data included.
