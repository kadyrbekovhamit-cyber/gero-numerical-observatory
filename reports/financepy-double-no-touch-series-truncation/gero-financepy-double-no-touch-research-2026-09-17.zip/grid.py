"""Executed public FXDoubleOneTouchOption against a method-of-images oracle."""
from pathlib import Path
import sys,math,json,hashlib,itertools,contextlib,io
from functools import lru_cache
R=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['baseline','early-stop-only','candidate','mutation','release']
sys.path.insert(0,str(R/mode))
import numpy as np
import mpmath as mp
from financepy.products.fx.fx_double_one_touch_option import FXDoubleOneTouchOption
from financepy.utils.date import Date
from financepy.utils.global_types import DoubleBarrierTypes
from financepy.utils.day_count import DayCountTypes
from financepy.utils.frequency import FrequencyTypes
if mode == 'release':
    from financepy.market.curves.discount_curve_flat import DiscountCurveFlat
else:
    from financepy.market.curves.flat_discount_curve import FlatDiscountCurve as DiscountCurveFlat
from financepy.models.black_scholes import BlackScholes
mp.mp.dps=60
@lru_cache(maxsize=None)
def image_probability(sigma,t,L,U,S,rd,rf,N=40):
    sig,T,lower,upper,spot,r_d,r_f=map(mp.mpf,(sigma,t,L,U,S,rd,rf))
    ell=mp.log(upper/lower);x=mp.log(spot/lower);nu=r_d-r_f-sig*sig/2;s=sig*mp.sqrt(T)
    cdf=lambda z: mp.erfc(-z/mp.sqrt(2))/2
    vals=[]
    for k in range(-N,N+1):
        z=2*k*ell
        term1=mp.exp(-nu*z/(sig*sig))*(cdf((ell-x+z-nu*T)/s)-cdf((-x+z-nu*T)/s))
        term2=mp.exp(-2*nu*(x+k*ell)/(sig*sig))*(cdf((ell+x+z-nu*T)/s)-cdf((x+z-nu*T)/s))
        vals.append(term1-term2)
    return mp.fsum(vals)
scenarios=[]
for sigma,a,days,pos,rf,K in itertools.product([.1,.2,.4],[.1,.25,.5],[7,30,180,730],[.25,.5,.75],[0.,.03],[1.,100.]):
    scenarios.append(('zero_log_drift',sigma,a,days,pos,rf,K,0.))
for sigma,a,days,pos,nu in itertools.product([.1,.2,.4],[.1,.25],[30,730],[math.sqrt(2)/4,.643],[-.015,.015]):
    scenarios.append(('nonzero_drift_control',sigma,a,days,pos,0.,1.,nu))
vdt=Date(1,1,2026);rows=[];oracle_path=R/'evidence/oracle.json'
saved=json.loads(oracle_path.read_text()) if oracle_path.exists() else None
for i,(kind,sigma,a,days,pos,rf,K,nu) in enumerate(scenarios):
    rd=rf+.5*sigma*sigma+nu;t=days/365.;L=100.;U=L*math.exp(2*a);S=L*math.exp(2*a*pos);expiry=vdt.add_days(days)
    with contextlib.redirect_stdout(io.StringIO()):
        d=DiscountCurveFlat(vdt,rd,FrequencyTypes.CONTINUOUS,DayCountTypes.ACT_365F)
        f=DiscountCurveFlat(vdt,rf,FrequencyTypes.CONTINUOUS,DayCountTypes.ACT_365F)
    df=float(d.df(expiry));df_f=float(f.df(expiry));rde=float(-np.log(df)/t);rfe=float(-np.log(df_f)/t)
    parameters={'sigma':sigma,'half_log_width':a,'days':days,'position':pos,'foreign_rate':rf,'payment':K,'declared_log_drift':nu,'spot':S,'lower':L,'upper':U,'t':t,'df':df,'effective_rd':rde,'effective_rf':rfe}
    if saved:
        assert parameters==saved[i]['input'];prob=mp.mpf(saved[i]['probability'])
    else:prob=image_probability(sigma,t,L,U,S,rde,rfe)
    assert -mp.mpf('1e-45')<=prob<=1+mp.mpf('1e-45'),(i,str(prob))
    values={ot.name:float(FXDoubleOneTouchOption(expiry,ot,L,U,K).value(vdt,S,d,f,BlackScholes(sigma))) for ot in DoubleBarrierTypes}
    normalized=values['KNOCK_OUT']/(K*df);expected=float(prob)
    row={'case':i,'kind':kind,'input':parameters,'oracle_probability':mp.nstr(prob,60),'observed':values,'normalized_no_touch':normalized,'expected_no_touch':K*df*expected,'expected_touch':K*df*(1-expected),'normalized_error':abs(normalized-expected),'oracle_failure':abs(normalized-expected)>2e-10,'range_failure':normalized < -1e-12 or normalized > 1+1e-12,'pair_sum_error':abs((values['KNOCK_OUT']+values['KNOCK_IN'])/(K*df)-1)}
    rows.append(row)
    if i and i%120==0:print(mode,i,'/',len(scenarios),flush=True)
if not saved:
    (R/'evidence/oracle.json').write_text(json.dumps([{'input':x['input'],'probability':x['oracle_probability']} for x in rows],indent=2)+'\n')
    checks=[]
    for i in [0,72,119,215,431,432,479]:
        q=rows[i]['input'];more=image_probability(q['sigma'],q['t'],q['lower'],q['upper'],q['spot'],q['effective_rd'],q['effective_rf'],60)
        err=abs(more-mp.mpf(rows[i]['oracle_probability']));assert err<mp.mpf('1e-45')
        checks.append({'case':i,'image40_vs60_difference':mp.nstr(err,8)})
    (R/'evidence/oracle-tail-check.json').write_text(json.dumps(checks,indent=2)+'\n')
out={'mode':mode,'rows':rows,'normalized_tolerance':2e-10,'range_tolerance':1e-12,'oracle':'60-decimal method of images for absorbing drifted Brownian transition density integrated over log barriers; 81 images, no shared spectral-series terms','summary':{'cases':len(rows),'oracle_failures':sum(r['oracle_failure'] for r in rows),'range_failures':sum(r['range_failure'] for r in rows),'control_failures':sum(r['oracle_failure'] for r in rows if r['kind']=='nonzero_drift_control'),'max_normalized_error':max(r['normalized_error'] for r in rows),'max_pair_sum_error':max(r['pair_sum_error'] for r in rows)},'source_file_sha256':hashlib.sha256((R/mode/'financepy/products/fx/fx_double_one_touch_option.py').read_bytes()).hexdigest()}
(R/'evidence'/f'grid-{mode}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary'],indent=2))
