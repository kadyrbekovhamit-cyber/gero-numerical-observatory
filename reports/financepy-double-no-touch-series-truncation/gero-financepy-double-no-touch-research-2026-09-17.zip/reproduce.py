"""GPL-3.0. CPU replay of the bundled FinancePy source and released wheel."""
from pathlib import Path
import argparse, datetime, hashlib, importlib.metadata, json, os, platform
import shutil, subprocess, sys, tarfile, zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
TARGET = Path('financepy/products/fx/fx_double_one_touch_option.py')
TEST = Path('unit_tests/test_FinFXDoubleOneTouchOption.py')
MODES = ['baseline', 'early-stop-only', 'candidate', 'mutation', 'release']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    out = args.output.resolve()
    if out.exists():
        raise SystemExit('Use a new output directory; existing data will not be overwritten.')
    sums = ROOT/'SHA256SUMS'
    assert sums.is_file(), 'Missing integrity manifest'
    for line in sums.read_text().splitlines():
        expected, name = line.split('  ', 1)
        p = ROOT/name
        assert p.resolve().is_relative_to(ROOT), name
        assert sha(p) == expected, name
    out.mkdir(parents=True)
    evidence = out/'evidence'
    evidence.mkdir()
    extracted = out/'source-archive'
    extracted.mkdir()
    with tarfile.open(ROOT/'vendor/financepy-source-4c7cd50bdadd.tar.gz') as archive:
        for member in archive.getmembers():
            assert member.isfile() or member.isdir(), member.name
            assert (extracted/member.name).resolve().is_relative_to(extracted)
        archive.extractall(extracted, filter='data')
    roots = list(extracted.iterdir())
    assert len(roots) == 1 and roots[0].is_dir()
    source = roots[0]
    manifest = json.loads((ROOT/'source-manifest.json').read_text())
    assert len(manifest) == 792
    assert {str(p.relative_to(source)) for p in source.rglob('*') if p.is_file()} == set(manifest)
    assert all(sha(source/name) == expected for name, expected in manifest.items())
    original = (source/TARGET).read_bytes()
    candidate = (ROOT/'candidate/fx_double_one_touch_option.py').read_bytes()
    for mode in MODES:
        dst = out/mode
        dst.mkdir()
        if mode == 'release':
            with zipfile.ZipFile(ROOT/'vendor/financepy-1.1.2-py3-none-any.whl') as wheel:
                names = [n for n in wheel.namelist() if n.startswith('financepy/') and not n.endswith('/')]
                assert len(names) == 219
                for name in names:
                    path = dst/name
                    assert path.resolve().is_relative_to(dst)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(wheel.read(name))
        else:
            shutil.copytree(source/'financepy', dst/'financepy')
        (dst/'unit_tests').mkdir()
        shutil.copy2(ROOT/'tests/test_FinFXDoubleOneTouchOption.py', dst/TEST)
        shutil.copy2(source/'pyproject.toml', dst/'pyproject.toml')
        if mode == 'release':
            p = dst/TEST
            text = p.read_text().replace(
                'from financepy.market.curves.flat_discount_curve import FlatDiscountCurve',
                'from financepy.market.curves.discount_curve_flat import DiscountCurveFlat as FlatDiscountCurve')
            p.write_text(text)
        if mode in ['candidate', 'mutation']:
            (dst/TARGET).write_bytes(candidate)
        if mode == 'mutation':
            (dst/TARGET).write_bytes(original)
        if mode == 'early-stop-only':
            frag = '        if np.abs(term) < rel_tol * (1.0 + np.abs(c)):\n            break\n'
            text = (dst/TARGET).read_text()
            assert text.count(frag) == 1
            (dst/TARGET).write_text(text.replace(frag, ''))
        if mode in ['baseline', 'mutation', 'release']:
            assert (dst/TARGET).read_bytes() == original
    shutil.copy2(ROOT/'grid.py', out/'grid.py')
    def env(mode):
        e = os.environ.copy()
        e.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
            NUMBA_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
            MKL_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
            MPLBACKEND='Agg', XDG_CACHE_HOME=str(out/'cache'),
            MPLCONFIGDIR=str(out/'matplotlib-cache'),
            NUMBA_CACHE_DIR=str(out/('numba-cache-'+mode)), PYTHONPATH=str(out/mode))
        return e
    def pytest_run(mode, names, label):
        xml = evidence/('pytest-'+label+'.xml')
        command = [sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                   *names, '--junitxml='+str(xml)]
        with (evidence/('pytest-'+label+'.log')).open('w') as f:
            result = subprocess.run(command, cwd=out/mode, env=env(mode),
                                    stdout=f, stderr=subprocess.STDOUT)
        cases = list(ET.parse(xml).getroot().iter('testcase'))
        failures = [c.attrib['name'] for c in cases if c.find('failure') is not None]
        errors = [c.attrib['name'] for c in cases if c.find('error') is not None]
        assert not errors, (label, errors)
        return {'exit_code': result.returncode, 'cases': len(cases),
                'failures': len(failures), 'failed_names': failures}
    summaries = {}
    grids = {}
    for i, mode in enumerate(MODES):
        t = pytest_run(mode, [str(TEST)], mode)
        assert t['cases'] == 89
        assert t['failures'] == [56, 13, 0, 56, 56][i], (mode, t)
        assert t['exit_code'] == (0 if mode == 'candidate' else 1)
        with (evidence/('grid-'+mode+'.log')).open('w') as f:
            subprocess.run([sys.executable, '-B', str(out/'grid.py'), mode],
                cwd=out, env=env(mode), stdout=f, stderr=subprocess.STDOUT, check=True)
        g = json.loads((evidence/('grid-'+mode+'.json')).read_text())
        assert g['summary']['cases'] == 480
        assert g['summary']['oracle_failures'] == [360, 48, 0, 360, 360][i]
        assert g['summary']['range_failures'] == [72, 24, 0, 72, 72][i]
        grids[mode] = g
        summaries[mode] = {'tests': t, 'grid': g['summary'], 'target_sha256': sha(out/mode/TARGET)}
        print(mode, 'tests failed', t['failures'], 'of 89; grid', g['summary'], flush=True)
    assert grids['baseline']['rows'] == grids['mutation']['rows'] == grids['release']['rows']
    assert summaries['baseline']['tests']['failed_names'] == summaries['mutation']['tests']['failed_names']
    adjacent = ['test_FinFXBarrierOption.py', 'test_FinFXForward.py', 'test_FinFXVanillaOption.py']
    for n in adjacent:
        shutil.copy2(source/'unit_tests'/n, out/'candidate/unit_tests'/n)
    suite = pytest_run('candidate', [str(TEST), *['unit_tests/'+n for n in adjacent]], 'candidate-and-adjacent')
    assert suite['cases'] == 103 and suite['failures'] == 0 and suite['exit_code'] == 0
    assert all(sha(source/name) == expected for name, expected in manifest.items())
    receipt = {'status':'portable_replay_verified',
        'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit':'4c7cd50bdadd6efc9ac74fa81e93374397d18e3e',
        'source_files_preserved':len(manifest), 'summaries':summaries,
        'candidate_and_adjacent':suite, 'oracle_recomputed':True,
        'platform':platform.platform(), 'machine':platform.machine(), 'python':sys.version,
        'dependencies':{n:importlib.metadata.version(n) for n in ['numpy','numba','scipy','mpmath','pytest','matplotlib']},
        'numerical_threads':1, 'gpu_used':False, 'audio_video_playback':False,
        'full_upstream_suite_run_locally':False}
    (out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print('COMPLETE: portable replay verified', flush=True)

if __name__ == '__main__':
    main()
