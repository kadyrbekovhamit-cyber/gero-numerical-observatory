"""Sequential Edge TTS narration of reviewed public scripts. No private chat upload."""
import argparse, asyncio, hashlib, json, socket
from pathlib import Path
import aiohttp, edge_tts

ROOT = Path(__file__).resolve().parent
PROFILE = json.loads((ROOT/'voice-profile.json').read_text())
assert PROFILE['tool'] == 'edge-tts'
VOICE = PROFILE['voice']

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--slug')
    args = parser.parse_args()
    for episode in json.loads((ROOT/'episodes.json').read_text()):
        if args.slug and episode['slug'] != args.slug:
            continue
        folder = ROOT/'episodes'/episode['slug']/'assets'
        folder.mkdir(parents=True, exist_ok=True)
        for i, scene in enumerate(episode['scenes'], 1):
            stem = folder/f'narration-{i}'
            signature = hashlib.sha256((VOICE+'|-3%|'+scene['voice']).encode()).hexdigest()
            receipt = stem.with_suffix('.json')
            if receipt.exists() and stem.with_suffix('.mp3').exists():
                if json.loads(receipt.read_text()).get('signature') == signature:
                    print('CACHED', episode['slug'], i, flush=True)
                    continue
            chunks=[]
            task=edge_tts.Communicate(scene['voice'],VOICE,rate='-3%',boundary='WordBoundary',
                connector=aiohttp.TCPConnector(family=socket.AF_INET),connect_timeout=20,receive_timeout=45)
            partial=stem.with_suffix('.partial.mp3')
            try:
                async with asyncio.timeout(90):
                    with partial.open('wb') as audio:
                        async for chunk in task.stream():
                            if chunk['type']=='audio':audio.write(chunk['data'])
                            elif chunk['type']=='WordBoundary':chunks.append(chunk)
                assert partial.stat().st_size > 1000 and chunks
                partial.replace(stem.with_suffix('.mp3'))
                receipt.write_text(json.dumps({'signature':signature,'voice':VOICE,'rate':'-3%',
                    'text':scene['voice'],'events':chunks,'service':'Microsoft Edge online TTS',
                    'client':'edge-tts '+edge_tts.__version__},indent=2))
                print('READY',episode['slug'],i,flush=True)
            finally:
                if partial.exists():partial.unlink()

if __name__=='__main__':asyncio.run(main())
