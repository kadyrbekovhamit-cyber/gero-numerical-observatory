FinancePy returned a negative option price, minus zero point one seven, for a payoff that cannot be negative.

The touch and no-touch prices still added up correctly. That check alone missed the error.

Two series truncation fixes removed all three hundred sixty discrepancies in four hundred eighty tested scenarios.

The maintainer reproduced the bug. The patch is proposed. Actual trading losses were not measured.
