Source ledger — reviewed before narration

Report: https://www.gero.uz/research/articles/financepy-double-no-touch-series-truncation.html
Evidence archive: 
Public artifact: https://github.com/kadyrbekovhamit-cyber/gero-numerical-observatory/blob/main/catalog/reports/financepy-double-no-touch-series-truncation.md
Primary sources:
https://github.com/domokane/FinancePy/issues/266
https://github.com/domokane/FinancePy/pull/270
https://pypi.org/project/financepy/1.1.2/

Scene 1: FinancePy returned a negative option price, minus zero point one seven, for a payoff that cannot be negative.
Classification: Recorded CPU test results and payoff invariant; maintained distinction between proposed correction and merged/released fix.

Scene 2: The touch and no-touch prices still added up correctly. That check alone missed the error.
Classification: Recorded CPU test results and payoff invariant; maintained distinction between proposed correction and merged/released fix.

Scene 3: Two series truncation fixes removed all three hundred sixty discrepancies in four hundred eighty tested scenarios.
Classification: Recorded CPU test results and payoff invariant; maintained distinction between proposed correction and merged/released fix.

Scene 4: The maintainer reproduced the bug. The patch is proposed. Actual trading losses were not measured.
Classification: Recorded CPU test results and payoff invariant; maintained distinction between proposed correction and merged/released fix.

Narration client: https://github.com/rany2/edge-tts . The client is open source; synthesis uses Microsoft's online service, not an open local model. Only reviewed public narration text was submitted.
