# Video and archival record links

- [YouTube](https://youtube.com/shorts/DbnhzRiMV1s)
- [GERO](https://www.gero.uz/research/articles/financepy-double-no-touch-series-truncation.html)
- [GitHub](https://github.com/kadyrbekovhamit-cyber/gero-numerical-observatory/blob/main/catalog/reports/financepy-double-no-touch-series-truncation.md)
- [Hugging Face](https://huggingface.co/datasets/XamitK/gero-research-evidence-2026-09/blob/main/financepy-double-no-touch-series-truncation.md)
- [Archive DOI](https://doi.org/10.5281/zenodo.22805090)

The 31-second video is public. The archive DOI was reserved before freezing these files and is registered on publication. Other report mirrors use their canonical paths. Video binaries are hosted on YouTube and LinkedIn, not in this archive.
