# Reproduce the FinancePy double no-touch report

Read REPORT_EN.md and LICENSES.md first. This is a source-pinned research archive, not an investment tool.

With Python 3.12, create a separate environment and install the requirements:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -B reproduce.py --output ./replay-output
```

The requirements match recorded scientific versions; compatible CPU wheels must exist for your platform. Installation uses the normal Python package index. The replay itself uses bundled FinancePy sources and no network. It sets numerical thread counts to one, uses a noninteractive plotting backend, and never plays sound or video. The output directory must not already exist.

It verifies all SHA256SUMS entries and all 792 original source files before extracting copies, runs the 89 focused tests and 480-scenario grid on original / partial / final candidate / restored / release variants, and checks original/restored equality. Nonzero pytest statuses in the original/partial/restored/release variants are expected and recorded; the runner fails on unexpected collection errors, changed failure counts or candidate regressions. The independent image reference is recomputed rather than copied from recorded results. The candidate is additionally checked with 14 existing neighboring FX tests.

The source target has two proposed truncation corrections, not a clipping workaround. Read the report's cap, parameter-domain and production-impact limitations. Source provenance and the upstream issue/PR are in SOURCE_LEDGER.md.

`evidence/recorded/` holds the 17 September reference outputs; logs can contain the original machine's source paths. They are provenance, not paths required by this portable runner. `replay-output/` receives a new REPLAY_RECEIPT.json with the current environment and results. Actual fresh reproduction receipts are reported separately from the frozen reference.
