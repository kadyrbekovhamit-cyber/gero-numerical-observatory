#!/usr/bin/env python3
"""Run genuine bond_pricing APIs versus explicit high-precision cash flows."""
from decimal import Decimal as D, localcontext
import difflib
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import resource
import sys
import time
import warnings
import zipfile

HERE = Path(__file__).resolve().parent
WHEEL = HERE / 'bond_pricing-0.7.3-py3-none-any.whl'
EXPECTED_WHEEL = '1b24f796eb5321128515b8c71563a93aa602ebe407c5c11e37638c9476f59962'
assert hashlib.sha256(WHEEL.read_bytes()).hexdigest() == EXPECTED_WHEEL
sys.path.insert(0, str(WHEEL))
with warnings.catch_warnings():
    warnings.filterwarnings('ignore', message='Module isda_daycounters is not installed.*')
    import bond_pricing.present_value as original
import numpy as np


def cash_flow_reference(rate, n, pv, fv, terminal, due, comp, cash):
    """Enumerate payments at integer periods; do not use annuity factor formula."""
    with localcontext() as ctx:
        ctx.prec = 85
        rate = D.from_float(float(rate))
        growth = (1 + rate / D(comp)) ** (D(comp) / D(cash))
        discount = 1 / growth
        factors = [D(1)]
        for _ in range(n):
            factors.append(factors[-1] * discount)
        start = 0 if due else 1
        annuity_factor = sum(factors[start:start + n])
        target = D(pv) + D(fv) * factors[n]
        # Match the documented immediate-start shift and existing PV/FV APIs:
        # terminal payment moves together with the payment stream.
        terminal_value = D(terminal) * factors[n - int(due)]
        return (target - terminal_value) / annuity_factor, annuity_factor, terminal_value, target


def close(actual, expected):
    return bool(np.isfinite(actual) and abs(D.from_float(float(actual)) - expected) <= max(D('1e-10'), abs(expected) * D('2e-12')))


def load_patch():
    with zipfile.ZipFile(WHEEL) as z:
        raw = z.read('bond_pricing/present_value.py')
    source = raw.decode()
    before = ('    reqd_annuity_pv = pv + (fv - terminal_payment) / (1 + r)**n_periods\n'
              '    return (reqd_annuity_pv / pvaf(r, n_periods))[()]')
    after = ('    reqd_annuity_pv = pv + (fv - terminal_payment) / (1 + r)**n_periods\n'
             '    reqd_annuity_pv = where(\n'
             '        immediate_start,\n'
             '        pv / (1 + r) + (fv / (1 + r) - terminal_payment) / (1 + r)**n_periods,\n'
             '        reqd_annuity_pv)\n'
             '    return (reqd_annuity_pv / pvaf(r, n_periods))[()]')
    assert source.count(before) == 1
    modified = source.replace(before, after)
    (HERE / 'present_value_original.py').write_bytes(raw)
    candidate = HERE / 'present_value_patched.py'
    candidate.write_text(modified)
    (HERE / 'fix.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True), modified.splitlines(True),
        fromfile='a/bond_pricing/present_value.py', tofile='b/bond_pricing/present_value.py')))
    spec = importlib.util.spec_from_file_location('bond_pricing._local_candidate', candidate)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, raw


def main():
    start = time.perf_counter()
    fixed, raw = load_patch()
    rows = []
    for rate, freq, n, funding, terminal, due in itertools.product(
            [-0.05, 0.0, 0.01, 0.1, 0.5], [(1, 1), (12, 12), (2, 12)],
            [1, 2, 12, 60], [(210, 0), (10000, 0), (0, 210)], [0, 25], [False, True]):
        comp, cash = freq
        pv, fv = funding
        expected, af, tv, target = cash_flow_reference(rate, n, pv, fv, terminal, due, comp, cash)
        args = dict(rate=rate, n_periods=n, pv=pv, fv=fv, terminal_payment=terminal,
                    immediate_start=due, comp_freq=comp, cf_freq=cash)
        before = float(original.annuity_instalment(**args))
        after = float(fixed.annuity_instalment(**args))
        # A second observable: present value of the actual returned payment stream.
        before_value = D.from_float(before) * af + tv
        after_value = D.from_float(after) * af + tv
        rows.append({'input': args, 'reference_payment': str(expected), 'before': before, 'after': after,
                     'before_pass': close(before, expected), 'after_pass': close(after, expected),
                     'before_cash_flow_pass': close(float(before_value), target),
                     'after_cash_flow_pass': close(float(after_value), target)})
    regression = []
    for due in [False, True]:
        for rate in [0.0, 0.1]:
            payment = float(fixed.annuity_instalment(rate=rate, n_periods=2, pv=210, immediate_start=due))
            back = float(original.annuity_pv(rate=rate, n_periods=2, instalment=payment, immediate_start=due))
            regression.append({'case': 'public_default_fv_roundtrip', 'due': due, 'rate': rate,
                               'payment': payment, 'returned_pv': back, 'passed': close(back, D(210))})
    vector = fixed.annuity_instalment(rate=0.1, n_periods=2, pv=210, immediate_start=[False, True])
    regression.append({'case': 'timing_vector', 'payments': vector.tolist(),
                       'passed': bool(np.allclose(vector, [121, 110], rtol=2e-12, atol=1e-10))})
    perpetuity = float(fixed.annuity_instalment(rate=0.1, pv=110, immediate_start=True))
    regression.append({'case': 'positive_rate_perpetuity', 'payment': perpetuity,
                       'passed': close(perpetuity, D(10))})
    report = {'package': 'bond-pricing', 'release': '0.7.3', 'wheel_sha256': EXPECTED_WHEEL,
              'upstream_commit': '8e04fd03c2594422e457e2f08b460017dc6b4993',
              'source_sha256': hashlib.sha256(raw).hexdigest(),
              'release_source_equals_current_master': raw == (HERE / 'vendor/present_value.py').read_bytes(),
              'cases': len(rows), 'before_failed': sum(not r['before_pass'] for r in rows),
              'after_failed': sum(not r['after_pass'] for r in rows),
              'before_cash_flow_failed': sum(not r['before_cash_flow_pass'] for r in rows),
              'after_cash_flow_failed': sum(not r['after_cash_flow_pass'] for r in rows),
              'ordinary_cases_unchanged': all(r['before'] == r['after'] for r in rows if not r['input']['immediate_start']),
              'regressions': regression, 'elapsed_seconds': round(time.perf_counter() - start, 6),
              'peak_process_rss_mib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024 * 1024),
              'reference': '85-digit Decimal explicit cash-flow sum; rate interpreted as the exact supplied binary64',
              'python': sys.version, 'numpy': np.__version__, 'rows': rows,
              'limits': ['Synthetic cash flows, not measured customer losses.',
                         'Novelty and bounty eligibility require separate review.',
                         'Reference and local patch have the same author.',
                         'Small-rate cancellation and unrelated PV/default semantics are outside this patch.'],
              'external_sends': 0, 'model_calls': 0}
    (HERE / 'RESULTS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, indent=2))
    assert report['after_failed'] == report['after_cash_flow_failed'] == 0
    assert all(r['passed'] for r in regression)
    assert report['ordinary_cases_unchanged']


if __name__ == '__main__':
    main()
