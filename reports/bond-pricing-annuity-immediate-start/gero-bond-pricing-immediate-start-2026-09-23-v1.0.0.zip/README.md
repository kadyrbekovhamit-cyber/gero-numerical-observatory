# Reproduce the bond_pricing immediate-start discrepancy

This package reproduces one documented payment-timing discrepancy in the actual bond-pricing 0.7.3 release and checks a proposed local correction.

Use Python 3.12 with an existing environment satisfying `requirements.txt`. If you choose to create a new environment, installing those pinned packages is a separate network action. The replay itself does not install anything or access the network.

Run in this directory, sequentially:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python reproduce.py
```

Expected: 720 scenarios; 288 payment and stream-PV mismatches before, zero after; 360 ordinary-annuity scenarios unchanged; six additional regression checks pass. `RESULTS.json`, the original/patched module copies and `fix.patch` are written here. The published recorded result is retained in `RECORDED_RESULTS.json`.

The real wheel is imported without installing it. Its SHA-256 is verified before import. The correction is applied to a separate local copy. The Decimal oracle enumerates cash flows instead of using the package's annuity-factor formula. Synthetic inputs and bounded coverage do not establish real customer losses or general correctness.

The complete report is `REPORT_EN.md`. Prior-report and bounty search scope is recorded in `NOVELTY_AND_BOUNTY.json`.

The wheel and upstream code are GPLv3; see `vendor/LICENSE-GPLv3.txt`. The derived patch and accompanying replay are also GPLv3. Report text is CC BY 4.0. The closed Audit Lab application, credentials, personal files and internal history are not included.
