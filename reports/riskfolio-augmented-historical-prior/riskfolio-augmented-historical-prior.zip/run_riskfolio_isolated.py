"""Execute actual unmodified AST function bodies; no package/C++ integration claim."""
import ast
from pathlib import Path
import sys
import types
import numpy as np
import pandas as pd
import pytest
from scipy.linalg import inv

root = Path(sys.argv[1]).resolve()
test = sys.argv[2]
path = root / "riskfolio/src/ParamsEstimation.py"
tree = ast.parse(path.read_text(), filename=str(path))
names = {"mean_vector", "covar_matrix", "black_litterman_bayesian", "augmented_black_litterman"}
module = types.ModuleType("riskfolio.src.ParamsEstimation")
module.np, module.pd, module.inv = np, pd, inv
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(selected) == len(names)
exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), module.__dict__)
for name in ["riskfolio", "riskfolio.src"]:
    package = types.ModuleType(name)
    package.__path__ = []
    sys.modules[name] = package
sys.modules["riskfolio"].src = sys.modules["riskfolio.src"]
sys.modules["riskfolio.src"].ParamsEstimation = module
sys.modules[module.__name__] = module
print("Scope: real function bodies with hist moments and supplied loadings; full package and C++ not loaded.")
raise SystemExit(pytest.main([str(root / "tests" / test), "-q", "--tb=short"]))
