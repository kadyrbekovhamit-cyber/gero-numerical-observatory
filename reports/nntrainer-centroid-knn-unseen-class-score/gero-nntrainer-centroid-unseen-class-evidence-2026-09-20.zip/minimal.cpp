// SPDX-License-Identifier: MIT
// GERO: actual nntrainer layer training and inference, no substitute algorithm.
#include <centroid_knn.h>
#include <layer_context.h>
#include <var_grad.h>
#include <weight.h>
#include <iomanip>
#include <iostream>
using namespace nntrainer;
int main() {
  CentroidKNN layer;
  layer.setProperty({"num_class=3"});
  TensorDim dim({1,1,1,2});
  InitLayerContext init({dim},{true},false,"knn_probe");
  layer.finalize(init);
  Weight map(init.getWeightsSpec()[0],true), counts(init.getWeightsSpec()[1],true);
  Var_Grad input(dim,Initializer::ZEROS,true,true,"input");
  Var_Grad output(init.getOutSpecs()[0].variable_spec.dim,Initializer::ZEROS,true,true,"output");
  RunLayerContext context("knn_probe",false,0.f,false,1.f,nullptr,false,{&map,&counts},{&input},{&output},{});
  auto train=[&](unsigned cls,float x,float y){
    input.getVariableRef().getData<float>()[0]=x;
    input.getVariableRef().getData<float>()[1]=y;
    output.getGradientRef().setValue(0.f);
    output.getGradientRef().getData<float>()[cls]=1.f;
    layer.forwarding(context,true);
  };
  train(0,0.f,0.f);train(1,3.f,4.f);
  auto test=[&](const char* stage){
    input.getVariableRef().setValue(0.f);
    layer.forwarding(context,false);
    auto &v=output.getVariableRef();
    std::cout<<std::setprecision(9)<<"{\"stage\":\""<<stage<<"\",\"scores\":[";
    for(unsigned i=0;i<3;++i){if(i)std::cout<<',';std::cout<<v.getData<float>()[i];}
    std::cout<<"],\"predicted\":"<<v.argmax()[0]<<",\"counts\":[";
    for(unsigned i=0;i<3;++i){if(i)std::cout<<',';std::cout<<counts.getVariableRef().getData<float>()[i];}
    std::cout<<"]}\n";
  };
  test("partial");train(2,6.f,8.f);test("complete");
}
