from pathlib import Path
from decimal import Decimal,localcontext
import json,hashlib,datetime
P=Path(__file__).resolve().parent;E=P/'evidence'
allrows={m:[json.loads(x) for x in (E/f'grid-{m}.jsonl').read_text().splitlines()] for m in ['original','candidate','restored']}
assert (E/'grid-original.jsonl').read_bytes()==(E/'grid-restored.jsonl').read_bytes()
summary={}
for mode,rows in allrows.items():
 fail=[];partial=0;full=0
 for r in rows:
  n=r['classes'];w=r['width'];mask=r['mask'];seen=[c for c in range(n) if mask&(1<<c)]
  centers=[[Decimal(4*c)+Decimal(j)/2 for j in range(w)] for c in range(n)]
  expected_input=[float(x+Decimal(str(r['offset']))) for x in centers[r['target']]]
  assert r['input']==expected_input
  expected_centroids=[float(v) if c in seen else 0 for c,a in enumerate(centers) for v in a]
  assert r['centroids']==expected_centroids
  assert r['counts']==[r['reps'] if c in seen else 0 for c in range(n)]
  with localcontext() as ctx:
   ctx.prec=80
   scores={c:-sum((Decimal(str(x))-y)**2 for x,y in zip(expected_input,centers[c])).sqrt() for c in seen}
  expected=max(scores,key=scores.get);assert expected==r['target']
  if r['prediction']!=expected:fail.append(r['id'])
  for c,ref in scores.items():assert abs(r['scores'][c]-float(ref))<=1e-6*max(1,abs(float(ref)))
  assert r['weights_unchanged']
  if len(seen)==n:full+=1
  else:partial+=1
 summary[mode]={'rows':len(rows),'classification_failures':len(fail),'partial_class_rows':partial,'fully_trained_control_rows':full,'failure_ids':fail}
for a,b in zip(allrows['original'],allrows['candidate']):
 for key in ['id','classes','width','mask','reps','target','offset','centroids','counts','input','weights_unchanged']:assert a[key]==b[key]
 for c in range(a['classes']):
  if a['mask']&(1<<c):assert a['scores'][c]==b['scores'][c]
 if a['mask']==(1<<a['classes'])-1:assert a==b
assert summary['candidate']['classification_failures']==0
r={'status':'native_reproduced_candidate_restoration_verified_prior_art_review_incomplete','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pin':'2d1e4974ae84e1e6d37784416bdfb52b647919a6','summary':summary,'restored_bytes_identical':True,'known_class_scores_unchanged':True,'independent_reference':'80-digit Decimal Euclidean distances to exact arithmetic means of explicitly generated dyadic training points; maximum negative distance over observed classes.','native_operations':'CentroidKNN finalize, forwarding(training=true), forwarding(false), Tensor::argmax','limits':'Batch1 CPU FP32 NCHW; modest finite values; at least one observed class; no all-unseen policy, extreme range, full test suite, real images, products or devices tested. Core full build reused at identical pin after2005source-file and library revalidation; current layer independently recompiled.','sha256':{f'grid-{m}.jsonl':hashlib.sha256((E/f'grid-{m}.jsonl').read_bytes()).hexdigest() for m in allrows}}
(E/'GRID_VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({m:{k:v for k,v in s.items() if k!='failure_ids'} for m,s in summary.items()},indent=2))
