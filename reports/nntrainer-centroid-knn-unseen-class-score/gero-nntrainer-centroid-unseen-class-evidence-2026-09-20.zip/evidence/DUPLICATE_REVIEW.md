# CentroidKNN prior-art review

Review completed 20 September 2026 (Asia/Tashkent). The candidate is a positive score for an unobserved class, despite observed-class scores being negative Euclidean distances. No exact prior report or proposed correction was found in this bounded review. This is not an exhaustive priority guarantee.

## Current implementation and corpus

Current main remains `2d1e4974ae84e1e6d37784416bdfb52b647919a6`. The current and latest reviewed release v0.5.0 both use `numeric_limits<float>::min()` in the zero-sample branch. The release source was inspected; its binary was not executed.

The fetched canonical GERO catalog has 115 publication entries, including ten whose title/ID explicitly names nntrainer. No CentroidKNN case occurs. Other prior grouped nntrainer reports in the maintainer-contact registry were checked; no matching centroid finding appears. These are publication entries, not independent defect counts.

## Searches and bodies/diffs

Saved GitHub searches include centroid, knn, numeric_limits, num_sample, centroid+min, empty+class, unseen, untrained, centroid+lowest, and unobserved, including closed issues and PRs. Relevant bodies, issue comments, actual file diffs and review comments were examined for PRs859,1394,1499,1580,1585,1702. Review-comment counts are91,2,0,0,38,0 respectively. Title-only exclusion was not used.

- PR859: initial nearest-centroid implementation already contains the positive min() sentinel. Discussion covers API/layer design, labels and nearest-centroid terminology; no matching sentinel correction found.
- PR1394: LayerV2 migration. No replacement of the empty-class sentinel.
- PR1499: moves the layer into the core/public C++ API. No sentinel fix.
- PR1580/1585: application support for adding classes and related file handling/formatting. Reviewed diffs and comments do not correct this score branch.
- PR1702: only query labels while training, a different inference problem.
- Issue1261: requireLabel() interface addition, separate label contract.
- Issue1493: integration into the core; issue1421: KNN application rewrite. No exact score report.
- Issue1480: sanitizer/memory errors; issue2602: example compilation. These do not describe the positive score cause.
- Issue4334: security audit checklist; body has no centroid/unseen/lowest() or numeric_limits<float>::min match.

All eleven saved commits touching the current centroid_knn.cpp path were inspected. Changes cover URL, tensor API, mixed precision, exports, weight decay, weight-index initialization, headers, label access, serialization, names and the original move into the core. None replaces the sentinel. Pre-move history is represented by PR859 and PR1394.

## Historical uncertainty retained

Issue1521, "Verification of centroid knn / l2norm", has no description. A comment says an accuracy-drop cause was found, but gives neither that cause nor a patch. Its timeline has no linked correction. It cannot be established from the public record whether the author encountered this same defect. The disclosure explicitly cites this issue and invites a pointer to matching prior work. Do not state that the issue was certainly unrelated or that no one previously knew of this behavior.

## Outreach check

The canonical account is kadyrbekovhamit-cyber. Ten existing nntrainer issues/PRs by that account were refreshed. Comments on4331,4336,4337 were read. No current maintainer reply or instruction to stop was present. The project-level collaboration offer already exists in4336; do not repeat the pitch. AGENTS.md and the bug-report template were read. The repository allows disclosed agent contributions; no false no-AI declaration is required or made.

## Conclusion

Native component and public-model reproduction plus candidate/restoration controls establish an implementation discrepancy for partially trained class sets with at least one observed class and finite modest distances. A single factual technical issue is appropriate. Report the existing issue1521 ambiguity, no real-image/device impact, and the untested all-unseen/nonfinite policies.
