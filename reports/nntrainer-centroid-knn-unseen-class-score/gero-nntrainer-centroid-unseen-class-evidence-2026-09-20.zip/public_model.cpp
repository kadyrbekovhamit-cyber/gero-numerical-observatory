// SPDX-License-Identifier: MIT
// Synthetic feature classifier via public nntrainer C++ model/dataset APIs.
#include <algorithm>
#include <array>
#include <dataset.h>
#include <iomanip>
#include <iostream>
#include <layer.h>
#include <model.h>
#include <optimizer.h>
#include <stdexcept>
#include <vector>
struct Samples { unsigned next = 0; unsigned classes; };
int sample(float **in, float **label, bool *last, void *data) {
  auto &s = *static_cast<Samples *>(data);
  unsigned cls = s.next++;
  in[0][0] = 3.0f * cls;
  in[0][1] = 4.0f * cls;
  std::fill(label[0], label[0] + 3, 0.0f);
  label[0][cls] = 1.0f;
  *last = s.next == s.classes;
  if (*last) s.next = 0;
  return 0;
}
void check(int r, const char *what) { if (r) throw std::runtime_error(what); }
void run(unsigned observed) {
  using namespace ml::train;
  Samples samples{0,observed};
  auto model = createModel(ModelType::NEURAL_NET, {"batch_size=1", "epochs=1"});
  check(model->addLayer(layer::CentroidKNN({"name=knn", "num_class=3", "input_shape=1:1:2", "trainable=false"})), "addLayer");
  check(model->setOptimizer(optimizer::SGD({"learning_rate=0.1"})), "optimizer");
  check(model->setDataset(DatasetModeType::MODE_TRAIN, createDataset(DatasetType::GENERATOR,sample,&samples,{"buffer_size=1"})), "dataset");
  check(model->compile(), "compile");
  check(model->initialize(), "initialize");
  check(model->train(), "train");
  for (unsigned cls=0;cls<observed;++cls) {
    float input[2]={3.0f*cls,4.0f*cls};
    auto out=model->inference(1,{input});
    if(out.size()!=1 || !out[0]) throw std::runtime_error("bad output");
    const auto predicted=std::max_element(out[0],out[0]+3)-out[0];
    std::cout<<std::setprecision(9)<<"GERO_RESULT {\"observed_classes\":"<<observed<<",\"query_class\":"<<cls<<",\"scores\":["<<out[0][0]<<','<<out[0][1]<<','<<out[0][2]<<"],\"predicted\":"<<predicted<<",\"expected\":"<<cls<<"}\n";
  }
}
int main() {try {run(2);run(3);} catch(const std::exception &e) {std::cerr<<"ERROR "<<e.what()<<'\n';return 1;}}
