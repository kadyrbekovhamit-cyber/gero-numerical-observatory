# Issue Description

`CentroidKNN` gives a class with **zero training samples** a positive score, whereas observed classes receive negative Euclidean distances. Consequently an unobserved class wins `argmax`, even when the query exactly matches an observed class centroid.

Reproduced on current main `2d1e4974ae84e1e6d37784416bdfb52b647919a6`, native CPU FP32, batch size 1. With `num_class=3`, train class 0 on `[0,0]` and class 1 on `[3,4]`; leave class 2 unobserved. Training and inference both complete successfully.

| Query | Native model output scores | Top class | Expected nearest observed class |
|---|---|---|---|
| `[0,0]` | `[0,-5,1.17549435e-38]` | 2 | 0 |
| `[3,4]` | `[-5,0,1.17549435e-38]` | 2 | 1 |

The public C++ model API produces these scores. The small reproduction below selects the maximum score; a separate native layer test using `Tensor::argmax` reproduces the same class selection.

Expected Result
============

A class for which no centroid has been estimated should not outrank an exact match to an observed centroid. If partially populated class sets are unsupported, rejecting them explicitly would also avoid silently returning this prediction. The implementation already has an explicit zero-sample branch.

At [the inference branch](https://github.com/nntrainer/nntrainer/blob/2d1e4974ae84e1e6d37784416bdfb52b647919a6/nntrainer/layers/centroid_knn.cpp#L118), `std::numeric_limits<float>::min()` means the **smallest positive normal float**, not the most negative float. Every finite `-distance` is less than that sentinel.

A one-line local candidate replaces `min()` with `lowest()`. With the same public-model program it produces `[0,-5,-3.40282347e38]` and `[-5,0,-3.40282347e38]`, selecting 0 and 1 respectively. Restoring the original source returns the two wrong selections. When all three classes are trained at `[0,0]`, `[3,4]`, `[6,8]`, all three query/control results remain unchanged.

How to Reproduce
===============

Build the pinned native core and C++ API, then compile and link the following standalone program against them. It uses a two-feature synthetic dataset, no external model or images. `run(2)` leaves the third class unobserved; `run(3)` is the fully populated control. No source modification is required to reproduce the original output.

```cpp
// SPDX-License-Identifier: MIT
// Synthetic feature classifier via public nntrainer C++ model/dataset APIs.
#include <algorithm>
#include <array>
#include <dataset.h>
#include <iomanip>
#include <iostream>
#include <layer.h>
#include <model.h>
#include <optimizer.h>
#include <stdexcept>
#include <vector>
struct Samples { unsigned next = 0; unsigned classes; };
int sample(float **in, float **label, bool *last, void *data) {
  auto &s = *static_cast<Samples *>(data);
  unsigned cls = s.next++;
  in[0][0] = 3.0f * cls;
  in[0][1] = 4.0f * cls;
  std::fill(label[0], label[0] + 3, 0.0f);
  label[0][cls] = 1.0f;
  *last = s.next == s.classes;
  if (*last) s.next = 0;
  return 0;
}
void check(int r, const char *what) { if (r) throw std::runtime_error(what); }
void run(unsigned observed) {
  using namespace ml::train;
  Samples samples{0,observed};
  auto model = createModel(ModelType::NEURAL_NET, {"batch_size=1", "epochs=1"});
  check(model->addLayer(layer::CentroidKNN({"name=knn", "num_class=3", "input_shape=1:1:2", "trainable=false"})), "addLayer");
  check(model->setOptimizer(optimizer::SGD({"learning_rate=0.1"})), "optimizer");
  check(model->setDataset(DatasetModeType::MODE_TRAIN, createDataset(DatasetType::GENERATOR,sample,&samples,{"buffer_size=1"})), "dataset");
  check(model->compile(), "compile");
  check(model->initialize(), "initialize");
  check(model->train(), "train");
  for (unsigned cls=0;cls<observed;++cls) {
    float input[2]={3.0f*cls,4.0f*cls};
    auto out=model->inference(1,{input});
    if(out.size()!=1 || !out[0]) throw std::runtime_error("bad output");
    const auto predicted=std::max_element(out[0],out[0]+3)-out[0];
    std::cout<<std::setprecision(9)<<"GERO_RESULT {\"observed_classes\":"<<observed<<",\"query_class\":"<<cls<<",\"scores\":["<<out[0][0]<<','<<out[0][1]<<','<<out[0][2]<<"],\"predicted\":"<<predicted<<",\"expected\":"<<cls<<"}\n";
  }
}
int main() {try {run(2);run(3);} catch(const std::exception &e) {std::cerr<<"ERROR "<<e.what()<<'\n';return 1;}}
```

Further Information
===============

- macOS 15.5 (24F74), ARM64; Apple clang 17.0.0; native CPU, one configured worker, no GPU. Tested source pin above; the same branch is present in reviewed v0.5.0 source, but that released binary was not executed.
- The full native core was built from pinned source. The five official C++ API sources are unchanged. For public-model A/B/A controls, only the centroid translation unit was recompiled for each variant and substituted while relinking copies of the full core. The runtime loader path was verified for each copy; shared source and build artifacts were not changed.
- A separate 1,728-scenario component grid varies 2, 3 or 5 classes, feature width 1, 2 or 4, nonempty observed-class subsets, one/two samples per observed class, and modest finite query offsets. An independent 80-digit Decimal reference computes the arithmetic centroids and Euclidean distances. Classification mismatches are **1,548 → 0 → 1,548** for original/candidate/restored. The 180 fully populated controls, observed-class scores and training state are unchanged. Inference does not mutate the tested centroid/count weights.
- Scope: batch 1, FP32 NCHW, at least one observed class, finite modest features/distances. The all-unobserved policy and extreme/nonfinite distances are not addressed by this candidate. No real-image classifier, application feature extractor, deployed Samsung device, customer loss or full upstream test-suite result is claimed.
- Duplicate review covered the current source, file history, relevant issue/PR bodies and diffs (including #859, #1394, #1499, #1580, #1585 and #1702). I found [issue #1521](https://github.com/nntrainer/nntrainer/issues/1521), whose comment mentions an accuracy-drop cause without identifying it. I could not establish whether it is the same issue; please point me to an existing matching report if it is.

The reproducer, independent expected results, local candidate and restoration checks were prepared with AI assistance for GERO / Xamit Kadirbekov. This is a technical report, not a claim of an accepted fix.
