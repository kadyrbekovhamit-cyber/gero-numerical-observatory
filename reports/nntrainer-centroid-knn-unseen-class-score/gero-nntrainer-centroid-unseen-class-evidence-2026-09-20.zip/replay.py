#!/usr/bin/env python3
"""Portable CPU replay for the recorded macOS/ARM64 native experiment.
Requires Python 3.9+, C++17, Meson and Ninja. No network, GPU or media playback.
Run from an isolated working directory: python3 /path/to/package/replay.py
Build and compiler work are sequential, with one configured numerical worker.
"""
from pathlib import Path
import datetime, hashlib, json, os, platform, shlex, shutil, subprocess, tarfile
P=Path(__file__).resolve().parent;W=Path.cwd()/'centroid-replay';S=W/'source';B=S/'build';E=W/'evidence'
assert platform.system()=='Darwin', 'This build wrapper was verified on macOS ARM64; use official build setup elsewhere.'
assert platform.machine()=='arm64', 'Recorded replay target is ARM64.'
assert not W.exists(), 'Use an empty working directory; existing replay is preserved.'
W.mkdir();E.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((P/'source-manifest.json').read_text())
for name,h in meta['archives'].items():assert sha(P/'sources'/name)==h,name
def extract(archive,root):
 root.mkdir(parents=True,exist_ok=True)
 with tarfile.open(archive) as tar:
  for m in tar.getmembers():
   target=(root/m.name).resolve();assert target.is_relative_to(root.resolve()),m.name
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   elif m.isfile():
    target.parent.mkdir(parents=True,exist_ok=True)
    with tar.extractfile(m) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
    target.chmod(m.mode&0o777)
   elif m.issym() and m.name=='compile_commands.json' and m.linkname=='build/compile_commands.json':pass
   else:raise RuntimeError('Unexpected archive member: '+m.name)
extract(P/'sources/nntrainer-current-source.tar.gz',S)
for vendor in ['googletest','iniparser']:extract(P/'sources'/f'{vendor}-source.tar.gz',S/'subprojects'/vendor)
for k,v in meta['files'].items():assert sha(S/k)==v['sha256'],k
cfg=json.loads((P/'build-options.json').read_text())
env=dict(os.environ)
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS']:env[key]='1'
env['PYTHONDONTWRITEBYTECODE']='1';env['CUDA_VISIBLE_DEVICES']=''
for name in ['meson','ninja','c++']:assert shutil.which(name),f'{name} must be on PATH'
def run(cmd,label,cwd):
 with (E/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:print((E/(label+'.log')).read_text()[-5000:]);r.check_returncode()
 print(label,'OK',flush=True)
run(['meson','setup','build',*cfg,'-Dcpp_args='+repr(['-include',str(P/'nntrainer-darwin-build.h')])],'configure',S)
(B/'nntrainer/malloc.h').write_text('#include <malloc/malloc.h>\n')
run(['ninja','-C','build','-j1','nntrainer/libnntrainer.dylib'],'clean-core-build',S)
commands=json.loads((B/'compile_commands.json').read_text())
def flags(suffix):
 record=next(x for x in commands if x['file'].endswith(suffix));raw=shlex.split(record['command']);f=[];i=1
 while i<len(raw):
  a=raw[i]
  if a in ['-MQ','-MF','-o']:i+=2
  elif a in ['-MD','-c'] or a==record['file']:i+=1
  else:f.append(a);i+=1
 return raw[0],f
core=B/'nntrainer/libnntrainer.dylib';compiler,cf=flags('/centroid_knn.cpp')
grid=W/'grid';model=W/'public-model'
run([compiler,*cf,str(P/'grid.cpp'),'-L'+str(core.parent),'-lnntrainer','-Wl,-rpath,'+str(core.parent),'-o',str(grid)],'compile-grid',B)
cc,af=flags('/api/ccapi/src/factory.cpp');apis=sorted((S/'api/ccapi/src').glob('*.cpp'))
run([cc,*af,str(P/'public_model.cpp'),*[str(x) for x in apis],'-L'+str(core.parent),'-lnntrainer','-Wl,-rpath,'+str(core.parent),'-o',str(model)],'compile-public-model',B)
link=shlex.split(subprocess.check_output(['ninja','-t','commands','nntrainer/libnntrainer.dylib'],cwd=B,env=env,text=True).splitlines()[-1])
old_obj=next(x for x in link if x.endswith('.o') and 'centroid_knn.cpp.o' in x)
source=S/'nntrainer/layers/centroid_knn.cpp';original=source.read_text();old='std::numeric_limits<float>::min()';assert original.count(old)==1
results={}
for variant,contents in [('original',original),('candidate',original.replace(old,'std::numeric_limits<float>::lowest()')),('restored',original)]:
 d=W/variant;d.mkdir();src=d/'centroid_knn.cpp';src.write_text(contents);obj=d/'centroid_knn.o';lib=d/'libnntrainer.dylib'
 run([compiler,*cf,'-c',str(src),'-o',str(obj)],'compile-layer-'+variant,B)
 lc=[str(obj) if x==old_obj else str(lib) if x=='nntrainer/libnntrainer.dylib' else x for x in link]
 run(lc,'link-core-'+variant,B)
 ve=dict(env,DYLD_LIBRARY_PATH=str(d),DYLD_PRINT_LIBRARIES='1')
 for name,exe in [('grid',grid),('model',model)]:
  output=E/(name+'-'+variant+'.txt');err=E/(name+'-'+variant+'.stderr')
  with output.open('w') as out,err.open('w') as e:subprocess.run([str(exe)],cwd=W,env=ve,stdout=out,stderr=e,check=True)
  assert str(lib) in err.read_text(), 'Loader path must match variant'
 g=E/f'grid-{variant}.txt';reference=P/'evidence'/f'grid-{variant}.jsonl'
 assert g.read_bytes()==reference.read_bytes(),f'Grid changed: {variant}'
 rows=[json.loads(x.split('GERO_RESULT ',1)[1]) for x in (E/f'model-{variant}.txt').read_text().splitlines() if 'GERO_RESULT ' in x]
 expected=json.loads((P/'public-model-expected.json').read_text())[variant]
 assert rows==expected,(variant,rows)
 results[variant]={'grid_rows':len(g.read_text().splitlines()),'grid_sha256':sha(g),'grid_byte_identical':True,'model_rows':rows,'model_rows_identical':True,'library_sha256':sha(lib),'source_sha256':sha(src)}
# Recompute independent Decimal oracle using freshly executed native grid bytes.
for variant in results:shutil.copyfile(E/f'grid-{variant}.txt',E/f'grid-{variant}.jsonl')
checker=W/'check_grid.py';checker.write_text((P/'check_grid.py').read_text())
run([shutil.which('python3'),str(checker)],'independent-oracle',W)
for k,v in meta['files'].items():assert sha(S/k)==v['sha256'],k
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'clean_full_native_cpu_replay_verified','source_pin':meta['source_pin'],'verified_source_files':len(meta['files']),'results':results,'source_unchanged':True,'platform':platform.platform(),'python':platform.python_version(),'gpu':False,'audio_playback':False,'configured_workers':1,'limits':'macOS ARM64 FP32 batch1 synthetic features; no released-binary, real-image, full suite or device validation'}
(E/'REPLAY_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'evidence':str(E)},indent=2))
