// SPDX-License-Identifier: MIT
// Native centroid training followed by native score vector and argmax.
#include <centroid_knn.h>
#include <layer_context.h>
#include <var_grad.h>
#include <weight.h>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace nntrainer;
void array(const Tensor &v) {
  std::cout << '[';
  for (unsigned i=0;i<v.size();++i) {if(i)std::cout<<',';std::cout<<v.getData<float>()[i];}
  std::cout << ']';
}
int main() {
  std::cout << std::setprecision(9);
  unsigned id=0;
  for (unsigned n:{2u,3u,5u}) for(unsigned width:{1u,2u,4u})
  for(unsigned mask=1;mask<(1u<<n);++mask) for(unsigned reps:{1u,2u}) {
    CentroidKNN layer;layer.setProperty({"num_class="+std::to_string(n)});
    TensorDim dim({1,1,1,width});InitLayerContext init({dim},{true},false,"centroid_grid");layer.finalize(init);
    Weight map(init.getWeightsSpec()[0],true),counts(init.getWeightsSpec()[1],true);
    Var_Grad input(dim,Initializer::ZEROS,true,true,"input");
    Var_Grad output(init.getOutSpecs()[0].variable_spec.dim,Initializer::ZEROS,true,true,"output");
    RunLayerContext ctx("centroid_grid",false,0.f,false,1.f,nullptr,false,{&map,&counts},{&input},{&output},{});
    for(unsigned c=0;c<n;++c) if(mask&(1u<<c)) for(unsigned r=0;r<reps;++r) {
      for(unsigned j=0;j<width;++j)input.getVariableRef().getData<float>()[j]=4.f*c+.5f*j+(reps==1?0.f:r==0?-1.f:1.f);
      output.getGradientRef().setValue(0.f);output.getGradientRef().getData<float>()[c]=1.f;
      layer.forwarding(ctx,true);
    }
    const Tensor before=map.getVariableRef().clone();const Tensor cnt_before=counts.getVariableRef().clone();
    for(unsigned target=0;target<n;++target) if(mask&(1u<<target)) for(float offset:{0.f,.25f,-.5f}) {
      for(unsigned j=0;j<width;++j)input.getVariableRef().getData<float>()[j]=4.f*target+.5f*j+offset;
      layer.forwarding(ctx,false);const auto &v=output.getVariableRef();
      std::cout<<"{\"id\":"<<id++<<",\"classes\":"<<n<<",\"width\":"<<width<<",\"mask\":"<<mask<<",\"reps\":"<<reps<<",\"target\":"<<target<<",\"offset\":"<<offset<<",\"scores\":";array(v);
      std::cout<<",\"prediction\":"<<v.argmax()[0]<<",\"centroids\":";array(map.getVariableRef());
      std::cout<<",\"counts\":";array(counts.getVariableRef());
      std::cout<<",\"input\":";array(input.getVariableRef());
      std::cout<<",\"weights_unchanged\":"<<(map.getVariableRef()==before&&counts.getVariableRef()==cnt_before?"true":"false")<<"}\n";
    }
  }
}
