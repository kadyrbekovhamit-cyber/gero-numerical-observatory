"""Validate the Rodrigues patch without building OpenCV:
  1) line-by-line Python port of the ORIGINAL matrix->vector branch must reproduce cv2 bit-for-bit-ish
     (fidelity of the port), random inputs + band inputs;
  2) port of the PATCHED branch: band errors vs mpmath oracle, Jacobian vs tangent FD,
     identical to cv2 outside the band;
  3) the new regression test (same logic as the C++ TEST) run against cv2 (expected FAIL) and the
     patched port (expected PASS)."""
import math, numpy as np, cv2, mpmath as mp
mp.mp.dps = 50
print("cv2", cv2.__version__)

def svd_orth(R):
    w, u, vt = cv2.SVDecomp(R)
    return u @ vt

def main_branch(R, r, s, c, theta):
    vth = 1/(2*s)
    dtheta_dtr = -1./s
    dvth_dtheta = -vth*c/s
    d1 = 0.5*dvth_dtheta*dtheta_dtr
    d2 = 0.5*dtheta_dtr
    dvardR = np.array([[0,0,0,0,0,1,0,-1,0],[0,0,-1,0,0,0,1,0,0],[0,1,0,-1,0,0,0,0,0],
                       [d1,0,0,0,d1,0,0,0,d1],[d2,0,0,0,d2,0,0,0,d2]], float)
    dvar2dvar = np.array([[vth,0,0,r[0],0],[0,vth,0,r[1],0],[0,0,vth,r[2],0],[0,0,0,0,1]], float)
    domegadvar2 = np.array([[theta,0,0,r[0]*vth],[0,theta,0,r[1]*vth],[0,0,theta,r[2]*vth]], float)
    J = domegadvar2 @ dvar2dvar @ dvardR
    J = J.reshape(3, 3, 3).transpose(0, 2, 1).reshape(3, 9)   # "transpose every row as 3x3"
    return r*(vth*theta), J

def log_old(R0):
    R = svd_orth(np.asarray(R0, float))
    r = np.array([R[2,1]-R[1,2], R[0,2]-R[2,0], R[1,0]-R[0,1]])
    s = math.sqrt((r @ r)*0.25)
    c = (R[0,0]+R[1,1]+R[2,2]-1)*0.5
    c = min(max(c, -1.), 1.)
    theta = math.acos(c)
    if s < 1e-5:
        J = np.zeros((3, 9))
        if c > 0:
            r = np.zeros(3)
            J[0,5] = J[1,6] = J[2,1] = -0.5; J[0,7] = J[1,2] = J[2,3] = 0.5
        else:
            r = np.zeros(3)
            r[0] = math.sqrt(max((R[0,0]+1)*0.5, 0.))
            r[1] = math.sqrt(max((R[1,1]+1)*0.5, 0.))*(-1. if R[0,1] < 0 else 1.)
            r[2] = math.sqrt(max((R[2,2]+1)*0.5, 0.))*(-1. if R[0,2] < 0 else 1.)
            if abs(r[0]) < abs(r[1]) and abs(r[0]) < abs(r[2]) and ((R[1,2] > 0) != (r[1]*r[2] > 0)):
                r[2] = -r[2]
            theta /= np.linalg.norm(r)
            r = r*theta
        return r, J
    return main_branch(R, r, s, c, theta)

def log_new(R0):
    R = svd_orth(np.asarray(R0, float))
    r = np.array([R[2,1]-R[1,2], R[0,2]-R[2,0], R[1,0]-R[0,1]])
    s = math.sqrt((r @ r)*0.25)
    c = (R[0,0]+R[1,1]+R[2,2]-1)*0.5
    c = min(max(c, -1.), 1.)
    theta = math.atan2(s, c)
    if s < 1e-5:
        if c > 0:
            r = r*(0.5*(1. + s*s/6.))
        else:
            B = (R + R.T)*0.5 - c*np.eye(3)
            k = (0 if B[0,0] >= B[2,2] else 2) if B[0,0] >= B[1,1] else (1 if B[1,1] >= B[2,2] else 2)
            n = B[:, k].copy(); n *= 1./np.linalg.norm(n)
            if n @ r < 0: n = -n
            r = n*theta
        beta = 1./12 if c > 0 else 1./(theta*theta) - s/(2*theta*(1 - c))
        rx = np.array([[0, -r[2], r[1]], [r[2], 0, -r[0]], [-r[1], r[0], 0]])
        Jinv = np.eye(3) - 0.5*rx + beta*(rx @ rx)
        D = np.zeros((3, 9))
        for b in range(3):
            D[0, 3*2+b] = 0.5*R[1, b]; D[0, 3*1+b] = -0.5*R[2, b]
            D[1, 3*0+b] = 0.5*R[2, b]; D[1, 3*2+b] = -0.5*R[0, b]
            D[2, 3*1+b] = 0.5*R[0, b]; D[2, 3*0+b] = -0.5*R[1, b]
        return r, Jinv @ D
    return main_branch(R, r, s, c, theta)

def cv_log(R):
    r, J = cv2.Rodrigues(np.asarray(R, float))
    return r.ravel(), J.T   # J is 9x3 -> 3x9

# ---- 1) fidelity of the port of the original code
rng = np.random.default_rng(123)
inputs = []
for _ in range(3000):
    v = rng.uniform(-1, 1, 3)*2*np.pi
    th = np.linalg.norm(v); th1 = math.fmod(th, 2*np.pi)
    if th1 > np.pi: th1 = -(2*np.pi - th1)
    inputs.append(v*th1/th)                      # same generator as CV_RodriguesTest
for th in [3e-6, 9e-6, 1.2e-5, np.pi-9e-6, np.pi-3e-6, np.pi-1e-7, np.pi, np.pi-2e-5]:
    for _ in range(20):
        u = rng.normal(size=3); u /= np.linalg.norm(u)
        inputs.append(u*th)
    for ax in np.eye(3):
        inputs += [ax*th, -ax*th]
dv = dj = 0
for v in inputs:
    R, _ = cv2.Rodrigues(v)
    a, Ja = cv_log(R); b, Jb = log_old(R)
    dv = max(dv, np.abs(a-b).max()); dj = max(dj, np.abs(Ja-Jb).max())
print("1) port of ORIGINAL vs cv2 %s over %d inputs: max |dr| = %.2e, max |dJ| = %.2e" % (cv2.__version__, len(inputs), dv, dj))

# ---- 2) patched port: accuracy vs exact oracle, and agreement with cv2 outside the band
def mexp(r):
    r = [mp.mpf(float(x)) for x in r]
    th = mp.sqrt(sum(x*x for x in r))
    if th == 0: return mp.eye(3)
    u = [x/th for x in r]
    K = mp.matrix([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
    uu = mp.matrix([[u[i]*u[j] for j in range(3)] for i in range(3)])
    return mp.cos(th)*mp.eye(3) + (1-mp.cos(th))*uu + mp.sin(th)*K
def geod(Ra, Rb):
    M = Ra.T*Rb
    c = (M[0,0]+M[1,1]+M[2,2]-1)/2
    w = [(M[2,1]-M[1,2])/2, (M[0,2]-M[2,0])/2, (M[1,0]-M[0,1])/2]
    return float(mp.atan2(mp.sqrt(sum(x*x for x in w)), c))
tonp = lambda M: np.array([[float(M[i,j]) for j in range(3)] for i in range(3)])
worst_old = worst_new = 0; worst_out = 0
for v in inputs[3000:]:
    Rm = mexp(v); Rd = tonp(Rm)
    eo = geod(Rm, mexp(cv_log(Rd)[0])); en = geod(Rm, mexp(log_new(Rd)[0]))
    worst_old = max(worst_old, eo); worst_new = max(worst_new, en)
for v in inputs[:3000]:
    R, _ = cv2.Rodrigues(v)
    a, Ja = cv_log(R); b, Jb = log_new(R)
    worst_out = max(worst_out, np.abs(a-b).max())
print("2) band inputs (%d): worst rotation error  cv2 = %.2e rad,  patched port = %.2e rad" % (len(inputs)-3000, worst_old, worst_new))
print("   outside the band (3000 random, test generator): max |r_patched - r_cv2| = %.2e" % worst_out)

# Jacobian vs exact tangent derivative (mpmath)
def mlog(M):
    c = (M[0,0]+M[1,1]+M[2,2]-1)/2
    v = [(M[2,1]-M[1,2])/2, (M[0,2]-M[2,0])/2, (M[1,0]-M[0,1])/2]
    s = mp.sqrt(sum(x*x for x in v)); t = mp.atan2(s, c)
    return [x*t/s for x in v]
def skew(w): return mp.matrix([[0,-w[2],w[1]],[w[2],0,-w[0]],[-w[1],w[0],0]])
jo = jn = 0
for th in [3e-6, 9e-6, np.pi-9e-6, np.pi-3e-6, 1.0, 2.5]:
    for ax in [np.array([0.36, -0.48, 0.8]), np.array([1., 0, 0]), np.array([0, -1., 0])]:
        v = ax/np.linalg.norm(ax)*th
        Rm = mexp(v); Rd = tonp(Rm)
        for w in np.eye(3):
            h = mp.mpf('1e-25')
            lp = mlog(Rm*mexp([h*x for x in w])); lm = mlog(Rm*mexp([-h*x for x in w]))
            dr = np.array([float((lp[i]-lm[i])/(2*h)) for i in range(3)])
            dR = tonp(Rm*skew([mp.mpf(float(x)) for x in w])).ravel()
            jo = max(jo, np.abs(cv_log(Rd)[1] @ dR - dr).max()/np.abs(dr).max())
            jn = max(jn, np.abs(log_new(Rd)[1] @ dR - dr).max()/np.abs(dr).max())
print("   jacobian along tangent directions, worst relative error: cv2 = %.2e, patched port = %.2e" % (jo, jn))

# ---- 3) the C++ regression test logic, in Python
def run_test(logf):
    d = 5e-6; fails = []
    cases = [(9e-6, 0, 0), (1e-6, -2e-6, 3e-6), (0, 5e-6, -5e-6), (np.pi-d, 0, 0), (-(np.pi-d), 0, 0), (0, np.pi-d, 0),
             (0, 0, -(np.pi-d)), tuple(np.array([0, 1, 1])*((np.pi-d)/np.sqrt(2))),
             tuple(np.array([1, -2, 3])*((np.pi-1e-7)/np.sqrt(14))), (np.pi-2e-8, 0, 0)]
    dirs = [np.array(v, float) for v in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (0.36, -0.48, 0.8)]]
    for r0 in cases:
        r0 = np.array(r0, float)
        R, _ = cv2.Rodrigues(r0)
        r1, J = logf(R)
        if np.linalg.norm(r1 - r0) > 1e-12:
            fails.append(("value", tuple(np.round(r0, 9)), np.linalg.norm(r1 - r0)))
        if np.pi - np.linalg.norm(r0) < 1e-6:
            continue
        h = 1e-8
        for w in dirs:
            Ep, _ = cv2.Rodrigues(w*h); Em, _ = cv2.Rodrigues(-w*h)
            rp = logf(R @ Ep)[0]; rm = logf(R @ Em)[0]
            dr_num = (rp - rm)*(0.5/h)
            wx = np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])
            dr = J @ (R @ wx).ravel()
            if np.linalg.norm(dr - dr_num) > 1e-5*np.linalg.norm(dr_num):
                fails.append(("jacobian", tuple(np.round(r0, 9)), np.linalg.norm(dr - dr_num)/np.linalg.norm(dr_num)))
    return fails
f_old = run_test(cv_log); f_new = run_test(log_new)
print("3) regression test vs cv2 (unpatched): %d failed checks" % len(f_old))
for f in f_old[:12]: print("     ", f)
print("   regression test vs patched port: %d failed checks %s" % (len(f_new), f_new[:5]))
