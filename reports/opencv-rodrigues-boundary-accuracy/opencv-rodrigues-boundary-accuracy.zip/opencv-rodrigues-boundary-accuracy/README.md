# OpenCV Rodrigues: accuracy at small angles and near pi

Read REPORT_EN.md for scope and limitations. Upstream patch and tests: https://github.com/opencv/opencv/pull/30482.

This package is a source/evidence bundle; it contains no prebuilt executable. No full-library validation claim.
