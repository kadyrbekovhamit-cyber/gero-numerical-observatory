"""Rodrigues matrix->vector: (a) value near 0 / near pi, (b) 3x9 Jacobian along tangent directions
vs 50-digit FD of the exact log map, (c) composeRT consequences.
Oracle: exact exp map (doc formula) in mpmath; the exact log of exp(r) is r itself for |r|<pi."""
import numpy as np, cv2, mpmath as mp
mp.mp.dps = 50
print("cv2", cv2.__version__)

def mexp(r):
    r = [mp.mpf(x) for x in r]
    th = mp.sqrt(sum(x*x for x in r))
    if th == 0: return mp.eye(3)
    u = [x/th for x in r]
    K = mp.matrix([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
    uu = mp.matrix([[u[i]*u[j] for j in range(3)] for i in range(3)])
    return mp.cos(th)*mp.eye(3) + (1-mp.cos(th))*uu + mp.sin(th)*K

def geod(Ra, Rb):
    M = Ra.T*Rb
    c = (M[0,0]+M[1,1]+M[2,2]-1)/2
    w = [(M[2,1]-M[1,2])/2, (M[0,2]-M[2,0])/2, (M[1,0]-M[0,1])/2]
    return mp.atan2(mp.sqrt(sum(x*x for x in w)), c)

def tonp(M): return np.array([[float(M[i,j]) for j in range(3)] for i in range(3)])

print("(a) value: r_true -> exact R (rounded to double) -> cv2.Rodrigues -> r_cv")
for r in [(9e-6, 0, 0), (0, 5e-6, -5e-6), (1e-6, 2e-6, 3e-6),
          (np.pi-5e-6, 0, 0), (-(np.pi-5e-6), 0, 0), (0, np.pi-5e-6, 0), (0, 0, -(np.pi-5e-6)),
          (0, (np.pi-5e-6)/np.sqrt(2), (np.pi-5e-6)/np.sqrt(2)),
          (np.pi-1e-7, 0, 0), (-(np.pi-1e-7), 0, 0)]:
    Rm = mexp(r)
    rcv, _ = cv2.Rodrigues(tonp(Rm))
    e = geod(Rm, mexp(rcv.ravel()))
    print("   r_true=%-40s r_cv=%-45s rotation error=%.3e rad" % (np.array2string(np.array(r), precision=9), np.array2string(rcv.ravel(), precision=9), float(e)))

print("(b) Jacobian dr/dR (3x9) applied to tangent perturbation dR = R*[w]x  vs exact d log(R exp(h w))/dh")
def skew(w): return mp.matrix([[0,-w[2],w[1]],[w[2],0,-w[0]],[-w[1],w[0],0]])
rng = np.random.default_rng(3)
for th in [3e-6, 2e-5, 1e-3, 1.0, 3.0, np.pi-2e-5, np.pi-5e-6]:
    u = np.array([0.36, -0.48, 0.8]); r = u*th
    Rm = mexp(r); Rd = tonp(Rm)
    rcv, J = cv2.Rodrigues(Rd)          # J is 9x3 for matrix input ? check shape
    J = J.reshape(J.shape)
    errs = []
    for _ in range(3):
        w = rng.normal(size=3); w /= np.linalg.norm(w)
        dR = Rm*skew([mp.mpf(x) for x in w])
        # exact derivative of log map: log(R exp(h w)) with branch continuity (|r|<pi)
        h = mp.mpf('1e-25')
        # log via exact formula from the known r: r(h) solves exp(r(h)) = R exp(h w); use BCH-free numeric:
        # use mp.findroot? simpler: high-precision log of rotation matrix
        def mlog(M):
            c = (M[0,0]+M[1,1]+M[2,2]-1)/2
            v = mp.matrix([M[2,1]-M[1,2], M[0,2]-M[2,0], M[1,0]-M[0,1]])/2
            s = mp.sqrt(v[0]**2+v[1]**2+v[2]**2)
            t = mp.atan2(s, c)
            return [x*t/s for x in v]
        lp = mlog(Rm*mexp([h*x for x in w])); lm = mlog(Rm*mexp([-h*x for x in w]))
        dr_true = np.array([float((lp[i]-lm[i])/(2*h)) for i in range(3)])
        dRv = np.array([float(dR[a,b]) for a in range(3) for b in range(3)])
        Jm = J if J.shape == (3, 9) else J.T
        dr_cv = Jm @ dRv
        errs.append(np.abs(dr_cv-dr_true).max()/np.abs(dr_true).max())
    print("   theta=%-20r  J.shape=%s  max rel err of J*dR = %.3e" % (th, J.shape, max(errs)))

print("(c) composeRT: r1 then r2 = -r1 + small rotation; exact r3 known")
for small in [(4e-6, 0, 0), (0, 7e-6, 0), (2e-5, 0, 0)]:
    r1 = np.array([0.4, -0.2, 0.9]); R1 = mexp(r1)
    Rs = mexp(small)
    # r2 such that R2 = Rs * R1^T
    R2 = Rs*R1.T
    r2, _ = cv2.Rodrigues(tonp(R2))
    r3, t3 = cv2.composeRT(r1, np.zeros(3), r2.ravel(), np.zeros(3))[:2]
    e = geod(Rs, mexp(r3.ravel()))
    print("   true r3=%s  composeRT r3=%s  error=%.3e rad" % (small, r3.ravel(), float(e)))
