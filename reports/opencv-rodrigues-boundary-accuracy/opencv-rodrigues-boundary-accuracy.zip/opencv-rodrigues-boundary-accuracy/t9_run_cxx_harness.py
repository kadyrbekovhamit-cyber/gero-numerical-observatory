"""Feed band matrices to the compiled harness (patched C++ lines verbatim) and check vs mpmath oracle,
vs the Python port, and run the regression-test logic with the harness as the inverse transform."""
import sys, subprocess, math, numpy as np, cv2, mpmath as mp
sys.path.insert(0, sys.argv[1])
mp.mp.dps = 50
HARNESS = sys.argv[2]
import t8_validate_patch as port   # reuses log_new / mexp / geod (prints its own summary first)

def harness(Rs):
    inp = "\n".join(" ".join("%.17g" % x for x in np.asarray(R).ravel()) for R in Rs) + "\n"
    out = subprocess.run([HARNESS], input=inp, capture_output=True, text=True, check=True).stdout.splitlines()
    res = []
    for line in out:
        if line == "MAIN": res.append(None); continue
        v = np.array([float(x) for x in line.split()])
        res.append((v[:3], v[3:].reshape(3, 9)))
    return res

def orth(R):
    w, u, vt = cv2.SVDecomp(np.asarray(R, float)); return u @ vt

def log_cxx(R):
    Ro = orth(R)
    h = harness([Ro])[0]
    return port.log_new(R) if h is None else h

print("\n=== C++ harness ===")
rng = np.random.default_rng(99)
vecs = []
for th in [1e-9, 3e-6, 9e-6, 9.99e-6, np.pi-9.99e-6, np.pi-5e-6, np.pi-1e-7, np.pi-1e-9, np.pi]:
    for _ in range(15):
        u = rng.normal(size=3); u /= np.linalg.norm(u); vecs.append(u*th)
    for ax in np.eye(3): vecs += [ax*th, -ax*th]
    vecs.append(np.array([0, 1, 1])/np.sqrt(2)*th); vecs.append(-np.array([0, 1, 1])/np.sqrt(2)*th)
Rs = []
for v in vecs:
    R, _ = cv2.Rodrigues(v); Rs.append(orth(R))
H = harness(Rs)
nmain = sum(h is None for h in H)
worst = 0; dport_r = 0; dport_J = 0
for v, R, h in zip(vecs, Rs, H):
    if h is None: continue
    Rm = port.mexp(v)
    worst = max(worst, port.geod(Rm, port.mexp(h[0])))
    pr, pJ = port.log_new(R)
    dport_r = max(dport_r, np.abs(pr - h[0]).max()); dport_J = max(dport_J, np.abs(pJ - h[1]).max())
print("band matrices: %d (harness says outside band: %d)" % (len(vecs), nmain))
print("worst rotation error of patched C++ vs exact: %.2e rad" % worst)
print("patched C++ vs Python port: max |dr| = %.2e, max |dJ| = %.2e" % (dport_r, dport_J))
fails = port.run_test(log_cxx)
print("regression test with patched C++ in the band: %d failed checks %s" % (len(fails), fails[:5]))
