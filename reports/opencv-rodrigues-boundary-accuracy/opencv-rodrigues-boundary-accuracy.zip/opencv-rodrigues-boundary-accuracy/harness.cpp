// Executes the PATCHED inverse-Rodrigues band code verbatim (band_snippet.inc is cut from
// patch/b/modules/calib3d/src/calibration_base.cpp). Header-only OpenCV types, no OpenCV library.
// Input: lines of 9 doubles (an already orthonormal R, row-major). Output: r (3) and J (27, 3x9 row-major),
// or "MAIN" if the input is outside the band (main branch not reproduced here).
#include <cstdio>
#include <cmath>
#include <cfloat>
#include "opencv2/core/cvdef.h"
#include "opencv2/core/matx.hpp"
#include "opencv2/core/types.hpp"
using namespace cv;

struct FakeMat { void* data; };

int main()
{
    double v[9];
    while (std::scanf("%lf %lf %lf %lf %lf %lf %lf %lf %lf", v, v+1, v+2, v+3, v+4, v+5, v+6, v+7, v+8) == 9)
    {
        Matx33d R(v);
        double theta, s, c;
        double J[27] = {0};
        double dummy = 1;
        FakeMat jacobian = { &dummy };
        Point3d r(R(2, 1) - R(1, 2), R(0, 2) - R(2, 0), R(1, 0) - R(0, 1));
        s = std::sqrt((r.x*r.x + r.y*r.y + r.z*r.z)*0.25);
        c = (R(0, 0) + R(1, 1) + R(2, 2) - 1)*0.5;
        c = c > 1. ? 1. : c < -1. ? -1. : c;
#include "band_snippet.inc"
        else
        {
            std::printf("MAIN\n");
            continue;
        }
        std::printf("%.17g %.17g %.17g", r.x, r.y, r.z);
        for (int i = 0; i < 27; i++) std::printf(" %.17g", J[i]);
        std::printf("\n");
    }
    return 0;
}
