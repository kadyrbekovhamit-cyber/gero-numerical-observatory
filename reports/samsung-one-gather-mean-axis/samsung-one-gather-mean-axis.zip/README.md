# Focused ONE evidence

See REPORT_EN.md and VERIFICATION.json. Apply the two patches to ONE at the pinned revision. Tests live in the existing FoldGatherPass.test.cpp and FuseMeanWithMeanPass.test.cpp modules. Build helpers target macOS clang; they are provided for transparency, not a portable full-project build. The independently repeated binary results are in logs/. Full source retains Apache-2.0. No private mail is included.
