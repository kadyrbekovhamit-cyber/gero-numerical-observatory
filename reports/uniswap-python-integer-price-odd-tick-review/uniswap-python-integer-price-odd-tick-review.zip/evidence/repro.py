"""Repro for uniswap-python @ bc8fdf4 — executes the VERBATIM function bodies
(extracted with ast, decorators stripped) against stub contracts; no web3, no RPC.
Oracle: mpmath (50 digits) / Fraction, independent of the library."""
import ast, math, sys
from collections import namedtuple
from fractions import Fraction
from decimal import Decimal
import mpmath as mp

mp.mp.dps = 50
ROOT = sys.argv[1]

def extract(path, cls, names):
    tree = ast.parse(open(path).read())
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == cls:
            for fn in node.body:
                if isinstance(fn, ast.FunctionDef) and fn.name in names:
                    fn.decorator_list = []
                    out[fn.name] = "from __future__ import annotations\n" + ast.unparse(fn)
    return out

class Call:
    def __init__(self, v): self.v = v
    def call(self): return self.v
    def _encode_transaction_data(self): return b""

# ---------------------------------------------------------------- TVL
src = extract(f"{ROOT}/uniswap/uniswap.py", "Uniswap",
              ["get_tvl_in_pool", "get_token0_in_pool", "get_token1_in_pool", "get_raw_price"])

def chunks(arr, n):
    for i in range(0, len(arr), n):
        yield arr[i:i + n]

class Dec:
    def __init__(self, d): self.functions = type("F", (), {"decimals": lambda s: Call(d)})()

ns = dict(namedtuple=namedtuple, chunks=chunks, HexBytes=bytes, Tuple=tuple, Contract=object,
          _tick_spacing={100: 1, 500: 10, 3000: 60, 10000: 200},
          _tick_bitmap_range={100: (0, 0), 500: (0, 0), 3000: (0, 0), 10000: (0, 0)},
          _load_contract_erc20=lambda w3, a: Dec(DECIMALS[a]),
          AddressLike=str, Optional=lambda x: x, float=float, Decimal=Decimal)
for s in src.values():
    exec(s, ns)

DECIMALS = {"T0": 0, "T1": 0}  # decimals 0 so the final // 10**dec does not hide anything

class FakePool:
    address = "POOL"
    class functions:
        @staticmethod
        def ticks(t): return Call(None)

def tvl_case(fee, tick_lo, tick_hi, L, sqrt_price):
    net = {tick_lo: L, tick_hi: -L}
    spacing = {100: 1, 500: 10, 3000: 60, 10000: 200}[fee]
    class Self:
        w3 = None
        def get_pool_immutables(s, pool): return {"fee": fee, "token0": "T0", "token1": "T1"}
        def get_pool_state(s, pool): return {"sqrtPriceX96": int(mp.nint(mp.mpf(sqrt_price) * 2**96))}
        def find_tick_from_bitmap(s, bs, pool, ts, f, left): return tick_hi + spacing if left else tick_lo - spacing
        def multicall(s, batch, types):
            # tick() ABI tuple: index 1 is liquidityNet
            return [(0, net.get(t, 0), 0, 0, 0, 0, 0, True) for t in BATCH_TICKS.pop(0)]
        get_token0_in_pool = ns["get_token0_in_pool"]
        get_token1_in_pool = ns["get_token1_in_pool"]
    global BATCH_TICKS
    BATCH_TICKS = [list(c) for c in chunks(range(tick_lo - spacing, tick_hi + spacing, spacing), 100)]
    got = ns["get_tvl_in_pool"](Self(), FakePool())
    # oracle: whitepaper eq. 6.29/6.30 with sqrt(P_a)=1.0001^(t_lo/2), exact in mpmath
    sa, sb = mp.power(mp.mpf("1.0001"), mp.mpf(tick_lo) / 2), mp.power(mp.mpf("1.0001"), mp.mpf(tick_hi) / 2)
    sp = mp.mpf(int(mp.nint(mp.mpf(sqrt_price) * 2**96))) / 2**96
    sp = max(min(sp, sb), sa)
    exp0 = L * (sb - sp) / (sp * sb)
    exp1 = L * (sp - sa)
    return got, (mp.nstr(exp0, 12), mp.nstr(exp1, 12))

print("=== get_tvl_in_pool (v3) ===")
L = 10**18
for fee, lo, hi, sp, label in [
    (100, 0, 1, 0.99, "fee=100 pool, single position [0,1), price below range"),
    (100, 1, 2, 0.99, "fee=100 pool, single position [1,2), price below range"),
    (100, -2, 2, 1.0, "fee=100 pool, position [-2,2), price at tick 0 (in range)"),
    (3000, -60, 60, 1.0, "control: fee=3000 pool, [-60,60), price at tick 0"),
]:
    got, exp = tvl_case(fee, lo, hi, L, sp)
    print(f"{label}\n   library -> token0={got[0]!r}, token1={got[1]!r}\n   oracle  -> token0={exp[0]}, token1={exp[1]}")

# ---------------------------------------------------------------- get_raw_price (v3)
print("\n=== Uniswap.get_raw_price (v3) ===")
TOK = {"PEPE": 18, "USDT": 6, "WETH": 18}
ORDER = {"PEPE": "0x6982", "USDT": "0xdAC1", "WETH": "0xC02a"}  # real address prefixes decide token0

def raw_price_case(token_in, token_out, human_price_t0_in_t1, t0, t1):
    # sqrtPriceX96 exactly encoding human price of token0 in token1
    raw = Fraction(human_price_t0_in_t1) * Fraction(10**TOK[t1], 10**TOK[t0])
    sqrtX96 = math.isqrt(raw.numerator * 2**192 // raw.denominator)
    class Pool:
        class functions:
            token1 = staticmethod(lambda: Call(t1))
            slot0 = staticmethod(lambda: Call([sqrtX96, 0, 0, 0, 0, 0, True]))
    class Self:
        version = 3
        w3 = type("W", (), {"to_checksum_address": staticmethod(lambda a: a)})()
        factory_contract = type("FC", (), {"functions": type("F", (), {"getPool": staticmethod(lambda *a: Call("POOL"))})()})()
        def get_token(s, a): return type("T", (), {"decimals": TOK[a]})()
        def get_weth_address(s): return "WETH"
    ns.update(validate_fee_tier=lambda fee, version: fee, ETH_ADDRESS="ETH",
              _load_contract=lambda w3, abi_name, address: Pool)
    got = ns["get_raw_price"](Self(), token_in, token_out, 3000)
    # oracle: exact price from the SAME integer sqrtPriceX96, in Fraction
    p = Fraction(sqrtX96 * sqrtX96, 2**192) * Fraction(10**TOK[t0], 10**TOK[t1])  # token1 per token0, human
    exp = p if token_in == t0 else 1 / p
    return got, float(exp)

for hp in ["0.00000987", "0.0000052", "0.00000049"]:
    for tin, tout in [("PEPE", "USDT"), ("USDT", "PEPE")]:
        try:
            got, exp = raw_price_case(tin, tout, hp, "PEPE", "USDT")
            err = (got - exp) / exp
            print(f"PEPE=${hp}: get_raw_price({tin}->{tout}) library={got!r} oracle={exp!r} rel.err={err:+.2%}")
        except Exception as e:
            print(f"PEPE=${hp}: get_raw_price({tin}->{tout}) library RAISES {type(e).__name__}: {e}")

# ---------------------------------------------------------------- v4 spot price
print("\n=== Uniswap4.get_token_token_spot_price (v4) ===")
src4 = extract(f"{ROOT}/uniswap/uniswap4.py", "Uniswap4", ["get_token_token_spot_price"])
ns4 = dict(ZERO_HOOK="0x0", _str_to_addr=lambda a: a, float=float)
exec(src4["get_token_token_spot_price"], ns4)
for hp in ["0.00000987", "0.00000049"]:
    raw = Fraction(hp) * Fraction(10**6, 10**18)
    sqrtX96 = math.isqrt(raw.numerator * 2**192 // raw.denominator)
    class S4:
        def get_token(s, a): return type("T", (), {"decimals": {"0x6982": 18, "0xdac1": 6}[a]})()
        def stateview_get_slot0(s, *a): return {"sqrtPriceX96": sqrtX96}
    p = Fraction(sqrtX96 * sqrtX96, 2**192) * Fraction(10**18, 10**6)
    for a, b in [("0x6982", "0xdac1"), ("0xdac1", "0x6982")]:
        exp = float(p if a == "0x6982" else 1 / p)
        try:
            got = ns4["get_token_token_spot_price"](S4(), a, b, 3000, 60)
            print(f"PEPE=${hp}: spot({a}->{b}) library={got!r} oracle={exp!r} rel.err={(got-exp)/exp:+.2%}")
        except Exception as e:
            print(f"PEPE=${hp}: spot({a}->{b}) library RAISES {type(e).__name__}: {e} (oracle {exp!r})")
