#!/usr/bin/env python3
"""Check zero-interest whole-life annuity benefit scaling.

The oracle uses a Beta(alpha=2) lifetime on [0, R].  For remaining lifetime
R, E[T] = R/3 and the annuity-due payment count has expectation
sum_{k=0}^{R-1} P(T>k) = (R+1)(2R+1)/(6R).
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import sys
import types
import numpy as np
from decimal import Decimal, getcontext
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VARIANT = sys.argv[1]
SRC = ROOT / "source" / VARIANT
EVIDENCE = ROOT / "evidence"


def install_optional_import_stubs() -> None:
    mpl = types.ModuleType("matplotlib")
    mpl.__path__ = []
    pyplot = types.ModuleType("matplotlib.pyplot")
    for name in (
        "plot", "show", "figure", "subplots", "title", "xlabel", "ylabel",
        "legend", "grid", "hist", "bar", "scatter",
    ):
        setattr(pyplot, name, lambda *args, **kwargs: None)
    mpl.pyplot = pyplot
    sys.modules["matplotlib"] = mpl
    sys.modules["matplotlib.pyplot"] = pyplot

    ipython = types.ModuleType("IPython")
    ipython.__path__ = []
    ipython.get_ipython = lambda: None
    display = types.ModuleType("IPython.display")
    display.display_latex = lambda *args, **kwargs: None
    display.display_pretty = lambda *args, **kwargs: None
    ipython.display = display
    sys.modules["IPython"] = ipython
    sys.modules["IPython.display"] = display


def exact_unit_annuity(remaining: int, discrete: bool) -> Decimal:
    r = Decimal(remaining)
    if discrete:
        return (r + 1) * (2 * r + 1) / (6 * r)
    return r / 3


def close(actual: float, expected: Decimal) -> bool:
    return math.isfinite(actual) and math.isclose(
        actual, float(expected), rel_tol=2e-12,
        abs_tol=2e-12 * max(1.0, abs(float(expected))),
    )


def main() -> None:
    getcontext().prec = 80
    install_optional_import_stubs()
    sys.path.insert(0, str(SRC))
    import actuarialmath  # type: ignore
    from actuarialmath import Annuity  # type: ignore

    assert Path(actuarialmath.__file__).resolve().is_relative_to(SRC.resolve())
    annuity_source = SRC / "actuarialmath" / "annuity.py"
    rows: list[dict[str, object]] = []

    def record(kind: str, actual: float, expected: Decimal,
               params: dict[str, object]) -> None:
        rows.append({
            "kind": kind,
            "params": params,
            "actual": actual,
            "expected": str(expected),
            "passed": close(actual, expected),
        })

    # Exact zero-interest checks. A generic Annuity with explicit Beta(2)
    # survival avoids every special mortality-law shortcut.
    def beta2_model() -> Annuity:
        def survival(x: int, s: float, t: float) -> float:
            remaining = 100 - (x + s)
            time = np.asarray(t)
            return np.where(
                (remaining > 0) & (time >= 0) & (time < remaining),
                ((remaining - time) / remaining) ** 2,
                0.0,
            )

        def density(x: int, s: float, t: float) -> float:
            remaining = 100 - (x + s)
            time = np.asarray(t)
            return np.where(
                (remaining > 0) & (time >= 0) & (time < remaining),
                2 * (remaining - time) / (remaining * remaining),
                0.0,
            )

        return Annuity().set_survival(
            S=survival, f=density, minage=0, maxage=100
        )

    life = beta2_model()
    for x in (10, 40, 70):
        for s in (0, 5):
            remaining = 100 - (x + s)
            for discrete in (False, True):
                unit = exact_unit_annuity(remaining, discrete)
                for b in (0, 1, 2, 7, 1000):
                    actual = life.whole_life_annuity(
                        x=x, s=s, b=b, discrete=discrete
                    )
                    record(
                        "zero_interest_exact",
                        actual,
                        Decimal(b) * unit,
                        {"x": x, "s": s, "remaining": remaining,
                         "b": b, "discrete": discrete},
                    )

    # Positive-interest controls must remain unchanged by the zero-rate repair.
    life_positive = beta2_model().set_interest(i=0.05)
    for x in (10, 40, 70):
        for discrete in (False, True):
            unit = Decimal.from_float(life_positive.whole_life_annuity(
                x=x, b=1, discrete=discrete
            ))
            for b in (0, 1, 2, 7, 1000):
                actual = life_positive.whole_life_annuity(
                    x=x, b=b, discrete=discrete
                )
                record(
                    "positive_interest_scaling_control",
                    actual,
                    Decimal(b) * unit,
                    {"x": x, "b": b, "discrete": discrete, "i": 0.05},
                )

    failures = [row for row in rows if not row["passed"]]
    payload = {
        "variant": VARIANT,
        "source_root": str(SRC.resolve()),
        "annuity_sha256": hashlib.sha256(annuity_source.read_bytes()).hexdigest(),
        "checks": len(rows),
        "failures": len(failures),
        "failure_counts": {
            kind: sum(row["kind"] == kind for row in failures)
            for kind in sorted({str(row["kind"]) for row in rows})
        },
        "sample_failures": failures[:8],
        "rows": rows,
    }
    EVIDENCE.mkdir(exist_ok=True)
    out = EVIDENCE / f"{VARIANT}.json"
    out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: payload[k] for k in (
        "variant", "annuity_sha256", "checks", "failures", "failure_counts"
    )}, sort_keys=True))


if __name__ == "__main__":
    main()
