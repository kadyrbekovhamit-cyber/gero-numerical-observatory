# actuarialmath zero-interest whole-life annuity benefit audit

- Upstream commit: `7d18f11ad304898f177b7922b3c53f70e4c2b4f4`
- Official release checked: PyPI 1.1.0
- Developer report: https://github.com/terence-lim/actuarialmath/issues/10
- Comparisons per variant: 90

Run `verify.py` for `current`, `release`, `candidate` and `restored` with Python 3.12, NumPy, SciPy and pandas. Plotting and notebook-display imports are stubbed because the checked numerical methods do not use them.
