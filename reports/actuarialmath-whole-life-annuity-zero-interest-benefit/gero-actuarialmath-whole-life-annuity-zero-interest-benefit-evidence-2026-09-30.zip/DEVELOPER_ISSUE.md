## Describe the bug

`Annuity.whole_life_annuity` ignores the documented benefit amount `b` when
the interest rate is zero. The positive-interest branch multiplies the annuity
factor by `b`; the zero-interest branch returns only the unit-benefit expected
payment count.

Tested on current `main` commit
`7d18f11ad304898f177b7922b3c53f70e4c2b4f4` and the official PyPI 1.1.0
source. Their `annuity.py` files are byte-identical.

## Minimal public-API reproduction

This example uses the generic `Annuity` class with a Beta(2) survival law, so
it does not depend on the separate `Uniform` or `Beta` shortcut code.

```python
from actuarialmath import Annuity

def S(x, s, t):
    R = 100 - (x + s)
    return ((R - t) / R) ** 2 if 0 <= t < R else 0

life = Annuity().set_survival(S=S, maxage=100).set_interest(i=0)

print(life.whole_life_annuity(40, b=7, discrete=False))
# observed: 20.0
# expected: 140.0

print(life.whole_life_annuity(40, b=0, discrete=False))
# observed: 20.0
# expected: 0.0
```

For remaining lifetime `R=60`,

```text
E[T] = integral_0^60 ((60-t)/60)^2 dt = 20,
```

so a continuous payment rate of 7 has EPV `7 * 20 = 140`.

## Cause and candidate correction

```diff
@@ Annuity.whole_life_annuity
-return discrete + self.e_x(x=x, s=s, curtate=discrete)
+return b * (discrete + self.e_x(x=x, s=s, curtate=discrete))
```

## Executed verification

I checked one explicit finite-support Beta(2) survival model with
`x={10,40,70}`, `s={0,5}`, continuous and annual-due payments, and
`b={0,1,2,7,1000}`. The exact oracles are `R/3` for the continuous unit
annuity and `(R+1)(2R+1)/(6R)` for the annual-due unit annuity. I also retained
30 positive-interest (`i=0.05`) scaling controls.

- current source: 48 failures / 90 comparisons;
- PyPI 1.1.0 source: 48 / 90;
- one-line candidate: 0 / 90;
- restored source: 48 / 90.

Exactly the 48 zero-interest rows with `b != 1` change; the other 42 rows are
bit-identical. Applying the patch to a fresh copy matches the candidate file,
and reversing it restores the original source byte-for-byte.

The bounded duplicate review covered all nine upstream issue/PR records,
their comments, focused GitHub issue/code searches, source history and the
adjacent GERO reports. No exact prior report was found. Issue #4 concerns
`ConstantForce.whole_life_insurance`; #7 concerns `Annuity.a_x`; #9 explicitly
excluded this observation. This is not a worldwide-priority claim.

Scope is limited to nonnegative constant benefits, one explicit survival law,
zero interest and positive-interest controls. I did not run the full upstream
suite or measure an insurer deployment, policyholder loss, reserve error or
regulatory impact.

Environment: Python 3.12.13, NumPy 2.5.3, SciPy 1.18.1, pandas 3.0.6,
macOS arm64, one numerical worker. The investigation and writing were
AI-assisted; the stated outputs come from executed public code and an
independent closed-form oracle.
