"""Bounded comparison, extracted upstream methods with framework doubles only."""
from pathlib import Path
import ast, math, types, datetime, json
from decimal import Decimal, ROUND_HALF_UP
P=Path(__file__).resolve().parent
original=P/'evidence/frappe-lending-quarterly-day-count/evidence/source/lending/loan_management/doctype/loan_repayment_schedule'
def methods(schedule,utils):
    ns={'math':math,'frappe':types.SimpleNamespace(db=types.SimpleNamespace(get_default=lambda _:2)),
        'cint':lambda x:int(x or 0),'flt':lambda x,p=None:round(float(x or 0),p) if p is not None else float(x or 0),
        'date_diff':lambda a,b:(a-b).days}
    for path,names in [(schedule,{'get_days_and_months','get_non_monthly_days'}),(utils,{'get_amounts','round_emi'})]:
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.FunctionDef) and node.name in names:
                exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),ns)
    return ns
dates=[datetime.date(y,m,1) for y,m in [(2026,4),(2026,7),(2026,10),(2027,1),(2027,4),(2027,7),(2027,10),(2028,1)]]
results={}
for version,schedule,utils in [('16.6.0',original/'loan_repayment_schedule.py',original/'utils.py'),('16.6.1',P/'release-source.py',P/'release-utils.py')]:
    ns=methods(schedule,utils); start=datetime.date(2026,1,1)
    obj=types.SimpleNamespace(repayment_frequency='Quarterly',repayment_start_date=dates[0],posting_date=start)
    obj.get_non_monthly_days=types.MethodType(ns['get_non_monthly_days'],obj)
    rows=[];previous=start
    for date in dates:
        args=[obj,date,0,1_000_000,12,'repayment_schedule',100,100]
        if version=='16.6.1':args.append(previous)
        days,den=ns['get_days_and_months'](*args)
        expected=(date-previous).days
        rows.append({'date':date.isoformat(),'days':days,'expected_days':expected,'denominator':den})
        previous=date
    expected=(Decimal(1_000_000)*Decimal('0.12')*Decimal(91)/Decimal(365)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    day_count=rows[1]['days'];actual=ns['get_amounts'](1_000_000,12,day_count,365,142456)[0]
    results[version]={'rows':rows,'day_count_mismatches':sum(r['days']!=r['expected_days'] for r in rows),'isolated_period_interest':actual,'decimal_reference':str(expected)}
assert results['16.6.0']['day_count_mismatches']==7
assert results['16.6.1']['day_count_mismatches']==0
assert results['16.6.0']['isolated_period_interest']==986.30
assert results['16.6.1']['isolated_period_interest']==29917.81
saved=json.loads((P/'evidence/frappe-lending-quarterly-day-count/evidence/original-result.json').read_text())
assert saved==json.loads((P/'replay-original.json').read_text())
receipt={'scope':'Unchanged extracted upstream methods, minimal framework doubles; no full site/database/upstream suite or production data. Isolated balance remains constant deliberately, not a reconstructed amortization schedule.','versions':results,'original_replay_matches_saved':True}
(P/'release-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
