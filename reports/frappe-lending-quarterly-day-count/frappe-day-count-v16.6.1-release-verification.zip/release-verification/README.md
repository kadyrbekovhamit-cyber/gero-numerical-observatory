# Frappe Lending 16.6.1 release verification

Run `python3 verify_release.py` with standard-library Python. It compares eight calendar intervals using unchanged upstream methods extracted with AST and minimal framework doubles. Expected day-count failures: 7 in16.6.0,0 in16.6.1. This does not start a site/database or run the upstream suite.

`evidence/` is the already public, source-pinned original package. Original report CC BY4.0; GERO replay MIT; upstream sources GPL-3.0, original LICENSE retained. The original archive is unmodified. Public upstream contributor credit remains Nihantra Patel/Frappe. No private correspondence included.
