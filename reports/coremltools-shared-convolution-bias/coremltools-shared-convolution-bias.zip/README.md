# Reproduction package

Upstream PR: https://github.com/apple/coremltools/pull/2901

Checkout apple/coremltools at a207b1a3452eafe02f2d870f486287834af2c82d. The patch includes six graph tests. Run `python -m pytest coremltools/converters/mil/mil/passes/tests/test_fuse_conv_bias_shared_const.py`, first with the test file alone, then with the source fix. `python runtime_repro.py` runs the independent CPU witness on macOS. Use a compatible coremltools runtime and numpy; tests also need the upstream development dependencies.

Do not treat this synthetic example as evidence of production losses. Report CC BY 4.0; runtime witness MIT; upstream source and proposed upstream patch retain BSD-3-Clause terms.
