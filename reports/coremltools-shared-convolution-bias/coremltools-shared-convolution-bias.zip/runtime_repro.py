"""Two 1x1 convolutions minus a shared offset; macOS Core ML CPU, no GPU/ANE."""
import json
import platform
import sys
import numpy as np
import coremltools as ct
from coremltools.converters.mil import Builder as mb

channels = 128
x = np.array([[[[1, 2], [3, 4]]]], dtype=np.float32)
offset = np.arange(1, channels + 1, dtype=np.float32).reshape(1, channels, 1, 1)

def program():
    @mb.program(input_specs=[mb.TensorSpec(shape=(1, 1, 2, 2))], opset_version=ct.target.iOS17)
    def p(x):
        a = mb.conv(x=x, weight=np.ones((channels, 1, 1, 1), dtype=np.float32))
        b = mb.conv(x=x, weight=np.full((channels, 1, 1, 1), 2, dtype=np.float32))
        return mb.sub(x=a, y=offset.copy(), name="out_a"), mb.sub(x=b, y=offset.copy(), name="out_b")
    return p

result = {"version": ct.__version__, "source": ct.__file__, "macOS": platform.mac_ver()[0], "compute_units": "CPU_ONLY", "precision": "FLOAT32", "pipelines": {}}
for name, pipeline in [("EMPTY", ct.PassPipeline.EMPTY), ("DEFAULT", ct.PassPipeline.DEFAULT)]:
    model = ct.convert(program(), convert_to="mlprogram", pass_pipeline=pipeline,
                       compute_units=ct.ComputeUnit.CPU_ONLY,
                       minimum_deployment_target=ct.target.iOS17, compute_precision=ct.precision.FLOAT32)
    actual = model.predict({"x": x})
    errors = {}
    for output, multiplier in [("out_a", 1), ("out_b", 2)]:
        expected = multiplier * x.astype(np.float64) - offset.astype(np.float64)
        errors[output] = float(np.max(np.abs(actual[output].astype(np.float64) - expected)))
    result["pipelines"][name] = errors
    del model
print(json.dumps(result, indent=2))
if len(sys.argv) > 1:
    from pathlib import Path
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2))
