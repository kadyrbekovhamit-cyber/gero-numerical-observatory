# Reproduction package

Pinned source: 90c7b3532499b662e57b5be2275a848ce90d5a70.

https://github.com/casact/chainladder-python/pull/1491

The patches include regression tests. Apply each patch to a separate checkout of the pinned source. To observe failure before the fix, apply only the new test file first. The patch itself then makes the reported regressions pass. Run `python public_api_repro.py` with the selected checkout on PYTHONPATH. See VERIFICATION.json for scope and original/patched outcomes. These are synthetic examples. Report CC BY 4.0; original reproduction MIT; upstream code and patches retain MPL-2.0 terms. AI assistance disclosed.
