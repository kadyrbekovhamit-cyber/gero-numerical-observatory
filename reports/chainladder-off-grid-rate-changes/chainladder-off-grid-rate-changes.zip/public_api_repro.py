"""Public API witness; exact reference for the wholly pre-change year."""
from fractions import Fraction
import json
import chainladder as cl
kw = dict(start_date="2000-01-01", end_date="2003-12-31", grain="Y")
results={}
for grain in ("M", "D"):
    df=cl.parallelogram_olf([0.20], ["2001-07-15"], approximation_grain=grain, **kw)
    results[grain]={str(k):float(v) for k,v in df["OLF"].items()}
print(json.dumps({"version":cl.__version__,"exact_2000_factor":str(Fraction(6,5)),"results":results},indent=2))
