def test_ndcg_at_k():
    # normal cases
    data = pd.DataFrame([
        {"target": [], "prediction": [], "k": [3], "ndcg": 1},  # no error is made
        {"target": [], "prediction": ["1", "2"], "k": [3], "ndcg": 0},
        {"target": ["1"], "prediction": [], "k": [3], "ndcg": 0},
        {"target": ["1"], "prediction": ["1"], "k": [3], "ndcg": 1},
        {"target": ["1"], "prediction": ["2"], "k": [3], "ndcg": 0},
    ])
    predictions = data["prediction"]
    targets = data["target"]
    result = ndcg_at_k(3).eval_fn(predictions, targets)
    assert ndcg_at_k(3)(predictions=predictions, targets=targets) == result

    assert result.scores == data["ndcg"].to_list()
    assert pytest.approx(result.aggregate_results["mean"]) == 0.4
    assert pytest.approx(result.aggregate_results["p90"]) == 1.0
    assert pytest.approx(result.aggregate_results["variance"]) == 0.24

    # test different k values
    predictions = pd.Series([["1", "2"]])
    targets = pd.Series([["1"]])
    ndcg = [1, 1, 1]
    for i in range(3):
        k = i + 1
        result = ndcg_at_k(k).eval_fn(predictions, targets)
        assert pytest.approx(result.scores[0]) == ndcg[i]

    # test different k values and prediction orders
    predictions = pd.Series([["2", "1", "3"]])
    targets = pd.Series([["1", "2", "3"]])
    ndcg = [1, 1, 1, 1]
    for i in range(4):
        k = i + 1
        result = ndcg_at_k(k).eval_fn(predictions, targets)
        assert pytest.approx(result.scores[0]) == ndcg[i]

    # test different k values
    predictions = pd.Series([["4", "5", "1"]])
    targets = pd.Series([["1", "2", "3"]])
    ndcg = [0, 0, 0.2346394, 0.2346394]
    for i in range(4):
        k = i + 1
        result = ndcg_at_k(k).eval_fn(predictions, targets)
        assert pytest.approx(result.scores[0]) == ndcg[i]

    # test duplicate predictions
    predictions = pd.Series([["1", "1", "2", "5", "5"], ["1_1", "1_2", "2", "5", "6"]])
    targets = pd.Series([["1", "2", "3"], ["1_1", "1_2", "2", "3"]])
    for i in range(4):
        k = i + 1
        result = ndcg_at_k(k).eval_fn(predictions, targets)
        # row 1 and 2 have the same ndcg score
        assert pytest.approx(result.scores[0]) == pytest.approx(result.scores[1])

    # test duplicate targets
    predictions = pd.Series([["1", "2", "3"], ["1", "2", "3"]])
    targets = pd.Series([["1", "1", "1"], ["1"]])
    for i in range(4):
        k = i + 1
        result = ndcg_at_k(k).eval_fn(predictions, targets)
        # row 1 and 2 have the same ndcg score
        assert pytest.approx(result.scores[0]) == pytest.approx(result.scores[1])

    predictions = pd.Series([["c", "c", "c"]])
    targets = pd.Series([["a", "b"]])
    result = ndcg_at_k(k=3).eval_fn(predictions, targets)
    assert result.scores[0] == 0.0
