"""Replay released/public MLflow metric and pinned helper; no external services."""
import os
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
os.environ["MLFLOW_ENABLE_TELEMETRY"] = "false"
os.environ["MLFLOW_DISABLE_AGENT_HINT"] = "1"
import ast
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import platform
import warnings
from collections import Counter

import pandas as pd
import mlflow
from mlflow import metrics
from mlflow.metrics import metric_definitions as release_module
from threadpoolctl import threadpool_info, threadpool_limits

warnings.filterwarnings("ignore", category=FutureWarning)
ROOT = Path(__file__).resolve().parent
E = ROOT / "evidence"
OUT = Path(os.environ.get("GERO_REPLAY_OUTPUT", str(E)))
OUT.mkdir(parents=True, exist_ok=True)
CURRENT = E / "mlflow-source/mlflow/metrics/metric_definitions.py"
CANDIDATE = E / "candidate-metric_definitions.py"


def oracle(predictions, targets, k):
    ground_truth = set(targets)
    retrieved = predictions[:k]
    if not ground_truth:
        return 0.0 if predictions else 1.0
    if not predictions:
        return 0.0
    dcg = sum((1 / math.log2(position + 2)) for position, doc in enumerate(retrieved) if doc in ground_truth)
    extra_relevant_occurrences = sum(max(0, predictions[:k].count(doc) - 1) for doc in ground_truth)
    ideal_relevant_count = min(k, len(ground_truth) + extra_relevant_occurrences)
    ideal = sum(1 / math.log2(position + 2) for position in range(ideal_relevant_count))
    return dcg / ideal


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


source = CURRENT.read_text()
tree = ast.parse(source)
helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_expand_duplicate_retrieved_docs")
lines = source.splitlines(keepends=True)
replacement = """def _expand_duplicate_retrieved_docs(predictions, targets):
    original_targets = frozenset(targets)
    expanded_targets = {(doc_id, 1) for doc_id in original_targets}
    counter = {}
    expanded_predictions = []
    for doc_id in predictions:
        counter[doc_id] = counter.get(doc_id, 0) + 1
        occurrence_id = (doc_id, counter[doc_id])
        expanded_predictions.append(occurrence_id)
        if doc_id in original_targets:
            expanded_targets.add(occurrence_id)
    return expanded_predictions, expanded_targets
"""
CANDIDATE.write_text("".join(lines[:helper.lineno - 1]) + replacement + "".join(lines[helper.end_lineno:]))

cases = [
    {"family": "minimal_rename", "predictions": ["a", "a_bc574ae_2", "a"], "targets": ["a"], "k": 3},
    {"family": "minimal_rename_control", "predictions": ["a", "b", "a"], "targets": ["a"], "k": 3},
    {"family": "irrelevant_collision", "predictions": ["a", "a", "z"], "targets": ["a_bc574ae_2"], "k": 3},
    {"family": "irrelevant_collision_control", "predictions": ["a", "a", "z"], "targets": ["b"], "k": 3},
]
ids = ["a", "b", "a_bc574ae_2", "b_bc574ae_2"]
for predictions in itertools.product(ids, repeat=3):
    for size in [1, 2]:
        for targets in itertools.combinations(ids, size):
            cases.append({"family": "collision_grid", "predictions": list(predictions), "targets": list(targets), "k": 3})
for base in ["a", "", "7", 7]:
    for repetition in [2, 3, 4]:
        synthetic = f"{base}_bc574ae_{repetition}"
        for position in range(repetition + 1):
            predictions = [base] * repetition
            predictions.insert(position, synthetic)
            for targets in [[base], [synthetic], [base, synthetic], [base, base]]:
                cases.append({"family": "occurrence_grid", "predictions": predictions, "targets": targets, "k": len(predictions)})
for predictions in itertools.product([1, "1", 2, "2"], repeat=3):
    cases.append({"family": "mixed_id_control", "predictions": list(predictions), "targets": [1, "2", "2"], "k": 3})
for predictions, targets in [([], []), ([], ["a"]), (["a", "b"], []), (["a", "b"], ["a", "a"]), (["a", "a", "b"], ["c"])]:
    cases.append({"family": "edge_control", "predictions": predictions, "targets": targets, "k": max(len(predictions), 1)})

# Add bijectively renamed controls preserving all original ID equalities and ranks.
original_count = len(cases)
for row in list(cases):
    universe = list(dict.fromkeys(row["predictions"] + row["targets"]))
    mapping = {doc: f"safe-id-{i}" for i, doc in enumerate(universe)}
    cases.append({"family": "renamed_control", "predictions": [mapping[d] for d in row["predictions"]], "targets": [mapping[d] for d in row["targets"]], "k": row["k"]})
(OUT / "mlflow-inputs.json").write_text(json.dumps(cases, indent=2) + "\n")

modules = {"release": release_module, "current": load_module(CURRENT, "gero_current_metrics"), "candidate": load_module(CANDIDATE, "gero_candidate_metrics"), "restored": load_module(CURRENT, "gero_restored_metrics")}
summary = {"version": mlflow.__version__, "python": platform.python_version(), "platform": platform.platform(), "source_pin": json.loads((E / "mlflow-head.json").read_text())["sha"], "source_sha256": hashlib.sha256(CURRENT.read_bytes()).hexdigest(), "release_source_sha256": hashlib.sha256(Path(release_module.__file__).read_bytes()).hexdigest(), "cases": len(cases), "rename_pairs": original_count, "single_worker": True, "gpu": False, "production_service_tested": False, "modes": {}}
with threadpool_limits(limits=1):
    for mode, module in modules.items():
        observed = []
        for i, row in enumerate(cases):
            fn = metrics.ndcg_at_k(row["k"]).eval_fn if mode == "release" else module._ndcg_at_k_eval_fn(row["k"])
            result = fn(pd.Series([row["predictions"]]), pd.Series([row["targets"]]))
            value = float(result.scores[0])
            expected = oracle(row["predictions"], row["targets"], row["k"])
            observed.append({"id": i, "family": row["family"], "actual": value, "expected": expected, "failed": not math.isclose(value, expected, abs_tol=1e-12, rel_tol=1e-12)})
        out = OUT / f"mlflow-observed-{mode}.json"
        out.write_text(json.dumps(observed, indent=2) + "\n")
        failures = [r for r in observed if r["failed"]]
        rename_failures = sum(not math.isclose(observed[i]["actual"], observed[i + original_count]["actual"], abs_tol=1e-12, rel_tol=1e-12) for i in range(original_count))
        summary["modes"][mode] = {"failures": len(failures), "rename_failures": rename_failures, "by_family": dict(Counter(r["family"] for r in failures)), "output_sha256": hashlib.sha256(out.read_bytes()).hexdigest(), "first_four": observed[:4]}
        print(mode, summary["modes"][mode]["failures"], "rename", rename_failures, flush=True)
    summary["threadpools"] = threadpool_info()
    assert all(p["num_threads"] == 1 for p in summary["threadpools"]), summary["threadpools"]
assert (OUT / "mlflow-observed-current.json").read_bytes() == (OUT / "mlflow-observed-restored.json").read_bytes()
assert summary["modes"]["candidate"]["failures"] == 0, summary
assert summary["modes"]["candidate"]["rename_failures"] == 0, summary
summary["current_restored_byte_identical"] = True
summary["release_api_deprecated"] = True
summary["current_public_factory_removed"] = "def ndcg_at_k(" not in (E / "mlflow-source/mlflow/metrics/__init__.py").read_text()
(OUT / "MLFLOW_REPLAY_RECEIPT.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
