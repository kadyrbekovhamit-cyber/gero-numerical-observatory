### Issues Policy acknowledgement

- [x] I have read and agree to submit bug reports in accordance with the [issues policy](https://github.com/mlflow/mlflow/blob/master/ISSUE_POLICY.md).

### Where did you encounter this bug?

Local machine.

### MLflow version

- Client: official `mlflow-skinny==3.16.1` from PyPI.
- Tracking server: not used.
- Current source checked: `35758a9a954422200034b949176879c2cbbe4a8a`; the entire `mlflow/metrics/metric_definitions.py` is byte-identical to the installed release.

### System information

- macOS 15.5, Apple Silicon, CPU only.
- Python 3.12.14; pandas 3.0.6; numpy 2.5.3; scikit-learn 1.9.1.
- One configured numerical worker; OpenMP pool limited to one thread.

### Describe the problem

`ndcg_at_k` can assign positive relevance to documents absent from the original target set when `_expand_duplicate_retrieved_docs` creates an ID that collides with a real document ID.

For targets `["a_bc574ae_2"]` and predictions `["a", "a", "z"]`, all original retrieved IDs are irrelevant. Expected NDCG@3 is exactly **0**, but the released public API returns **0.6309297535714574**. Renaming the unobserved target to `"b"` restores zero even though the relevance of every retrieved position remains unchanged.

A second example changes only an irrelevant identifier: with targets `["a"]`, predictions `["a", "a_bc574ae_2", "a"]` return **1.0**, while `["a", "b", "a"]` return **0.9197207891481877**. Under the documented duplicate policy both have relevance `[1,0,1]` and expected `(1 + 1/log2(4)) / (1 + 1/log2(3))`.

The API documentation accepts string/integer IDs and defines relevance from the original target IDs. No suffix namespace is reserved. I understand this API has been deprecated since 3.4.0; this report concerns the still-available released API, not the newer GenAI scorers.

### Tracking information

Not a tracking issue; no server, Databricks workspace, model inference, or external data was used.

### Code to reproduce issue

Install `mlflow-skinny==3.16.1`, `pandas==3.0.6`, and `scikit-learn==1.9.1`, then run:

```python
import pandas as pd
from mlflow.metrics import ndcg_at_k

metric = ndcg_at_k(3)
cases = [
    (["a_bc574ae_2"], ["a", "a", "z"]),  # expected 0
    (["b"], ["a", "a", "z"]),            # expected 0
    (["a"], ["a", "a_bc574ae_2", "a"]),  # expected ~0.919720789
    (["a"], ["a", "b", "a"]),            # expected ~0.919720789
]
for targets, predictions in cases:
    result = metric.eval_fn(pd.Series([predictions]), pd.Series([targets]))
    print(result.scores[0])
```

Observed:

```text
0.6309297535714574
0.0
1.0
0.9197207891481877
```

### Stack trace

No exception is raised. The defect is an incorrect returned score; the normal API deprecation warning is expected.

### Other info / logs

The fixed string suffix `_bc574ae_2` shares the namespace with real IDs. A possible correction is to represent **all** IDs internally as `(original_id, occurrence_number)` and evaluate membership against an immutable original target set:

```python
def _expand_duplicate_retrieved_docs(predictions, targets):
    original_targets = frozenset(targets)
    expanded_targets = {(doc_id, 1) for doc_id in original_targets}
    counter = {}
    expanded_predictions = []
    for doc_id in predictions:
        counter[doc_id] = counter.get(doc_id, 0) + 1
        occurrence_id = (doc_id, counter[doc_id])
        expanded_predictions.append(occurrence_id)
        if doc_id in original_targets:
            expanded_targets.add(occurrence_id)
    return expanded_predictions, expanded_targets
```

Local verification used an independent positional DCG oracle: 1,810 scenarios including 905 bijective-renaming pairs. Original/current module: 214 failures; candidate: 0; restored original: the same 214. All 1,596 previously passing cases are exactly unchanged. A second fresh process with `PYTHONHASHSEED=17` reproduced all four output files byte-for-byte. The unchanged upstream `test_ndcg_at_k` function also passes against original/candidate/restored helpers; this is not a claim that the full pytest module or MLflow suite was run.

Related history reviewed: #12361 / #12447 fixed unconditional promotion of irrelevant duplicates. Their relevance guard is already present, but does not prevent this collision. #24541 and proposed fixes #24543/#24545/#24550/#24551/#24553 concern short retrieval lists; the nonempty main cases here have `k <= len(predictions)`, and those patches retain the suffix helper. I found no exact same collision report in the bounded review.

This is synthetic local library evidence. No hosted-service/customer impact or financial loss has been measured. Research and report preparation were AI-assisted; numerical outputs came from the actual implementation.

### Willingness to contribute

Yes. I would be willing to contribute a focused correction and regression tests with guidance from the MLflow community. I will wait for maintainer triage and the `ready` label before opening a PR, as requested by the issue template.

### What component(s) does this bug affect?

- [x] `area/evaluation`: MLflow model evaluation features, evaluation metrics, and evaluation workflows.
