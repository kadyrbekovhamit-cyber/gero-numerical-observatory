import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[key] = "1"
os.environ["MLFLOW_ENABLE_TELEMETRY"] = "false"
os.environ["MLFLOW_DISABLE_AGENT_HINT"] = "1"
import ast, hashlib, importlib.util, json, warnings
from pathlib import Path
import pandas as pd
import pytest
from mlflow.metrics import ndcg_at_k
from mlflow.metrics import metric_definitions as actual
warnings.filterwarnings("ignore", category=FutureWarning)
r=Path(__file__).resolve().parent
e=r/"evidence/disclosure-review"
p=e/"tests/metrics/test_metric_definitions.py"
s=p.read_text();tree=ast.parse(s)
f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=="test_ndcg_at_k")
fragment=ast.get_source_segment(s,f)
(e/"unchanged-upstream-test_ndcg_at_k.py").write_text(fragment+"\n")
original=actual._expand_duplicate_retrieved_docs
spec=importlib.util.spec_from_file_location("candidate",r/"evidence/candidate-metric_definitions.py");candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
rows=[]
for mode,helper in [("original",original),("candidate",candidate._expand_duplicate_retrieved_docs),("restored",original)]:
    actual._expand_duplicate_retrieved_docs=helper
    namespace={"pd":pd,"pytest":pytest,"ndcg_at_k":ndcg_at_k}
    exec(compile(fragment,str(p),"exec"),namespace)
    namespace["test_ndcg_at_k"]()
    rows.append({"mode":mode,"unchanged_upstream_function":"test_ndcg_at_k","result":"passed"})
    print(mode,"passed",flush=True)
actual._expand_duplicate_retrieved_docs=original
(e/"MLFLOW_UPSTREAM_TEST_RECEIPT.json").write_text(json.dumps({"source_file_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"source_fragment_sha256":hashlib.sha256(fragment.encode()).hexdigest(),"results":rows,"scope":"One unchanged upstream NDCG test function executed with real release imports; full pytest module/conftest and full suite not run."},indent=2)+"\n")
