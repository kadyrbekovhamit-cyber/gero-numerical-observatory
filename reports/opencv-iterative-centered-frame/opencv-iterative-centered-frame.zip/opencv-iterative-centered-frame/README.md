# OpenCV iterative PnP: solve near the object instead of a distant origin

Read REPORT_EN.md for scope and limitations. Upstream patch and tests: https://github.com/opencv/opencv/pull/30484.

This package is a source/evidence bundle; it contains no prebuilt executable. No full-library validation claim.
