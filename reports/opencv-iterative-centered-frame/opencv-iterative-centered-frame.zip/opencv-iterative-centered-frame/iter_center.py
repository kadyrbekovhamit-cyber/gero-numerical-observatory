"""Observation F: SOLVEPNP_ITERATIVE with large object-frame offsets, plain and with a guess
0.2 deg off (what solvePnPRansac feeds it). Centred emulation: solve on X-c, t = t' - R c."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from common import project_mp, rot_err_deg, rodrigues_mp
print("cv2", cv2.__version__)
K = np.array([[1000., 0, 640], [0, 1000, 360], [0, 0, 1]])
rng = np.random.default_rng(5)
Xl = rng.uniform(-20, 20, (30, 3)); rv = np.array([1.2, -0.4, 0.3]); R = np.array(rodrigues_mp(rv).tolist(), dtype=float)
def rms(X, r, t, img): return np.sqrt(((project_mp(X, r, t, K) - img) ** 2).sum(1).mean())
for mag in [0, 1e4, 1e5, 1e6, 5e6]:
    off = mag * np.array([0.3, 0.9, 0.8]); X = Xl + off
    tv = np.array([0.5, -0.3, 60.0]) - R @ off
    img = project_mp(X, rv, tv, K)
    _, r1, t1 = cv2.solvePnP(X, img, K, None, flags=cv2.SOLVEPNP_ITERATIVE)
    rg = cv2.Rodrigues(cv2.Rodrigues(rv)[0] @ cv2.Rodrigues(np.array([0.0035, 0, 0]))[0])[0]   # 0.2 deg off
    Rg = cv2.Rodrigues(rg)[0]; c0 = X.mean(0); tg = (tv + R @ c0 - Rg @ c0 + 0.05).reshape(3, 1)  # image-consistent guess
    _, r2, t2 = cv2.solvePnP(X, img, K, None, rg.copy(), tg.copy(), True, cv2.SOLVEPNP_ITERATIVE)
    c = X.mean(0)
    _, r3, t3 = cv2.solvePnP(X - c, img, K, None, flags=cv2.SOLVEPNP_ITERATIVE); t3 = t3.ravel() - cv2.Rodrigues(r3)[0] @ c
    print(f"offset {mag:6.0e}: plain rms={rms(X, r1, t1, img):.1e}px | guess-0.2deg rms={rms(X, r2, t2, img):.1e}px rot={rot_err_deg(r2, rv):.1e} | centred rms={rms(X, r3, t3, img):.1e}px")
