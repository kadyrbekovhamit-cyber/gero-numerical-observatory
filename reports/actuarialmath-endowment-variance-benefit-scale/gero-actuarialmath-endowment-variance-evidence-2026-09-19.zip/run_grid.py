from pathlib import Path
import sys,subprocess,os,json,hashlib
from datetime import datetime,timezone
R=Path(__file__).resolve().parent
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',MPLBACKEND='Agg',MPLCONFIGDIR=str(R/'mpl-cache'),XDG_CACHE_HOME=str(R/'cache'))
results={}
for variant in ['baseline','release','candidate','restored','prior_whole_life_fix_only']:
 result=subprocess.run([sys.executable,'-B',str(R/'check_endowment.py'),str(R/'source'/variant),str(R/'evidence'/f'grid-{variant}.json')],env=env,capture_output=True,text=True,timeout=120)
 (R/'evidence'/f'grid-{variant}.log').write_text(result.stdout+result.stderr)
 assert result.returncode==0,(variant,result.stdout,result.stderr)
 results[variant]=json.loads((R/'evidence'/f'grid-{variant}.json').read_text())
 print(variant,results[variant]['cases'],results[variant]['failures'],flush=True)
base=results['baseline'];fixed=results['candidate']
for variant in ['release','restored','prior_whole_life_fix_only']:
 assert base['rows']==results[variant]['rows'],variant
assert fixed['failures']['variance']==0,fixed['failures']
assert all(a['actual'][:2]==b['actual'][:2] for a,b in zip(base['rows'],fixed['rows']))
unchanged=sum(a['actual']==b['actual'] for a,b in zip(base['rows'],fixed['rows']))
for row in json.loads((R/'SOURCE_MANIFEST.json').read_text())['files']:
 assert hashlib.sha256((R/'source/baseline'/row['path']).read_bytes()).hexdigest()==row['sha256']
 assert (R/'source/baseline'/row['path']).read_bytes()==(R/'source/restored'/row['path']).read_bytes()
receipt=dict(verified_at=datetime.now(timezone.utc).isoformat(),cases=base['cases'],failures={k:v['failures'] for k,v in results.items()},first_second_moments_unchanged=True,identical_all_three_outputs=unchanged,original_files_unchanged=91,prior_whole_life_patch_does_not_fix=True,release_target_matches_current=True,scope='Discrete finite-state synthetic endowment contracts; no continuous path/full upstream suite/customer exposure claim.')
(R/'GRID_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
