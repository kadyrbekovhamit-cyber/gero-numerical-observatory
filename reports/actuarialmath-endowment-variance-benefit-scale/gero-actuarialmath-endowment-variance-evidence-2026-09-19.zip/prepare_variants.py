from pathlib import Path
import shutil,difflib,json,hashlib,zipfile
R=Path(__file__).resolve().parent
original=R/'source/baseline';rel='src/actuarialmath/insurance.py'
text=(original/rel).read_text()
start=text.index('    def endowment_insurance(');end=text.index('    def increasing_insurance(',start)
section=text[start:end];old='return self.insurance_variance(A2=A2, A1=A1, b=b)';new='return self.insurance_variance(A2=A2, A1=A1, b=1)'
assert section.count(old)==1
corrected=text[:start]+section.replace(old,new)+text[end:]
prior_old='A1 = self.whole_life_insurance(x, s=s, discrete=discrete)**2'
prior_new='A1 = self.whole_life_insurance(x, s=s, discrete=discrete)'
assert text.count(prior_old)==1
for variant,content in [('candidate',corrected),('restored',corrected.replace(new,old,1)),('prior_whole_life_fix_only',text.replace(prior_old,prior_new))]:
 target=R/'source'/variant
 assert not target.exists(),target
 shutil.copytree(original,target,ignore=shutil.ignore_patterns('__pycache__'))
 (target/rel).write_text(content)
# Whole-file restoration, not just an expectation mutation.
assert (R/'source/restored'/rel).read_bytes()==(original/rel).read_bytes()
(R/'candidate.patch').write_text(''.join(difflib.unified_diff(text.splitlines(True),corrected.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
with zipfile.ZipFile(R/'actuarialmath-1.1.0-py3-none-any.whl') as z:
 for n in z.namelist():
  if n.startswith('actuarialmath/') and not n.endswith('/'):
   assert z.read(n)==(R/'source/release/src'/n).read_bytes(),n
print('Narrow candidate, restored source, prior whole-life control, and official wheel files verified.')
