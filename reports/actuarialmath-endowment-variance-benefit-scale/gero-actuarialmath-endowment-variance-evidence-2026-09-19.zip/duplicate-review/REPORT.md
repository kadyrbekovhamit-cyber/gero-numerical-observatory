# Endowment variance: fresh duplicate and history review

Completed 19 September 2026 at 13:53 Asia/Tashkent / 08:53 UTC.

No exact earlier report or proposed correction was found in the public scope inspected. This is a bounded duplicate review, not proof of priority or a numerical confirmation. Root owns the actual execution.

## Current source and cause

Current main is still 7d18f11ad304898f177b7922b3c53f70e4c2b4f4. Fresh insurance.py Git blob: 19735996e4f69505fd94e1c60eab0a613956b8d2.

[Endowment variance caller](https://github.com/terence-lim/actuarialmath/blob/7d18f11ad304898f177b7922b3c53f70e4c2b4f4/src/actuarialmath/insurance.py#L193) obtains recursive first and second moments using the actual death and endowment benefits. It then passes b again to [insurance_variance](https://github.com/terence-lim/actuarialmath/blob/7d18f11ad304898f177b7922b3c53f70e4c2b4f4/src/actuarialmath/insurance.py#L84), whose contract multiplies the unit-benefit variance by b squared. No documentation authorizing two benefit scalings was found.

The one-year independent oracle remains q*(1-q)*(b-e)^2*v^2. For q=1/4, b=2, e=1 and i=0, the exact result is 3/16. Source analysis predicts 3/4. These are not measurements from this reviewer.

## Fresh issue/PR and comment review

The all-state upstream API returned five records; all bodies were read:
- Closed #1: UDD m-thly documentation. Both comments discuss interest-rate conversion.
- Open PR #2: UDD fractional-age conditioning. Its fresh complete two-file diff modifies fractional.py and adds six density tests.
- Open #3: our published whole-life variance first-moment double square.
- Open #4: our published ConstantForce positive continuous-moment benefit omission.
- Open #5: our published Beta density issue, with its archive-link comment.

The all-state pulls endpoint independently returned only PR #2. Its head is b4c9a78600b3a1edff17e2474661e517e7844e66; base is current main. The full current diff was read and saved, so the historical-diff limitation from the preceding triage is resolved.

The guide repository's all-state issue/PR endpoint returned an empty list.

## Exact indexed searches

All eight GitHub issue/PR searches included title, body and comments, with no state filter. Each response has incomplete_results=false.

| Query scope and terms | Results |
|---|---|
| Main repo: endowment | 1, our Beta issue #5; unrelated density cause |
| Guide repo: variance | 0 |
| Global: actuarialmath + endowment_insurance | 0 |
| Global: actuarialmath + insurance_variance | 1, our whole-life issue #3 |
| Global: endowment_insurance + variance | 0 |
| Global: actuarialmath + endowment + variance | 0 |
| Guide repo: endowment | 0 |
| Global: endowment_insurance | 0 |

The exact query strings and complete returned bodies are saved in SOURCES.json. Three additional domain-limited public-web queries surfaced the author's insurance, m-thly and exam guide pages; none surfaced an identified prior report. Search engines may omit differently phrased or unindexed material.

## Source history

The current-path history API returned nine insurance.py commits. Their full target-file diffs were fetched; relevant bodies and hunks were inspected, including the initial source addition.

| Commit prefix | Date | Effect relevant to review |
|---|---|---|
| d51eebe5 | 2024-01-20 | Example indentation only |
| c1c9756f | 2023-08-08 | A_x integer range conversion and unrelated examples/plot/quantile changes |
| 7c244786 | 2023-07-21 | Documentation/examples; no endowment variance formula correction |
| e79d4843 | 2023-06-24 | A_x numerical integration exception wrapper |
| fba47990 | 2023-06-22 | Documentation/examples |
| 049fc5ac | 2023-06-19 | Import path |
| 4374a8fd | 2023-06-08 | Shared variance helper adds a nonnegative clamp; b squared remains |
| c83e6fe8 | 2023-06-06 | Quantile solver invocation |
| a5d2797a | 2023-06-04 | Initial addition already contains the endowment double-scaling pattern |

[Initial source addition](https://github.com/terence-lim/actuarialmath/commit/a5d2797ac722b6abcb2d1459311b85c20130a018) already calculates benefit-scaled endowment A1/A2 and then calls the helper with b. Later target-file diffs do not correct that branch. This is an old implementation candidate being investigated now, not evidence of a recent regression. History was limited to the current path and returned ancestry, not every fork or alternate historical filename.

## Comparison with GERO's previous publications

Fresh current catalog report blob IDs match the complete reports read during the preceding triage:
- Whole-life variance: b328e70debaf8ea396b674d78ab94fe4c0ae138d.
- ConstantForce benefit scaling: 796a49935174916e53e1a0cdcccf855c67cde976.

The whole-life specialist repository's published candidate.patch was also fetched fresh: blob 6bae40a9c92c10d971221dd9e7fe9dd85f69bb07. It modifies only line 111's extra square and adds 16 tests that call whole_life_insurance. It does not modify or test endowment_insurance.

The original whole-life frozen archive's WORK_STATUS, candidate.patch and reproduce_variance.py were read in the preceding review. They document only whole-life variance; a separate pure-endowment t=0 observation is marked static-only. The archive naturally includes upstream source containing other callers, but that is not a prior report or validation of this endowment cause.

The distinction is structural:
- Published whole-life cause: unit first moment squared before a helper that squares it again.
- Published ConstantForce cause: missing b**moment in the continuous positive-moment shortcut.
- I01 candidate: first and second moments already include b/e, then variance receives an additional b squared.

The I01 LifeTable path invokes neither the old whole-life variance branch nor the ConstantForce class. Both prior patches should therefore be useful negative attribution controls. No new defect count or publication is justified until root confirms the behavior.

## Evidence limits and handoff

All required fresh sources for this bounded refresh completed successfully. Earlier network timeouts are resolved; no source in the scope above remains unavailable. Private/deleted reports, unindexed discussions, every fork, and unrelated branches were not inspected. No global novelty guarantee is made.

SOURCES.json contains the dated current source, five issue/PR bodies, three comments, sole PR metadata and complete diff, empty guide issue list, eight exact search receipts, nine history diffs, fresh prior patch and catalog hashes. Prior archive-read receipts remain at /private/tmp/gero-insurance-triage-20260919/SOURCES.json.

No target execution, release validation, patch application, publication or external message was performed by this reviewer. Root can combine this bounded deduplication result with its independent runtime evidence.
