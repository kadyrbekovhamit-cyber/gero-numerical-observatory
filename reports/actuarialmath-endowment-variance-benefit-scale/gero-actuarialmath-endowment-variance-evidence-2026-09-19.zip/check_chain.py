"""GERO synthetic risk-summary adapter using two real upstream library APIs.
No insurance sale, premium, regulatory capital calculation or real underwriting.
"""
import sys,json,math,hashlib
from pathlib import Path
from fractions import Fraction as F
from statistics import NormalDist
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(source/'src' if (source/'src').exists() else source))
import actuarialmath
from actuarialmath import LifeTable
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)
cases=[dict(id='scaled-benefit',q='0.25',b=100,e=50,N=100,budget=7000),dict(id='zero-death-benefit',q='0.25',b=0,e=100,N=100,budget=7900),dict(id='unit-benefit-control',q='0.25',b=1,e=0,N=100,budget=40),dict(id='deterministic-control',q='0.25',b=100,e=100,N=100,budget=10000)]
results=[]
for c in cases:
 q=F(c['q']);b=F(c['b']);e=F(c['e']);N=c['N'];prob=F(19,20)
 mean=q*b+(1-q)*e;variance=q*(1-q)*(b-e)**2
 life=LifeTable().set_table(q={40:float(q),41:1}).set_interest(i=0)
 args=dict(x=40,t=1,b=c['b'],endowment=c['e'])
 actual_mean=life.endowment_insurance(**args)
 actual_variance=life.endowment_insurance(**args,moment=life.VARIANCE)
 percentile=life.portfolio_percentile(mean=actual_mean,variance=actual_variance,prob=float(prob),N=N)
 ref_percentile=float(mean)*N+NormalDist().inv_cdf(float(prob))*math.sqrt(float(variance)*N)
 # Independent exact discrete distribution, to distinguish approximation from ground truth.
 distribution={}
 for k in range(N+1):
  value=b*k+e*(N-k);mass=F(math.comb(N,k))*q**k*(1-q)**(N-k)
  distribution[value]=distribution.get(value,F(0))+mass
 assert sum(distribution.values())==1
 cumulative=F(0)
 for value,mass in sorted(distribution.items()):
  cumulative+=mass
  if cumulative>=prob:
   exact_quantile=value;break
 report=dict(document_type='GERO SYNTHETIC RISK SUMMARY',id=c['id'],inputs=c,confidence=0.95,mean_per_policy=actual_mean,variance_per_policy=actual_variance,approximate_95_percentile=percentile,maximum_possible_aggregate=float(max(distribution)),method='Upstream Life.portfolio_percentile normal approximation; upstream endowment moments; GERO wiring and document, not a production insurer workflow.')
 d=out/c['id'];d.mkdir(exist_ok=True)
 (d/'risk-summary.json').write_text(json.dumps(report,indent=2)+'\n')
 # Budget monitor consumes serialized output; decision rule is wholly GERO-authored.
 loaded=json.loads((d/'risk-summary.json').read_text())
 decision=dict(rule='GERO example only: normal-approximation 95th percentile <= budget',budget=c['budget'],reported_value=loaded['approximate_95_percentile'],decision='WITHIN_EXAMPLE_LIMIT' if loaded['approximate_95_percentile']<=c['budget'] else 'EXCEEDS_EXAMPLE_LIMIT',excess=max(0,loaded['approximate_95_percentile']-c['budget']))
 (d/'example-decision.json').write_text(json.dumps(decision,indent=2)+'\n')
 expected_decision='WITHIN_EXAMPLE_LIMIT' if ref_percentile<=c['budget'] else 'EXCEEDS_EXAMPLE_LIMIT'
 (d/'risk-summary.html').write_text('<!doctype html><meta charset="utf-8"><title>Synthetic risk summary</title><h1>GERO synthetic risk summary</h1><p>No real insurer, customer or regulatory calculation.</p><pre>'+json.dumps(report,indent=2)+'</pre><h2>Example limit check</h2><pre>'+json.dumps(decision,indent=2)+'</pre>')
 results.append(dict(id=c['id'],actual=report,decision=decision,expected_mean=str(mean),expected_variance=str(variance),reference_normal_95_percentile=ref_percentile,exact_discrete_95_percentile=str(exact_quantile),reference_decision=expected_decision,normal_approximation_difference=ref_percentile-float(exact_quantile),amount_difference=percentile-ref_percentile,decision_matches=decision['decision']==expected_decision,percentile_matches=math.isclose(percentile,ref_percentile,rel_tol=1e-12,abs_tol=1e-9)))
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([dict(id=x['id'],observed=x['actual']['approximate_95_percentile'],expected=x['reference_normal_95_percentile'],exact=x['exact_discrete_95_percentile'],decision=x['decision']['decision'],expected_decision=x['reference_decision']) for x in results]))
