from pathlib import Path
import subprocess,sys,os,json,re
R=Path(__file__).resolve().parent;results={}
for label in ['baseline','release','candidate','restored']:
 env=dict(os.environ);env.update(MPLBACKEND='Agg',MPLCONFIGDIR=str(R/'mpl-cache'),XDG_CACHE_HOME=str(R/'cache'),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R/'source'/label/'src')+os.pathsep+os.environ.get('PYTHONPATH',''))
 p=subprocess.run([sys.executable,'-B',str(R/'test_endowment_variance.py')],env=env,capture_output=True,text=True,timeout=60)
 (R/'evidence'/f'tests-{label}.log').write_text(p.stdout+p.stderr)
 results[label]=dict(returncode=p.returncode,summary=p.stderr.strip().splitlines()[-1],methods=int(re.search(r'Ran (\d+) tests',p.stderr).group(1)),failure_entries=len(re.findall(r'^FAIL:',p.stderr,re.M)))
 assert p.returncode==(0 if label=='candidate' else 1),(label,p.stderr)
 print(label,results[label])
(R/'TEST_RECEIPT.json').write_text(json.dumps(results,indent=2)+'\n')
