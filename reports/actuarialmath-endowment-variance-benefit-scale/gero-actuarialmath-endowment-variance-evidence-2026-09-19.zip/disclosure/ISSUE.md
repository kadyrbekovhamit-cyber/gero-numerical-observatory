Hello Terence,

The `Insurance.endowment_insurance(..., moment=VARIANCE)` caller computes moments with the actual benefits already included, then passes `b` to `insurance_variance`, applying another `b**2`. This is distinct from the whole-life first-moment squaring in #3 and the ConstantForce omission in #4.

Tested: current main `7d18f11ad304898f177b7922b3c53f70e4c2b4f4` and the separately extracted official PyPI 1.1.0 wheel.

### Minimal public-API reproduction

```python
from actuarialmath import LifeTable
life = LifeTable().set_table(q={40: 0.25, 41: 1}).set_interest(i=0)
args = dict(x=40, t=1, b=2, endowment=1)
print(life.endowment_insurance(**args))  # 1.25
print(life.endowment_insurance(**args, moment=2))  # 1.75
print(life.endowment_insurance(**args, moment=life.VARIANCE))
# observed 0.75; exact variance 1.75 - 1.25**2 = 0.1875
```

The payout is exactly 2 with probability 1/4 and 1 with probability 3/4, so no integration or mortality approximation is involved. More generally, the one-year variance is `q*(1-q)*(b-e)**2*v**2`. `b=0,endowment=1` gives observed 0 although the same example has variance 0.1875. Scaling both benefits by c scales the affected result by c**4 instead of c**2.

### Narrow candidate

Only in the `endowment_insurance` variance branch, change:

```diff
- return self.insurance_variance(A2=A2, A1=A1, b=b)
+ return self.insurance_variance(A2=A2, A1=A1, b=1)
```

Keep the shared helper unchanged: other callers provide unit-benefit moments.

An exact Fraction finite-payout oracle over 1,300 discrete scenarios gives 483 variance mismatches on current/release, 0 with this candidate, and 483 when the original line is restored. Positive first/second moments all pass and remain exactly equal in the recorded outputs; 794 complete rows remain identical, with another 23 previously passing rows changing only within the rounding tolerance (at most about 4e-15). Six focused regression methods pass after the change. Applying only the earlier whole-life patch leaves all 483 discrepancies. I did not run the full upstream suite.

### Executed downstream demonstration and limits

Passing the real endowment mean/variance into the real `Life.portfolio_percentile` API for 100 independent policies (one-year death/survival benefits 100/50, q=.25, zero interest) gives a normal-approximation 95th percentile 41862.125661 rather than 6606.121257. The exact binomial percentile is 6600, so the candidate preserves the normal approximation rather than claiming exactness. A disclosed GERO-generated JSON risk summary then changes an example 7000-limit decision; that document/wiring/monitor is our synthetic adapter, not an insurer feature. No real premium, regulatory capital, production exposure or customer loss is claimed.

Fresh bounded duplicate review covered all five issue/PR bodies, comments, PR #2 diff, guide issues, nine target-file history diffs and prior GERO reports. No exact earlier report found; the source pattern is old, not a newly introduced regression. Python 3.12.14, numpy 2.5.3, scipy 1.18.1, pandas 3.0.6 and matplotlib 3.10.8. Reproduction, review and preparation were AI-assisted; numerical outputs were executed locally against the public code. A frozen portable evidence archive will be linked in this same thread after publication.

Thank you,
Xamit Kadirbekov / GERO
