"""Run only from a fresh extracted evidence package with installed dependencies."""
from pathlib import Path
import sys,os,subprocess,zipfile,hashlib,json
R=Path(__file__).resolve().parent
assert sys.version_info>=(3,12)
for row in json.loads((R/'SOURCE_MANIFEST.json').read_text())['files']:
 assert hashlib.sha256((R/'source/baseline'/row['path']).read_bytes()).hexdigest()==row['sha256']
manifest=json.loads((R/'SOURCE_MANIFEST.json').read_text())
wheel=R/manifest['wheel']['filename']
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==manifest['wheel']['digests']['sha256']
release=R/'source/release/src';release.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(wheel) as z:
 for name in z.namelist():
  if name.startswith('actuarialmath/') and not name.endswith('/'):
   p=release/name
   assert p.resolve().is_relative_to(release.resolve())
   p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
env=dict(os.environ)
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS','RAYON_NUM_THREADS']:env[name]='1'
env.update(MPLBACKEND='Agg',MPLCONFIGDIR=str(R/'mpl-cache'),XDG_CACHE_HOME=str(R/'cache'),PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
# Published expected outputs stay immutable; executions write into a separate folder.
(R/'evidence').mkdir(exist_ok=True)
for script in ['prepare_variants.py','run_grid.py','run_chain.py','run_tests.py']:
 subprocess.run([sys.executable,'-B',str(R/script)],env=env,check=True)
for variant in ['baseline','release','candidate','restored','prior_whole_life_fix_only']:
 a=json.loads((R/'expected/evidence'/f'grid-{variant}.json').read_text());b=json.loads((R/'evidence'/f'grid-{variant}.json').read_text())
 assert a['rows']==b['rows'] and a['scale']==b['scale'],variant
for variant in ['baseline','release','candidate','restored']:
 assert (R/'expected/downstream'/variant/'RESULTS.json').read_bytes()==(R/'downstream'/variant/'RESULTS.json').read_bytes(),variant
assert json.loads((R/'expected/TEST_RECEIPT.json').read_text())==json.loads((R/'TEST_RECEIPT.json').read_text())
print('PORTABLE REPLAY PASS: all five direct grids, four downstream results and targeted test outcomes reproduce.')
