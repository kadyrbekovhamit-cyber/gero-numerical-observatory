# GERO endowment variance evidence

Public actuarialmath implementation, pinned current source and separately verified official PyPI 1.1.0. See REPORT_EN.md for claims, measured downstream scope, source URLs and limits. No real insurer or customer records are present. Upstream source retains its original MIT license; GERO-authored scripts/reports are MIT licensed (LICENSE-GERO.txt).

Use a fresh extracted copy and Python 3.12. Install the exact direct dependencies in an isolated virtual environment:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-repro.txt
.venv/bin/python -B reproduce_portable.py
```

The replay does not fetch upstream, send messages, create posts or play audio. Installing dependencies requires network; all tested upstream sources/artifacts and expected numerical outputs are included. Configure one CPU worker, no GPU. The scripts set standard numerical-library thread variables; this is not an OS-wide CPU cap. On the documented macOS arm64 environment the replay compares grid rows and downstream JSON exactly; other platforms can have floating-point differences and must be reviewed rather than assumed identical.

Inputs: finite synthetic discrete lifetime tables, benefits and interest rates. The independent Fraction oracle directly enumerates payout outcomes. The narrow candidate modifies only the endowment variance caller; the package recreates baseline, official release, candidate, restored source and earlier-whole-life-patch-only control in separate processes. Six regression methods test boundary behavior, scaling and the unchanged shared helper. Original source regressions are expected to fail; the wrapper checks those failures.

Expected raw outputs are under expected/. Generated outputs are under evidence/ and downstream/. Synthetic risk-summary JSON/HTML and its limit checker are GERO adapters. The portfolio-percentile calculation is the real library's normal approximation; exact binomial percentiles are separately enumerated. No production underwriting, premium, reserve/solvency requirement or loss claim.

See SOURCE_MANIFEST.json, GRID_RECEIPT.json, DOWNSTREAM_RECEIPT.json, TEST_RECEIPT.json and SHA256SUMS. A ZIP checksum is stored in the outer publication receipt. Old GERO findings and PyLoan archives remain separate and unchanged.
