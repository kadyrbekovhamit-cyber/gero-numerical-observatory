"""Independent finite-state Fraction oracle against unmodified public library APIs."""
import sys,json,math,hashlib,importlib.metadata,platform
from pathlib import Path
from fractions import Fraction as F
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2])
sys.path.insert(0,str(source/'src' if (source/'src').exists() else source))
import actuarialmath
from actuarialmath import LifeTable
assert Path(actuarialmath.__file__).resolve().is_relative_to(source)
profiles=[([q,'1'],1) for q in ['0','0.01','0.1','0.25','0.5','0.9','1']]
profiles += [(q,t) for q in [['0.1','0.2','0.3','1'],['0','0','0','1']] for t in [1,2,3]]
rows=[]
for qs,t in profiles:
 for rs in ['0','0.01','0.05','0.2']:
  q=[F(x) for x in qs];v=1/(1+F(rs))
  life=LifeTable().set_table(q={40+k:float(x) for k,x in enumerate(q)}).set_interest(i=float(F(rs)))
  for b in [0,1,2,100,100000]:
   for e_arg in [0,1,2,100,-1]:
    e=b if e_arg<0 else e_arg
    survival=F(1);outcomes=[]
    for k in range(t):
     outcomes.append((survival*q[k],F(b)*v**(k+1)))
     survival*=1-q[k]
    outcomes.append((survival,F(e)*v**t))
    assert sum(p for p,z in outcomes)==1
    mean=sum(p*z for p,z in outcomes);second=sum(p*z*z for p,z in outcomes)
    variance=sum(p*(z-mean)**2 for p,z in outcomes)
    assert variance==second-mean*mean
    actual=[life.endowment_insurance(40,t=t,b=b,endowment=e_arg,moment=m) for m in [1,2,life.VARIANCE]]
    expected=[mean,second,variance]
    tolerances=[256*sys.float_info.epsilon*max(1,b,e),256*sys.float_info.epsilon*max(1,b*b,e*e),256*sys.float_info.epsilon*max(1,b*b,e*e)]
    flags=[math.isfinite(a) and abs(a-float(x))<=tol for a,x,tol in zip(actual,expected,tolerances)]
    support=[z for p,z in outcomes if p>0];upper=(max(support)-min(support))**2/4
    rows.append(dict(q=qs,t=t,rate=rs,b=b,endowment_argument=e_arg,exact=[str(x) for x in expected],actual=actual,tolerances=tolerances,passes=flags,variance_bound=float(upper),bound_pass=actual[2]<=float(upper)+tolerances[2]))
# Fixed physical distribution represented in units and hundredths.
scale=[]
life=LifeTable().set_table(q={40:.25,41:1}).set_interest(i=0)
for factor in [1,2,10,100]:
 value=life.endowment_insurance(40,t=1,b=2*factor,endowment=factor,moment=life.VARIANCE)
 scale.append(dict(scale=factor,variance=value,converted_variance=value/(factor*factor),expected_variance=float(F(3,16)*factor*factor)))
result=dict(source=str(source),imported_from=actuarialmath.__file__,source_pin='7d18f11ad304898f177b7922b3c53f70e4c2b4f4',python=sys.version,platform=platform.platform(),dependencies={x:importlib.metadata.version(x) for x in ['numpy','scipy','pandas','matplotlib','ipython']},cases=len(rows),failures=dict(mean=sum(not r['passes'][0] for r in rows),second=sum(not r['passes'][1] for r in rows),variance=sum(not r['passes'][2] for r in rows),bound=sum(not r['bound_pass'] for r in rows)),rows=rows,scale=scale,scope='Finite discrete endowment payouts; no commercial product or actual customer inspected.')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['cases','failures','scale']}))
assert result['failures']['mean']==result['failures']['second']==0
