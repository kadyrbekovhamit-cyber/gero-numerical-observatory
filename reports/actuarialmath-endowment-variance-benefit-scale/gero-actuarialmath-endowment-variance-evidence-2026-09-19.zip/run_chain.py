from pathlib import Path
import sys,subprocess,os,json
from datetime import datetime,timezone
R=Path(__file__).resolve().parent;results={}
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',MPLBACKEND='Agg',MPLCONFIGDIR=str(R/'mpl-cache'),XDG_CACHE_HOME=str(R/'cache'))
for v in ['baseline','release','candidate','restored']:
 out=R/'downstream'/v
 p=subprocess.run([sys.executable,'-B',str(R/'check_chain.py'),str(R/'source'/v),str(out)],env=env,capture_output=True,text=True,timeout=45)
 (R/'evidence'/f'chain-{v}.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(v,p.stderr)
 results[v]=json.loads((out/'RESULTS.json').read_text());print(v,p.stdout,flush=True)
for v in ['release','restored']:assert results[v]==results['baseline']
assert all(x['decision_matches'] and x['percentile_matches'] for x in results['candidate'])
assert [x['actual'] for x in results['candidate'][2:]]==[x['actual'] for x in results['baseline'][2:]]
receipt=dict(verified_at=datetime.now(timezone.utc).isoformat(),case_count=4,percentile_mismatches={k:sum(not x['percentile_matches'] for x in v) for k,v in results.items()},decision_mismatches={k:sum(not x['decision_matches'] for x in v) for k,v in results.items()},positive_and_negative_direction=True,real_upstream_components=['LifeTable.endowment_insurance','Life.portfolio_percentile'],gero_components=['parameter wiring','risk-summary JSON/HTML serialization','budget monitor reading JSON'],limits='Synthetic independently distributed finite payouts and arbitrary disclosed example budgets. Native percentile is a normal approximation, not exact quantile. No actual premium, reserve requirement, solvency rule, insurer decision or client loss measured.')
(R/'DOWNSTREAM_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
