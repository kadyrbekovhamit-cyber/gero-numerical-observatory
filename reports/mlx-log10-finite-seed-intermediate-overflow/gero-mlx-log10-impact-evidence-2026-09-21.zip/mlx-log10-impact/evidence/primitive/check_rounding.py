import json
from decimal import Decimal
from pathlib import Path

p = Path(__file__).resolve().parent

def nearest_even(n, d):
    q, r = divmod(n, d)
    return q + int(2 * r > d or (2 * r == d and q % 2 == 1))

def binary32(text):
    value = Decimal(text)
    negative = value.is_signed()
    # copy_abs preserves all digits without applying the ambient Decimal context.
    n, d = value.copy_abs().as_integer_ratio()
    if n == 0:
        return int(negative) << 31
    e = n.bit_length() - d.bit_length()
    if (n < (d << e)) if e >= 0 else ((n << -e) < d):
        e -= 1
    if e < -126:
        fraction = nearest_even(n << 149, d)
        payload = fraction
    else:
        shift = 23 - e
        fraction = nearest_even(n << shift, d) if shift >= 0 else nearest_even(n, d << -shift)
        if fraction == 1 << 24:
            fraction >>= 1
            e += 1
        payload = 0x7f800000 if e > 127 else ((e + 127) << 23) | (fraction - (1 << 23))
    return (int(negative) << 31) | payload

oracle = json.loads((p / 'oracle.json').read_text())
differences = []
for index, row in enumerate(oracle):
    low = binary32(row['reference_80'])
    high = binary32(row['reference_120'])
    assert low == high
    if high != row['expected_bits']:
        differences.append({'id': index, 'direct': high, 'previous': row['expected_bits']})
assert not differences
receipt = {'cases': len(oracle), 'precision_digits': [80, 120], 'method': 'Decimal.as_integer_ratio, integer division, round-to-nearest ties-to-even directly to IEEE binary32, including subnormal and overflow thresholds; no binary64 intermediate.', 'matches_all_saved_expected_bits': True, 'differences': differences}
(p / 'DIRECT_ROUNDING_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
