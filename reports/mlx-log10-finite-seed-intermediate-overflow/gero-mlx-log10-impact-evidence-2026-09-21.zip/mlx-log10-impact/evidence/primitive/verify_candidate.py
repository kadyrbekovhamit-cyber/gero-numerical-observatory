import csv
import difflib
import hashlib
import io
import json
import math
import os
import struct
import subprocess
from datetime import datetime
from decimal import Decimal, localcontext
from pathlib import Path
from zoneinfo import ZoneInfo


p = Path(__file__).resolve().parent
root = Path('/Users/khamit/Documents/Codex/gero-continuous-research/research/mlx-reduction-invariants-2026-09-17')
source = root / 'mlx-59d600b5e64c238427d0f8d897ab7c682ef4d3d2'
library = root / 'build/mlx-build/libmlx.a'
work = p / 'candidate-verification'
work.mkdir(exist_ok=True)
original = (source / 'mlx/primitives.cpp').read_text()
candidate = original
for method, seeds in [('vjp', 'cotangents'), ('jvp', 'tangents')]:
    start = candidate.index(f'std::vector<array> Log::{method}(')
    stop = candidate.index('\n}', start) + 2
    body = candidate[start:stop]
    old = '    out = multiply(array(scale, out.dtype()), out, stream());'
    assert body.count(old) == 1
    new = f'''    auto factor = array(scale, out.dtype());
    auto scaled_out = multiply(factor, out, stream());
    if (base_ == Base::ten && out.dtype() == float32) {{
      auto ratio_overflow = logical_and(
          isinf(out, stream()),
          not_equal(primals[0], array(0.0f), stream()),
          stream());
      auto scaled_first = divide(
          multiply(factor, {seeds}[0], stream()), primals[0], stream());
      out = where(ratio_overflow, scaled_first, scaled_out, stream());
    }} else {{
      out = scaled_out;
    }}'''
    candidate = candidate[:start] + body.replace(old, new) + candidate[stop:]
reuse_objects = {}
for label, text in [('original', original), ('candidate', candidate)]:
    previous = work / f'{label}-primitives.cpp'
    reuse_objects[label] = previous.exists() and previous.read_text() == text and (work / f'{label}.o').exists() and (work / f'compile-{label}.log').exists() and not (work / f'compile-{label}.log').read_text()
    previous.write_text(text)
(work / 'candidate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True), fromfile='a/mlx/primitives.cpp', tofile='b/mlx/primitives.cpp')))

def f32(value):
    try:
        return struct.unpack('f', struct.pack('f', value))[0]
    except OverflowError:
        return math.copysign(math.inf, value)

def bits(value):
    return struct.unpack('I', struct.pack('f', value))[0]

def value(bit_pattern):
    return struct.unpack('f', struct.pack('I', int(bit_pattern)))[0]

cases = [(x['x'], x['v']) for x in json.loads((p / 'oracle.json').read_text())]
seen = {(bits(x), bits(v)) for x, v in cases}
# Boundary inputs on both sides of the true final-overflow threshold.
for x in [0.125, 0.25, 0.375, 0.5, 0.625, 0.75]:
    threshold = value(0x7f7fffff) * x * math.log(10)
    if threshold > value(0x7f7fffff):
        continue
    center = bits(f32(threshold))
    for offset in range(-8, 9):
        for sign in [1, -1]:
            seed = sign * value(center + offset)
            key = (bits(x), bits(seed))
            if key not in seen:
                cases.append((x, seed))
                seen.add(key)
refs = []
for x, v in cases:
    exact = []
    for precision in [80, 120]:
        with localcontext() as ctx:
            ctx.prec = precision
            exact.append(Decimal.from_float(v) / Decimal.from_float(x) / Decimal(10).ln())
    assert bits(f32(float(exact[0]))) == bits(f32(float(exact[1])))
    refs.append({'x': x, 'v': v, 'reference_80': str(exact[0]), 'reference_120': str(exact[1]), 'expected_bits': bits(f32(float(exact[1])))})
(work / 'inputs.txt').write_text(''.join(f'{i} {bits(x)} {bits(v)}\n' for i, (x, v) in enumerate(cases)))
(work / 'oracle.json').write_text(json.dumps(refs, indent=2) + '\n')

common = ['/usr/bin/c++', '-std=c++20', '-O3', '-DNDEBUG', '-DMLX_STATIC', '-DFMT_HEADER_ONLY=1', '-DACCELERATE_NEW_LAPACK', '-DMLX_USE_ACCELERATE', '-I' + str(source), '-I/Users/khamit/Documents/math/software-audits/current-stack-2026-09-07-round3/build-native/_deps/fmt-src/include', '-I/Users/khamit/Documents/math/software-audits/current-stack-2026-09-07-round3/build-native/_deps/json-src/single_include/nlohmann']
commands = []

def run(command, log):
    commands.append(command)
    result = subprocess.run(command, capture_output=True, text=True)
    (work / log).write_text(result.stdout + result.stderr)
    result.check_returncode()

for label in ['candidate', 'original']:
    command = common + ['-c', str(work / f'{label}-primitives.cpp'), '-o', str(work / f'{label}.o')]
    if reuse_objects[label]:
        commands.append({'reused_successful_compile': command, 'source_sha256': hashlib.sha256((work / f'{label}-primitives.cpp').read_bytes()).hexdigest(), 'object_sha256': hashlib.sha256((work / f'{label}.o').read_bytes()).hexdigest()})
    else:
        run(command, f'compile-{label}.log')
run(common + ['-c', str(p / 'grid.cpp'), '-o', str(work / 'grid.o')], 'compile-grid.log')
results = {}
rows_by_variant = {}
for variant, objects in [('original', []), ('candidate', [work / 'candidate.o']), ('restored', [work / 'original.o'])]:
    run(common + [str(work / 'grid.o')] + list(map(str, objects)) + [str(library), '-framework', 'Accelerate', '-o', str(work / variant)], f'link-{variant}.log')
    summaries = {}
    rows_by_variant[variant] = {}
    for layout in ['vector', 'row', 'column']:
        result = subprocess.run([str(work / variant), str(work / 'inputs.txt'), layout], capture_output=True, text=True, check=True)
        (work / f'{variant}-{layout}.csv').write_text(result.stdout)
        rows = list(csv.DictReader(io.StringIO(result.stdout)))
        rows_by_variant[variant][layout] = rows
        problems = {direction: {'finite_to_nonfinite': [], 'nonfinite_to_finite': [], 'finite_accuracy': []} for direction in ['jvp', 'vjp']}
        for row, ref in zip(rows, refs):
            expected = value(ref['expected_bits'])
            for direction in problems:
                actual = value(row[direction + '_bits'])
                if math.isfinite(expected) and not math.isfinite(actual):
                    problems[direction]['finite_to_nonfinite'].append(int(row['id']))
                elif not math.isfinite(expected) and math.isfinite(actual):
                    problems[direction]['nonfinite_to_finite'].append(int(row['id']))
                elif math.isfinite(expected) and abs(actual - expected) > max(abs(expected) * 5e-7, 2 * value(1)):
                    problems[direction]['finite_accuracy'].append(int(row['id']))
        summaries[layout] = problems
    assert rows_by_variant[variant]['vector'] == rows_by_variant[variant]['row'] == rows_by_variant[variant]['column']
    results[variant] = summaries
assert rows_by_variant['original'] == rows_by_variant['restored']
unchanged = {}
for direction in ['jvp', 'vjp']:
    old_bad = set(results['original']['vector'][direction]['finite_to_nonfinite'])
    controls = [(a, b) for a, b in zip(rows_by_variant['original']['vector'], rows_by_variant['candidate']['vector']) if int(a['id']) not in old_bad]
    unchanged[direction] = {'eligible_controls': len(controls), 'bit_identical': sum(a[direction + '_bits'] == b[direction + '_bits'] for a, b in controls)}
receipt = {'at': datetime.now(ZoneInfo('Asia/Tashkent')).isoformat(), 'source_pin': '59d600b5e64c238427d0f8d897ab7c682ef4d3d2', 'unique_inputs': len(cases), 'layouts': 3, 'results': results, 'previous_controls': unchanged, 'restored_exactly_matches_original': True, 'oracle_80_120_agrees': True, 'candidate_scope': 'float32 Log base ten JVP/VJP overflow fallback only; no claim of a complete log derivative correction', 'build_method': 'Compile complete actual primitives.cpp translation unit with narrow diff and link before unchanged full MLX CPU library; restoration links the compiled unmodified translation unit.', 'commands': commands, 'library_sha256': hashlib.sha256(library.read_bytes()).hexdigest(), 'limitations': ['CPU only, no production model/device test.', 'No official release binary executed.', 'Performance overhead not measured.', 'Near-overflow rounding failures are retained in results; candidate is experimental.'], 'gpu': False, 'audio_playback': False, 'thread_environment': {k: os.getenv(k) for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']}}
(work / 'CANDIDATE_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'unique_inputs': len(cases), 'counts': {variant: {direction: {key: len(ids) for key, ids in problem.items()} for direction, problem in summary['vector'].items()} for variant, summary in results.items()}, 'previous_controls': unchanged}, indent=2))
