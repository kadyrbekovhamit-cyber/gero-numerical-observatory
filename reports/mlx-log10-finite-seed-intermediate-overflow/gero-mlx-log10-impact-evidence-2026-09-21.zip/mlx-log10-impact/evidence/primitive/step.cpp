#include "mlx/mlx.h"
#include <bit>
#include <cstdint>
#include <iostream>

namespace mx = mlx::core;
uint32_t bits(float v) { return std::bit_cast<uint32_t>(v); }

int main() {
  mx::set_default_device(mx::Device(mx::Device::cpu));
  mx::array x(0.5f), rate(1.0e-39f);
  auto loss = [](const mx::array& a) {
    return mx::multiply(mx::array(3.2e38f), mx::log10(a));
  };
  auto y = loss(x);
  auto gradient = mx::grad(loss)(x);
  auto next = mx::subtract(x, mx::multiply(rate, gradient));
  mx::eval(y, gradient, next);
  std::cout << "{\"input_bits\":" << bits(x.item<float>())
            << ",\"rate_bits\":" << bits(rate.item<float>())
            << ",\"loss_bits\":" << bits(y.item<float>())
            << ",\"gradient_bits\":" << bits(gradient.item<float>())
            << ",\"next_bits\":" << bits(next.item<float>()) << "}\n";
}
