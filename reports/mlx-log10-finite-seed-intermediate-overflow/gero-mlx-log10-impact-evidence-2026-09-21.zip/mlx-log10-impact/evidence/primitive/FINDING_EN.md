# MLX log10 derivative: finite result lost to an overflowing intermediate

Local confirmation, 21 September 2026. Not submitted upstream or published.

## Result

On current main `59d600b5e64c238427d0f8d897ab7c682ef4d3d2`, actual C++ CPU JVP and VJP for `log10` return infinity for `x=float32(0.5)` and seed `float32(3.2e38)`. The correctly rounded binary32 derivative action is `2.779484577684454e38`, within range. The forward value remains finite.

Both native methods form `seed/x` before multiplication by `1/ln(10)`. The first division overflows even though the complete result is representable. This is a distinct operator observation related to the previously documented erf/rsqrt intermediate-range family; it is not a new kind of floating-point arithmetic or a claim of a newly introduced regression.

## Executed evidence

294 distinct positive finite input / finite seed pairs were evaluated in vector, row and column layouts, with both JVP and VJP. An independent Decimal oracle at 80 and120 digits agrees under direct integer-based IEEE binary32 round-to-nearest ties-to-even conversion. No binary64 intermediate is used in the final rounding audit.

The original produces66 finite-reference/nonfinite-output failures per derivative direction in each layout. These are the same66 inputs across layouts, not198 independent failures or multiple defects. Native outputs are bit-identical across the three layouts.

A narrow experimental float32 fallback is compiled in the full actual `primitives.cpp` translation unit and linked against the otherwise unchanged full CPU library. It removes those66 failures but introduces4 other mismatches at the true final-overflow boundary.224of228 other controls remain bit-identical. Forward bits are unchanged. This is an incomplete candidate, not a ready upstream fix. Restoring and compiling the original translation unit exactly restores the original raw outputs and all66 failures.

## Measured synthetic consequence

The actual MLX loss is `float32(3.2e38)*log10(x)`, with `x=0.5` and the explicitly recorded subnormal rate `float32(1e-39)`. Native autodiff and the parameter update execute in MLX. The original updated parameter is negative infinity; the candidate gives `0.2220514714717865`, matching the rounded independent exact-step value; restoration returns negative infinity.

GERO writes these values to a JSON checkpoint. A separate process reads that file and switches from `REJECT_NONFINITE_CHECKPOINT` to `ACCEPT_FINITE_CHECKPOINT`. The checkpoint format and acceptance policy are GERO demonstration adapters. No trained model accuracy, real user incident, device failure or financial loss is demonstrated.

## Version, novelty and limits

The target methods in official tag v0.32.2 are text-identical to the tested main methods. The existing installed v0.32.2 package was found, but import failed because no Metal device was available; the release binary was not executed and no GPU access/settings changes were attempted.

Bounded searches of open and closed MLX reports found no exact log10 finite-seed overflow match. PR3605 addresses complex conjugation; PR4266 addresses graph equivalence between logarithm bases; their bodies/diffs were reviewed. Earlier GERO activation research covers ELU/GELU/Softplus and is distinct. Searches and current catalog listing are retained. This does not establish absolute novelty.

All numerical work used the shared one-worker lease and configured library thread counts1. No GPU, audio playback, paid call, browser submission or new media. No full repository suite, performance benchmark, other dtype/device guarantee or general correction claim.

## Files and continuation

`CONFIRMATION_RECEIPT.json`, `CANDIDATE_RECEIPT.json`, `STEP_RECEIPT.json`, `DIRECT_ROUNDING_RECEIPT.json` and raw CSV/JSON files contain measured results. `candidate.patch` is experimental; all four residual boundary discrepancies are retained. `RELEASE_CHECK.json` records the failed binary import accurately. Commands and build provenance are in the receipts.

Before any distribution, finish a portable archive replay and contributor-reviewed vendor handoff. MLX permits AI-assisted work but requires understanding, validation and the contributor’s own voice; the local AGENTS file also prohibits automated PR submission and reviewer replies. Do not claim maintainer acceptance or send an unreviewed PR. Existing actuarialmath publication and media queues remain separate.
