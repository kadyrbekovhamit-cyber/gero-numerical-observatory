import base64
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import struct
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

import mlx.core as mx

mx.set_default_device(mx.cpu)
p = Path(__file__).resolve().parent
oracle = json.loads((p / 'oracle.json').read_text())

def bits(v):
    return struct.unpack('I', struct.pack('f', v))[0]

def value(b):
    return struct.unpack('f', struct.pack('I', int(b)))[0]

summaries = {}
outputs = {}
for layout, shape in [('vector', [len(oracle)]), ('row', [1, len(oracle)]), ('column', [len(oracle), 1])]:
    x = mx.reshape(mx.array([r['x'] for r in oracle], dtype=mx.float32), shape)
    v = mx.reshape(mx.array([r['v'] for r in oracle], dtype=mx.float32), shape)
    forward, tangent = mx.jvp(mx.log10, [x], [v])
    _, cotangent = mx.vjp(mx.log10, [x], [v])
    mx.eval(forward, tangent, cotangent)
    arrays = [mx.flatten(a[0]).tolist() for a in [forward, tangent, cotangent]]
    rows = []
    failures = {'jvp': [], 'vjp': []}
    for i, (r, f, j, w) in enumerate(zip(oracle, *arrays)):
        rows.append({'id': i, 'x_bits': bits(r['x']), 'v_bits': bits(r['v']), 'forward_bits': bits(f), 'jvp_bits': bits(j), 'vjp_bits': bits(w)})
        for direction, actual in [('jvp', j), ('vjp', w)]:
            if math.isfinite(value(r['expected_bits'])) and not math.isfinite(actual):
                failures[direction].append(i)
    with (p / f'release-{layout}.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    outputs[layout] = rows
    summaries[layout] = failures
assert outputs['vector'] == outputs['row'] == outputs['column']
x = mx.array(0.5, dtype=mx.float32)
rate = mx.array(1e-39, dtype=mx.float32)
loss = lambda a: mx.array(3.2e38, dtype=mx.float32) * mx.log10(a)
g = mx.grad(loss)(x)
y = loss(x)
updated = x - rate * g
mx.eval(y, g, updated)
file_checks = []
for name in ['mlx', 'mlx-metal']:
    dist = importlib.metadata.distribution(name)
    for f in dist.files:
        if str(f).endswith(('.so', '.dylib')):
            digest = hashlib.sha256(dist.locate_file(f).read_bytes()).digest()
            actual = base64.urlsafe_b64encode(digest).decode().rstrip('=')
            assert f.hash.mode == 'sha256' and f.hash.value == actual
            file_checks.append({'distribution': name, 'path': str(f), 'sha256': digest.hex(), 'matches_installed_RECORD': True})
receipt = {'at': datetime.now(ZoneInfo('Asia/Tashkent')).isoformat(), 'python': sys.version, 'mlx_version': importlib.metadata.version('mlx'), 'mlx_metal_version': importlib.metadata.version('mlx-metal'), 'module_file': mx.__file__, 'device': str(mx.default_device()), 'unique_inputs': len(oracle), 'results': summaries, 'layout_bits_identical': True, 'step': {'loss_bits': bits(y.item()), 'gradient_bits': bits(g.item()), 'next_bits': bits(updated.item())}, 'native_module_RECORD_checks': file_checks, 'package_provenance_note': 'Reused existing installed0.32.2 distributions from previously recorded official-wheel environment. Native files match their installed wheel RECORD; no fresh wheel download or reinstall.', 'gpu': False, 'audio_playback': False, 'thread_environment': {k: os.getenv(k) for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']}}
(p / 'RELEASE_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'version': receipt['mlx_version'], 'device': receipt['device'], 'counts': {k: {d: len(v) for d, v in s.items()} for k, s in summaries.items()}, 'step': receipt['step'], 'native_files_checked': len(file_checks)}, indent=2))
