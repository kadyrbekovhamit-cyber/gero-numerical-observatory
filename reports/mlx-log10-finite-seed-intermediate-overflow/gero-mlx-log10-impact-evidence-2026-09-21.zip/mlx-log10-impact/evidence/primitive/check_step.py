import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
from datetime import datetime
from decimal import Decimal, localcontext
from zoneinfo import ZoneInfo

p = Path(__file__).resolve().parent
base = Path('/Users/khamit/Documents/Codex/gero-continuous-research/research/mlx-reduction-invariants-2026-09-17')
source = base / 'mlx-59d600b5e64c238427d0f8d897ab7c682ef4d3d2'
lib = base / 'build/mlx-build/libmlx.a'
commands = []

def run(command):
    commands.append(command)
    r = subprocess.run(command, capture_output=True, text=True)
    r.check_returncode()
    return r.stdout

def value(bits):
    return struct.unpack('f', struct.pack('I', bits))[0]

def f32(x):
    return struct.unpack('f', struct.pack('f', x))[0]

def serial(x):
    return x if math.isfinite(x) else str(x)

run(['/usr/bin/c++', '-std=c++20', '-O2', '-DMLX_STATIC', '-I' + str(source), '-c', str(p / 'step.cpp'), '-o', str(p / 'step.o')])
results = {}
for variant, objects in [('original', []), ('candidate', [p / 'candidate.o']), ('restored', [p / 'original.o'])]:
    binary = p / ('step-' + variant)
    run(['/usr/bin/c++', str(p / 'step.o')] + list(map(str, objects)) + [str(lib), '-framework', 'Accelerate', '-o', str(binary)])
    raw = json.loads(run([str(binary)]))
    memo = {'variant': variant, 'scope': 'Synthetic single-parameter MLX step; GERO checkpoint adapter, not a real deployed model.', 'input': value(raw['input_bits']), 'learning_rate': value(raw['rate_bits']), 'loss': serial(value(raw['loss_bits'])), 'gradient': serial(value(raw['gradient_bits'])), 'updated_parameter': serial(value(raw['next_bits'])), 'raw_bits': raw}
    file = p / ('checkpoint-' + variant + '.json')
    file.write_text(json.dumps(memo, indent=2, allow_nan=False) + '\n')
    consumer = "import json,math,sys; d=json.load(open(sys.argv[1])); v=float(d['updated_parameter']); print(json.dumps({'decision':'ACCEPT_FINITE_CHECKPOINT' if math.isfinite(v) else 'REJECT_NONFINITE_CHECKPOINT','parameter_read':v if math.isfinite(v) else str(v)}))"
    decision = json.loads(run(['python3', '-B', '-c', consumer, str(file)]))
    (p / ('decision-' + variant + '.json')).write_text(json.dumps(decision, indent=2) + '\n')
    results[variant] = {'checkpoint': memo, 'consumer': decision}
assert results['original']['checkpoint']['raw_bits'] == results['restored']['checkpoint']['raw_bits']
references = []
for precision in [80, 120]:
    with localcontext() as ctx:
        ctx.prec = precision
        x = Decimal.from_float(f32(0.5))
        seed = Decimal.from_float(f32(3.2e38))
        rate = Decimal.from_float(f32(1e-39))
        gradient = seed / (x * Decimal(10).ln())
        exact_next = x - rate * gradient
        references.append({'precision': precision, 'gradient_exact': str(gradient), 'updated_parameter_exact': str(exact_next), 'gradient_f32': f32(float(gradient)), 'updated_parameter_f32': f32(float(exact_next))})
assert references[0]['gradient_f32'] == references[1]['gradient_f32']
assert references[0]['updated_parameter_f32'] == references[1]['updated_parameter_f32']
receipt = {'at': datetime.now(ZoneInfo('Asia/Tashkent')).isoformat(), 'status': 'executed_synthetic_downstream_chain', 'loss': 'float32(3.2e38) * log10(x)', 'reference': references, 'results': results, 'commands': commands, 'source_sha256': hashlib.sha256((p / 'step.cpp').read_bytes()).hexdigest(), 'limitations': ['One synthetic stress-condition step, not a trained model or production system.', 'The JSON checkpoint and accept/reject reader are GERO adapters; the loss, gradient and arithmetic step execute actual MLX C++.', 'Subnormal learning rate is deliberate and recorded as actual float32 bits.', 'Experimental correction has four other boundary mismatches in the separate294-input grid.'], 'thread_environment': {k: os.getenv(k) for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']}, 'audio_playback': False, 'gpu': False}
(p / 'STEP_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'variants': {k: {'gradient': v['checkpoint']['gradient'], 'parameter': v['checkpoint']['updated_parameter'], 'decision': v['consumer']['decision']} for k, v in results.items()}, 'reference': references[1]}, indent=2))
