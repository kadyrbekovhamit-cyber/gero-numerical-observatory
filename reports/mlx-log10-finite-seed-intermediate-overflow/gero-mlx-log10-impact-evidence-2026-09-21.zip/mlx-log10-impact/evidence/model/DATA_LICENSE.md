# Dataset attribution

Alpaydin, E. & Kaynak, C. (1998). Optical Recognition of Handwritten Digits [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C50P49 . Official record: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits . The UCI record licenses these data under CC BY4.0: https://creativecommons.org/licenses/by/4.0/ .

Source copy: scikit-learn load_digits, version recorded in DATASET.json. It contains1797images from the original UCI test subset. We select3and8, retain their labels and original row indices, divide pixels by16 and create a new stratified experimental train/test split. This is not the original writer-independent UCI benchmark. CSV/text format is our export. No endorsement is implied. Scikit-learn software has a separate BSD3-Clause license; no library source is included by this exporter.
