import csv
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
import sklearn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

p = Path(__file__).resolve().parent
work = p / 'classifier-impact'
work.mkdir(exist_ok=True)
base = Path('/Users/khamit/Documents/Codex/gero-continuous-research/research/mlx-reduction-invariants-2026-09-17')
source = base / 'mlx-59d600b5e64c238427d0f8d897ab7c682ef4d3d2'
lib = base / 'build/mlx-build/libmlx.a'
assert hashlib.sha256(lib.read_bytes()).hexdigest() == '616ca266f7ab6a0398764aed5c9cdf417d1194d766383d78b43140b5d71e4603'
plan = {'written_before_training': datetime.now(ZoneInfo('Asia/Tashkent')).isoformat(), 'dataset': 'sklearn load_digits, digits3and8, new split within1797-image UCI test subset', 'split_seed': 20260921, 'test_fraction': 0.3, 'stratify': True, 'features': 'pixel/16 and constant bias1', 'initial_weights': '65zeros', 'pretraining': {'steps': 60, 'full_batch': True, 'sgd_rate': 1.0}, 'selection': {'true_label_probability_bins': [[0.5, 0.65], [0.65, 0.8], [0.8, 0.9]], 'tie_break': 'smallest original dataset id; first two upper endpoints excluded; third included', 'if_empty': 'record unavailable, do not tune split or epochs', 'only_training_data': True}, 'intervention': {'independent_steps_from_same_checkpoint': True, 'loss_scales': ['1', '1e20', '3.2e38'], 'rate': 0.05, 'unscale_gradients_before_sgd': True, 'guarded_branch': 'skip update when any unscaled gradient is nonfinite', 'no_momentum_weight_decay_clipping': True}, 'metrics': 'parameters,logits and probabilities must all be finite for valid predictions; conditional accuracy null when no valid predictions', 'scope': 'deliberate extreme-loss-scaling stress test, not natural-frequency or production-incident estimate'}
plan_path = work / 'EXPERIMENT_PLAN.json'
if plan_path.exists():
    previous = json.loads(plan_path.read_text())
    plan['written_before_training'] = previous['written_before_training']
    assert previous == plan
else:
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
dataset = load_digits()
eligible = np.flatnonzero(np.isin(dataset.target, [3, 8]))
train_ids, test_ids = train_test_split(eligible, test_size=0.3, random_state=20260921, stratify=dataset.target[eligible])
for name, ids in [('train', train_ids), ('test', test_ids)]:
    with (work / f'{name}.txt').open('w') as out:
        for index in ids:
            out.write(str(index) + ' ' + str(dataset.target[index]) + ' ' + ' '.join(format(float(x / 16), '.9g') for x in dataset.data[index]) + '\n')
(work / 'DATASET.json').write_text(json.dumps({'sklearn_version': sklearn.__version__, 'numpy_version': np.__version__, 'python': sys.version, 'original_images': len(dataset.target), 'subset_images': len(eligible), 'train_images': len(train_ids), 'held_out_images': len(test_ids), 'dataset_data_sha256': hashlib.sha256(dataset.data.tobytes()).hexdigest(), 'dataset_labels_sha256': hashlib.sha256(dataset.target.tobytes()).hexdigest(), 'train_ids': train_ids.tolist(), 'test_ids': test_ids.tolist()}, indent=2) + '\n')
(work / 'DATA_LICENSE.md').write_text('''# Dataset attribution\n\nAlpaydin, E. & Kaynak, C. (1998). Optical Recognition of Handwritten Digits [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C50P49 . Official record: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits . The UCI record licenses these data under CC BY4.0: https://creativecommons.org/licenses/by/4.0/ .\n\nSource copy: scikit-learn load_digits, version recorded in DATASET.json. It contains1797images from the original UCI test subset. We select3and8, retain their labels and original row indices, divide pixels by16 and create a new stratified experimental train/test split. This is not the original writer-independent UCI benchmark. CSV/text format is our export. No endorsement is implied. Scikit-learn software has a separate BSD3-Clause license; no library source is included by this exporter.\n''')
commands = []
def run(command, name):
    commands.append(command)
    result = subprocess.run(command, capture_output=True, text=True)
    (work / (name + '.log')).write_text(result.stdout + result.stderr)
    result.check_returncode()

compiler = ['/usr/bin/c++', '-std=c++20', '-O2', '-DMLX_STATIC', '-I' + str(source)]
run(compiler + ['-c', str(p / 'classifier.cpp'), '-o', str(work / 'classifier.o')], 'compile')
variants = {'original': [], 'candidate': [p / 'candidate-verification/candidate.o'], 'restored': [p / 'candidate-verification/original.o']}
for name, objects in variants.items():
    run(['/usr/bin/c++', str(work / 'classifier.o')] + list(map(str, objects)) + [str(lib), '-framework', 'Accelerate', '-o', str(work / name)], 'link-' + name)

checkpoint = work / 'frozen-checkpoint-bits.txt'
def invoke(variant, prefix, mode, selected=-1, scale='1', eta='0.05', steps=0):
    run([str(work / variant), str(work / 'train.txt'), str(work / 'test.txt'), str(checkpoint), str(work / prefix), mode, str(selected), str(scale), str(eta), str(steps)], prefix)

invoke('original', 'pretrained', 'train', eta='1', steps=60)
checkpoint_hash = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
def value(b): return struct.unpack('f', struct.pack('I', int(b)))[0]
def read_vectors(path):
    return np.array([value(r['bits']) for r in csv.DictReader(path.read_text().splitlines())], dtype=np.float64)

initial = read_vectors(work / 'pretrained-weights.csv')
def prediction_metrics(prefix):
    weights = read_vectors(work / (prefix + '-weights.csv'))
    rows = list(csv.DictReader((work / (prefix + '-test-predictions.csv')).read_text().splitlines()))
    valid = correct = 0
    for r in rows:
        logit = value(r['logit_bits']); probability = value(r['probability_bits'])
        good = bool(np.isfinite(weights).all()) and math.isfinite(logit) and math.isfinite(probability)
        if good:
            valid += 1
            correct += (8 if probability >= 0.5 else 3) == int(r['label'])
    return {'held_out': len(rows), 'finite_parameters': int(np.isfinite(weights).sum()), 'total_parameters': len(weights), 'valid_predictions': valid, 'correct_valid': correct, 'accuracy_on_valid': correct / valid if valid else None, 'success_with_abstentions_counted_unsuccessful': correct / len(rows), 'parameter_changed_count': int(np.count_nonzero(weights != initial)), 'max_finite_parameter_change': float(np.max(np.abs(weights - initial))) if np.isfinite(weights).all() else None}

training_predictions = list(csv.DictReader((work / 'pretrained-train-predictions.csv').read_text().splitlines()))
chosen = []
for bin_index, (low, high) in enumerate(plan['selection']['true_label_probability_bins']):
    options = []
    for row_index, r in enumerate(training_predictions):
        probability = value(r['probability_bits'])
        q = probability if int(r['label']) == 8 else 1 - probability
        if q >= low and (q < high or (bin_index == 2 and q <= high)):
            options.append((int(r['id']), row_index, q))
    record = {'bin': [low, high], 'eligible_training_examples': len(options), 'selected': min(options) if options else None}
    chosen.append(record)
(work / 'SELECTION.json').write_text(json.dumps(chosen, indent=2) + '\n')
results = []
for index, selection in enumerate(chosen):
    if selection['selected'] is None: continue
    dataset_id, position, q_selection = selection['selected']
    features = np.append(dataset.data[dataset_id] / 16, 1.0)
    sign = 1.0 if dataset.target[dataset_id] == 8 else -1.0
    z_reference = float(features @ initial)
    q_reference = 1 / (1 + math.exp(-sign * z_reference))
    gradient_reference = -sign * (1 - q_reference) * features / math.log(10)
    eta = value(struct.unpack('I', struct.pack('f', .05))[0])
    weight_reference = initial - eta * gradient_reference
    for variant in variants:
        for scale_index, scale in enumerate(['1', '1e20', '3.2e38']):
            for mode in ['step', 'guarded']:
                prefix = f'example{index}-{variant}-scale{scale_index}-{mode}'
                invoke(variant, prefix, mode, position, scale)
                assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == checkpoint_hash
                meta = json.loads((work / (prefix + '-step.json')).read_text())
                normalized = read_vectors(work / (prefix + '-unscaled-gradient.csv'))
                weights = read_vectors(work / (prefix + '-weights.csv'))
                metric = prediction_metrics(prefix)
                metric.update({'bin_index': index, 'dataset_id': dataset_id, 'variant': variant, 'loss_scale_argument': scale, 'mode': mode, 'skipped': meta['skipped'], 'q': value(meta['q_bits']), 'loss_finite': math.isfinite(value(meta['loss_bits'])), 'log10_cotangent_finite': math.isfinite(value(meta['log10_cotangent_bits'])), 'unscaled_gradient_finite': bool(np.isfinite(normalized).all()), 'max_gradient_error_float64_oracle': float(np.max(np.abs(normalized - gradient_reference))) if np.isfinite(normalized).all() else None, 'max_parameter_error_float64_oracle': float(np.max(np.abs(weights - weight_reference))) if np.isfinite(weights).all() and not meta['skipped'] else None, 'prefix': prefix})
                results.append(metric)
    # The fixed oracle and train-only selection are retained for independent review.
    (work / f'example{index}-oracle.json').write_text(json.dumps({'dataset_id': dataset_id, 'q_selection_float32': q_selection, 'q_float64': q_reference, 'gradient_float64': gradient_reference.tolist(), 'weights_after_step_float64': weight_reference.tolist()}, indent=2) + '\n')
for r in results:
    counterpart = next(t for t in results if t['bin_index'] == r['bin_index'] and t['variant'] == 'original' and t['loss_scale_argument'] == r['loss_scale_argument'] and t['mode'] == r['mode'])
    if r['variant'] == 'restored':
        for suffix in ['-weights.csv', '-test-predictions.csv', '-raw-gradient.csv']:
            assert (work / (r['prefix'] + suffix)).read_bytes() == (work / (counterpart['prefix'] + suffix)).read_bytes()
    if r['skipped']:
        assert (work / (r['prefix'] + '-weights.csv')).read_bytes() == (work / 'pretrained-weights.csv').read_bytes()
receipt = {'at': datetime.now(ZoneInfo('Asia/Tashkent')).isoformat(), 'experiment_plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(), 'frozen_checkpoint_sha256': checkpoint_hash, 'before_step': prediction_metrics('pretrained'), 'selection': chosen, 'results': results, 'restoration_matches_exactly': True, 'guarded_skip_preserves_checkpoint_exactly': True, 'commands': commands, 'training_driver': 'GERO deterministic classifier and plain SGD, actual MLX C++ matmul/sigmoid/log10/autodiff/gradient unscale/update; inference abstention and nonfinite guard are explicitly GERO policies.', 'limitations': ['Extreme scale3.2e38 is an injected stress condition, not ordinary automatic scaling or an estimate of field frequency.', 'One fixed small binary classifier and one new split inside the UCI test subset, not broad model robustness.', 'Experimental patch has four known residual boundary mismatches outside these model inputs.', 'No production users, customer losses, GPU or device failure assessed.'], 'thread_environment': {k: os.getenv(k) for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']}, 'gpu': False, 'audio_playback': False}
(work / 'IMPACT_RECEIPT.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
print(json.dumps({'before': receipt['before_step'], 'selection': chosen, 'extreme_unguarded': [r for r in results if r['loss_scale_argument'] == '3.2e38' and r['mode'] == 'step'], 'extreme_guarded': [r for r in results if r['loss_scale_argument'] == '3.2e38' and r['mode'] == 'guarded']}, indent=2))
