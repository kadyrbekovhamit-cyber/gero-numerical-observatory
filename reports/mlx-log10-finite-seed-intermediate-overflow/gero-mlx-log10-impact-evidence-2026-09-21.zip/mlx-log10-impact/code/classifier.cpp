#include "mlx/mlx.h"
#include <bit>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace mx = mlx::core;
uint32_t bits(float v) { return std::bit_cast<uint32_t>(v); }
struct Data {
  std::vector<int> ids;
  std::vector<float> xs, signs;
};
Data read_data(const std::string& path) {
  std::ifstream in(path);
  Data d;
  int id, label;
  while (in >> id >> label) {
    d.ids.push_back(id);
    d.signs.push_back(label == 8 ? 1.0f : -1.0f);
    for (int i = 0; i < 64; ++i) { float x; in >> x; d.xs.push_back(x); }
    d.xs.push_back(1.0f);
  }
  return d;
}
void dump(const std::string& path, const mx::array& a) {
  std::ofstream out(path);
  out << "index,bits\n";
  for (int i = 0; i < a.size(); ++i) out << i << ',' << bits(a.data<float>()[i]) << '\n';
}
void evaluate(const Data& d, const mx::array& w, const std::string& path) {
  mx::array x(d.xs.data(), {static_cast<int>(d.ids.size()), 65}, mx::float32);
  auto logits = mx::matmul(x, w);
  auto probabilities = mx::sigmoid(logits);
  mx::eval(logits, probabilities);
  std::ofstream out(path);
  out << "id,label,logit_bits,probability_bits\n";
  for (int i = 0; i < d.ids.size(); ++i) {
    out << d.ids[i] << ',' << (d.signs[i] > 0 ? 8 : 3) << ','
        << bits(logits.data<float>()[i]) << ',' << bits(probabilities.data<float>()[i]) << '\n';
  }
}
int main(int argc, char** argv) {
  if (argc != 10) return 2;
  mx::set_default_device(mx::Device(mx::Device::cpu));
  Data train = read_data(argv[1]), test = read_data(argv[2]);
  std::string checkpoint(argv[3]), prefix(argv[4]), mode(argv[5]);
  int selected = std::stoi(argv[6]);
  float scale_value = std::stof(argv[7]), eta_value = std::stof(argv[8]);
  int steps = std::stoi(argv[9]);
  mx::array w = mx::zeros({65}, mx::float32);
  if (mode == "train") {
    mx::array x(train.xs.data(), {static_cast<int>(train.ids.size()), 65}, mx::float32);
    mx::array signs(train.signs.data(), {static_cast<int>(train.ids.size())}, mx::float32);
    auto loss = [&](const mx::array& weights) {
      auto q = mx::sigmoid(mx::multiply(signs, mx::matmul(x, weights)));
      return mx::negative(mx::mean(mx::log10(q)));
    };
    auto gradient = mx::grad(loss);
    std::ofstream trace(prefix + "-training.csv");
    trace << "step,loss_bits\n";
    for (int step = 0; step < steps; ++step) {
      auto value = loss(w);
      auto g = gradient(w);
      w = mx::stop_gradient(mx::subtract(w, mx::multiply(mx::array(eta_value), g)));
      mx::eval(value, w);
      trace << step << ',' << bits(value.item<float>()) << '\n';
    }
    std::ofstream file(checkpoint);
    for (int i = 0; i < 65; ++i) file << bits(w.data<float>()[i]) << '\n';
  } else {
    std::ifstream file(checkpoint);
    std::vector<float> weights;
    uint32_t b;
    while (file >> b) weights.push_back(std::bit_cast<float>(b));
    if (weights.size() != 65 || selected < 0 || selected >= train.ids.size()) return 3;
    w = mx::array(weights.data(), {65}, mx::float32);
    mx::array x(train.xs.data() + selected * 65, {1, 65}, mx::float32);
    auto sign = mx::array(train.signs[selected]);
    auto scale = mx::array(scale_value);
    auto eta = mx::array(eta_value);
    auto loss = [&](const mx::array& weights) {
      auto q = mx::sigmoid(mx::multiply(sign, mx::matmul(x, weights)));
      return mx::multiply(scale, mx::negative(mx::mean(mx::log10(q))));
    };
    auto q = mx::sigmoid(mx::multiply(sign, mx::matmul(x, w)));
    auto before_loss = loss(w);
    auto raw = mx::grad(loss)(w);
    auto unscaled = mx::divide(raw, scale);
    auto log_action = mx::vjp([](const mx::array& a) { return mx::log10(a); }, q, mx::array({-scale_value}));
    mx::eval(q, before_loss, raw, unscaled, log_action.second);
    bool finite = true;
    for (int i = 0; i < 65; ++i) finite = finite && std::isfinite(unscaled.data<float>()[i]);
    bool skip = mode == "guarded" && !finite;
    dump(prefix + "-raw-gradient.csv", raw);
    dump(prefix + "-unscaled-gradient.csv", unscaled);
    if (!skip) w = mx::subtract(w, mx::multiply(eta, unscaled));
    mx::eval(w);
    std::ofstream meta(prefix + "-step.json");
    meta << "{\"selected_dataset_id\":" << train.ids[selected]
         << ",\"q_bits\":" << bits(q.item<float>())
         << ",\"scale_bits\":" << bits(scale_value)
         << ",\"eta_bits\":" << bits(eta_value)
         << ",\"loss_bits\":" << bits(before_loss.item<float>())
         << ",\"log10_cotangent_bits\":" << bits(log_action.second.item<float>())
         << ",\"skipped\":" << (skip ? "true" : "false") << "}\n";
  }
  mx::eval(w);
  dump(prefix + "-weights.csv", w);
  evaluate(train, w, prefix + "-train-predictions.csv");
  evaluate(test, w, prefix + "-test-predictions.csv");
}
