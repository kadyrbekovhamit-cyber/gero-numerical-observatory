"""Replay the archived MLX CPU evidence; no Python numerical dependency.

Use a complete MLX static CPU build of the archived commit. This runner compiles
the actual full primitive translation unit for both intervention and restoration.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
from datetime import datetime, timezone
from decimal import Decimal, localcontext


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def value(b):
    return struct.unpack('<f', struct.pack('<I', int(b)))[0]


def nearest_even(n, d):
    q, r = divmod(n, d)
    return q + int(2 * r > d or (2 * r == d and q % 2 == 1))


def binary32(v):
    neg = v.is_signed()
    n, d = v.copy_abs().as_integer_ratio()
    if not n:
        return int(neg) << 31
    e = n.bit_length() - d.bit_length()
    if (n < (d << e)) if e >= 0 else ((n << -e) < d):
        e -= 1
    if e < -126:
        payload = nearest_even(n << 149, d)
    else:
        shift = 23 - e
        f = nearest_even(n << shift, d) if shift >= 0 else nearest_even(n, d << -shift)
        if f == 1 << 24:
            f >>= 1
            e += 1
        payload = 0x7f800000 if e > 127 else ((e + 127) << 23) | (f - (1 << 23))
    return (int(neg) << 31) | payload


def rows(path):
    return list(csv.DictReader(path.open()))


def vector(path):
    return [value(r['bits']) for r in rows(path)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--library', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--compiler', default='/usr/bin/c++')
    args = parser.parse_args()
    packet = Path(__file__).resolve().parents[1]
    primitive = packet / 'evidence/primitive'
    model = packet / 'evidence/model'
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    for line in (packet / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(packet / name) == digest, name
    assert sha(args.source / 'mlx/primitives.cpp') == sha(primitive / 'original-primitives.cpp')
    env = os.environ.copy()
    for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']:
        env[key] = '1'
    commands = []

    def run(command, label):
        commands.append(list(map(str, command)))
        result = subprocess.run(list(map(str, command)), env=env, capture_output=True, text=True)
        (out / (label + '.log')).write_text(result.stdout + result.stderr)
        result.check_returncode()
        return result.stdout

    common = [args.compiler, '-std=c++20', '-O3', '-DNDEBUG', '-DMLX_STATIC', '-DFMT_HEADER_ONLY=1', '-DACCELERATE_NEW_LAPACK', '-DMLX_USE_ACCELERATE', '-I' + str(args.source), '-I' + str(packet / 'source/fmt/include'), '-I' + str(packet / 'source/json/single_include/nlohmann')]
    for name in ['original', 'candidate']:
        run(common + ['-c', primitive / (name + '-primitives.cpp'), '-o', out / (name + '.o')], 'compile-' + name)
    for driver in ['grid', 'classifier']:
        run(common + ['-c', packet / 'code' / (driver + '.cpp'), '-o', out / (driver + '.o')], 'compile-' + driver)
        for variant, extras in [('original', []), ('candidate', [out / 'candidate.o']), ('restored', [out / 'original.o'])]:
            run([args.compiler, out / (driver + '.o')] + extras + [args.library, '-framework', 'Accelerate', '-o', out / (driver + '-' + variant)], 'link-' + driver + '-' + variant)
    oracle = json.loads((primitive / 'oracle.json').read_text())
    for r in oracle:
        refs = []
        for precision in [80, 120]:
            with localcontext() as ctx:
                ctx.prec = precision
                refs.append(binary32(Decimal.from_float(r['v']) / Decimal.from_float(r['x']) / Decimal(10).ln()))
        assert refs[0] == refs[1] == r['expected_bits']
    counts = {}
    for variant in ['original', 'candidate', 'restored']:
        for layout in ['vector', 'row', 'column']:
            raw = run([out / ('grid-' + variant), primitive / 'inputs.txt', layout], 'grid-' + variant + '-' + layout)
            path = out / (variant + '-' + layout + '.csv')
            path.write_text(raw)
            assert path.read_bytes() == (primitive / path.name).read_bytes(), path.name
        summary = {}
        for direction in ['jvp', 'vjp']:
            pairs = [(value(r[direction + '_bits']), value(ref['expected_bits'])) for r, ref in zip(rows(out / (variant + '-vector.csv')), oracle)]
            summary[direction] = {'finite_to_nonfinite': sum(math.isfinite(ref) and not math.isfinite(x) for x, ref in pairs), 'final_overflow_boundary_mismatch': sum(not math.isfinite(ref) and math.isfinite(x) for x, ref in pairs)}
        counts[variant] = summary
    assert counts['original'] == counts['restored']
    for direction in ['jvp', 'vjp']:
        assert counts['original'][direction]['finite_to_nonfinite'] == 66
        assert counts['candidate'][direction] == {'finite_to_nonfinite': 0, 'final_overflow_boundary_mismatch': 4}
    checkpoint = out / 'checkpoint-bits.txt'

    def invoke(variant, prefix, mode, selected=-1, scale='1', eta='0.05', steps=0):
        run([out / ('classifier-' + variant), model / 'train.txt', model / 'test.txt', checkpoint, out / prefix, mode, str(selected), scale, eta, str(steps)], prefix)

    invoke('original', 'pretrained', 'train', eta='1', steps=60)
    assert checkpoint.read_bytes() == (model / 'frozen-checkpoint-bits.txt').read_bytes()
    initial = vector(out / 'pretrained-weights.csv')
    train = [line.split() for line in (model / 'train.txt').read_text().splitlines()]
    preds = rows(out / 'pretrained-train-predictions.csv')
    selections = json.loads((model / 'SELECTION.json').read_text())
    results = []
    for i, chosen in enumerate(selections):
        lo, hi = chosen['bin']
        options = []
        for position, r in enumerate(preds):
            p = value(r['probability_bits'])
            q = p if r['label'] == '8' else 1 - p
            if lo <= q and (q < hi or (i == 2 and q <= hi)):
                options.append((int(r['id']), position, q))
        assert list(min(options)) == chosen['selected']
        dataset_id, position, _ = chosen['selected']
        record = train[position]
        xs = [float(x) for x in record[2:]] + [1.0]
        sign = 1 if record[1] == '8' else -1
        z = math.fsum(x * w for x, w in zip(xs, initial))
        q = 1 / (1 + math.exp(-sign * z))
        grad_ref = [-sign * (1 - q) * x / math.log(10) for x in xs]
        eta = struct.unpack('<f', struct.pack('<f', .05))[0]
        weights_ref = [w - eta * g for w, g in zip(initial, grad_ref)]
        for variant in ['original', 'candidate', 'restored']:
            for s, scale in enumerate(['1', '1e20', '3.2e38']):
                for mode in ['step', 'guarded']:
                    prefix = f'example{i}-{variant}-scale{s}-{mode}'
                    invoke(variant, prefix, mode, position, scale)
                    for suffix in ['-weights.csv', '-raw-gradient.csv', '-unscaled-gradient.csv', '-test-predictions.csv', '-train-predictions.csv', '-step.json']:
                        assert (out / (prefix + suffix)).read_bytes() == (model / (prefix + suffix)).read_bytes(), prefix + suffix
                    weights = vector(out / (prefix + '-weights.csv'))
                    gradient = vector(out / (prefix + '-unscaled-gradient.csv'))
                    prediction_rows = rows(out / (prefix + '-test-predictions.csv'))
                    finite_params = sum(math.isfinite(w) for w in weights)
                    valid = [r for r in prediction_rows if finite_params == 65 and math.isfinite(value(r['logit_bits'])) and math.isfinite(value(r['probability_bits']))]
                    correct = sum((8 if value(r['probability_bits']) >= .5 else 3) == int(r['label']) for r in valid)
                    meta = json.loads((out / (prefix + '-step.json')).read_text())
                    assert math.isfinite(value(meta['loss_bits']))
                    bad = s == 2 and variant != 'candidate'
                    assert meta['skipped'] == (bad and mode == 'guarded')
                    if bad and mode == 'step':
                        assert finite_params == 0 and not valid
                    elif bad:
                        assert weights == initial and correct == 103
                    else:
                        assert finite_params == 65 and len(valid) == 108 and correct == [104, 104, 103][i]
                        assert max(abs(a-b) for a,b in zip(gradient, grad_ref)) < 1e-7
                        assert max(abs(a-b) for a,b in zip(weights, weights_ref)) < 1e-7
                    results.append({'example': i, 'dataset_id': dataset_id, 'variant': variant, 'scale': scale, 'mode': mode, 'finite_parameters': finite_params, 'valid_predictions': len(valid), 'correct_valid': correct, 'accuracy_on_valid': correct / len(valid) if valid else None, 'skipped': meta['skipped']})
        for suffix in ['-weights.csv', '-test-predictions.csv']:
            assert (out / f'example{i}-candidate-scale2-step{suffix}').read_bytes() == (out / f'example{i}-original-scale0-step{suffix}').read_bytes()
    receipt = {'at': datetime.now(timezone.utc).isoformat(), 'status': 'portable_packet_native_replay_verified', 'source_primitive_sha256': sha(args.source / 'mlx/primitives.cpp'), 'library_sha256': sha(args.library), 'packet_manifest_sha256': sha(packet / 'SHA256SUMS'), 'checkpoint_sha256': sha(checkpoint), 'primitive_counts': counts, 'model_results': results, 'archive_outputs_reproduced_exactly': True, 'original_restoration_matches': True, 'candidate_extreme_step_matches_unscaled_control_exactly': True, 'oracle': 'primitive80/120decimal digits and directintegerbinary32rounding; modelindependentbinary64analyticgradient and update', 'build_scope': 'fresh complete primitive and driver translation units linked to supplied prebuilt complete pinned CPU archive; not a new full-library build', 'commands': commands, 'gpu': False, 'audio_playback': False, 'configured_threads': 1}
    (out / 'REPLAY_RECEIPT.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['commands','model_results']}, indent=2))


if __name__ == '__main__':
    main()
