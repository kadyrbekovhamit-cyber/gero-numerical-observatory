from pathlib import Path
import json,hashlib,zipfile,tarfile,shutil,subprocess,sys
B=Path(__file__).resolve().parent
m=json.loads((B/'SOURCE_MANIFEST.json').read_text())
for version,h in [('0.7.2',m['old_wheel_sha256']),('0.7.3',m['wheel_sha256'])]:
 p=B/'artifacts'/('pyloan-'+version+'-py3-none-any.whl');assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 with zipfile.ZipFile(p) as z:
  assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist());z.extractall(B/('release-'+version))
p=B/'artifacts/source.tar.gz';assert hashlib.sha256(p.read_bytes()).hexdigest()==m['source_tar_sha256']
if not (B/'source').exists():
 with tarfile.open(p) as t:
  members=t.getmembers();assert all(not x.name.startswith('/') and '..' not in Path(x.name).parts and not x.issym() and not x.islnk() for x in members);root=members[0].name.split('/')[0];t.extractall(B/'unpack');(B/'unpack'/root).rename(B/'source')
shutil.copytree(B/'source/src/pyloan',B/'restored/pyloan',dirs_exist_ok=True)
f=B/'restored/pyloan/pyloan.py';s=f.read_text();fixed='if (is_last_payment and self.loan_type != LoanType.INTEREST_ONLY\n                        and not (self.loan_type == LoanType.ANNUITY and self.payment_amount is not None)):';original='if is_last_payment and self.loan_type != LoanType.INTEREST_ONLY:';assert s.count(fixed)==1;f.write_text(s.replace(fixed,original))
shutil.copytree(B/'source',B/'restored-source',dirs_exist_ok=True);shutil.copy2(f,B/'restored-source/src/pyloan/pyloan.py')
subprocess.run([sys.executable,'-B',str(B/'replay.py')],check=True)
