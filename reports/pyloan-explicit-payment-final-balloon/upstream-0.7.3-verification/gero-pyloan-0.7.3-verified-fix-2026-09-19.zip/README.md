# PyLoan 0.7.3 verification package

Same reported explicit-annuity defect; no new defect ID. Original reports: https://doi.org/10.5281/zenodo.22834912 and https://doi.org/10.5281/zenodo.22836495.

Requirements: Python3.12 and python-dateutil==2.9.0.post0. Run `python -B reproduce.py` with numerical thread variables set to1. Uses only the archived official wheels/source; no network, payments, messages or playback. It extracts isolated copies locally and overwrites this package's generated evidence outputs.

Read UPSTREAM_FIX_UPDATE.md for complete claims and limitations. Source/archive checksums in SOURCE_MANIFEST.json; all output checksums in VERIFICATION_RECEIPT.json. The broad upstream suite retains3known baseline failures; their nonzero exit is recorded rather than concealed. Source is MIT; original notices retained. Scientific content is GERO/author original and MIT licensed for reproducibility. No media binary included.
