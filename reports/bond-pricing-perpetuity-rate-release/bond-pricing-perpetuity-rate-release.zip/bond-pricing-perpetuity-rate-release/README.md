# bond_pricing: perpetuity-rate inversion fixed in release 1.0.1

Fixed in official release 1.0.1; independently replayed

See REPORT_EN.md. Run the included Python harness against the source version named there with the package dependencies installed. For actuarialmath place the checkout package in source/current/actuarialmath and a patched copy in source/candidate/actuarialmath, then run verify_variance.py current and candidate. For bond_pricing: check_perpetuity.py PATH_TO_PACKAGE_PARENT result.json. For curo: check_curo.py CHECKOUT result.json. Tests intentionally record discrepancies rather than return a failing exit code; inspect the JSON failure counts.

Report CC BY 4.0; original harness MIT; upstream-derived patches retain GPL-3.0 terms. AI assistance disclosed. No private messages or customer data included.
