"""Executed against an unmodified wheel or a separately patched copy.

The reference is an 80-digit Decimal geometric-series identity, independent
of bond_pricing's rate conversion and annuity routines. Synthetic checks only.
"""
import argparse
from decimal import Decimal, localcontext
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import sys

p = argparse.ArgumentParser()
p.add_argument("source")
p.add_argument("output")
a = p.parse_args()
sys.path.insert(0, str(Path(a.source).resolve()))
import numpy as np
import pandas as pd
import scipy
import bond_pricing as bp

def reference(payment, price, due, frequency, compounding):
    with localcontext() as c:
        c.prec = 80
        payment, price = Decimal(str(payment)), Decimal(str(price))
        q = payment / (price - (payment if due else 0))
        force = Decimal(frequency) * (1 + q).ln()
        if math.isinf(compounding):
            return float(force)
        m = Decimal(compounding)
        return float(m * ((force / m).exp() - 1))

rows = []
for price, ratio, frequency, compounding, due in itertools.product(
        [1000., 100000., 1000000.], [0.01, 0.025, 0.05, 0.10],
        [1, 2, 12], [1, 2, 12, math.inf], [False, True]):
    payment = price * ratio
    kwargs = dict(instalment=payment, pv=price, immediate_start=due,
                  cf_freq=frequency, comp_freq=compounding)
    got = float(bp.annuity_rate(**kwargs))
    expected = reference(payment, price, due, frequency, compounding)
    roundtrip = float(bp.annuity_pv(rate=got, **{
        k: v for k, v in kwargs.items() if k != "pv"}))
    rows.append(dict(price=price, payment=payment, due=due,
                     frequency=frequency, compounding=str(compounding),
                     actual_rate=got, expected_rate=expected,
                     reconstructed_pv=roundtrip,
                     rate_ok=math.isclose(got, expected, rel_tol=1e-10, abs_tol=1e-12),
                     pv_ok=math.isclose(roundtrip, price, rel_tol=1e-10, abs_tol=1e-8)))

# Finite-term branch controls: build the price by an explicit Decimal sum,
# then ask the public rate solver to recover a moderate, known annual rate.
controls = []
for n, rate, due in itertools.product([2, 12, 60], [0.025, 0.05, 0.1], [False, True]):
    with localcontext() as c:
        c.prec = 80
        d = Decimal(str(rate))
        price = float(sum(Decimal(100) / (1+d)**k for k in range(0 if due else 1, n if due else n+1)))
    got = float(bp.annuity_rate(n_periods=n, instalment=100, pv=price,
                              immediate_start=due, r_guess=0.05))
    controls.append(dict(n=n, expected_rate=rate, due=due, pv=price,
                         actual_rate=got,
                         ok=math.isclose(got, rate, abs_tol=1e-9)))

# Broadcast the documented frequency/timing arguments; preserve this evidence
# separately from scalar test counts.
vector = bp.annuity_rate(instalment=100., pv=1000.,
                       immediate_start=[False, True], cf_freq=[1, 2],
                       comp_freq=[1, 12]).tolist()
vector_expected = [reference(100., 1000., False, 1, 1),
                   reference(100., 1000., True, 2, 12)]
module = Path(a.source) / 'bond_pricing/present_value.py'
result = dict(environment=dict(python=platform.python_version(), numpy=np.__version__,
                               pandas=pd.__version__, scipy=scipy.__version__),
              source_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),
              cases=len(rows), rate_failures=sum(not x['rate_ok'] for x in rows),
              pv_failures=sum(not x['pv_ok'] for x in rows),
              finite_controls=len(controls), finite_control_failures=sum(not x['ok'] for x in controls),
              vector=vector, vector_expected=vector_expected,
              vector_ok=all(math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-12) for x,y in zip(vector,vector_expected)),
              minimal=dict(actual_rate=float(bp.annuity_rate(instalment=100.,pv=1000.)),
                           expected_rate=0.1,
                           actual_pv=float(bp.annuity_pv(rate=bp.annuity_rate(instalment=100.,pv=1000.),instalment=100.))),
              rows=rows, controls=controls)
Path(a.output).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','controls')}))
