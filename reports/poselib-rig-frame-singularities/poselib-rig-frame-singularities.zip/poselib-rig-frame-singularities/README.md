# PoseLib: valid camera geometry lost through coordinate singularities

Read REPORT_EN.md for scope and limitations. Upstream patch and tests: https://github.com/PoseLib/PoseLib/pull/217.

This package is a source/evidence bundle; it contains no prebuilt executable. No full-library validation claim.
