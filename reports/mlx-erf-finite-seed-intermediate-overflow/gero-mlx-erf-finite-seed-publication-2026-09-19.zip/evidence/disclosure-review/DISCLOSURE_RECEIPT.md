# MLX erf: disclosure channel and human handoff

Checked: 2026-09-19 12:19:57 UTC / 17:19:57 Asia/Tashkent.
Status: read-only review completed; no message, issue, comment, PR, push, mail tab, or publication.

## Conclusion

The verified official technical reporting channel is [MLX GitHub Issues](https://github.com/ml-explore/mlx/issues). For a confirmed new erf case, use a genuinely human-written report that the user understands and has verified. The current templates explicitly prohibit AI-written issues. Broad prior user authorization to report confirmed bugs already exists; the remaining requirement is authentic human authorship/understanding, not another generic permission to send.

There is no verified alternative MLX contact that authorizes automated prose or removes this condition. Do not reroute the report through a blank issue, “Other,” a discussion, an unrelated tracker, personal addresses, a security channel, or a general Apple email merely to avoid the project's policy.

## Rules verified

- [CONTRIBUTING.md](https://github.com/ml-explore/mlx/blob/main/CONTRIBUTING.md) permits AI-assisted coding tools but holds contributors responsible for their code, issues, PRs and comments. It requires personal understanding, verification, and the contributor's own expression. Issues should include reproducible steps, expected/actual behavior, environment and accurately stated impact.
- [Bug template](https://github.com/ml-explore/mlx/blob/main/.github/ISSUE_TEMPLATE/bug_report.md), API content refreshed successfully in this review, line 10: “I understand it is strictly prohibited to use AI to write issues.”
- [Other template](https://github.com/ml-explore/mlx/blob/main/.github/ISSUE_TEMPLATE/other.md), also refreshed successfully through the API, has the same declaration.
- [Template configuration](https://github.com/ml-explore/mlx/blob/main/.github/ISSUE_TEMPLATE/config.yml), API content refreshed successfully: blank issues are disabled.
- [AGENTS.md](https://github.com/ml-explore/mlx/blob/main/AGENTS.md), read in pinned local source and the official raw web view, prohibits agent-written PR descriptions/commit messages, responses to comments on the user's behalf, pushes and PR creation. It does not prevent this read-only policy review or factual local evidence preparation.

The broad allowance in CONTRIBUTING does not justify falsely asserting the more specific issue-template declaration. Removing the declaration or using the API to bypass its UI would not resolve authorship.

Local policy snapshot:
 /Users/khamit/Documents/Codex/gero-continuous-research/research/mlx-reduction-invariants-2026-09-17/mlx-59d600b5e64c238427d0f8d897ab7c682ef4d3d2/AGENTS.md
The existing pinned tree also has the same issue-template text. Fresh main-commit and CONTRIBUTING API requests timed out; the official web/raw CONTRIBUTING view was available. Therefore this receipt does not independently reassert the current main SHA. The latest successful template API reads are current endpoint observations, and source execution/version pinning remains root's separate work.

## Existing Apple outreach, without overstating delivery

Saved records inspected:
- /Users/khamit/Documents/Codex/2026-09-15/maintainer-outreach/case-contact-registry.json
- /Users/khamit/Documents/Codex/2026-09-15/maintainer-outreach/sent-receipts.json
- /Users/khamit/Documents/Codex/2026-09-15/maintainer-outreach/SUMMARY_RU.md
- /Users/khamit/Documents/Codex/gero-continuous-research/pending-publication/mlx-rsqrt-directional-derivative-scale/MAINTAINER_SENT_RECEIPT.json
- The rsqrt WORK_STATUS.md.

The first consolidated MLX/Swift Numerics routing-and-collaboration email was sent on 15 September to opensource@apple.com. The saved receipt says sender, sent-folder body and two attachments were verified; delivery and internal routing were not confirmed. Its address was documented then from the Contact Apple Open Source footer at https://opensource.apple.com/.

The rsqrt follow-up was sent in that same thread on 17 September at 23:45 Asia/Tashkent. Its receipt records sent verification, no new attachments, no direct maintainer acknowledgment, no acceptance, and explicitly identifies the address as a routing address rather than a direct MLX maintainer. Do not resend either previous package or repeat the collaboration pitch.

This read-only review did not open Gmail or inspect fresh replies. Those sent-only states are the latest saved confirmations, not a claim that no reply has arrived since. The general Apple homepage opened through the web tool; its extracted text did not expose the footer address, and a direct read failed DNS resolution. Accordingly, the address's prior official provenance is retained but was not freshly confirmed from the current footer here.

Even if currently valid, that general corporate routing mailbox is not documented here as MLX's bug intake or an approved exception to its contribution rules. Prior sends are historical facts, not permission to bypass the current project rules. If a human wants to request a clarification of the accepted process, the existing official thread is preferable to contacting unrelated individuals, but this review does not propose sending the erf report there as a workaround.

## Work already authorized and useful now

The root can complete the independent-oracle/current-source/released-version tests, restoration controls, duplicate-body/diff checks and claim review. It can prepare reproducible files, raw results, a narrow candidate correction, source/version ledger, and an honest local report explaining the result to the user. Label AI assistance accurately and keep personal-data/device/customer claims out unless measured.

A local factual handoff is permitted and useful. It is distinct from ghostwriting a ready-to-submit issue. The root should not stop scientific work merely because the project-facing prose requires a human. This review itself does not certify the erf candidate: root's execution and novelty checks must finish first.

## Concrete human-written handoff required if confirmed

Give the user a compact evidence card, in Russian if easier to understand, containing:

1. The exact call, float dtype, CPU backend, input and incoming tangent/cotangent; expected value with the independent derivative formula; actual result.
2. Pinned MLX commit/release and the reproducer command, with the captured output the user can inspect and rerun.
3. The implicated source expression, proposed correction, meaningful regression/restoration results, and remaining limits.
4. Duplicate-search conclusion with related links; explain why any similar known report is different.
5. A link/path to the evidence package and a clear statement that its preparation used AI.

The user must understand the finding, verify the submitted reproduction, and independently write the issue's title and explanatory prose in their own words. Their approving or copying an AI-written issue is not equivalent to human authorship. The tool-generated evidence/reproducer can be attached or linked honestly; the report must not misrepresent the user as personally having performed a test they have not performed. If the user cannot truthfully meet the template, retain the packet as awaiting human review rather than submitting it.

No ready-to-copy first-person issue text is supplied in this receipt. No new permission request is needed for the already authorized research; the eventual necessary user action is a genuine authorship/verification handoff. Keep vendor-first publication pending for this case until the official report is actually submitted and its receipt verified, or the user explicitly changes that sequence. Continue other authorized independent work while waiting.
