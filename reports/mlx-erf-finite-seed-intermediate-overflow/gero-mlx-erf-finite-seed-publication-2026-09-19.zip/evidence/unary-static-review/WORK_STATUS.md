# WORK_STATUS

Updated: 2026-09-19 17:12 Asia/Tashkent (12:12 UTC).

Goal: bounded independent read-only review of current MLX unary derivative scale;
exclude prior GERO cases and return at most one strong candidate.

Completed:
- Read source AGENTS.md and the supplied 31-entry MLX exclusion registry.
- Confirmed current main pin 59d600b5e64c238427d0f8d897ab7c682ef4d3d2.
- Inspected erf, erfinv, log10 and sqrt derivative formulas and relevant tests.
- Six all-state GitHub queries; selected full bodies and six relevant PR diffs.
- Read the previous broad activation report to distinguish root causes.

Result: one unexecuted candidate in Erf::jvp / VJP for float32 x=1, seed=3.2e38.
Exact derivative action: g * 2 / (e * sqrt(pi)); finite normal.
Predicted avoidable overflow in (2/sqrt(pi))*g before damping.
This is a normal-float stress seed near float32 maximum, not ordinary data scale.

Local status: read-only review saved; no calculations/build/patch/GPU/render.
Published status: nothing sent or published; not_ready.

Next: parent executes native CPU release/current case and independent oracle on its
single worker. Parent has separately switched focus to authorized publication;
do not begin another task or publish this candidate.

Files:
- REPORT.md
- SOURCES.json
- RECEIPT.json (file/source checksums and verification)
