# MLX unary derivative scale review

Reviewed 2026-09-19, 12:12 UTC (17:12 Asia/Tashkent).
Status: one strong static candidate; NOT executed or confirmed by this reviewer.
No source modifications, numerical jobs, builds, GPU work, publication or vendor messages.

## Selected candidate: erf derivative prescales a finite seed into infinity

Pinned main: 59d600b5e64c238427d0f8d897ab7c682ef4d3d2.
A fresh GitHub main lookup returned the same pin. GitHub blob for mlx/primitives.cpp:
f046670eefa87cd1d54e70aea36338006bc0ec31, 196228 bytes.

Source:
https://github.com/ml-explore/mlx/blob/59d600b5e64c238427d0f8d897ab7c682ef4d3d2/mlx/primitives.cpp#L1969
Erf::vjp calls Erf::jvp. Lines 1984-1988 first form:
    scale = multiply(array(M_2_SQRTPI, dtype), tangents[0], stream())
and only then multiply scale by exp(-square(x)).

Minimal proposed native CPU case:
    x = mx.array(1.0, dtype=mx.float32)
    seed = mx.array(3.2e38, dtype=mx.float32)
    mx.vjp(mx.erf, [x], [seed])
    mx.jvp(mx.erf, [x], [seed])
Evaluate outputs explicitly, record the actual stored float32 seed and dtype.

Both x and seed are finite normal float32 values; seed is deliberately an extreme
near-maximum stress value, not a claim about a typical training gradient.
Forward erf(1) is finite. The independent exact-real derivative action for the
stored seed g is:
    g * (2 / sqrt(pi)) * exp(-1) = g * 2 / (e * sqrt(pi)).
It lies well within finite normal float32 range (approximately 1.33e38; this is
an explanatory approximation, NOT an executed measurement in this review).

By inspection, the first multiplication 2/sqrt(pi) * g exceeds float32 maximum.
The subsequent multiplication by exp(-1) cannot recover a finite result if the
intermediate has already materialized as infinity. This is a predicted runtime
failure, still requiring parent execution to establish backend behavior.

An optional actual composed scalar function for the same root cause is
    f(x) = seed * mx.erf(x).
At x=1 its forward value is also finite, while its mathematically finite gradient
should be the same derivative action above. This is a synthetic library-level
example, not a measured downstream model or product effect.

A decisive metamorphic control is:
    VJP(erf, x, g) approximately equals g * VJP(erf, x, 1).
Both complete mathematical expressions are representable for the selected x/g.
Compute the independent oracle in high precision using the actual float32 inputs,
not the decimal 3.2e38 as though it were exactly representable.

The candidate is different from the published rsqrt case: it does not construct
x^(-3/2), use a reciprocal square root or depend on underflow/overflow of a local
rsqrt derivative. Here the leading constant greater than one overflows the seed
before a damping factor is applied. It is also different from zero-cotangent
masked singularities: x is 1, seed is nonzero, and erf is smooth everywhere.

## Suggested bounded parent test plan

1. Execute the scalar CPU VJP and JVP and the composed scalar gradient above on
   the official installed release; record version, dtype, explicit evaluated
   finite forward and derivative.
2. Repeat on the pinned native source if the parent has a matching ready build.
   Do not describe a Python graph workaround as a native library correction.
3. Test x=+1 and -1, positive and negative seed 3.2e38, and ordinary seed 1.
   Include smaller large seeds below the leading-product overflow threshold.
4. Test arrays/shape layouts with the same values to separate arithmetic failure
   from shape dispatch. No GPU run is required or authorized for this task.
5. A targeted order change forming the bounded derivative coefficient before the
   huge seed is a hypothesis for this input family. It is NOT asserted to repair
   every erf tail: exp(-x^2) can underflow for large |x| even if a large seed would
   make the complete action representable. Keep those conditions outside a narrow
   claim unless independently tested.
6. Retain signed zeros, ordinary inputs, finite tails, NaN/infinite boundary
   behavior and first/second derivatives as appropriate regression controls.
   A full current/candidate/restored replay remains parent's responsibility.

## Other functions reviewed

| Function | Observed implementation | Disposition |
| --- | --- | --- |
| erfinv | Forms (sqrt(pi)/2)*seed, then multiplies exp(erfinv(x)^2) or the saved output squared. | No new strong ordinary finite-input candidate promoted. Endpoints +/-1 produce nonfinite forward and are excluded. Existing CPU float64 narrowing is already publicly reported (#3047, #4182). |
| log10 | Forms seed/x, then multiplies by 1/log(10); it does not form x*log(10) as a denominator. | Rejected the initial denominator-overflow suspicion because it does not match current code. Extreme seed scaling deserves a separate later review, but was not promoted or executed here. |
| sqrt | Nonreciprocal VJP forms (0.5*seed)/sqrt(x). | No strong finite-normal-input candidate selected. Zero-cotangent singular cases have existing #3668/#3692/#3733 coverage; rsqrt scale is already in GERO registry. |
| erf | Forms (2/sqrt(pi)*seed)*exp(-x^2). | Sole selected unexecuted candidate above. |

## Contract and tests actually inspected

Official erf API:
https://ml-explore.github.io/mlx/build/html/python/_autosummary/mlx.core.erf.html
documents 2/sqrt(pi) integral_0^x exp(-t^2) dt.
Pinned binding: python/src/ops.cpp around lines 1002-1015.

Official VJP API:
https://ml-explore.github.io/mlx/build/html/python/_autosummary/mlx.core.vjp.html
describes the cotangent/Jacobian product; requires matching number, shape and type.
No cotangent magnitude cap is stated on that page.

Pinned tests/autograd_tests.cpp lines 512-521 cover erf VJP at +infinity/seed 1,
-infinity/seed 2, and zero/seed 1. No huge-seed check appears in that block.
A targeted search of that file and python/tests/test_autograd.py was performed;
this is not a claim that every test file in the repository was exhaustively audited.

## Bounded duplicate review

All following GitHub issue searches included open and closed items, and returned
incomplete_results=false:

- repo:ml-explore/mlx "erf" in:title,body,comments: 25 results.
- repo:ml-explore/mlx "erfinv" in:title,body,comments: 14 results.
- repo:ml-explore/mlx "sqrt" "gradient" in:title,body,comments: 17 results.
- repo:ml-explore/mlx "log10" in:title,body,comments: 3 results.
- repo:ml-explore/mlx "erf" "overflow" in:title,body,comments: 0 results.
- Global "mlx" "erf" "cotangent" in:title,body,comments: 0 results.

The initial broad erf full-body response was truncated. Its complete compact index
was fetched again; selected plausibly relevant bodies and actual complete API
file patches were then read separately. No claim is made that all bodies of all
irrelevant install/compiler reports were read.

Specific nearby work inspected:

- PR #4227 (closed, unmerged), body and its complete single-file diff:
  https://github.com/ml-explore/mlx/pull/4227
  Adds multi-point closed-form derivative tests, including erf. Its erf gradients
  come from sum(erf(x)), hence unit cotangents. The body explicitly says it found
  no gradient defects in v0.32.0 and describes temporary injected test defects.
  It does not report or test the huge finite seed overflow above.
  Maintainer comment says they currently add tests for new features/regressions.
- PR #3927 (closed, unmerged), body and all four file patches:
  https://github.com/ml-explore/mlx/pull/3927
  Adds a separate pure-Python special-functions proposal; it does not change
  core Erf::jvp and contains no selected large-seed derivative check.
- PR #3025 (merged), body and complete Metal erf patch:
  https://github.com/ml-explore/mlx/pull/3025
  Improves forward near-zero erf via expm1f, not derivative multiplication order.
- Issue #3047 and PR #4182 (closed, unmerged), body and both PR file patches:
  https://github.com/ml-explore/mlx/issues/3047
  https://github.com/ml-explore/mlx/pull/4182
  Existing CPU float64-to-float32 implementation/range problems. The patch routes
  double through libm and intentionally leaves float32 unchanged. Not this case.
- PR #4243 body: complex dtype rejection, not real float32 derivatives.
- Issue #3668, PR #3692 and PR #3733 bodies; complete two-file patches for each PR:
  https://github.com/ml-explore/mlx/issues/3668
  https://github.com/ml-explore/mlx/pull/3692
  https://github.com/ml-explore/mlx/pull/3733
  These target zero-cotangent sqrt/rsqrt singularities. #3733 is closed/unmerged;
  this review does not incorrectly call it an accepted current-main fix.

The supplied GERO registry's 31 MLX IDs were inspected. The full published
finite-input activation report was read:
https://github.com/kadyrbekovhamit-cyber/gero-numerical-observatory/blob/main/catalog/reports/finite-inputs-nonfinite-activations-mlx-nntrainer.md

That report concerns ELU/SELU inactive exponentials, exact GELU forward exterior
multiplication, approximate GELU cubic gradients, and nntrainer Softplus. It does
mention erf as part of GELU's formula but does not disclose this core Erf::jvp
seed-overflow root. Known sigmoid, rsqrt, expm1 and inverse-hyperbolic reports were
excluded from this task as instructed.

Conclusion: no exact matching prior report identified within the recorded bounded
search. This is not exhaustive priority proof, nor authorization to present an
unexecuted candidate as a new confirmed finding.

## Artifacts and next step

SOURCES.json stores the exact inspected results, source excerpts, search indexes,
selected bodies and PR patches. WORK_STATUS.md is the handoff.

Next step belongs to root: run the minimal native CPU case sequentially when its
single numerical worker is available. Until then, status is static_candidate and
publication_status is not_ready.
