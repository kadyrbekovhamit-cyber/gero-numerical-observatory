# Independent factual review: MLX erf report

Reviewed 2026-09-19 12:34 UTC / 17:34 Asia/Tashkent.
Final reviewed REPORT_EN.md SHA-256:
8bbb9b6fd31cbb5ed856c14cfe22de539fe14483ad6a3d745017e4f5e9a429ec

Result: no unresolved material factual discrepancy identified in the requested
counts, boundary separation, scalar consequence chain, or retained limitations.

This review read existing artifacts only. It did not run MLX, rebuild a target,
rerun the high-precision oracle, or publish/send anything. It parsed saved data,
decoded stored IEEE bits, compared file bytes, and checked report arithmetic.

## Counts and boundary split

- oracle.json has 1292 distinct (x_bits, seed_bits) pairs.
- 944 primary finite targets + 304 tail targets + 44 genuine overflow cases.
- All four GRID_COUNTS blocks match lengths of the saved failure lists.
- All three layout summaries match, and CSV output bytes match within each variant.
- All saved original grid/scalar/boundary CSVs match restored output bytes.
- Evaluated forward-erf bits are identical across the four grid variants.

First-action counts verified:

| Variant | Primary | Tail | Genuine-overflow mismatches |
| --- | ---: | ---: | ---: |
| original | 372 | 216 | 0 |
| coefficient-first | 4 | 184 | 0 |
| balanced | 0 | 60 | 0 |
| restored | 372 | 216 | 0 |

The 372 primary failures separate correctly into 368 nonzero-x cases and four
x=+0/-0 boundary rows. All 368 nonzero rows have finite stored oracle targets and
nonfinite original JVP, VJP and composed gradients.

Boundary row IDs: 30, 31, 68, 69. Seed magnitude:
3.0156738459912657e38. Stored oracle output magnitude:
3.4028234663852886e38 (maximum finite float32). Original outputs are signed
infinities; balanced outputs match those finite maximum values. These four rows
are accurately separated from the x=1 damping example.

The simple candidate's remaining 188 failures are exactly 4+184.
The balanced candidate's remaining 60 first-action failures occur only at x=+/-12.

## Scalar chain and documents

Compared all 32 one-row scalar CSV records (8 scenarios x 4 variants) against
DOWNSTREAM_RECEIPT.json and documents/{variant}.json. No value or decision
mismatch found. Every saved scalar erf forward and weighted loss is finite.

Scenarios 0-3: theta=+/-1, scale=+/-3.2e38.
Original guard decisions are SKIP_NONFINITE_UPDATE; balanced decisions are
APPLY_UPDATE. For theta=1, the actual saved balanced parameter is
0.9584892392158508; for theta=-1 it is -1.0415107011795044. These exactly match
the corresponding saved ordinary unscaled-erf proposals.

Scenarios 4-7: theta=+/-1, scale=+/-1.
All four decisions and saved parameter proposals remain unchanged.

The probe performs native MLX erf, differentiation, division, multiplication and
subtraction. The saved source evaluates:
    theta - float32(0.1) * (grad(L)/s)
The report now shows exactly that grouping. The finite-value guard and documents
are explicitly attributed to GERO. The text correctly avoids claiming a real
model, built-in optimizer integration, device fault or customer loss.

The restored downstream receipt rows are identical to the original rows.
All twelve original CSV files (three grid layouts, eight scalar files and one
boundary file) are byte-identical to their restored counterparts.

## Remaining first/second derivative limitations

Primary second-derivative failure counts match: 488 original -> 292 balanced.
The coefficient-first candidate retains 488. Primary controls with |seed|<=1
have zero second-derivative failures for all variants.

The headline large-seed scalar second derivative remains -Infinity in the
balanced evidence at x=1. The report explicitly retains that limitation.

The 60 balanced tail failures all occur at +/-12. Examples from the existing
saved oracle and CSV have relative errors 5.7357616e-6 and 5.6756893e-6, supporting
the report's approximate 5.7e-6 statement without changing the 3e-6 tolerance.

Extra cutoff rows use stored x=+/-13.267000198364258 and seed=3.19999997882106e38.
Balanced and coefficient-first derivative fields are zero; original/restored
fields are NaN. The report correctly presents the balanced zero as a remaining
finite-action range limitation, not as a successful correction.

Signed-zero and nonfinite-primal rows are indeed recorded in the separate
boundary CSV. The report does not promise universal signed-zero/Hessian behavior.

## Portable replay completed during this review

At the beginning, the replay receipt did not exist and the report used an
ambiguous present-tense reference. Root first changed it to explicit pending
status. A successful completion receipt then appeared at 12:33:23 UTC, and the
latest report now describes that completed run.

The three receipt copies (root, package, portable-replay) are byte-identical:
SHA-256 0e3a5828a7f1d141b86ad5a48c62a9b7642f96719e3d36f5d70ed178489fe21e.

Receipt data agree with the latest report:
- fresh_full_cpu_build: true;
- verified Git blobs: MLX 958, fmt 128, json 1090;
- primary failures: [372,4,0,372];
- CSV files reproduced byte-for-byte: 48;
- source restored: true;
- GPU and audio playback: false.

The replay script checks 3 grid + 8 scalar + 1 boundary CSV for each of 4 variants,
which accounts for 48. I directly compared all twelve persisted portable grid
CSVs with the earlier saved grid CSVs; they match. The replay's scalar/boundary
stdout equality is supported by script assertions and receipt, not a second
native execution by this reviewer.

## Resolved factual corrections and limits of approval

Two initial observations were resolved while reviewing:
1. Added parentheses to match the actual normalized-step operation order.
2. Made replay status explicit; then replaced pending wording with the verified
   completion details when the actual receipt became available.

No data changed in this review. Main numerical findings are internally consistent
with the saved evidence under the report's stated tolerance and scope.

This is a factual artifact review, not a new novelty search, vendor-policy
determination, independent runtime reproduction, or permission to claim
production impact. The latest source/report hashes and detailed comparisons are
in RECEIPT.json and EVIDENCE_REVIEW.json.
