# WORK_STATUS

Updated 2026-09-19 17:28 Asia/Tashkent (12:28 UTC).
Active scope: independent static review of split-factor Erf::jvp derivative.

Completed:
- Proved the exact-real prefix bound for (g*h)*h by h<=1 / h>1 cases.
- Separated that proof from near-overflow rounding and subnormal behavior.
- Read actual CPU SIMD exp cutoff at -88 and proposed additional x=13.267,
  seed=3.2e38 normal-output tail control, absent from the current x<=12 grid.
- Identified reverse AD's shared-h sum 2*g*h as a remaining higher-order risk.
- Read root's actual check_erf.py; no execution or source mutation.

Local: static analysis only. External/publication: none.
Next: root executes split-factor, boundary/cutoff and higher-order diagnostics
with its single CPU worker. Do not claim a universal erf-gradient repair.

Files:
- REVIEW.md: earlier coefficient-first and synthetic SGD analysis.
- SPLIT_FACTOR_REVIEW.md: current factorization assessment.
- SOURCES_SPLIT.json: inspected evidence and proposed probe.
- RECEIPT.json: updated artifact checksums.
