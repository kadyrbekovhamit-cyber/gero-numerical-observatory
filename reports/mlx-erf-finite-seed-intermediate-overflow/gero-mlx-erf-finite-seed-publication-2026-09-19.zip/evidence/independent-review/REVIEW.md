# Independent analysis of the MLX erf derivative candidate

2026-09-19 12:21 UTC / 17:21 Asia/Tashkent.
Pin: 59d600b5e64c238427d0f8d897ab7c682ef4d3d2.
This is a static review. No calculations, target execution, build, source edit,
render or external message was performed. Predicted outcomes require root's run.

## Minimal order change and the exact scope it can support

Let c = 2/sqrt(pi), e = exp(-x*x), and g be the incoming seed.
Current Erf::jvp evaluates (c*g)*e. Erf::vjp delegates to this same function.

The smallest targeted graph change is:
    coefficient = c * exp(-square(x))
    result = coefficient * g

That is an analysis sketch, not an applied patch or an upstream PR description.
Keep the current dtype, stream and native primitive functions.

For finite real x, the mathematical e is in [0,1]. The coefficient is bounded
by c, independently of g. Thus coefficient construction cannot itself overflow
float32. The only potentially large product is then the requested final
directional derivative. In the selected x=1, float32 g=3.2e38 family, the leading
c*g no longer exists, while the complete result is representable.

This supports a narrow claim about avoiding the unnecessary leading seed
overflow. It does NOT prove correct rounding or numerical safety over every
finite x/seed pair. Multiplication order changes last-bit rounding. Existing
exp/square approximation, underflow, flush-to-zero behavior, and other dtypes
remain separate considerations and require controls.

A mathematically equivalent alternative is (g*e)*c. It also removes the selected
leading overflow. The derivative-coefficient-first form is simpler to explain
and makes the bounded coefficient explicit. Neither order is universally the
most accurate for every subnormal boundary; avoid claiming that distinction
without measurements.

## Three meaningful control groups

1. First derivative, seed linearity, and true overflow boundary.

   Test VJP and JVP at x=+1 and -1 with g=+/-1 and +/-float32(3.2e38).
   Expected action: g*c*exp(-x*x), using the actual stored float32 input/seed in
   the high-precision oracle. erf' is even in x and linear in g.
   Compare VJP(erf,x,g) with g*VJP(erf,x,1), where both sides fit the dtype.
   Include g below the c*g overflow threshold as a nearby non-target control.
   Include x=0 with g=3.2e38 as a genuine final-overflow control: its derivative
   c*g really exceeds float32 range, so infinity there must not be suppressed
   by clamping or nan_to_num. Zero seed at x=1 should remain zero.

2. Second derivative on an ordinary scale, plus a separate stress diagnostic.

   For f_g(x)=g*erf(x), the exact second derivative is:
       f_g''(x) = -2*x*g*c*exp(-x*x).
   Use x in {-1,-0.5,0,0.5,1} and ordinary g in {1,2}. This checks sign, odd
   symmetry in x, the exact zero at x=0, and composition of differentiation.
   Run reverse-over-reverse and forward-over-reverse where available. These
   are real analytic controls, not merely a rewrite of the tested graph.

   Also record, without assuming it will pass, x=1,g=float32(3.2e38).
   Its first and second mathematical derivatives both fit float32. However,
   the minimal first-order reordering does not guarantee a repaired nested
   reverse derivative. See the source-level explanation below. A retained
   failure belongs in limitations, not in a claimed all-gradients repair.

3. Retained tail limitation.

   Propose x=11,g=float32(1e30) as a diagnostic, not an acceptance target for the
   narrow patch. exp(-121) is below the smallest positive float32 even though
   g*c*exp(-121) is a representable normal float32 number. Both the current and
   reordered graphs materialize the unscaled exponential, so both can return
   zero. The forward erf(11) and the weighted forward remain finite.
   Record the oracle and actual result; do not silently omit this case or call
   zero a successful correction. Ordinary x around +/-1 remains the patch target.

## Why the second derivative may still fail

The reordered first derivative graph is y = (c*e)*g. Differentiating y in reverse:

- The outer Multiply sends g to the c*e node.
- The c*e Multiply sends c*g to Exp.
- Exp::vjp then multiplies that cotangent by its output e.

Thus the same oversized c*g can reappear in the automatically generated
second-derivative graph, even though the first derivative evaluation no longer
forms it. At x=1,g=3.2e38, the true second derivative is finite; reverse-over-reverse
can still overflow before the damping factor is reached.

Pinned source:
- Multiply::vjp at mlx/primitives.cpp:3185 multiplies the other primal by the
  incoming cotangent.
- Exp::vjp at :2033 multiplies the cotangent by the saved exponential output.
- Square::jvp at :5576 computes x*(2*tangent), another ordering that can be
  relevant for higher derivatives under other extreme scales.

This is a reason to distinguish first-order and higher-order claims, not a
confirmed additional bug from this review. No code was executed here.
Forward-over-reverse may traverse a different order and should be measured
separately. Do not assert backend/compiler reassociation will preserve any
particular intermediate order without the native execution trace/results.

Changing c*exp(-x*x) to exp(log(c)-x*x) might avoid this particular c*g path, but
it adds transcendental/rounding behavior and is more than a minimal reordering.
It should not be smuggled into the patch without independent validation.
Custom derivative machinery, clipping or stop_gradient would be larger changes
and could alter legitimate higher derivatives; none is proposed here.

## A measurable ordinary core-operation consequence

The cleanest demonstration is invariance of an SGD proposal under loss rescaling,
rather than an invented real-world training claim.

Define scalar float32 theta=1, s=3.2e38 and learning_rate=0.1.
Let unscaled loss L(theta)=erf(theta), scaled loss L_s(theta)=s*erf(theta).
The scaled forward at theta=1 is finite.

Compute, with the scale and theta stored in explicit float32 arrays:
    grad_plain = grad(L)(theta)
    grad_scaled = grad(L_s)(theta)
    proposal_plain = theta - learning_rate*grad_plain
    proposal_scaled = theta - learning_rate*(grad_scaled/s)

The mathematical proposal is the same in both cases:
    theta_next = 1 - 0.1 * 2/(e*sqrt(pi)),
approximately 0.95849 (explanatory estimate, not an executed result here).
Use the stored float32 learning_rate in the precise oracle.

Predicted original behavior: grad_scaled is +inf, unscaling leaves +inf and
proposal_scaled becomes -inf, while proposal_plain is finite.
Predicted reordered behavior: grad_scaled and proposal_scaled are finite and
the two proposals agree within a float32 numerical tolerance.

Useful measured outputs after root execution:
- both forward losses and finiteness;
- original/current/patched/restored grad_scaled;
- unscaled gradient, both proposals and their absolute error;
- whether an all-finite update check would accept or reject the proposal.

This is a synthetic scalar stress test with an intentionally extreme scale.
It establishes an effect in the executed update path only. It does not establish
training convergence, model accuracy, production incidence or affected Apple
devices. Do not portray a hand-authored acceptance rule as a native MLX feature.

The core proposal is exactly the operation used by the real SGD implementation
when momentum and weight decay are zero:
    parameter - learning_rate.astype(gradient.dtype) * gradient
at python/mlx/optimizers/optimizers.py:280.
For a stronger native library demonstration, parent may run the actual SGD
apply_single with the unscaled gradient and momentum=weight_decay=0, and compare
it with the same core expression. That remains unexecuted in this review.

An alternative direct step on the huge weighted loss can use learning_rate=2^-126,
the smallest normal float32, producing a finite correct update in this case.
The rescale/unscale construction above is preferable for explanation because it
uses an ordinary learning_rate and directly tests a mathematical invariant.

## Evidence and handoff

SOURCES.json contains inspected source excerpts and official pinned source URLs.
Previous duplicate/registry review remains at:
  /private/tmp/gero-mlx-unary-review-20260919/REPORT.md
  /private/tmp/gero-mlx-unary-review-20260919/SOURCES.json

No fresh novelty conclusion is added here. Root owns numerical work and all
publication decisions. Preserve higher-order and tail limits in any resulting
report; do not describe this static analysis as a completed replay.
