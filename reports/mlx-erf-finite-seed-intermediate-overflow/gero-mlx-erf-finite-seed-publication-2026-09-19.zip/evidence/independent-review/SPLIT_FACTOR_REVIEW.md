# Independent split-factor review for Erf::jvp

2026-09-19 12:28 UTC / 17:28 Asia/Tashkent.
Static analysis only. No numerical execution or changes to source/shared state.

Root has reported an executed baseline screen: 588 first-derivative failing rows
among 1292 rows; coefficient-first leaves 188 failures (4 near-maximum boundary
rows at x=0 and 184 tail rows), with second-derivative issues retained. These
counts are attributed to root, not independently rerun here.

The source check_erf.py and its oracle design were read. The existing x-grid
stops at +/-12; it does not include the additional CPU exp cutoff probe below.

## Proposed factorization

Let c = 2/sqrt(pi), a = sqrt(c), h = a*exp(-x*x/2).
The mathematical first derivative action is g*h*h.

The candidate evaluation order is:
    h = sqrt(c) * exp(-square(x)/2)
    result = (g*h)*h

All claims below distinguish exact-real reasoning from floating-point evaluation.

## Why this eliminates the avoidable leading overflow in exact arithmetic

Assume finite real g, positive h and a finite representable exact final magnitude
|g|*h*h. Consider the first product |g|*h.

- If 0 <= h <= 1, |g|*h <= |g|, so a finite seed bounds the prefix.
- If h > 1, |g|*h <= |g|*h*h, so the finite final result bounds the prefix.

Consequently there is no intrinsically oversized intermediate product relative
to both the seed and final result. In contrast, the original c*g may exceed both
the seed and final result because the later exponential can shrink it.

For finite real x, exact h is nonnegative and at most sqrt(c), a small constant.
The h construction has no true positive overflow. If square(x) overflows for
enormous finite x, the intended derivative is far below float32 range for every
finite float32 seed, so a zero derivative at those huge x is consistent with
underflow, provided NaN intermediates are not introduced.

This proof is a range argument. It is not a proof of correctly rounded output or
of all first-derivative tests passing on an approximate exp implementation.

## Floating-point and boundary caveats

1. Rounding of a, the exponent, exp, the first multiplication, and the second
   multiplication changes g*h_hat^2 relative to g*c*exp(-x^2). Near the float32
   overflow midpoint, one-ULP changes can turn finite into inf or the reverse.
   In particular x=0 squares the rounded sqrt(c), which need not equal either
   the rounded c or the exact real c. Keep the existing threshold-neighbor
   controls; do not waive their failures as a universal proof artifact.

2. For normal intermediates, first-order rounding error in h is approximately
   doubled in h^2. A usual relative tolerance may be justified by actual exp
   error and selected domain, not merely by counting multiplications. Relative
   error can grow sharply for subnormal h or output.

3. If the exact intermediate g*h underflows while h<=1, the final exact magnitude
   cannot be larger, so losing that prefix cannot hide a large representable
   answer. When h>1 and g is a normal seed, g*h is not an underflow case.

4. Under ideal gradual underflow and proper rounding, h itself becoming zero
   would imply an extremely tiny h (roughly below half the minimum subnormal).
   Even multiplying h^2 by the largest float32 seed is then far below the
   minimum representable output. Splitting the exponential therefore postpones
   underflow enough to avoid the original unscaled-exp tail failure in a much
   wider range. This statement depends on true gradual underflow.

5. The actual CPU exp is not an ideal exp implementation. At pinned source
   mlx/backend/cpu/simd/math.h it explicitly returns zero for input < -88.0f.
   It constructs the exponent bit field directly and does not promise correct
   subnormal exp values before that cutoff either. Flushing subnormals or
   premature saturation invalidates the ideal-underflow argument.

6. Finite real x gives nonnegative h. For finite negative seeds, multiplying
   by positive h twice preserves the negative sign. Signed zero seeds should
   also retain their sign in these plain multiplications, including h=0, but
   verify actual CPU results. The current checker's numeric tolerance does not
   distinguish +0 from -0, so use a separate bit-level diagnostic if reporting
   signed-zero preservation. No new signed-zero API contract is asserted.

7. Nonfinite seeds/x, half precision, bfloat16, float64, CUDA, Metal and compiled
   fused graphs are outside a finite-float32 CPU claim unless separately tested.

## Concrete retained CPU cutoff probe

Proposed additional inputs:
    x = float32(13.267)
    seed = float32(3.2e38)

The half squared exponent is just below -88, so the source's CPU SIMD exp clamp
can return zero for h. Yet the complete real derivative seed*c*exp(-x*x) is still
of order 1.3e-38, a normal float32 output. This is an analytical prediction;
the exact stored-input oracle and native result must be measured by root.

Use neighbors around this x (and both signs), maximum finite seed and a nearby
large seed. Record expected normal/subnormal classification explicitly.
Do not call this a new independent finding or claim that all tails are fixed.
The existing x-grid through 12 can pass after splitting while missing this case.

Pinned source showing the cutoff:
https://github.com/ml-explore/mlx/blob/59d600b5e64c238427d0f8d897ab7c682ef4d3d2/mlx/backend/cpu/simd/math.h#L55

## Higher-order derivatives still have a different evaluation graph

For y=(g*h)*h, reverse AD traverses two paths to the shared h:

    partial y / partial h = g*h + g*h = 2*g*h.

This sum can overflow before h'(x)=-x*h attenuates it. At x=1,
g=float32(3.2e38), h is approximately 0.644: each g*h is finite, but their sum can
exceed float32 maximum. The exact second derivative -2*x*g*h^2 is nevertheless
finite. This predicts a retained reverse-over-reverse failure.

Forward-over-reverse can form two separately attenuated contributions:
    (g*h')*h + (g*h)*h'
and may avoid that particular overflow. It needs separate execution; mathematical
equivalence does not guarantee identical floating-point ranges.

The shared-node accumulation follows the real Multiply primitive derivatives,
not a hypothetical production graph. Changing evaluation mode or duplicating h
nodes should not be presented as a robust native fix without accounting for graph
sharing and compiler common-subexpression elimination. No such workaround is
recommended in this review.

Higher derivatives through the split exponential also encounter Square's
x*(2*tangent) order and Add accumulation. The first-action range proof does not
extend automatically to any of these higher-order computations.

## Oracle and execution review notes

Root's check_erf.py:
- builds exact rational values from stored float32 inputs;
- calculates high-precision first and second analytic derivatives;
- checks the generated oracle is unchanged at 100 versus 150 decimal digits;
- screens original/candidate/restored and flat/row/column layouts;
- distinguishes primary, tail_limit and legitimate_overflow rows.

These are appropriate structural checks. Retain the exact bit records around the
overflow boundary. Its tolerance accepts absolute error up to four minimum
subnormals, so a zero result against a very small positive subnormal can count as
passing; state that tolerance if making a subnormal-accuracy claim.

Suggested next measurement: split-factor replay, existing threshold boundaries,
new +/-13.267 cutoff controls, ordinary second derivatives, and the explicit
large-seed reverse-over-reverse versus forward-over-reverse diagnostic.

Only root should execute that work. The scaled-loss SGD proposal from REVIEW.md
remains useful after the first derivative is independently verified.
