# Licenses

Original bundled source archives retain their licenses and copyright notices: Apple MLX (MIT), fmt (MIT), nlohmann/json (MIT), mpmath (BSD-3-Clause). Each archive includes its upstream notices. GERO reproducer code and candidate patch are covered by LICENSE_CODE.txt. GERO authored reports/evidence descriptions: CC BY4.0; original source notices remain controlling for upstream material. This package does not claim rights to any voice or media because it contains no generated media.
