# MLX erf finite-seed derivative audit

Public evidence edition 1.0.0; not an upstream contribution. See REPORT_EN.md for measured scope, remaining failures and disclosure status.

Requirements: Python>=3.12 with mpmath1.3.0, CMake>=3.25, Ninja and a C++20 compiler. This package has been prepared for a CPU-only macOS/Accelerate replay. Other platforms are not claimed tested.

```sh
python -m pip install --no-index sources/mpmath-1.3.0-py3-none-any.whl
python reproduce.py --work-dir /path/to/new-empty-replay --cmake /path/to/cmake --ninja /path/to/ninja
```

The replay verifies all source archives and their original Git blobs, builds the complete native library, runs original/coefficient-first/balanced/restored variants, recreates the high-precision oracle, and compares raw outputs with archived evidence. It compiles serially with CPU backend only. On the owner's Mac, invoke it through the shared one_worker.py lock to coordinate other work.

The grid has 1,292 input/seed pairs, not 3,876 independent cases; the three shapes repeat it. Primary 944 finite-target rows: 372 → 4 → 0 → 372. Broader tails and second derivatives retain failures. Source methods in release0.32.2 match but the released binary was not executed.

MLX core calculates losses/derivatives/proposed steps. GERO supplies the synthetic decision guard and documents. No measured real-user, model or device impact.

No media playback or GPU work. No passwords, tokens or customer data are included. AI-assisted evidence preparation is disclosed; this README/report is not a human-authored GitHub issue.
