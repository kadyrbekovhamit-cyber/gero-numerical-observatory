# Publication edition 1.0.0 — 19 September 2026

This edition updates publication-status wording in authored report and README only; it adds this note and a human-readable source ledger. Raw observed outputs, analytical references, source archives, code, patches and replay receipts are unchanged from the cleanly replayed research package. Historical Russian review and receipts retain their original dates/status. No upstream submission or acceptance is claimed.
