Apply each patch independently to the base documented in REPORT_EN.md. See PRs for current review. This archive contains only public code cases. No private medical case or correspondence is included.
