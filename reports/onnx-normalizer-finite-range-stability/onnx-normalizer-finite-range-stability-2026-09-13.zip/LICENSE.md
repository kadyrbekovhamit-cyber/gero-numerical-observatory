# Reuse

REPORT.md, the article snapshot and new archival metadata by Xamit Kadirbekov: Creative Commons Attribution 4.0 International, https://creativecommons.org/licenses/by/4.0/.

Everything under reproducer/ is copied from the public repository and retains the MIT license in reproducer/LICENSE. Referenced third-party projects retain their own licenses; their source or binaries are not bundled.
