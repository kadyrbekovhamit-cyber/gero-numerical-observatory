# Archival provenance

Independent report by Xamit Kadirbekov, first published 13 September 2026. Archived ONNX 1.22.0 and ONNX Runtime 1.29.0 CPU experiments show finite extreme-scale Normalizer inputs producing zeros, NaNs or unnormalized values. For L2 rows [1e30,1e30] and [1e-30,-1e-30], correctly rounded outputs are [0.70710677,0.70710677] and [0.70710677,-0.70710677]. The reference evaluator also violates output dtype and rank-one handling in the recorded cases.

This archive includes the latest public report and reproducibility repository, including the separate L1/L2 documentation correction and MAX semantic conflict. For [-2,-1], the raw-maximum interpretation returns [2,1], while division by maximum absolute value returns [-1,-0.5]. These are different contracts; choosing between them requires a specification decision, not just a stability patch.

The original report records seven passing ONNX Runtime Normalizer tests for the candidate correction. The published proposals are ONNX PRs #8450 and #8451, ONNX Runtime PR #32573, and ONNX issue #8452. Their existence is not upstream acceptance or proof of model-level impact. No security vulnerability is claimed.

This deposit packages already-public work; numerical experiments and source builds were not rerun for this archival step. Report and archival metadata: CC BY 4.0. The original reproducer repository retains its included MIT license. Third-party projects retain their own licenses.

Frozen reproducer: https://github.com/kadyrbekovhamit-cyber/gero-onnx-normalizer-stability-audit/tree/d50663511461efed70d9d58127393d627aac79cc

The eight reproducer files are byte-identical to the pinned Git objects. REPORT.md and article.html preserve the report and its publication rendering, including the documentation and already-public MAX issue. The HTML expands the earlier GERO page with that MAX section during this publication. Expected-output.txt is a published fixture, not a fresh execution log. No new test result or performance measurement is claimed.
