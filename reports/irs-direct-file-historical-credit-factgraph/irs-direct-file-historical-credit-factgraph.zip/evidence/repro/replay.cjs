const fs = require('fs');
const path = require('path');
const assert = require('assert');
const {W, graph, get, setStubs} = require('./fg.cjs');
const started = process.hrtime.bigint();
const full = [];
for (const name of ['witness_savers_A', 'witness_savers_control', 'witness_savers_normal', 'witness_savers_normal_control', 'witness_eitc_hoh2']) {
  setStubs({});
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, name + '.json')));
  const g = graph(data.facts || data);
  const paths = ['/agi','/filingStatus','/primaryFiler/isEligibleForSaversCredit','/secondaryFiler/isEligibleForSaversCredit',
    '/primaryFilerGrossDistributions','/secondaryFilerGrossDistributions', '/secondaryFilerTotalContributions',
    '/qualifiedSaverCreditAmount','/earnedIncomeCredit','/totalTax'];
  full.push({name, stubs: false, values: Object.fromEntries(paths.map(p=>[p,get(g,p)]))});
}
for (const i of [0,2]) {
  assert.strictEqual(Number(full[i].values['/qualifiedSaverCreditAmount']),750);
  assert.strictEqual(Number(full[i+1].values['/qualifiedSaverCreditAmount']),150);
  assert.strictEqual(Number(full[i+1].values['/totalTax'])-Number(full[i].values['/totalTax']),600);
}
assert.strictEqual(Number(full[4].values['/earnedIncomeCredit']),3116);
setStubs({'/magiForStudentLoanInterestDeduction':'Dollar','/studentLoanInterestAmount':'Dollar','/cannotDeductStudentLoanInterest':'Boolean'});
const isolated=[];
for (const [status,magi,interest] of [['single',80981,777],['marriedFilingJointly',165495,2500],['single',80000,777]]) {
  const g=graph({'/filingStatus':W.en(status,'/filingStatusOptions'),'/magiForStudentLoanInterestDeduction':W.dollar(magi),
    '/studentLoanInterestAmount':W.dollar(interest),'/cannotDeductStudentLoanInterest':W.bool(false),'/hadStudentLoanInterestPayments':W.bool(true)});
  isolated.push({status,magi,interest,stubs:true,result:get(g,'/studentLoanInterestAdjustmentAmount')});
}
assert.strictEqual(Number(isolated[0].result),727);
assert.strictEqual(Number(isolated[2].result),777);
console.log(JSON.stringify({source_commit:'e365f9f43446010af36cccf7edecc52953c00fe9',engine:'upstream prebuilt Scala.js',
  scope:'Local fact-graph scenarios; no web interface, JVM backend, e-file transmission or historical taxpayer return tested.',
  full,isolated,elapsed_seconds:Number(process.hrtime.bigint()-started)/1e9},null,2));
