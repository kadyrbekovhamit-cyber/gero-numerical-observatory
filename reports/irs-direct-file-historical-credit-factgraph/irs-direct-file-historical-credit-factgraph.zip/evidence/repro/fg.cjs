// Minimal Node harness around the repo's own prebuilt Scala.js fact graph (main.js).
const path = require('path');
const root = process.env.DF_SOURCE_ROOT || path.resolve(__dirname, '../source');
const sfg = require(path.join(root, 'direct-file/df-client/js-factgraph-scala/src/main.js'));
const wrapped = require('./facts.json');
let dict = null; let STUBS = {};
// stubs: {'/path': 'Dollar'|'Int'|'Boolean'} turns a derived fact into a writable input (unit-isolation of downstream formulas)
function setStubs(s) { STUBS = s; dict = null; }
function dictionary() {
  if (dict) return dict;
  const meta = new sfg.DigestMetaWrapper('2024').toNative();
  const src = wrapped.map(f => STUBS[f.path] ? { path: f.path, writable: { typeName: STUBS[f.path], options: {}, collectionItemAlias: null, limits: [] }, derived: null, placeholder: null } : f);
  const facts = src.map(f => sfg.DigestNodeWrapperFactory.toNative(new sfg.DigestNodeWrapper(f.path, f.writable, f.derived, f.placeholder)));
  dict = sfg.FactDictionaryFactory.fromConfig(sfg.FactDictionaryConfig.create(meta, facts));
  return dict;
}
const W = {
  bool: v => ({ $type: 'gov.irs.factgraph.persisters.BooleanWrapper', item: v }),
  str: v => ({ $type: 'gov.irs.factgraph.persisters.StringWrapper', item: v }),
  dollar: v => ({ $type: 'gov.irs.factgraph.persisters.DollarWrapper', item: String(v) }),
  int: v => ({ $type: 'gov.irs.factgraph.persisters.IntWrapper', item: v }),
  day: v => ({ $type: 'gov.irs.factgraph.persisters.DayWrapper', item: { date: v } }),
  en: (v, o) => ({ $type: 'gov.irs.factgraph.persisters.EnumWrapper', item: { value: [v], enumOptionsPath: o } }),
  coll: ids => ({ $type: 'gov.irs.factgraph.persisters.CollectionWrapper', item: { items: ids } }),
  item: id => ({ $type: 'gov.irs.factgraph.persisters.CollectionItemWrapper', item: { id } }),
  tin: (a, g, s) => ({ $type: 'gov.irs.factgraph.persisters.TinWrapper', item: { area: a, group: g, serial: s } }),
};
function emptyCollections() {
  const o = {};
  for (const f of wrapped) if (f.writable && f.writable.typeName === 'Collection') o[f.path] = W.coll([]);
  return o;
}
function graph(facts) {
  const persister = sfg.JSPersister.create(JSON.stringify(facts));
  const g = sfg.GraphFactory.apply(dictionary(), persister);
  const issues = g.checkPersister();
  if (issues.length) console.error('PERSISTER ISSUES', issues.map(i => i.message + ' ' + i.path));
  return g;
}
function get(g, p) {
  const r = g.get(p);
  return r.complete ? r.get.toString() : (r.hasValue ? '(incomplete:' + r.get.toString() + ')' : '(incomplete)');
}
module.exports = { sfg, W, graph, get, emptyCollections, setStubs };
