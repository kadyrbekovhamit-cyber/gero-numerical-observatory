# Convert Direct File XML fact modules into the WrappedFact digest JSON that
# InterceptingFactGraph feeds to the Scala.js fact graph (document order kept).
import json, os, sys, xml.etree.ElementTree as ET
SRC = sys.argv[1]; OUT = sys.argv[2]

def opts(e):
    o = {k: v.strip() for k, v in e.attrib.items()}
    t = (e.text or '').strip()
    if len(e) == 0:
        o['value'] = t if not e.attrib else t
        if e.attrib and not t: del o['value']
    elif t:
        o['value'] = t
    return o

def derived(e):
    if len(e) == 0 and not e.attrib:
        return {'typeName': e.tag, 'options': {'value': (e.text or '').strip()}, 'children': []}
    return {'typeName': e.tag, 'options': opts(e), 'children': [derived(c) for c in e]}

def writable(w):
    kids = list(w)
    first = [k for k in kids if k.tag != 'Limit'][0]
    tn = first.tag
    o = {k: v.strip() for k, v in first.attrib.items()}
    alias = None
    if tn == 'CollectionItem':
        alias = o.get('collection'); o = {}
    limits = []
    for l in [k for k in kids if k.tag == 'Limit']:
        inner = list(l)[0]
        if inner.tag == 'Dependency':
            node = {'typeName': 'Dependency', 'options': {'path': inner.attrib['path']}, 'children': []}
        else:
            node = {'typeName': inner.tag, 'options': {'value': (inner.text or '').strip()}, 'children': []}
        limits.append({'operation': l.attrib['type'], 'level': 'Error', 'node': node})
    return {'typeName': tn, 'options': o, 'collectionItemAlias': alias, 'limits': limits}

facts = []
for f in sorted(os.listdir(SRC)):
    if not f.endswith('.xml'): continue
    root = ET.parse(os.path.join(SRC, f)).getroot()
    for fact in root.iter('Fact'):
        w = fact.find('Writable'); d = fact.find('Derived'); p = fact.find('Placeholder')
        facts.append({'path': fact.attrib['path'],
                      'writable': writable(w) if w is not None else None,
                      'derived': derived(list(d)[0]) if d is not None else None,
                      'placeholder': derived(list(p)[0]) if p is not None else None})
json.dump(facts, open(OUT, 'w'))
print(len(facts), 'facts')
