import importlib.util,sys,json,dataclasses,warnings,math
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).resolve().parent
def load(name):
 f=P/'source/penaltyblog/betting'/f'{name}.py';spec=importlib.util.spec_from_file_location('audit_'+name,f);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod);return mod
arb=load('arbitrage');k=load('kelly');lp=arb.linprog
def one(*a,**kw):
 kw['options']={**kw.get('options',{}),'threads':1}
 with warnings.catch_warnings():
  warnings.filterwarnings('ignore',message='Unrecognized options detected.*');return lp(*a,**kw)
arb.linprog=one
r=arb.arbitrage_hedge([50,0,0],[3.5,3.4,2.9],[2.8,3.8,3.1])
h=[F(0),F(40),F(50)];paid=F(50)+sum(h)
cash=[F(50)*F('3.5')-paid,h[1]*F('3.8')-paid,h[2]*F('3.1')-paid]
ruin=k.kelly_criterion(2.,.8,fraction=2.)
cap=k.multiple_kelly_criterion([2.],[.9]);control=k.multiple_kelly_criterion([2.],[.9],method='independent')
print(json.dumps({'scope':'Unmodified imported modules; unrelated package init bypassed; SciPy numerical threads one; synthetic examples only.', 'lp':{'actual':dataclasses.asdict(r),'counterexample_stakes':[0,40,50],'independent_payoffs':list(map(str,cash))},'ruin':{'actual':dataclasses.asdict(ruin),'expected_log_growth':'-Infinity for positive probability of ruin'},'cap':{'actual':dataclasses.asdict(cap),'independent_mode':dataclasses.asdict(control),'exact_single_bet_kelly':0.8,'classification':'Undocumented constraint; could be intentional risk policy, not claimed mathematical error.'}},indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
